'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var CameraOffFill16 = function CameraOffFill16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M2.0299 0.969666L14.079 13.0188L13.0183 14.0794L11.3832 12.4444C11.024 12.7885 10.5366 13 9.9998 13H3.9998C2.34295 13 0.999802 11.6569 0.999802 10V5.00001C0.999802 4.20519 1.46345 3.51866 2.13503 3.19612L0.969238 2.03032L2.0299 0.969666ZM11.9998 8.93937V5.00001C11.9998 3.89544 11.1044 3.00001 9.9998 3.00001H6.06044L11.9998 8.93937ZM12.9998 7.88822C12.9998 6.99788 13.3953 6.15354 14.0792 5.58356L15.7697 4.17488C16.2582 3.7678 16.9998 4.11517 16.9998 4.75105V11.2632C16.9998 11.8991 16.2582 12.2465 15.7697 11.8394L14.0792 10.4307C13.3953 9.86072 12.9998 9.01638 12.9998 8.12604V7.88822Z',
    })
  );
};
CameraOffFill16.displayName = 'CameraOffFill16';
exports['default'] = CameraOffFill16;
