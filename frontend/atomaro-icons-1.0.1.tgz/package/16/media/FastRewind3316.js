'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var FastRewind3316 = function FastRewind3316(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M7.87626 3.11206L1.37845 7.26977C0.87385 7.59264 0.873849 8.40736 1.37845 8.73023L7.87625 12.8879C8.37698 13.2083 9 12.8035 9 12.1577L9 9.76781L13.8763 12.8879C14.377 13.2083 15 12.8035 15 12.1577L15 3.84229C15 3.19652 14.377 2.79166 13.8763 3.11206L9 6.2322L9 3.84229C9 3.19651 8.37698 2.79166 7.87626 3.11206Z',
    })
  );
};
FastRewind3316.displayName = 'FastRewind3316';
exports['default'] = FastRewind3316;
