'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var FastForward16 = function FastForward16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M7 9.76781V12.1577C7 12.8035 7.62302 13.2083 8.12374 12.8879L14.6216 8.73023C15.1262 8.40736 15.1261 7.59264 14.6216 7.26977L8.12374 3.11206C7.62302 2.79166 7 3.19652 7 3.84229V6.23219L2.12374 3.11206C1.62302 2.79166 1 3.19652 1 3.84229V12.1577C1 12.8035 1.62302 13.2083 2.12374 12.8879L7 9.76781Z',
    })
  );
};
FastForward16.displayName = 'FastForward16';
exports['default'] = FastForward16;
