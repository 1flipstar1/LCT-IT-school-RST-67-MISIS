'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var Camera16 = function Camera16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M2 3C0.89543 3 0 3.89543 0 5V10C0 11.6569 1.34315 13 3 13H9C10.1046 13 11 12.1046 11 11V5C11 3.89543 10.1046 3 9 3H2ZM1.5 5C1.5 4.72386 1.72386 4.5 2 4.5H9C9.27614 4.5 9.5 4.72386 9.5 5V11C9.5 11.2761 9.27614 11.5 9 11.5H3C2.17157 11.5 1.5 10.8284 1.5 10V5ZM14.0705 6.76622L14.5308 6.38265V9.69226L14.0705 9.3087C13.7285 9.02371 13.5308 8.60154 13.5308 8.15637V7.91855C13.5308 7.47338 13.7285 7.05121 14.0705 6.76622ZM12.0308 7.91855C12.0308 7.02821 12.4262 6.18387 13.1102 5.61388L14.8006 4.20521C15.2891 3.79813 16.0308 4.14549 16.0308 4.78137V11.2935C16.0308 11.9294 15.2891 12.2768 14.8006 11.8697L13.1102 10.461C12.4262 9.89105 12.0308 9.04671 12.0308 8.15637V7.91855Z',
    })
  );
};
Camera16.displayName = 'Camera16';
exports['default'] = Camera16;
