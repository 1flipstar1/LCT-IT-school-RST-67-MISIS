'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var CameraOff16 = function CameraOff16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M13.1097 13.0491L1.06066 1L0 2.06066L1.16579 3.22645C0.494207 3.54899 0.0305633 4.23552 0.0305633 5.03034V10.0303C0.0305633 11.6872 1.37371 13.0303 3.03056 13.0303H9.03056C9.56735 13.0303 10.0548 12.8189 10.414 12.4747L12.0491 14.1098L13.1097 13.0491ZM9.35235 11.413L2.46968 4.53034H2.34856H2.03056C1.75442 4.53034 1.53056 4.7542 1.53056 5.03034V10.0303C1.53056 10.8588 2.20214 11.5303 3.03056 11.5303H9.03056C9.12193 11.5303 9.20756 11.5058 9.28127 11.463C9.30644 11.4484 9.33021 11.4317 9.35235 11.413ZM11.0306 7.4697V8.9697L10.5912 8.53036L9.53056 7.4697V5.03034C9.53056 4.7542 9.30671 4.53034 9.03056 4.53034H6.59121L5.53055 3.46968L5.09121 3.03034H6.59121H7.21253H9.03056C10.1351 3.03034 11.0306 3.92577 11.0306 5.03034V6.84838V7.4697ZM14.0703 6.76622L14.5306 6.38266V9.69227L14.0703 9.30871C13.7283 9.02372 13.5306 8.60154 13.5306 8.15638V7.91856C13.5306 7.47339 13.7283 7.05122 14.0703 6.76622ZM12.0306 7.91856C12.0306 7.02822 12.426 6.18387 13.11 5.61389L14.8004 4.20521C15.2889 3.79813 16.0306 4.1455 16.0306 4.78138V11.2936C16.0306 11.9294 15.2889 12.2768 14.8004 11.8697L13.11 10.461C12.426 9.89106 12.0306 9.04671 12.0306 8.15638V7.91856Z',
    })
  );
};
CameraOff16.displayName = 'CameraOff16';
exports['default'] = CameraOff16;
