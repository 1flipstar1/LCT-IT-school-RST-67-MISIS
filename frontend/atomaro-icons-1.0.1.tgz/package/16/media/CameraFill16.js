'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var CameraFill16 = function CameraFill16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M2 3C0.895431 3 0 3.89543 0 5V10C0 11.6569 1.34315 13 3 13H9C10.1046 13 11 12.1046 11 11V5C11 3.89543 10.1046 3 9 3H2ZM13.0794 5.58355C12.3955 6.15353 12 6.99788 12 7.88821V8.12603C12 9.01637 12.3955 9.86071 13.0794 10.4307L14.7699 11.8394C15.2584 12.2465 16 11.8991 16 11.2632V4.75104C16 4.11516 15.2584 3.76779 14.7699 4.17487L13.0794 5.58355Z',
    })
  );
};
CameraFill16.displayName = 'CameraFill16';
exports['default'] = CameraFill16;
