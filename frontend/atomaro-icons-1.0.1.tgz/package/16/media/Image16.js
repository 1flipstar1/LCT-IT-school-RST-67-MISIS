'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var Image16 = function Image16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M2.5 4L2.5 8.73499L3.89823 7.58265C4.28295 7.26559 4.84245 7.28032 5.20995 7.6172L11.5832 13.4593L11.5459 13.5H12C12.8284 13.5 13.5 12.8284 13.5 12V4C13.5 3.17157 12.8284 2.5 12 2.5L4 2.5C3.17157 2.5 2.5 3.17157 2.5 4ZM2.5 12V10.6788L4.51678 9.01665L9.40771 13.5H4C3.17157 13.5 2.5 12.8284 2.5 12ZM1 12C1 13.6569 2.34315 15 4 15H12C13.6569 15 15 13.6569 15 12V4C15 2.34315 13.6569 1 12 1H4C2.34315 1 1 2.34315 1 4V12ZM11.7497 5.5C11.7497 6.19019 11.1902 6.74969 10.5 6.74969C9.80981 6.74969 9.25031 6.19019 9.25031 5.5C9.25031 4.80981 9.80981 4.25031 10.5 4.25031C11.1902 4.25031 11.7497 4.80981 11.7497 5.5Z',
    })
  );
};
Image16.displayName = 'Image16';
exports['default'] = Image16;
