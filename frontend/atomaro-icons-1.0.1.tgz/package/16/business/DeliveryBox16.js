'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var DeliveryBox16 = function DeliveryBox16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M2.50012 3.5V5H13.5001V3.5H2.50012ZM1.25012 2C1.11205 2 1.00012 2.11193 1.00012 2.25V6.25C1.00012 6.38807 1.11205 6.5 1.25012 6.5H2.00012V12C2.00012 13.1045 2.89555 14 4.00012 14H12.0001C13.1047 14 14.0001 13.1045 14.0001 12V6.5H14.7501C14.8882 6.5 15.0001 6.38807 15.0001 6.25V2.25C15.0001 2.11193 14.8882 2 14.7501 2H1.25012ZM3.50012 12V6.5H12.5001V12C12.5001 12.2761 12.2763 12.5 12.0001 12.5H4.00012C3.72398 12.5 3.50012 12.2761 3.50012 12ZM6.75012 7.5C6.33591 7.5 6.00012 7.83579 6.00012 8.25C6.00012 8.66421 6.33591 9 6.75012 9H9.25012C9.66434 9 10.0001 8.66421 10.0001 8.25C10.0001 7.83579 9.66434 7.5 9.25012 7.5H6.75012Z',
    })
  );
};
DeliveryBox16.displayName = 'DeliveryBox16';
exports['default'] = DeliveryBox16;
