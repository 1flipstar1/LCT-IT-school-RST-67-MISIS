"use strict";

var __importDefault = this && this.__importDefault || function (mod) {
  return mod && mod.__esModule ? mod : {
    "default": mod
  };
};
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Wallet16 = exports.StatisticsLine16 = exports.Ruble16 = exports.Reuse16 = exports.Promocode16 = exports.Portfolio16 = exports.Percentage16 = exports.DeliveryBox16 = void 0;
var DeliveryBox16_1 = require("./DeliveryBox16");
Object.defineProperty(exports, "DeliveryBox16", {
  enumerable: true,
  get: function get() {
    return __importDefault(DeliveryBox16_1)["default"];
  }
});
var Percentage16_1 = require("./Percentage16");
Object.defineProperty(exports, "Percentage16", {
  enumerable: true,
  get: function get() {
    return __importDefault(Percentage16_1)["default"];
  }
});
var Portfolio16_1 = require("./Portfolio16");
Object.defineProperty(exports, "Portfolio16", {
  enumerable: true,
  get: function get() {
    return __importDefault(Portfolio16_1)["default"];
  }
});
var Promocode16_1 = require("./Promocode16");
Object.defineProperty(exports, "Promocode16", {
  enumerable: true,
  get: function get() {
    return __importDefault(Promocode16_1)["default"];
  }
});
var Reuse16_1 = require("./Reuse16");
Object.defineProperty(exports, "Reuse16", {
  enumerable: true,
  get: function get() {
    return __importDefault(Reuse16_1)["default"];
  }
});
var Ruble16_1 = require("./Ruble16");
Object.defineProperty(exports, "Ruble16", {
  enumerable: true,
  get: function get() {
    return __importDefault(Ruble16_1)["default"];
  }
});
var StatisticsLine16_1 = require("./StatisticsLine16");
Object.defineProperty(exports, "StatisticsLine16", {
  enumerable: true,
  get: function get() {
    return __importDefault(StatisticsLine16_1)["default"];
  }
});
var Wallet16_1 = require("./Wallet16");
Object.defineProperty(exports, "Wallet16", {
  enumerable: true,
  get: function get() {
    return __importDefault(Wallet16_1)["default"];
  }
});