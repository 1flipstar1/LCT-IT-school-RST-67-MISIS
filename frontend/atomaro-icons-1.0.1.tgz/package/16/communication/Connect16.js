'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var Connect16 = function Connect16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M9 3.5C9 4.05228 8.55229 4.5 8 4.5C7.44771 4.5 7 4.05228 7 3.5C7 2.94771 7.44771 2.5 8 2.5C8.55229 2.5 9 2.94771 9 3.5ZM10.5 3.5C10.5 4.88071 9.38071 6 8 6C6.61929 6 5.5 4.88071 5.5 3.5C5.5 2.11929 6.61929 1 8 1C9.38071 1 10.5 2.11929 10.5 3.5ZM3.5 12.5C3.5 13.0523 3.05228 13.5 2.5 13.5C1.94772 13.5 1.5 13.0523 1.5 12.5C1.5 11.9477 1.94772 11.5 2.5 11.5C3.05228 11.5 3.5 11.9477 3.5 12.5ZM5 12.5C5 13.8807 3.88071 15 2.5 15C1.11929 15 0 13.8807 0 12.5C0 11.1193 1.11929 10 2.5 10C3.88071 10 5 11.1193 5 12.5ZM13.5 13.5C14.0523 13.5 14.5 13.0523 14.5 12.5C14.5 11.9477 14.0523 11.5 13.5 11.5C12.9477 11.5 12.5 11.9477 12.5 12.5C12.5 13.0523 12.9477 13.5 13.5 13.5ZM13.5 15C14.8807 15 16 13.8807 16 12.5C16 11.1193 14.8807 10 13.5 10C12.1193 10 11 11.1193 11 12.5C11 13.8807 12.1193 15 13.5 15ZM10.1594 6.25461C10.5571 5.9424 10.8856 5.54592 11.1178 5.09206C12.3817 5.9766 13.2526 7.38433 13.4162 9.00099C12.8865 9.01343 12.386 9.14355 11.9397 9.3662C11.8781 8.06382 11.1848 6.92678 10.1594 6.25461ZM10.0274 12.9397C10.0927 13.4613 10.2729 13.9472 10.5418 14.3714C9.783 14.7727 8.91797 14.9999 7.99986 14.9999C7.08178 14.9999 6.21677 14.7727 5.45802 14.3714C5.72689 13.9472 5.90706 13.4613 5.97244 12.9397C6.56491 13.2954 7.2585 13.4999 7.99986 13.4999C8.74125 13.4999 9.43487 13.2954 10.0274 12.9397ZM4.06006 9.36616C4.12167 8.06373 4.81498 6.92666 5.84043 6.25451C5.44274 5.94228 5.11435 5.54578 4.88215 5.09192C3.61808 5.97645 2.7471 7.38424 2.5835 9.00098C3.11317 9.01341 3.61374 9.14352 4.06006 9.36616Z',
    })
  );
};
Connect16.displayName = 'Connect16';
exports['default'] = Connect16;
