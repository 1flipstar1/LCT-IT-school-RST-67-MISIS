'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var Comments16 = function Comments16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M10.2002 11.5009C10.4587 11.5009 10.7127 11.5676 10.9377 11.6947L13.5 13.1414V10.0167V10.0089H13.5L13.5 10.0009V4.50085C13.5 3.94857 13.0523 3.50085 12.5 3.50085H3.5C2.94772 3.50085 2.5 3.94857 2.5 4.50085V10.0009C2.5 10.8293 3.17157 11.5009 4 11.5009H10.2002ZM1 4.50085C1 3.12014 2.11929 2.00085 3.5 2.00085H12.5C13.8807 2.00085 15 3.12014 15 4.50085V10.0009L15 10.0167V13.9979C15 14.7634 14.1749 15.2451 13.5083 14.8687L10.2002 13.0009H4C2.34315 13.0009 1 11.6577 1 10.0009V4.50085ZM11 5.24998H5V6.74998H11V5.24998ZM5 8.24998H11V9.74998H5V8.24998Z',
    })
  );
};
Comments16.displayName = 'Comments16';
exports['default'] = Comments16;
