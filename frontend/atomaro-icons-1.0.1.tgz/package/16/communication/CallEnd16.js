'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var CallEnd16 = function CallEnd16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M15.7205 9.77594C15.7409 9.75952 15.7605 9.74189 15.7794 9.72304C16.0728 9.43064 16.0728 8.95657 15.7794 8.66418L15.0026 7.88996C11.1338 4.03423 4.86026 4.03552 0.991645 7.89102L0.214671 8.66536C-0.0787185 8.95776 -0.0787185 9.43183 0.214671 9.72422C0.23017 9.73967 0.246178 9.7543 0.26264 9.76811L1.99665 11.3057C2.21982 11.5036 2.53944 11.5509 2.81069 11.4262L5.23471 10.3118C5.47664 10.2006 5.64137 9.97004 5.66765 9.7058L5.96213 6.74437C7.29676 6.41373 8.69689 6.41351 10.0315 6.74375L10.3249 9.70576C10.3509 9.96885 10.5143 10.1988 10.7546 10.3106L13.1502 11.4255C13.4201 11.5512 13.7391 11.506 13.9631 11.3103L15.7205 9.77594ZM11.5965 7.30017L11.7781 9.13426L13.3418 9.862L14.1491 9.1571L13.9401 8.94882C13.2388 8.24988 12.4443 7.70033 11.5965 7.30017ZM2.0541 8.94988C2.75518 8.25118 3.54935 7.70168 4.39684 7.30142L4.21484 9.1316L2.62796 9.8611L1.84045 9.16281L2.0541 8.94988Z',
    })
  );
};
CallEnd16.displayName = 'CallEnd16';
exports['default'] = CallEnd16;
