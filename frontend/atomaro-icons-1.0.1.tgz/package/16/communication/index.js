"use strict";

var __importDefault = this && this.__importDefault || function (mod) {
  return mod && mod.__esModule ? mod : {
    "default": mod
  };
};
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Users16 = exports.User16 = exports.Task16 = exports.Share16 = exports.Reply16 = exports.ReplyFill16 = exports.ParentIssue16 = exports.ParentIssueDouble16 = exports.OperatorSupport16 = exports.Mail16 = exports.Lego16 = exports.History16 = exports.Forward16 = exports.ForwardFill16 = exports.Connect16 = exports.Comments16 = exports.Call16 = exports.CallOutgoing16 = exports.CallEnd16 = exports.Calendar16 = exports.At16 = void 0;
var At16_1 = require("./At16");
Object.defineProperty(exports, "At16", {
  enumerable: true,
  get: function get() {
    return __importDefault(At16_1)["default"];
  }
});
var Calendar16_1 = require("./Calendar16");
Object.defineProperty(exports, "Calendar16", {
  enumerable: true,
  get: function get() {
    return __importDefault(Calendar16_1)["default"];
  }
});
var CallEnd16_1 = require("./CallEnd16");
Object.defineProperty(exports, "CallEnd16", {
  enumerable: true,
  get: function get() {
    return __importDefault(CallEnd16_1)["default"];
  }
});
var CallOutgoing16_1 = require("./CallOutgoing16");
Object.defineProperty(exports, "CallOutgoing16", {
  enumerable: true,
  get: function get() {
    return __importDefault(CallOutgoing16_1)["default"];
  }
});
var Call16_1 = require("./Call16");
Object.defineProperty(exports, "Call16", {
  enumerable: true,
  get: function get() {
    return __importDefault(Call16_1)["default"];
  }
});
var Comments16_1 = require("./Comments16");
Object.defineProperty(exports, "Comments16", {
  enumerable: true,
  get: function get() {
    return __importDefault(Comments16_1)["default"];
  }
});
var Connect16_1 = require("./Connect16");
Object.defineProperty(exports, "Connect16", {
  enumerable: true,
  get: function get() {
    return __importDefault(Connect16_1)["default"];
  }
});
var ForwardFill16_1 = require("./ForwardFill16");
Object.defineProperty(exports, "ForwardFill16", {
  enumerable: true,
  get: function get() {
    return __importDefault(ForwardFill16_1)["default"];
  }
});
var Forward16_1 = require("./Forward16");
Object.defineProperty(exports, "Forward16", {
  enumerable: true,
  get: function get() {
    return __importDefault(Forward16_1)["default"];
  }
});
var History16_1 = require("./History16");
Object.defineProperty(exports, "History16", {
  enumerable: true,
  get: function get() {
    return __importDefault(History16_1)["default"];
  }
});
var Lego16_1 = require("./Lego16");
Object.defineProperty(exports, "Lego16", {
  enumerable: true,
  get: function get() {
    return __importDefault(Lego16_1)["default"];
  }
});
var Mail16_1 = require("./Mail16");
Object.defineProperty(exports, "Mail16", {
  enumerable: true,
  get: function get() {
    return __importDefault(Mail16_1)["default"];
  }
});
var OperatorSupport16_1 = require("./OperatorSupport16");
Object.defineProperty(exports, "OperatorSupport16", {
  enumerable: true,
  get: function get() {
    return __importDefault(OperatorSupport16_1)["default"];
  }
});
var ParentIssueDouble16_1 = require("./ParentIssueDouble16");
Object.defineProperty(exports, "ParentIssueDouble16", {
  enumerable: true,
  get: function get() {
    return __importDefault(ParentIssueDouble16_1)["default"];
  }
});
var ParentIssue16_1 = require("./ParentIssue16");
Object.defineProperty(exports, "ParentIssue16", {
  enumerable: true,
  get: function get() {
    return __importDefault(ParentIssue16_1)["default"];
  }
});
var ReplyFill16_1 = require("./ReplyFill16");
Object.defineProperty(exports, "ReplyFill16", {
  enumerable: true,
  get: function get() {
    return __importDefault(ReplyFill16_1)["default"];
  }
});
var Reply16_1 = require("./Reply16");
Object.defineProperty(exports, "Reply16", {
  enumerable: true,
  get: function get() {
    return __importDefault(Reply16_1)["default"];
  }
});
var Share16_1 = require("./Share16");
Object.defineProperty(exports, "Share16", {
  enumerable: true,
  get: function get() {
    return __importDefault(Share16_1)["default"];
  }
});
var Task16_1 = require("./Task16");
Object.defineProperty(exports, "Task16", {
  enumerable: true,
  get: function get() {
    return __importDefault(Task16_1)["default"];
  }
});
var User16_1 = require("./User16");
Object.defineProperty(exports, "User16", {
  enumerable: true,
  get: function get() {
    return __importDefault(User16_1)["default"];
  }
});
var Users16_1 = require("./Users16");
Object.defineProperty(exports, "Users16", {
  enumerable: true,
  get: function get() {
    return __importDefault(Users16_1)["default"];
  }
});