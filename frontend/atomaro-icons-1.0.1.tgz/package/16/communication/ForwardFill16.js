'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var ForwardFill16 = function ForwardFill16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M8.83818 2.11639C8.68922 1.99187 8.48164 1.96483 8.30576 2.04705C8.12988 2.12927 8.01749 2.30587 8.0175 2.50002L8.01756 4.97168C4.94659 5.28696 3.18414 6.98068 2.43425 9.00477C1.66508 11.0809 1.96987 13.4838 2.9383 14.9998L3.85647 14.7871C4.15861 12.1273 6.02118 10.3546 8.01746 10.098V12.4928C8.01746 12.6869 8.12978 12.8634 8.30558 12.9457C8.48137 13.0279 8.68888 13.001 8.83788 12.8767L14.8192 7.88376C14.9329 7.7888 14.9987 7.64827 14.9987 7.50009C14.9988 7.3519 14.9331 7.21133 14.8194 7.11629L8.83818 2.11639Z',
    })
  );
};
ForwardFill16.displayName = 'ForwardFill16';
exports['default'] = ForwardFill16;
