'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var History16 = function History16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M9.89024 2.83302C8.62409 2.36967 7.23185 2.38738 5.9779 2.8828C5.09688 3.23087 4.39163 3.70079 3.69012 4.50483L4.99996 4.50492L4.99985 6.00492L1.7624 6.00469C1.34821 6.00466 1.01246 5.66888 1.01246 5.25469L1.01246 1.99965L2.51245 1.99965L2.51245 3.5738C3.36488 2.5811 4.27094 1.94436 5.42673 1.48773C7.02257 0.857242 8.79438 0.834699 10.4057 1.42438C12.0171 2.01406 13.3558 3.17491 14.1677 4.68652C14.9795 6.19812 15.208 7.95522 14.8097 9.62416C14.4114 11.2931 13.414 12.7577 12.007 13.7398C10.6 14.7219 8.88134 15.1531 7.17733 14.9516C5.47333 14.7502 3.90263 13.93 2.7635 12.6468C1.62436 11.3637 0.996111 9.70689 0.998051 7.99108L2.49805 7.99278C2.49653 9.34095 2.99016 10.6427 3.88524 11.651C4.78031 12.6592 6.0145 13.3037 7.35346 13.462C8.69242 13.6203 10.0429 13.2815 11.1485 12.5098C12.254 11.7381 13.0377 10.5873 13.3507 9.27595C13.6636 7.9646 13.4841 6.58399 12.8462 5.39626C12.2083 4.20852 11.1564 3.29637 9.89024 2.83302ZM7.24941 7.5012V4.49999H8.74941V7.5012C8.74941 7.8354 8.88323 8.15568 9.121 8.39053L10.216 9.4721L9.16194 10.5393L8.06692 9.45773C7.54382 8.94106 7.24941 8.23644 7.24941 7.5012Z',
    })
  );
};
History16.displayName = 'History16';
exports['default'] = History16;
