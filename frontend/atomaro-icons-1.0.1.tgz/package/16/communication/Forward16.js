'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var Forward16 = function Forward16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M8.42825 2.06658C8.69663 1.94514 9.01126 1.99207 9.23253 2.18654L14.7441 7.03045C14.908 7.17445 15.001 7.38266 14.999 7.60079C14.9969 7.81891 14.9 8.02535 14.7335 8.16628L9.22192 12.8312C8.999 13.0198 8.68682 13.062 8.42187 12.9391C8.15692 12.8162 7.98739 12.5507 7.98739 12.2587V10.3251C6.25132 10.7069 4.53448 12.3645 4.27281 14.6831L2.89431 15.0008C1.90478 13.4417 1.68327 10.9918 2.51332 8.89171C3.30811 6.88078 5.06663 5.18547 7.98748 4.80342L7.98742 2.74991C7.98741 2.45533 8.15986 2.18802 8.42825 2.06658ZM9.48747 4.40756L9.48749 5.48709C9.4875 5.8854 9.17617 6.21423 8.77846 6.23599C6.02896 6.38641 4.55518 7.8064 3.90831 9.44306C3.56133 10.321 3.4519 11.2609 3.52348 12.1177C4.61123 10.069 6.67725 8.74136 8.73739 8.74136C9.1516 8.74136 9.48739 9.07714 9.48739 9.49136V10.6413L13.1007 7.58311L9.48747 4.40756Z',
    })
  );
};
Forward16.displayName = 'Forward16';
exports['default'] = Forward16;
