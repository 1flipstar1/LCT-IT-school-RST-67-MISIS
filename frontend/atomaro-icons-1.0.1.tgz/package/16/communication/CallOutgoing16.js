'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var CallOutgoing16 = function CallOutgoing16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M12.2155 5.94755L13.4258 4.74962L10 4.74962V3.24962L13.4235 3.24962L12.2155 2.05396L13.2816 0.998779L15.7816 3.47314C16.076 3.76452 16.076 4.23694 15.7816 4.52832L13.2816 7.00272L12.2155 5.94755ZM1.75049 1.00034C1.76371 1.00034 1.77686 1.00068 1.78992 1.00136L4.4835 1.00136C4.79344 1.00136 5.07145 1.192 5.18312 1.48112L6.42628 4.69952C6.52363 4.95156 6.4779 5.23648 6.30655 5.44539L3.92534 8.34857C4.82705 9.88522 6.11183 11.1699 7.64852 12.0716L10.5518 9.69153C10.7606 9.52032 11.0454 9.47461 11.2973 9.57184L14.5155 10.8138C14.8047 10.9255 14.9954 11.2035 14.9954 11.5135V14.2049C14.9962 14.2186 14.9966 14.2324 14.9966 14.2463C14.9966 14.6605 14.6608 14.9963 14.2466 14.9963H12.9077C6.33161 14.9963 1.00049 9.6653 1.00049 3.08919V1.75034C1.00049 1.33613 1.33627 1.00034 1.75049 1.00034ZM4.8695 4.83217L3.20518 6.86131C2.75015 5.69177 2.50049 4.41964 2.50049 3.08919V2.50136H3.9692L4.8695 4.83217ZM9.13603 12.7918C10.3054 13.2467 11.5774 13.4963 12.9077 13.4963H13.4954V12.028L11.1649 11.1286L9.13603 12.7918Z',
    })
  );
};
CallOutgoing16.displayName = 'CallOutgoing16';
exports['default'] = CallOutgoing16;
