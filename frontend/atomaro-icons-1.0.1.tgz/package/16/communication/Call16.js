'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var Call16 = function Call16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M2.78152 1.99882C2.7701 1.99831 2.75862 1.99805 2.74707 1.99805C2.33286 1.99805 1.99707 2.33383 1.99707 2.74805V3.87348C1.99707 9.4675 6.53349 14.0021 12.1272 14.0021H13.2528C13.667 14.0021 14.0028 13.6663 14.0028 13.2521C14.0028 13.2419 14.0026 13.2317 14.0022 13.2216V10.955C14.0022 10.645 13.8115 10.3669 13.5222 10.2553L10.8166 9.21129C10.5647 9.11408 10.28 9.15979 10.0712 9.33095L7.69508 11.2786C6.47598 10.5475 5.45227 9.52408 4.72102 8.30522L6.6696 5.92987C6.84098 5.72095 6.88673 5.43599 6.78935 5.18392L5.7442 2.47855C5.63251 2.18945 5.35451 1.99882 5.04459 1.99882L2.78152 1.99882ZM4.0091 6.808L5.23256 5.31659L4.53031 3.49882H3.49707V3.87348C3.49707 4.9038 3.67773 5.89195 4.0091 6.808ZM12.1272 12.5021C11.097 12.5021 10.1089 12.3215 9.19287 11.9904L10.6842 10.768L12.5022 11.4695V12.5021H12.1272Z',
    })
  );
};
Call16.displayName = 'Call16';
exports['default'] = Call16;
