'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var FolderFill16 = function FolderFill16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      d: 'M14 2L10.7426 2C9.94699 2 9.18393 2.31607 8.62132 2.87868L8 3.5L2 3.5C1.44772 3.5 1 3.94772 1 4.5L1 12C1 13.1046 1.89543 14 3 14L13 14C14.1046 14 15 13.1046 15 12L15 3C15 2.44772 14.5523 2 14 2Z',
    })
  );
};
FolderFill16.displayName = 'FolderFill16';
exports['default'] = FolderFill16;
