'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var FolderOpen16 = function FolderOpen16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M8.62131 5H7.99999L2.49999 5L2.49999 7L9.4724 7C10.3743 7 11.1646 7.60364 11.4019 8.47377L9.95478 8.86844C9.89545 8.65091 9.69787 8.5 9.4724 8.5L1.67115 8.5L2.57647 12.1213C2.63212 12.3438 2.83211 12.5 3.06154 12.5L10.9452 12.5L9.95478 8.86844L11.4019 8.47377L12.3995 12.1316C12.4587 12.3486 12.6556 12.4994 12.8805 12.5L12.8819 12.5H13C13.2761 12.5 13.5 12.2761 13.5 12L13.5 3.5L10.7426 3.5C10.3448 3.5 9.96327 3.65804 9.68197 3.93934L9.06065 4.56066L8.62131 5ZM11 14L3.06154 14C2.14381 14 1.34384 13.3754 1.12126 12.4851L0.0606235 8.24253C-0.0946644 7.62138 0.365235 7.01937 0.99999 7.00046L0.99999 4.5C0.99999 3.94772 1.44771 3.5 1.99999 3.5L7.99999 3.5L8.62131 2.87868C9.18392 2.31607 9.94698 2 10.7426 2L14 2C14.5523 2 15 2.44772 15 3L15 12C15 13.1046 14.1046 14 13 14H12.8819H11Z',
    })
  );
};
FolderOpen16.displayName = 'FolderOpen16';
exports['default'] = FolderOpen16;
