'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var DocumentText16 = function DocumentText16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M12 13.5H4C3.72386 13.5 3.5 13.2761 3.5 13V3C3.5 2.72386 3.72386 2.5 4 2.5H9.17157C9.30418 2.5 9.43136 2.55268 9.52513 2.64645L12.3536 5.47487C12.4473 5.56864 12.5 5.69582 12.5 5.82843V13C12.5 13.2761 12.2761 13.5 12 13.5ZM2 3C2 1.89543 2.89543 1 4 1H9.17157C9.70201 1 10.2107 1.21071 10.5858 1.58579L13.4142 4.41421C13.7893 4.78929 14 5.29799 14 5.82843V13C14 14.1046 13.1046 15 12 15H4C2.89543 15 2 14.1046 2 13V3ZM11 7.5H5V6H11V7.5ZM11 11H5V9.5H11V11Z',
    })
  );
};
DocumentText16.displayName = 'DocumentText16';
exports['default'] = DocumentText16;
