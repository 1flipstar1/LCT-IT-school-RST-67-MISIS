'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var Arhive16 = function Arhive16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M4 13.5H12C12.2761 13.5 12.5 13.2761 12.5 13V5.82843C12.5 5.69582 12.4473 5.56864 12.3536 5.47487L9.52513 2.64645C9.43136 2.55268 9.30418 2.5 9.17157 2.5H7.99524V3.75C7.99524 3.88807 8.10717 4 8.24524 4H9.25537C9.39344 4 9.50537 4.11193 9.50537 4.25V5.75C9.50537 5.88807 9.39344 6 9.25537 6H8.24524C8.10717 6 7.99524 6.11193 7.99524 6.25V7.75C7.99524 7.88807 8.10717 8 8.24524 8H9.25537C9.39344 8 9.50537 8.11193 9.50537 8.25V9.75C9.50537 9.88807 9.39344 10 9.25537 10H8.24524C8.10717 10 7.99524 10.1119 7.99524 10.25V11.75C7.99524 11.8881 7.88331 12 7.74524 12H6.24524C6.10717 12 5.99524 11.8881 5.99524 11.75V10.25C5.99524 10.1119 6.10717 10 6.24524 10H7.25537C7.39344 10 7.50537 9.88807 7.50537 9.75V8.25C7.50537 8.11193 7.39344 8 7.25537 8H6.24524C6.10717 8 5.99524 7.88807 5.99524 7.75V6.25C5.99524 6.11193 6.10717 6 6.24524 6H7.25537C7.39344 6 7.50537 5.88807 7.50537 5.75V4.25C7.50537 4.11193 7.39344 4 7.25537 4H6.24524C6.10717 4 5.99524 3.88807 5.99524 3.75V2.5H4C3.72386 2.5 3.5 2.72386 3.5 3V13C3.5 13.2761 3.72386 13.5 4 13.5ZM4 1C2.89543 1 2 1.89543 2 3V13C2 14.1046 2.89543 15 4 15H12C13.1046 15 14 14.1046 14 13V5.82843C14 5.29799 13.7893 4.78929 13.4142 4.41421L10.5858 1.58579C10.2107 1.21071 9.70201 1 9.17157 1H4Z',
    })
  );
};
Arhive16.displayName = 'Arhive16';
exports['default'] = Arhive16;
