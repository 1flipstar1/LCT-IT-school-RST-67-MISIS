'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var Folder16 = function Folder16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M8.62132 5L2.5 5L2.5 12C2.5 12.2761 2.72386 12.5 3 12.5L13 12.5C13.2761 12.5 13.5 12.2761 13.5 12L13.5 3.5H10.7426C10.3448 3.5 9.96328 3.65804 9.68198 3.93934L8.62132 5ZM8 3.5L8.62132 2.87868C8.69165 2.80835 8.7651 2.74188 8.84137 2.67939C9.3752 2.24199 10.0464 2 10.7426 2L14 2C14.5523 2 15 2.44772 15 3L15 12C15 13.1046 14.1046 14 13 14L3 14C1.89543 14 1 13.1046 1 12L1 4.5C1 3.94772 1.44772 3.5 2 3.5L8 3.5Z',
    })
  );
};
Folder16.displayName = 'Folder16';
exports['default'] = Folder16;
