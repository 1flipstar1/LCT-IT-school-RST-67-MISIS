"use strict";

var __importDefault = this && this.__importDefault || function (mod) {
  return mod && mod.__esModule ? mod : {
    "default": mod
  };
};
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Snippet16 = exports.Music16 = exports.Media16 = exports.Folder16 = exports.FolderOpen16 = exports.FolderOpenFill16 = exports.FolderFill16 = exports.DocumentText16 = exports.DocumentImage16 = exports.Arhive16 = void 0;
var Arhive16_1 = require("./Arhive16");
Object.defineProperty(exports, "Arhive16", {
  enumerable: true,
  get: function get() {
    return __importDefault(Arhive16_1)["default"];
  }
});
var DocumentImage16_1 = require("./DocumentImage16");
Object.defineProperty(exports, "DocumentImage16", {
  enumerable: true,
  get: function get() {
    return __importDefault(DocumentImage16_1)["default"];
  }
});
var DocumentText16_1 = require("./DocumentText16");
Object.defineProperty(exports, "DocumentText16", {
  enumerable: true,
  get: function get() {
    return __importDefault(DocumentText16_1)["default"];
  }
});
var FolderFill16_1 = require("./FolderFill16");
Object.defineProperty(exports, "FolderFill16", {
  enumerable: true,
  get: function get() {
    return __importDefault(FolderFill16_1)["default"];
  }
});
var FolderOpenFill16_1 = require("./FolderOpenFill16");
Object.defineProperty(exports, "FolderOpenFill16", {
  enumerable: true,
  get: function get() {
    return __importDefault(FolderOpenFill16_1)["default"];
  }
});
var FolderOpen16_1 = require("./FolderOpen16");
Object.defineProperty(exports, "FolderOpen16", {
  enumerable: true,
  get: function get() {
    return __importDefault(FolderOpen16_1)["default"];
  }
});
var Folder16_1 = require("./Folder16");
Object.defineProperty(exports, "Folder16", {
  enumerable: true,
  get: function get() {
    return __importDefault(Folder16_1)["default"];
  }
});
var Media16_1 = require("./Media16");
Object.defineProperty(exports, "Media16", {
  enumerable: true,
  get: function get() {
    return __importDefault(Media16_1)["default"];
  }
});
var Music16_1 = require("./Music16");
Object.defineProperty(exports, "Music16", {
  enumerable: true,
  get: function get() {
    return __importDefault(Music16_1)["default"];
  }
});
var Snippet16_1 = require("./Snippet16");
Object.defineProperty(exports, "Snippet16", {
  enumerable: true,
  get: function get() {
    return __importDefault(Snippet16_1)["default"];
  }
});