'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var FolderOpenFill16 = function FolderOpenFill16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M10.7458 2L14 2C14.5523 2 15 2.44772 15 3L15 12.75C15 13.4244 14.4659 13.9741 13.7976 13.9991C13.2231 13.9784 12.7211 13.5977 12.5484 13.0457L10.9388 7.90262C10.6776 7.06808 9.90453 6.49998 9.03007 6.49998L1.00706 6.49998L1.007 4.50003C1.00698 3.94773 1.4547 3.5 2.007 3.5L8.00347 3.5L8.62395 2.87921C9.1866 2.31628 9.94989 2 10.7458 2ZM3.005 14C2.11681 13.9991 1.33548 13.4126 1.08688 12.5597L0.107371 9.19945C-0.0674599 8.59969 0.382379 8 1.00711 8V7.99998L9.03007 7.99998C9.24869 7.99998 9.44195 8.14201 9.50725 8.35064L11.1168 13.4937C11.1725 13.6714 11.2443 13.8406 11.3304 14L3.00696 14C3.00631 14 3.00565 14 3.005 14Z',
    })
  );
};
FolderOpenFill16.displayName = 'FolderOpenFill16';
exports['default'] = FolderOpenFill16;
