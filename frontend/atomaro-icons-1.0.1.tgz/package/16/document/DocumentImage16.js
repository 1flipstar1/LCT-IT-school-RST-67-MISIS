'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var DocumentImage16 = function DocumentImage16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M3.5 13C3.5 13.2761 3.72386 13.5 4 13.5H12C12.2761 13.5 12.5 13.2761 12.5 13V12.8398L9.97914 10.679L8.46316 11.8693C8.18183 12.0902 7.78366 12.0817 7.51203 11.849L4.9836 9.68269L3.5 10.8696V13ZM10.4881 9.13967L12.5 10.8642V5.82843C12.5 5.69582 12.4473 5.56864 12.3536 5.47487L9.52513 2.64645C9.43136 2.55268 9.30418 2.5 9.17157 2.5H4C3.72386 2.5 3.5 2.72386 3.5 3V8.94864L4.53148 8.12346C4.81279 7.89841 5.21439 7.90517 5.48797 8.13957L8.02075 10.3096L9.53683 9.11921C9.81822 8.89828 10.2165 8.90685 10.4881 9.13967ZM4 1C2.89543 1 2 1.89543 2 3V13C2 14.1046 2.89543 15 4 15H12C13.1046 15 14 14.1046 14 13V5.82843C14 5.29799 13.7893 4.78929 13.4142 4.41421L10.5858 1.58579C10.2107 1.21071 9.70201 1 9.17157 1H4ZM9.5 7.75C10.1904 7.75 10.75 7.19036 10.75 6.5C10.75 5.80964 10.1904 5.25 9.5 5.25C8.80964 5.25 8.25 5.80964 8.25 6.5C8.25 7.19036 8.80964 7.75 9.5 7.75Z',
    })
  );
};
DocumentImage16.displayName = 'DocumentImage16';
exports['default'] = DocumentImage16;
