'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var Blueto16 = function Blueto16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M7.41756 1.08132C7.66839 0.95312 7.9699 0.976282 8.19821 1.14129L12.6907 4.38821C12.8888 4.53139 13.0047 4.76213 13.0013 5.00655C12.9979 5.25096 12.8756 5.47837 12.6736 5.61596L9.17429 7.99907L12.6733 10.3799C12.8754 10.5174 12.9978 10.7447 13.0013 10.9891C13.0049 11.2335 12.8891 11.4642 12.6911 11.6075L8.19862 14.8591C7.97035 15.0243 7.66874 15.0476 7.41778 14.9195C7.16683 14.7913 7.00888 14.5333 7.00888 14.2515V9.47378L3.85189 11.6238L3.00756 10.384L6.50867 7.99962L3 5.61223L3.84383 4.37209L7.00888 6.52567V1.74915C7.00888 1.46746 7.16673 1.20952 7.41756 1.08132ZM8.50888 9.36062L10.946 11.0189L8.50888 12.7829V9.36062ZM8.50888 6.63742V3.21658L10.9458 4.97782L8.50888 6.63742Z',
    })
  );
};
Blueto16.displayName = 'Blueto16';
exports['default'] = Blueto16;
