'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var Desktop16 = function Desktop16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M12.9998 3.5H2.99976C2.72361 3.5 2.49976 3.72386 2.49976 4V10C2.49976 10.2761 2.72361 10.5 2.99976 10.5H12.9998C13.2759 10.5 13.4998 10.2761 13.4998 10V4C13.4998 3.72386 13.2759 3.5 12.9998 3.5ZM2.99976 2C1.89519 2 0.999756 2.89543 0.999756 4V10C0.999756 11.1046 1.89519 12 2.99976 12H7.24989L7.24989 13.4991H5.00012V14.9991H11.0001V13.4991H8.74989L8.74989 12H12.9998C14.1043 12 14.9998 11.1046 14.9998 10V4C14.9998 2.89543 14.1043 2 12.9998 2H2.99976Z',
    })
  );
};
Desktop16.displayName = 'Desktop16';
exports['default'] = Desktop16;
