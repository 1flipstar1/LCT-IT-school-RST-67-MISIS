'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var FloppyDisk16 = function FloppyDisk16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M12 12.5C12.2761 12.5 12.5 12.2761 12.5 12V5.82843C12.5 5.69582 12.4473 5.56864 12.3536 5.47487L10.5251 3.64645C10.4314 3.55268 10.3042 3.5 10.1716 3.5H10V4.5C10 5.60457 9.10457 6.5 8 6.5H6.5C5.39543 6.5 4.5 5.60457 4.5 4.5V3.5H4C3.72386 3.5 3.5 3.72386 3.5 4V12C3.5 12.2761 3.72386 12.5 4 12.5H4.5V10.5C4.5 9.39543 5.39543 8.5 6.5 8.5H9.5C10.6046 8.5 11.5 9.39543 11.5 10.5V12.5H12ZM11.5 14H10H6H4.5H4C2.89543 14 2 13.1046 2 12V4C2 2.89543 2.89543 2 4 2H4.5H6H8.5H10H10.1716C10.702 2 11.2107 2.21071 11.5858 2.58579L13.4142 4.41421C13.7893 4.78929 14 5.29799 14 5.82843V12C14 13.1046 13.1046 14 12 14H11.5ZM10 12.5V10.5C10 10.2239 9.77614 10 9.5 10H6.5C6.22386 10 6 10.2239 6 10.5V12.5H10ZM6 3.5H8.5V4.5C8.5 4.77614 8.27614 5 8 5H6.5C6.22386 5 6 4.77614 6 4.5V3.5Z',
    })
  );
};
FloppyDisk16.displayName = 'FloppyDisk16';
exports['default'] = FloppyDisk16;
