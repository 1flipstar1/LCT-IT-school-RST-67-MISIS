'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var Internet16 = function Internet16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M10.4991 12.9007C12.0685 12.0989 13.2018 10.5653 13.4493 8.75H11.4801C11.3944 10.3593 11.036 11.8057 10.4991 12.9007ZM8 15C11.866 15 15 11.866 15 8C15 4.13401 11.866 1 8 1C4.13401 1 1 4.13401 1 8C1 11.866 4.13401 15 8 15ZM5.50085 3.09927C3.93154 3.90115 2.79823 5.43466 2.55071 7.25H4.51985C4.60556 5.64067 4.96396 4.1943 5.50085 3.09927ZM6.02221 7.25C6.10765 5.81912 6.4322 4.59021 6.86677 3.72107C7.42041 2.61378 7.90774 2.5 8 2.5C8.09226 2.5 8.57959 2.61378 9.13323 3.72107C9.5678 4.59021 9.89235 5.81912 9.97779 7.25H6.02221ZM6.02221 8.75C6.10765 10.1809 6.4322 11.4098 6.86677 12.2789C7.42041 13.3862 7.90774 13.5 8 13.5C8.09226 13.5 8.57959 13.3862 9.13323 12.2789C9.5678 11.4098 9.89235 10.1809 9.97779 8.75H6.02221ZM4.51985 8.75C4.60556 10.3593 4.96396 11.8057 5.50085 12.9007C3.93154 12.0989 2.79823 10.5653 2.55071 8.75H4.51985ZM11.4801 7.25C11.3944 5.64067 11.036 4.1943 10.4991 3.09927C12.0685 3.90115 13.2018 5.43466 13.4493 7.25H11.4801Z',
    })
  );
};
Internet16.displayName = 'Internet16';
exports['default'] = Internet16;
