'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var AllDevices16 = function AllDevices16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M12.5 3V5H10C8.89543 5 8 5.89543 8 7V10.5H3C2.72386 10.5 2.5 10.2761 2.5 10L2.5 3C2.5 2.72386 2.72386 2.5 3 2.5L12 2.5C12.2761 2.5 12.5 2.72386 12.5 3ZM14 3V5.26757C14.5978 5.61337 15 6.25972 15 7V13C15 14.1046 14.1046 15 13 15H10C8.89543 15 8 14.1046 8 13V12L3 12C1.89543 12 1 11.1046 1 10V3C1 1.89543 1.89543 1 3 1H12C13.1046 1 14 1.89543 14 3ZM5.5 7.50029V5.5H4V7.50029H5.5ZM13 6.5H10C9.72386 6.5 9.5 6.72386 9.5 7V13C9.5 13.2761 9.72386 13.5 10 13.5H13C13.2761 13.5 13.5 13.2761 13.5 13V7C13.5 6.72386 13.2761 6.5 13 6.5ZM12.25 10.5H10.75V12H12.25V10.5Z',
    })
  );
};
AllDevices16.displayName = 'AllDevices16';
exports['default'] = AllDevices16;
