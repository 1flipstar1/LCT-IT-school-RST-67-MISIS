'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var ArrowRightLeft16 = function ArrowRightLeft16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M10.1437 6.97614L11.3912 5.76029L3.00084 5.76029V4.26029L11.3892 4.26029L10.1437 3.04643L11.2179 1.99951L13.7711 4.4878C14.0677 4.7769 14.0677 5.24562 13.7711 5.53472L11.218 8.02305L10.1437 6.97614ZM5.85622 12.948L4.60869 11.7322L12.9991 11.7322V10.2322L4.61071 10.2322L5.85621 9.01834L4.78199 7.97142L2.22883 10.4597C1.93219 10.7488 1.93219 11.2175 2.22882 11.5066L4.78199 13.995L5.85622 12.948Z',
    })
  );
};
ArrowRightLeft16.displayName = 'ArrowRightLeft16';
exports['default'] = ArrowRightLeft16;
