'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var ArrowForwardRight16 = function ArrowForwardRight16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M9.78033 1.50098L13.7803 5.50098C14.0732 5.79387 14.0732 6.26874 13.7803 6.56164L9.78033 10.5616L8.71967 9.50098L11.4706 6.75006H5.75C4.50736 6.75006 3.5 7.75742 3.5 9.00006V14.0001H2V9.00006C2 6.92899 3.67893 5.25006 5.75 5.25006H11.4081L8.71967 2.56164L9.78033 1.50098Z',
    })
  );
};
ArrowForwardRight16.displayName = 'ArrowForwardRight16';
exports['default'] = ArrowForwardRight16;
