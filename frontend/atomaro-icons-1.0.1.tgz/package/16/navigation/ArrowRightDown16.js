'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var ArrowRightDown16 = function ArrowRightDown16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M11.5009 10.4431L4.05851 3L2.9978 4.06061L10.4404 11.5038L6.02037 11.5038L6.02037 13.0038L12.0009 13.0038C12.5532 13.0038 13.0009 12.5561 13.0009 12.0038L13.0009 6.02274L11.5009 6.02274L11.5009 10.4431Z',
    })
  );
};
ArrowRightDown16.displayName = 'ArrowRightDown16';
exports['default'] = ArrowRightDown16;
