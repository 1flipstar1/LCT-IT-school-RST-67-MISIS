'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var Geolocation16 = function Geolocation16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M9.59493 13.6535L9.73872 13.2944L9.7412 13.2882L9.88459 12.9301L9.91884 12.8446L13.6646 3.48935L13.6703 3.47524L13.7479 3.28137L13.7485 3.27974L13.9609 2.74932C14.0006 2.65004 14.0103 2.54128 13.9889 2.43652C13.9674 2.33177 13.9157 2.23562 13.8402 2.16001C13.7646 2.08439 13.6686 2.03263 13.5639 2.01114C13.4593 1.98966 13.3506 1.99938 13.2514 2.03912L12.7188 2.25198L12.718 2.25231L12.525 2.32943L12.511 2.33501L3.15298 6.07478L3.0692 6.10826L2.71224 6.25091L2.70851 6.2524L2.3461 6.39723C2.2386 6.43953 2.14728 6.51487 2.08528 6.61242C2.02329 6.70998 1.99381 6.82471 2.00109 6.9401C2.00837 7.05549 2.05203 7.1656 2.1258 7.25457C2.19957 7.34353 2.29963 7.40678 2.41159 7.4352L2.79209 7.53072L2.79986 7.53267L3.17125 7.6259L3.25873 7.64786L7.33554 8.67125L8.34632 12.7366L8.36856 12.826L8.46148 13.1997L8.46389 13.2094L8.55801 13.588C8.58641 13.7001 8.64959 13.8002 8.73847 13.8741C8.82735 13.9479 8.93734 13.9916 9.05262 13.9989C9.16789 14.0062 9.2825 13.9767 9.37996 13.9146C9.47741 13.8526 9.55268 13.7612 9.59493 13.6535ZM9.29986 10.3551L11.7411 4.25806L5.63561 6.69798L7.70075 7.21639L8.57398 7.4356L8.79122 8.30932L9.29986 10.3551Z',
    })
  );
};
Geolocation16.displayName = 'Geolocation16';
exports['default'] = Geolocation16;
