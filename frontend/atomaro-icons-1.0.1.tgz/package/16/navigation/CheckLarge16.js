'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var CheckLarge16 = function CheckLarge16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M14.0304 5.03033L7.03039 12.0303C6.73749 12.3232 6.26262 12.3232 5.96973 12.0303L1.96973 8.03033L3.03039 6.96967L6.50006 10.4393L12.9697 3.96967L14.0304 5.03033Z',
    })
  );
};
CheckLarge16.displayName = 'CheckLarge16';
exports['default'] = CheckLarge16;
