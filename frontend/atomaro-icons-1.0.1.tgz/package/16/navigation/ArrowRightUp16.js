'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var ArrowRightUp16 = function ArrowRightUp16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M13.0036 9.98053L13.0036 4C13.0036 3.44772 12.5559 3 12.0036 3H6.02253L6.02253 4.5L10.443 4.5L3 11.9424L4.06061 13.0031L11.5036 5.56074L11.5036 9.98053H13.0036Z',
    })
  );
};
ArrowRightUp16.displayName = 'ArrowRightUp16';
exports['default'] = ArrowRightUp16;
