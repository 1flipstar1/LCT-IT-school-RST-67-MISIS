'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var ArrowUp16 = function ArrowUp16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M7.24964 4.81315L7.24964 14.0008L8.74964 14.0008L8.74964 4.81226L11.469 7.53473L12.5303 6.47467L8.53094 2.47077C8.39028 2.32994 8.19941 2.25081 8.00037 2.25079C7.80133 2.25078 7.61045 2.32988 7.46976 2.47068L3.4691 6.47458L4.53019 7.53482L7.24964 4.81315Z',
    })
  );
};
ArrowUp16.displayName = 'ArrowUp16';
exports['default'] = ArrowUp16;
