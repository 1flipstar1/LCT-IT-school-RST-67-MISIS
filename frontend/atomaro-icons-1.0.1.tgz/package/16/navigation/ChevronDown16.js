'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var ChevronDown16 = function ChevronDown16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M7.46882 10.534L3.46948 6.53005L4.53075 5.47L7.99954 8.94275L11.4696 5.46991L12.5307 6.53014L8.53 10.534C8.38931 10.6748 8.19843 10.7539 7.99939 10.7539C7.80035 10.7539 7.60948 10.6748 7.46882 10.534Z',
    })
  );
};
ChevronDown16.displayName = 'ChevronDown16';
exports['default'] = ChevronDown16;
