'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var ChevronSort16 = function ChevronSort16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M4.53047 6.53028L8.0001 3.06008L11.4697 6.53028L12.5305 5.46971L8.53047 1.46904C8.38982 1.32836 8.19903 1.24933 8.0001 1.24933C7.80117 1.24933 7.61038 1.32836 7.46973 1.46904L3.46973 5.46971L4.53047 6.53028ZM4.53082 9.469L8.00049 12.9387L11.4702 9.469L12.5308 10.5297L8.53082 14.5297C8.23793 14.8226 7.76305 14.8226 7.47016 14.5297L3.47016 10.5297L4.53082 9.469Z',
    })
  );
};
ChevronSort16.displayName = 'ChevronSort16';
exports['default'] = ChevronSort16;
