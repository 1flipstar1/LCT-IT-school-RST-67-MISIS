'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var ArrowLeftUp16 = function ArrowLeftUp16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M9.98077 2.99973L4.00024 2.99973C3.44796 2.99973 3.00024 3.44744 3.00024 3.99973L3.00024 9.98083L4.50024 9.98083L4.50024 5.56031L11.9426 13.0034L13.0033 11.9427L5.56098 4.49973L9.98077 4.49973V2.99973Z',
    })
  );
};
ArrowLeftUp16.displayName = 'ArrowLeftUp16';
exports['default'] = ArrowLeftUp16;
