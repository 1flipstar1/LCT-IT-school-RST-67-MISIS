'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var GeolocationFill16 = function GeolocationFill16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      d: 'M13.9609 2.74932L9.59493 13.6535C9.55268 13.7612 9.47741 13.8526 9.37996 13.9146C9.2825 13.9767 9.16789 14.0062 9.05262 13.9989C8.93734 13.9916 8.82735 13.9479 8.73847 13.8741C8.64959 13.8002 8.58641 13.7001 8.55801 13.588L7.33554 8.67125L2.41159 7.4352C2.29963 7.40678 2.19957 7.34353 2.1258 7.25457C2.05203 7.1656 2.00837 7.05549 2.00109 6.9401C1.99381 6.82471 2.02329 6.70998 2.08528 6.61242C2.14728 6.51487 2.2386 6.43953 2.3461 6.39723L13.2514 2.03912C13.3506 1.99938 13.4593 1.98966 13.5639 2.01114C13.6686 2.03263 13.7646 2.08439 13.8402 2.16001C13.9157 2.23562 13.9674 2.33177 13.9889 2.43652C14.0103 2.54128 14.0006 2.65004 13.9609 2.74932Z',
    })
  );
};
GeolocationFill16.displayName = 'GeolocationFill16';
exports['default'] = GeolocationFill16;
