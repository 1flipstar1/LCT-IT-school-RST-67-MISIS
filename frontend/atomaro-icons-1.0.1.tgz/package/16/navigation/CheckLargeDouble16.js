'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var CheckLargeDouble16 = function CheckLargeDouble16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M6.03039 12.0304L13.0304 5.03039L11.9697 3.96973L5.50006 10.4394L2.03039 6.96973L0.969727 8.03039L4.96973 12.0304C5.26262 12.3233 5.73749 12.3233 6.03039 12.0304ZM10.0304 12.0304L17.0304 5.03039L15.9697 3.96973L9.50006 10.4394L9.03039 9.96973L7.96973 11.0304L8.96973 12.0304C9.26262 12.3233 9.73749 12.3233 10.0304 12.0304Z',
    })
  );
};
CheckLargeDouble16.displayName = 'CheckLargeDouble16';
exports['default'] = CheckLargeDouble16;
