'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var Fold16 = function Fold16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M14.0019 5.49814H11.5628L15.0626 1.99849L14.002 0.937832L10.5022 4.43749V1.99841H9.00218V5.99814C9.00218 6.55042 9.44989 6.99814 10.0022 6.99814H14.0019V5.49814ZM2.00028 10.5002H4.43933L0.939453 14L2.00011 15.0606L5.5 11.5609V13.9999H7V10.0002C7 9.44793 6.55229 9.00022 6 9.00022H2.00028V10.5002Z',
    })
  );
};
Fold16.displayName = 'Fold16';
exports['default'] = Fold16;
