'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var ArrowLeft16 = function ArrowLeft16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M6.46967 3.46964L2.46967 7.46964C2.17678 7.76253 2.17678 8.2374 2.46967 8.53029L6.46967 12.5303L7.53033 11.4696L4.80909 8.74839L13.9999 8.7501L14.0001 7.2501L4.81223 7.24839L7.53033 4.5303L6.46967 3.46964Z',
    })
  );
};
ArrowLeft16.displayName = 'ArrowLeft16';
exports['default'] = ArrowLeft16;
