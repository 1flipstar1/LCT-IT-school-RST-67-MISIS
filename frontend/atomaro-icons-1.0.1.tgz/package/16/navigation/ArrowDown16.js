'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var ArrowDown16 = function ArrowDown16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M8.75 11.1922V2H7.25V11.1934L4.5305 8.47079L3.46924 9.53085L7.46857 13.5348C7.60924 13.6756 7.80011 13.7547 7.99914 13.7547C8.19818 13.7547 8.38907 13.6756 8.52975 13.5348L12.5304 9.53093L11.4693 8.4707L8.75 11.1922Z',
    })
  );
};
ArrowDown16.displayName = 'ArrowDown16';
exports['default'] = ArrowDown16;
