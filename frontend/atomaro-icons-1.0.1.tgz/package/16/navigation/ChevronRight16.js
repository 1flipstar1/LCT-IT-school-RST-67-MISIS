'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var ChevronRight16 = function ChevronRight16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      d: 'M8.93602 8.00047L5.46948 4.53054L6.53066 3.4704L10.5268 7.4704C10.8193 7.76323 10.8193 8.23771 10.5268 8.53054L6.53066 12.5305L5.46948 11.4704L8.93602 8.00047Z',
    })
  );
};
ChevronRight16.displayName = 'ChevronRight16';
exports['default'] = ChevronRight16;
