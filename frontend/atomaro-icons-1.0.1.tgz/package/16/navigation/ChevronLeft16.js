'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var ChevronLeft16 = function ChevronLeft16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M5.47022 7.46796L9.47412 3.46863L10.5342 4.52989L7.06142 7.99868L10.5343 11.4687L9.47403 12.5298L5.47013 8.52914C5.32933 8.38846 5.25023 8.19757 5.25024 7.99853C5.25026 7.79949 5.32939 7.60862 5.47022 7.46796Z',
    })
  );
};
ChevronLeft16.displayName = 'ChevronLeft16';
exports['default'] = ChevronLeft16;
