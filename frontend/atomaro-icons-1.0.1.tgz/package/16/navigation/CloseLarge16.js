'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var CloseLarge16 = function CloseLarge16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M9.0615 7.99995L13.0306 11.9691L11.97 13.0297L8.00072 9.06049L4.03057 13.0298L2.97003 11.969L6.94006 7.99983L2.96997 4.02972L4.03063 2.96906L8.00084 6.93928L11.97 2.97095L13.0306 4.03173L9.0615 7.99995Z',
    })
  );
};
CloseLarge16.displayName = 'CloseLarge16';
exports['default'] = CloseLarge16;
