'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var ArrowForwardLeft16 = function ArrowForwardLeft16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M6.21967 1.50098L2.21967 5.50098C1.92678 5.79387 1.92678 6.26874 2.21967 6.56164L6.21967 10.5616L7.28033 9.50098L4.52941 6.75006H10.25C11.4926 6.75006 12.5 7.75742 12.5 9.00006V14.0001H14V9.00006C14 6.92899 12.3211 5.25006 10.25 5.25006H4.59191L7.28033 2.56164L6.21967 1.50098Z',
    })
  );
};
ArrowForwardLeft16.displayName = 'ArrowForwardLeft16';
exports['default'] = ArrowForwardLeft16;
