'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var CloseSmall16 = function CloseSmall16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M7.99941 9.06106L5.52945 11.5308L4.47012 10.4688L6.93878 8.00036L4.47011 5.53152L5.52953 4.46962L7.99949 6.93975L10.4707 4.46882L11.53 5.53081L9.06012 8.00045L11.5296 10.4701L10.4702 11.532L7.99941 9.06106Z',
    })
  );
};
CloseSmall16.displayName = 'CloseSmall16';
exports['default'] = CloseSmall16;
