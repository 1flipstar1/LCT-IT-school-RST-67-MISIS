'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var ArrowRight16 = function ArrowRight16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M9.53033 12.5296L13.5303 8.52959C13.8232 8.2367 13.8232 7.76183 13.5303 7.46893L9.53033 3.46893L8.46967 4.52959L11.191 7.25097L2.00028 7.24926L2 8.74926L11.1876 8.75097L8.46967 11.4689L9.53033 12.5296Z',
    })
  );
};
ArrowRight16.displayName = 'ArrowRight16';
exports['default'] = ArrowRight16;
