'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var GitlabFill16 = function GitlabFill16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      d: 'M2.10204 7.2805L3.56296 2.83985C3.70964 2.39398 4.33435 2.37769 4.50408 2.8153L5.79746 6.15002H10.2047L11.4937 2.81651C11.663 2.37865 12.2879 2.39441 12.4349 2.84025L13.8988 7.2798C14.1765 8.12191 13.8666 9.04633 13.1374 9.55085L8.28557 12.9077C8.11441 13.0261 7.88777 13.0261 7.7166 12.9077L2.86393 9.55024C2.13515 9.04601 1.82509 8.12232 2.10204 7.2805Z',
    })
  );
};
GitlabFill16.displayName = 'GitlabFill16';
exports['default'] = GitlabFill16;
