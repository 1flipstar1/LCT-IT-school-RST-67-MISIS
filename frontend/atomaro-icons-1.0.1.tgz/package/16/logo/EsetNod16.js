'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var EsetNod16 = function EsetNod16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M8 13.5C5.47336 13.5 4.25093 13.0409 3.59717 12.3806C2.94003 11.7168 2.5 10.4905 2.5 7.99998C2.5 5.42852 2.94042 4.21717 3.58237 3.57683C4.22521 2.93561 5.43755 2.5 8 2.5C10.5471 2.5 11.7647 2.95184 12.4123 3.60432C13.0625 4.25941 13.5 5.47993 13.5 7.99998C13.5 10.5162 13.0585 11.738 12.4054 12.3943C11.7541 13.0489 10.5343 13.5 8 13.5ZM1 7.99998C1 2.70625 2.72813 1 8 1C13.2719 1 15 2.79371 15 7.99998C15 13.2063 13.25 15 8 15C2.75 15 1 13.1625 1 7.99998ZM9.16667 7.13768C9.16667 6.12319 8.74242 6.02174 7.89394 6.02174C6.93939 6.02174 6.72727 6.32609 6.72727 7.23913H9.16667V7.13768ZM8 11.5C5.13636 11.5 4.5 10.587 4.5 8.05072C4.5 5.41304 5.0303 4.5 7.89394 4.5C10.6515 4.5 11.3939 5.21015 11.3939 8.05072V8.35507H6.62121C6.62121 9.57246 6.83333 9.97826 7.89394 9.97826C8.63636 9.97826 9.16667 9.87681 9.16667 9.16667H11.5C11.5 10.1812 11.1818 10.7899 10.5455 11.0942C9.90909 11.3986 9.06061 11.5 8 11.5Z',
    })
  );
};
EsetNod16.displayName = 'EsetNod16';
exports['default'] = EsetNod16;
