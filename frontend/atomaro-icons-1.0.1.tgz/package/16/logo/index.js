"use strict";

var __importDefault = this && this.__importDefault || function (mod) {
  return mod && mod.__esModule ? mod : {
    "default": mod
  };
};
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.YoutubeFill16 = exports.Yandex16 = exports.YandexDisk16 = exports.Wink16 = exports.WinkFill16 = exports.WindowsFill16 = exports.WhatsApp16 = exports.VkontakteFill16 = exports.Viber16 = exports.TwitterFill16 = exports.TelegramFill16 = exports.TamTam16 = exports.Sber16 = exports.Rostelecom16 = exports.RostelecomSmartHome16 = exports.RostelecomSmartHomeFill16 = exports.RostelecomFill16 = exports.Onlime16 = exports.OnlimeFill16 = exports.OdnoklassnikiFill16 = exports.MicrosoftOffice16 = exports.Mailru16 = exports.Licey16 = exports.LiceyFill16 = exports.Kluch16 = exports.KluchFill16 = exports.Googleplus16 = exports.GooglePlayFill16 = exports.GitlabFill16 = exports.GithubFill16 = exports.FlickrFill16 = exports.EsetNod16 = exports.DrWeb16 = exports.AppleFill16 = exports.AndroidFill16 = void 0;
var AndroidFill16_1 = require("./AndroidFill16");
Object.defineProperty(exports, "AndroidFill16", {
  enumerable: true,
  get: function get() {
    return __importDefault(AndroidFill16_1)["default"];
  }
});
var AppleFill16_1 = require("./AppleFill16");
Object.defineProperty(exports, "AppleFill16", {
  enumerable: true,
  get: function get() {
    return __importDefault(AppleFill16_1)["default"];
  }
});
var DrWeb16_1 = require("./DrWeb16");
Object.defineProperty(exports, "DrWeb16", {
  enumerable: true,
  get: function get() {
    return __importDefault(DrWeb16_1)["default"];
  }
});
var EsetNod16_1 = require("./EsetNod16");
Object.defineProperty(exports, "EsetNod16", {
  enumerable: true,
  get: function get() {
    return __importDefault(EsetNod16_1)["default"];
  }
});
var FlickrFill16_1 = require("./FlickrFill16");
Object.defineProperty(exports, "FlickrFill16", {
  enumerable: true,
  get: function get() {
    return __importDefault(FlickrFill16_1)["default"];
  }
});
var GithubFill16_1 = require("./GithubFill16");
Object.defineProperty(exports, "GithubFill16", {
  enumerable: true,
  get: function get() {
    return __importDefault(GithubFill16_1)["default"];
  }
});
var GitlabFill16_1 = require("./GitlabFill16");
Object.defineProperty(exports, "GitlabFill16", {
  enumerable: true,
  get: function get() {
    return __importDefault(GitlabFill16_1)["default"];
  }
});
var GooglePlayFill16_1 = require("./GooglePlayFill16");
Object.defineProperty(exports, "GooglePlayFill16", {
  enumerable: true,
  get: function get() {
    return __importDefault(GooglePlayFill16_1)["default"];
  }
});
var Googleplus16_1 = require("./Googleplus16");
Object.defineProperty(exports, "Googleplus16", {
  enumerable: true,
  get: function get() {
    return __importDefault(Googleplus16_1)["default"];
  }
});
var KluchFill16_1 = require("./KluchFill16");
Object.defineProperty(exports, "KluchFill16", {
  enumerable: true,
  get: function get() {
    return __importDefault(KluchFill16_1)["default"];
  }
});
var Kluch16_1 = require("./Kluch16");
Object.defineProperty(exports, "Kluch16", {
  enumerable: true,
  get: function get() {
    return __importDefault(Kluch16_1)["default"];
  }
});
var LiceyFill16_1 = require("./LiceyFill16");
Object.defineProperty(exports, "LiceyFill16", {
  enumerable: true,
  get: function get() {
    return __importDefault(LiceyFill16_1)["default"];
  }
});
var Licey16_1 = require("./Licey16");
Object.defineProperty(exports, "Licey16", {
  enumerable: true,
  get: function get() {
    return __importDefault(Licey16_1)["default"];
  }
});
var Mailru16_1 = require("./Mailru16");
Object.defineProperty(exports, "Mailru16", {
  enumerable: true,
  get: function get() {
    return __importDefault(Mailru16_1)["default"];
  }
});
var MicrosoftOffice16_1 = require("./MicrosoftOffice16");
Object.defineProperty(exports, "MicrosoftOffice16", {
  enumerable: true,
  get: function get() {
    return __importDefault(MicrosoftOffice16_1)["default"];
  }
});
var OdnoklassnikiFill16_1 = require("./OdnoklassnikiFill16");
Object.defineProperty(exports, "OdnoklassnikiFill16", {
  enumerable: true,
  get: function get() {
    return __importDefault(OdnoklassnikiFill16_1)["default"];
  }
});
var OnlimeFill16_1 = require("./OnlimeFill16");
Object.defineProperty(exports, "OnlimeFill16", {
  enumerable: true,
  get: function get() {
    return __importDefault(OnlimeFill16_1)["default"];
  }
});
var Onlime16_1 = require("./Onlime16");
Object.defineProperty(exports, "Onlime16", {
  enumerable: true,
  get: function get() {
    return __importDefault(Onlime16_1)["default"];
  }
});
var RostelecomFill16_1 = require("./RostelecomFill16");
Object.defineProperty(exports, "RostelecomFill16", {
  enumerable: true,
  get: function get() {
    return __importDefault(RostelecomFill16_1)["default"];
  }
});
var RostelecomSmartHomeFill16_1 = require("./RostelecomSmartHomeFill16");
Object.defineProperty(exports, "RostelecomSmartHomeFill16", {
  enumerable: true,
  get: function get() {
    return __importDefault(RostelecomSmartHomeFill16_1)["default"];
  }
});
var RostelecomSmartHome16_1 = require("./RostelecomSmartHome16");
Object.defineProperty(exports, "RostelecomSmartHome16", {
  enumerable: true,
  get: function get() {
    return __importDefault(RostelecomSmartHome16_1)["default"];
  }
});
var Rostelecom16_1 = require("./Rostelecom16");
Object.defineProperty(exports, "Rostelecom16", {
  enumerable: true,
  get: function get() {
    return __importDefault(Rostelecom16_1)["default"];
  }
});
var Sber16_1 = require("./Sber16");
Object.defineProperty(exports, "Sber16", {
  enumerable: true,
  get: function get() {
    return __importDefault(Sber16_1)["default"];
  }
});
var TamTam16_1 = require("./TamTam16");
Object.defineProperty(exports, "TamTam16", {
  enumerable: true,
  get: function get() {
    return __importDefault(TamTam16_1)["default"];
  }
});
var TelegramFill16_1 = require("./TelegramFill16");
Object.defineProperty(exports, "TelegramFill16", {
  enumerable: true,
  get: function get() {
    return __importDefault(TelegramFill16_1)["default"];
  }
});
var TwitterFill16_1 = require("./TwitterFill16");
Object.defineProperty(exports, "TwitterFill16", {
  enumerable: true,
  get: function get() {
    return __importDefault(TwitterFill16_1)["default"];
  }
});
var Viber16_1 = require("./Viber16");
Object.defineProperty(exports, "Viber16", {
  enumerable: true,
  get: function get() {
    return __importDefault(Viber16_1)["default"];
  }
});
var VkontakteFill16_1 = require("./VkontakteFill16");
Object.defineProperty(exports, "VkontakteFill16", {
  enumerable: true,
  get: function get() {
    return __importDefault(VkontakteFill16_1)["default"];
  }
});
var WhatsApp16_1 = require("./WhatsApp16");
Object.defineProperty(exports, "WhatsApp16", {
  enumerable: true,
  get: function get() {
    return __importDefault(WhatsApp16_1)["default"];
  }
});
var WindowsFill16_1 = require("./WindowsFill16");
Object.defineProperty(exports, "WindowsFill16", {
  enumerable: true,
  get: function get() {
    return __importDefault(WindowsFill16_1)["default"];
  }
});
var WinkFill16_1 = require("./WinkFill16");
Object.defineProperty(exports, "WinkFill16", {
  enumerable: true,
  get: function get() {
    return __importDefault(WinkFill16_1)["default"];
  }
});
var Wink16_1 = require("./Wink16");
Object.defineProperty(exports, "Wink16", {
  enumerable: true,
  get: function get() {
    return __importDefault(Wink16_1)["default"];
  }
});
var YandexDisk16_1 = require("./YandexDisk16");
Object.defineProperty(exports, "YandexDisk16", {
  enumerable: true,
  get: function get() {
    return __importDefault(YandexDisk16_1)["default"];
  }
});
var Yandex16_1 = require("./Yandex16");
Object.defineProperty(exports, "Yandex16", {
  enumerable: true,
  get: function get() {
    return __importDefault(Yandex16_1)["default"];
  }
});
var YoutubeFill16_1 = require("./YoutubeFill16");
Object.defineProperty(exports, "YoutubeFill16", {
  enumerable: true,
  get: function get() {
    return __importDefault(YoutubeFill16_1)["default"];
  }
});