'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var GithubFill16 = function GithubFill16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M8 1C4.1325 1 1 4.09703 1 7.92073C1 10.9832 3.00375 13.5698 5.78625 14.4868C6.13625 14.5473 6.2675 14.3397 6.2675 14.158C6.2675 13.9937 6.25875 13.4487 6.25875 12.8691C4.5 13.1891 4.045 12.4452 3.905 12.0559C3.82625 11.8569 3.485 11.2427 3.1875 11.0783C2.9425 10.9486 2.5925 10.6285 3.17875 10.6198C3.73 10.6112 4.12375 11.1216 4.255 11.3292C4.885 12.376 5.89125 12.0818 6.29375 11.9002C6.355 11.4503 6.53875 11.1475 6.74 10.9745C5.1825 10.8015 3.555 10.2046 3.555 7.55739C3.555 6.80477 3.82625 6.1819 4.2725 5.69745C4.2025 5.52443 3.9575 4.81505 4.3425 3.86345C4.3425 3.86345 4.92875 3.68178 6.2675 4.57283C6.8275 4.41711 7.4225 4.33925 8.0175 4.33925C8.6125 4.33925 9.2075 4.41711 9.7675 4.57283C11.1062 3.67313 11.6925 3.86345 11.6925 3.86345C12.0775 4.81505 11.8325 5.52443 11.7625 5.69745C12.2087 6.1819 12.48 6.79611 12.48 7.55739C12.48 10.2132 10.8438 10.8015 9.28625 10.9745C9.54 11.1908 9.75875 11.606 9.75875 12.2548C9.75875 13.1805 9.75 13.9245 9.75 14.158C9.75 14.3397 9.88125 14.556 10.2312 14.4868C11.6209 14.023 12.8284 13.14 13.6839 11.9621C14.5393 10.7842 14.9996 9.3708 15 7.92073C15 4.09703 11.8675 1 8 1Z',
    })
  );
};
GithubFill16.displayName = 'GithubFill16';
exports['default'] = GithubFill16;
