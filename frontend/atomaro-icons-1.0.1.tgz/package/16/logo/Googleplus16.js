'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var Googleplus16 = function Googleplus16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M9.29493 4.23812C8.35453 3.48369 7.20089 2.94656 5.9731 3.00424C3.41147 2.91802 1.05611 5.17373 1.01323 7.74985C0.849258 9.85526 2.22655 11.9205 4.17109 12.665C6.10868 13.4148 8.59209 12.9039 9.82916 11.1538C10.6461 10.0487 10.8217 8.617 10.7267 7.28C9.931 7.28 9.1401 7.2811 8.3493 7.28219C7.5587 7.28329 6.76819 7.28438 5.9731 7.28438C5.97155 7.66322 5.97207 8.0462 5.97258 8.42848C5.97284 8.61936 5.9731 8.81007 5.9731 9H8.8198C8.40204 11.1124 5.54317 11.8174 4.03087 10.4378C2.4757 9.22725 2.54929 6.57306 4.16646 5.4487C5.29633 4.54164 6.90365 4.76593 8.0341 5.55123C8.47794 5.13819 8.89339 4.6966 9.29493 4.23812ZM13.875 9.65231H12.625V8.5297H11.502V7.2797H12.625V6.15625H13.875V7.2797H14.998V8.5297H13.875V9.65231Z',
    })
  );
};
Googleplus16.displayName = 'Googleplus16';
exports['default'] = Googleplus16;
