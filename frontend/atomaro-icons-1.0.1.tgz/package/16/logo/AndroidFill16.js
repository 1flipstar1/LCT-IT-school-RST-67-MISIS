'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var AndroidFill16 = function AndroidFill16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M4.5045 5.8322L3.17075 3.16602L1.82925 3.8371L3.24846 6.67413C2.07895 7.67062 1.23766 9.11212 1.01773 10.9986C0.953782 11.5472 1.4086 12.0002 1.96088 12.0002H14.0382C14.5905 12.0002 15.0453 11.5472 14.9813 10.9986C14.7615 9.11273 13.9207 7.67155 12.7518 6.6751L14.1708 3.83697L12.8292 3.16615L11.4958 5.83285C9.35777 4.7234 6.64278 4.72318 4.5045 5.8322ZM5.49995 10.0013C5.23473 10.0013 4.98037 9.89596 4.79284 9.70843C4.6053 9.52089 4.49994 9.26654 4.49994 9.00132C4.49994 8.7361 4.6053 8.48175 4.79284 8.29421C4.98037 8.10668 5.23473 8.00132 5.49995 8.00132C5.76516 8.00132 6.01952 8.10668 6.20705 8.29421C6.39459 8.48175 6.49994 8.7361 6.49994 9.00132C6.49994 9.26654 6.39459 9.52089 6.20705 9.70843C6.01952 9.89596 5.76516 10.0013 5.49995 10.0013ZM10.4999 10.0013C10.2347 10.0013 9.98037 9.89596 9.79284 9.70843C9.6053 9.52089 9.49994 9.26654 9.49994 9.00132C9.49994 8.7361 9.6053 8.48175 9.79284 8.29421C9.98037 8.10668 10.2347 8.00132 10.4999 8.00132C10.7652 8.00132 11.0195 8.10668 11.2071 8.29421C11.3946 8.48175 11.4999 8.7361 11.4999 9.00132C11.4999 9.26654 11.3946 9.52089 11.2071 9.70843C11.0195 9.89596 10.7652 10.0013 10.4999 10.0013Z',
    })
  );
};
AndroidFill16.displayName = 'AndroidFill16';
exports['default'] = AndroidFill16;
