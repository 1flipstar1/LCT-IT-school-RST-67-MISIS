'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var GooglePlayFill16 = function GooglePlayFill16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M11.9164 10.1902C11.8151 10.2497 11.6859 10.2305 11.6062 10.1442L9.78305 8.16909C9.69466 8.07332 9.69466 7.92571 9.78305 7.82995L11.6044 5.85687C11.6841 5.7705 11.8132 5.75133 11.9146 5.81082L13.1665 6.54542C14.2779 7.19761 14.2779 8.80452 13.1665 9.45671L11.9164 10.1902ZM10.1509 11.2262C10.2885 11.1455 10.3163 10.9583 10.2081 10.841L8.78955 9.30427C8.69056 9.19703 8.52114 9.19703 8.42215 9.30427L3.72751 14.3901C3.59275 14.5361 3.67713 14.7647 3.87456 14.7424C4.09938 14.717 4.32551 14.6445 4.54094 14.5181L10.1509 11.2262ZM2.42939 13.5849C2.31212 13.712 2.10483 13.6829 2.05917 13.5161C2.02011 13.3734 1.99902 13.2216 1.99902 13.0625V2.93965C1.99902 2.77953 2.02037 2.62684 2.0599 2.48339C2.10579 2.31685 2.3129 2.2879 2.43008 2.41484L7.42864 7.82995C7.51704 7.92571 7.51704 8.07332 7.42864 8.16909L2.42939 13.5849ZM3.87787 1.26012C3.68032 1.23741 3.59567 1.46609 3.73054 1.6122L8.42215 6.69477C8.52114 6.80201 8.69056 6.80201 8.78955 6.69477L10.2062 5.16001C10.3145 5.04279 10.2867 4.85557 10.1491 4.77482L4.54095 1.484C4.32657 1.3582 4.1016 1.28583 3.87787 1.26012Z',
    })
  );
};
GooglePlayFill16.displayName = 'GooglePlayFill16';
exports['default'] = GooglePlayFill16;
