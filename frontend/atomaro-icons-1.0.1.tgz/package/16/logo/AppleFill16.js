'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var AppleFill16 = function AppleFill16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      d: 'M11.6864 7.90702C11.7057 9.8751 13.4831 10.5271 13.5 10.5388C13.4864 10.5853 13.2207 11.4739 12.5688 12.3863C12.0042 13.1769 11.4217 13.9661 10.5008 13.9828C9.59265 13.9982 9.30494 13.465 8.27143 13.4672C7.2351 13.4672 6.91313 13.9697 6.0575 13.9991C5.1662 14.0325 4.48893 13.1449 3.9243 12.3565C2.76172 10.7451 1.87511 7.79956 3.06304 5.80529C3.6563 4.81606 4.71281 4.19345 5.8585 4.17539C6.73337 4.16094 7.55708 4.73841 8.08791 4.73841C8.62204 4.73841 9.62363 4.04445 10.6773 4.14423C11.1157 4.16139 12.3524 4.314 13.148 5.43055C13.0837 5.46757 11.6709 6.2595 11.6864 7.90702ZM9.9855 3.0778C9.51568 3.62591 8.74219 4.05574 7.98606 3.99705C7.8814 3.25298 8.26017 2.47369 8.69807 1.98607C9.18432 1.4384 10.0071 1.0298 10.6867 1C10.774 1.76348 10.4549 2.52742 9.9855 3.0778Z',
    })
  );
};
AppleFill16.displayName = 'AppleFill16';
exports['default'] = AppleFill16;
