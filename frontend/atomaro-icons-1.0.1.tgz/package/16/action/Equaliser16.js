'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var Equaliser16 = function Equaliser16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M11 7C10.4477 7 10 6.55229 10 6C10 5.44772 10.4477 5 11 5C11.5523 5 12 5.44772 12 6C12 6.55229 11.5523 7 11 7ZM8.5 6C8.5 7.11941 9.23573 8.06699 10.25 8.38555L10.25 14L11.75 14L11.75 8.38555C12.7643 8.06698 13.5 7.11941 13.5 6C13.5 4.88059 12.7643 3.93302 11.75 3.61445L11.75 2L10.25 2L10.25 3.61445C9.23572 3.93302 8.5 4.88059 8.5 6ZM5.75 7.61445L5.75001 2L4.25001 2L4.25 7.61445C3.23573 7.93301 2.5 8.88059 2.5 10C2.5 11.1194 3.23572 12.067 4.25 12.3855L4.25 14L5.75 14L5.75 12.3855C6.76428 12.067 7.5 11.1194 7.5 10C7.5 8.88059 6.76428 7.93302 5.75 7.61445ZM5 11C4.44771 11 4 10.5523 4 10C4 9.44771 4.44771 9 5 9C5.55228 9 6 9.44771 6 10C6 10.5523 5.55228 11 5 11Z',
    })
  );
};
Equaliser16.displayName = 'Equaliser16';
exports['default'] = Equaliser16;
