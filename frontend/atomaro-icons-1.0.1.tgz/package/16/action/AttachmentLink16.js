'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var AttachmentLink16 = function AttachmentLink16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M13.8368 2.16363C12.286 0.61208 9.77168 0.612129 8.22093 2.16374L6.36731 4.01825C4.80987 5.57656 4.80992 8.10299 6.36742 9.66123L7.0016 10.3035C7.03924 10.3416 7.10039 10.3434 7.13918 10.3064C7.78885 9.68768 7.94533 9.08505 7.4444 8.58388C6.48162 7.62064 6.48158 6.05884 7.44433 5.09556L9.29795 3.24105C10.2539 2.28455 11.8038 2.28452 12.7599 3.24098C13.7159 4.19749 13.7159 5.74836 12.7599 6.7049L11.9314 7.53422C11.9044 7.56133 11.8952 7.60151 11.9074 7.63786C12.0851 8.16988 12.1534 8.67047 12.1284 9.23905C12.1242 9.33261 12.239 9.38562 12.3051 9.31929L13.8369 7.78221C15.3876 6.23064 15.3876 3.71514 13.8368 2.16363ZM3.83287 6.83358C3.83705 6.74065 3.724 6.68736 3.65751 6.75242L2.16007 8.21779C0.609361 9.76936 0.609412 12.2849 2.16018 13.8364C3.71099 15.3879 6.22533 15.3879 7.77608 13.8363L9.62838 11.9831C11.1858 10.4248 11.1858 7.89833 9.62827 6.34009L9.04955 5.78423C9.01243 5.74857 8.95418 5.74688 8.91553 5.78089C8.35261 6.27613 7.94534 6.8112 8.55129 7.41744C9.51408 8.38068 9.51411 9.94248 8.55136 10.9058L6.69906 12.759C5.74309 13.7155 4.19316 13.7155 3.23716 12.759C2.2811 11.8025 2.28107 10.2516 3.23709 9.2951L4.06398 8.46736C4.09121 8.44012 4.10028 8.39958 4.08766 8.36319C3.88133 7.76829 3.80859 7.37291 3.83287 6.83358Z',
    })
  );
};
AttachmentLink16.displayName = 'AttachmentLink16';
exports['default'] = AttachmentLink16;
