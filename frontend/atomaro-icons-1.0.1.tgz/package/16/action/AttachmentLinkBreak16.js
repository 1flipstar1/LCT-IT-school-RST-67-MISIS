'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var AttachmentLinkBreak16 = function AttachmentLinkBreak16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M4.95558 0L5.75132 3.18298L4.29611 3.54678L3.50036 0.363803L4.95558 0ZM3.55176 4.31581L0.364846 3.52006L0.00146484 4.97538L3.18837 5.77113L3.55176 4.31581ZM15.6364 12.4835L12.4494 11.6878L12.8128 10.2324L15.9997 11.0282L15.6364 12.4835ZM11.0446 16.0032L10.2489 12.8202L11.7041 12.4564L12.4999 15.6394L11.0446 16.0032ZM10.0297 3.10084L7.52642 5.60055L6.46508 4.54057L8.96829 2.04093C10.3484 0.66277 12.5861 0.66277 13.9662 2.04093C15.3463 3.4191 15.3463 5.65354 13.9662 7.03171L11.4626 9.53172L10.4013 8.47174L12.9048 5.9718C13.6987 5.17901 13.6987 3.89363 12.9048 3.10084C12.1108 2.30804 10.8236 2.30804 10.0297 3.10084ZM4.53178 6.47111L5.59312 7.5311L3.08913 10.0315C2.2952 10.8243 2.29521 12.1097 3.08913 12.9025C3.88306 13.6953 5.17027 13.6953 5.9642 12.9025L8.46796 10.4023L9.5293 11.4623L7.02562 13.9624C5.64548 15.3405 3.40785 15.3405 2.02772 13.9624C0.647583 12.5842 0.647584 10.3498 2.02772 8.97161L4.53178 6.47111Z',
    })
  );
};
AttachmentLinkBreak16.displayName = 'AttachmentLinkBreak16';
exports['default'] = AttachmentLinkBreak16;
