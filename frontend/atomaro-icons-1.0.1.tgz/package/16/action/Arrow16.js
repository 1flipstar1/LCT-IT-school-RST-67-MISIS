'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var Arrow16 = function Arrow16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M6.0073 9.29853C6.1418 9.2614 6.28067 9.34156 6.31578 9.4766L7.22246 12.9631C7.25758 13.0981 7.39644 13.1783 7.53094 13.1412L9.68907 12.5453C9.82076 12.509 9.89888 12.3736 9.86449 12.2414L8.95406 8.74045C8.91967 8.60824 8.99779 8.4729 9.12948 8.43655L11.0537 7.9053C11.13 7.88425 11.1527 7.78715 11.0938 7.73439L6.41405 3.54641C6.36048 3.49847 6.27535 3.52103 6.25253 3.5892L4.23207 9.62699C4.20666 9.70292 4.27634 9.77643 4.35351 9.75512L6.0073 9.29853ZM2.01453 11.5269C1.947 11.7287 2.12574 11.9263 2.32585 11.871L4.9388 11.1496C5.0733 11.1125 5.21216 11.1927 5.24728 11.3277L6.15091 14.8025C6.18787 14.9446 6.32963 15.0289 6.46754 14.9909L11.5004 13.6014C11.6383 13.5633 11.7202 13.4172 11.6832 13.2751L10.7777 9.79309C10.7433 9.66088 10.8214 9.52554 10.9531 9.48919L13.8082 8.70093C14.0084 8.64568 14.0673 8.38249 13.9109 8.24252L5.89103 1.06539C5.75272 0.941614 5.5368 1.00123 5.47709 1.17967L2.01453 11.5269Z',
    })
  );
};
Arrow16.displayName = 'Arrow16';
exports['default'] = Arrow16;
