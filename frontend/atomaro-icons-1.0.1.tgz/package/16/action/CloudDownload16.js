'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var CloudDownload16 = function CloudDownload16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M11.4427 6.42983L12.2587 6.5131C13.5171 6.64151 14.5 7.70692 14.5 9C14.5 10.3807 13.3808 11.5 12 11.5V13C14.2092 13 16 11.2091 16 9C16 6.92959 14.427 5.22657 12.4109 5.02085C11.5044 3.22868 9.64572 2 7.50005 2C4.88341 2 2.69355 3.82726 2.13688 6.27538C0.881083 6.80689 0 8.05055 0 9.5C0 11.3995 1.51324 12.9457 3.4 12.9986C3.4315 12.9995 3.4631 13 3.4948 13L3.50002 13L3.50525 13C3.53695 13 3.56855 12.9995 3.60005 12.9986V13H3.60009H4.00005V11.4868L3.55796 11.4992C3.53876 11.4997 3.51945 11.5 3.50002 11.5C2.39543 11.5 1.5 10.6046 1.5 9.5C1.5 8.6741 2.00095 7.96173 2.72154 7.65674L3.42917 7.35724L3.59955 6.60797C4.00434 4.82774 5.59894 3.5 7.50005 3.5C9.05837 3.5 10.4113 4.39082 11.0724 5.6979L11.4427 6.42983ZM6.28007 10.4619L7.24941 11.4321L7.24941 7.00009H8.74941L8.74941 11.439L9.72798 10.4614L10.78 11.5308L8.5277 13.7808C8.23627 14.0719 7.76637 14.0717 7.47521 13.7803L5.2271 11.5303L6.28007 10.4619Z',
    })
  );
};
CloudDownload16.displayName = 'CloudDownload16';
exports['default'] = CloudDownload16;
