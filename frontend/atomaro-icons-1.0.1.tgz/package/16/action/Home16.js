'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var Home16 = function Home16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M12.4328 7.36345L11.5003 7.74456V8.75196V12.0027C11.5003 12.2788 11.2764 12.5027 11.0003 12.5027H9.99976V9.00049C9.99976 8.4482 9.55204 8.00049 8.99976 8.00049H6.99976C6.44747 8.00049 5.99976 8.4482 5.99976 9.00049V12.5027H5.00029C4.72415 12.5027 4.50029 12.2788 4.50029 12.0027V8.75196V7.74449L3.56768 7.36341L3.03218 7.14459L8.00002 3.61206L12.968 7.14471L12.4328 7.36345ZM7.49976 12.5027H8.49976V9.50049H7.49976V12.5027ZM14.3766 8.18947L13.0003 8.75196V12.0027C13.0003 13.1073 12.1049 14.0027 11.0003 14.0027H5.00029C3.89572 14.0027 3.00029 13.1073 3.00029 12.0027V8.75196L1.6236 8.18942C0.893956 7.89127 0.779988 6.90552 1.42235 6.44875L7.42051 2.18357C7.76746 1.93686 8.23257 1.93686 8.57952 2.18357L14.5778 6.44883C15.2201 6.90558 15.1062 7.89129 14.3766 8.18947Z',
    })
  );
};
Home16.displayName = 'Home16';
exports['default'] = Home16;
