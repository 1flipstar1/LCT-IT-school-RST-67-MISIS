'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var Checklist16 = function Checklist16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M6.02978 5.96923L8.0001 7.93952L13.9704 1.96918L15.0298 3.03118L8.52977 9.53118C8.23714 9.82381 7.76309 9.82381 7.47045 9.53118L4.97047 7.03124L6.02978 5.96923ZM5 1.99999H10V3.49999H5C4.17157 3.49999 3.5 4.17156 3.5 4.99999V11C3.5 11.8284 4.17157 12.5 5 12.5H11C11.8284 12.5 12.5 11.8284 12.5 11V7.99999H14V11C14 12.6568 12.6569 14 11 14H5C3.34315 14 2 12.6568 2 11V4.99999C2 3.34313 3.34315 1.99999 5 1.99999Z',
    })
  );
};
Checklist16.displayName = 'Checklist16';
exports['default'] = Checklist16;
