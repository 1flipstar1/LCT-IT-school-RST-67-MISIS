'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var Download16 = function Download16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M6.5 6.5V5V3.5H9.5V5V6.5H11H11.3787L8 9.87868L4.62132 6.5H5H6.5ZM5 5V3.5V2.75C5 2.33579 5.33579 2 5.75 2H10.25C10.6642 2 11 2.33579 11 2.75V3.5V5H12.5H13.1893C13.8575 5 14.1921 5.80786 13.7197 6.28033L8.53033 11.4697C8.23744 11.7626 7.76256 11.7626 7.46967 11.4697L2.28033 6.28033C1.80786 5.80786 2.14248 5 2.81066 5H3.5H5ZM2.5 13V11H1V13C1 14.1046 1.89543 15 3 15H13C14.1046 15 15 14.1046 15 13V11H13.5V13C13.5 13.2761 13.2761 13.5 13 13.5H3C2.72386 13.5 2.5 13.2761 2.5 13Z',
    })
  );
};
Download16.displayName = 'Download16';
exports['default'] = Download16;
