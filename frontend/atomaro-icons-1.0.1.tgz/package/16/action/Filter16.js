'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var Filter16 = function Filter16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M5.81993 6.73794L5.81993 6.73795C6.24884 7.06933 6.5 7.58075 6.5 8.12277V12.5729L9.5 11.0729V8.12277C9.5 7.58076 9.75115 7.06933 10.1801 6.73794L13.5 4.17295V3.5H2.5V4.17295L5.81993 6.73794ZM1 4.90958V2.5C1 2.22386 1.22386 2 1.5 2H14.5C14.7761 2 15 2.22386 15 2.5V4.90958L11.0972 7.92494C11.0359 7.97228 11 8.04534 11 8.12277V11.382C11 11.7607 10.786 12.107 10.4472 12.2764L6.5 14.25L6.4583 14.2709L5.80902 14.5955L5.3618 14.8191C5.19558 14.9022 5 14.7813 5 14.5955V14.0955V13.3696V13.3229V8.12277C5 8.04534 4.96412 7.97228 4.90285 7.92494L1 4.90958ZM9.77639 10.9348L9.77581 10.935L9.77639 10.9348Z',
    })
  );
};
Filter16.displayName = 'Filter16';
exports['default'] = Filter16;
