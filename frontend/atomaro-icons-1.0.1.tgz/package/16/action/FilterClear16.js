'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var FilterClear16 = function FilterClear16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M5.81993 6.73795L5.81993 6.73794L2.5 4.17295V3.5H13.5V4.17295L10.1801 6.73794C9.75115 7.06933 9.5 7.58076 9.5 8.12277V11.0729L6.5 12.5729V8.12277C6.5 7.58075 6.24884 7.06933 5.81993 6.73795ZM1 2.5V4.90958L4.90285 7.92494C4.96412 7.97228 5 8.04534 5 8.12277V13.3229V13.3696V14.0955V14.5955C5 14.7813 5.19558 14.9022 5.3618 14.8191L5.80902 14.5955L6.4583 14.2709L6.5 14.25L10.1708 12.4146C10.679 12.1605 11 11.6411 11 11.0729V8.12277C11 8.04534 11.0359 7.97228 11.0972 7.92494L15 4.90958V2.5C15 2.22386 14.7761 2 14.5 2H1.5C1.22386 2 1 2.22386 1 2.5ZM12.5304 14.9972L13.7329 13.7947L14.9368 14.9987L15.9975 13.938L14.7936 12.734L15.9972 11.5304L14.9365 10.4697L13.7329 11.6733L12.5294 10.4697L11.4688 11.5304L12.6723 12.734L11.4697 13.9365L12.5304 14.9972Z',
    })
  );
};
FilterClear16.displayName = 'FilterClear16';
exports['default'] = FilterClear16;
