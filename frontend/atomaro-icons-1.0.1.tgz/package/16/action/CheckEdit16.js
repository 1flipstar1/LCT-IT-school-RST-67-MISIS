'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var CheckEdit16 = function CheckEdit16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M6.3 8.81429V9.69998H7.17632L10.9029 5.9636L10.0248 5.08551L6.3 8.81429ZM11.0849 4.02428L11.9622 4.90155L12.517 4.34522C12.7563 4.10527 12.7587 3.71763 12.5222 3.47483C12.281 3.2271 11.8838 3.22457 11.6394 3.4692L11.0849 4.02428ZM5.29252 7.98339C5.10521 8.1709 5 8.42509 5 8.69012V9.99998C5 10.5523 5.44772 11 6 11H7.30081C7.56648 11 7.82124 10.8943 8.00885 10.7062L13.4375 5.26325C14.1786 4.5202 14.1858 3.31978 13.4536 2.5679C12.7066 1.80074 11.4764 1.79289 10.7197 2.55045L5.29252 7.98339ZM8 1.99999H5C3.34315 1.99999 2 3.34314 2 4.99999V11C2 12.6568 3.34315 14 5 14H11C12.6569 14 14 12.6568 14 11V7.99999H12.5V11C12.5 11.8284 11.8284 12.5 11 12.5H5C4.17157 12.5 3.5 11.8284 3.5 11V4.99999C3.5 4.17156 4.17157 3.49999 5 3.49999H8V1.99999Z',
    })
  );
};
CheckEdit16.displayName = 'CheckEdit16';
exports['default'] = CheckEdit16;
