'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var FilterFill16 = function FilterFill16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      d: 'M14.5 2H1.5C1.22386 2 1 2.22386 1 2.5V4.89661L5.43035 7.64655C5.57729 7.73775 5.66667 7.89842 5.66667 8.07136V14.5295C5.66667 14.7299 5.89055 14.8488 6.05658 14.7367L9.89299 12.1459C10.1683 11.9599 10.3333 11.6494 10.3333 11.3171V8.07136C10.3333 7.89842 10.4227 7.73775 10.5696 7.64655L15 4.89661V2.5C15 2.22386 14.7761 2 14.5 2Z',
    })
  );
};
FilterFill16.displayName = 'FilterFill16';
exports['default'] = FilterFill16;
