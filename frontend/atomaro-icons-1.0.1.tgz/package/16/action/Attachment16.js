'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var Attachment16 = function Attachment16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M11.3287 2.51648C11.8355 2.61673 12.3052 2.86138 12.6795 3.22429C13.7695 4.28129 13.7695 6.03035 12.6795 7.08734L6.80264 12.786C5.81958 13.7392 4.25725 13.7397 3.27362 12.787C2.24533 11.7911 2.24483 10.142 3.27252 9.14545L7.68542 4.86637C8.0316 4.53068 8.5818 4.5306 8.92809 4.86618C9.28992 5.21683 9.29002 5.79727 8.92832 6.14805L4.33603 10.6016L5.3803 11.6784L9.97259 7.22485C10.9421 6.28464 10.9418 4.72887 9.97197 3.78901C9.04382 2.88953 7.5691 2.88975 6.64121 3.7895L2.22831 8.06859C0.592643 9.65466 0.593434 12.2794 2.23006 13.8645C3.79561 15.3808 6.28221 15.38 7.84685 13.8628L13.7237 8.1642C15.4215 6.51791 15.4215 3.79372 13.7237 2.14743C13.0697 1.51326 12.2285 1.11096 11.3287 0.997986V2.51648Z',
    })
  );
};
Attachment16.displayName = 'Attachment16';
exports['default'] = Attachment16;
