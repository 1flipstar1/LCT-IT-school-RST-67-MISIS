'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var Copy16 = function Copy16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M5 4H3C2.44772 4 2 4.44772 2 5V14C2 14.5523 2.44772 15 3 15H10C10.5523 15 11 14.5523 11 14V12H13C13.5523 12 14 11.5523 14 11V4C14 2.34315 12.6569 1 11 1H6C5.44772 1 5 1.44771 5 2V4ZM6.5 4H8C9.65685 4 11 5.34315 11 7V10.5H12.5V4C12.5 3.17157 11.8284 2.5 11 2.5H6.5V4ZM3.5 13.5V5.5H8C8.82843 5.5 9.5 6.17157 9.5 7V13.5H3.5Z',
    })
  );
};
Copy16.displayName = 'Copy16';
exports['default'] = Copy16;
