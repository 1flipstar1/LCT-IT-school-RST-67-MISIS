'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var AttachmentLinkAdd16 = function AttachmentLinkAdd16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M8.22093 2.16374C9.77168 0.612129 12.286 0.61208 13.8368 2.16363C15.3876 3.71514 15.3876 6.23064 13.8369 7.78221L12.3051 9.31929C12.239 9.38562 12.1242 9.33261 12.1284 9.23905C12.1534 8.67047 12.0851 8.16988 11.9074 7.63786C11.8952 7.60151 11.9044 7.56133 11.9314 7.53422L12.7599 6.7049C13.7159 5.74836 13.7159 4.19749 12.7599 3.24098C11.8038 2.28452 10.2539 2.28455 9.29795 3.24105L7.44433 5.09556C6.48158 6.05884 6.48162 7.62064 7.4444 8.58388C7.94533 9.08505 7.78885 9.68768 7.13918 10.3064C7.10039 10.3434 7.03924 10.3416 7.0016 10.3035L6.36742 9.66123C4.80992 8.10299 4.80987 5.57656 6.36731 4.01825L8.22093 2.16374ZM3.65751 6.75242C3.724 6.68736 3.83705 6.74065 3.83287 6.83358C3.80859 7.37291 3.88133 7.76829 4.08766 8.36319C4.10028 8.39958 4.09121 8.44012 4.06398 8.46736L3.23709 9.2951C2.28107 10.2516 2.2811 11.8025 3.23716 12.759C4.19316 13.7155 5.74309 13.7155 6.69906 12.759L8.55136 10.9058C9.51411 9.94248 9.51408 8.38068 8.55129 7.41744C7.94534 6.8112 8.35261 6.27613 8.91553 5.78089C8.95418 5.74688 9.01243 5.74857 9.04955 5.78423L9.62827 6.34009C11.1858 7.89833 11.1858 10.4248 9.62838 11.9831L7.77608 13.8363C6.22533 15.3879 3.71099 15.3879 2.16018 13.8364C0.609412 12.2849 0.609361 9.76936 2.16007 8.21779L3.65751 6.75242ZM12.75 16V14.25H11V12.75H12.75V11H14.25V12.75H16V14.25H14.25V16H12.75Z',
    })
  );
};
AttachmentLinkAdd16.displayName = 'AttachmentLinkAdd16';
exports['default'] = AttachmentLinkAdd16;
