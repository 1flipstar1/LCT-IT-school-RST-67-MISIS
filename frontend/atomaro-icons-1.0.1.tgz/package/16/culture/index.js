"use strict";

var __importDefault = this && this.__importDefault || function (mod) {
  return mod && mod.__esModule ? mod : {
    "default": mod
  };
};
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Education16 = void 0;
var Education16_1 = require("./Education16");
Object.defineProperty(exports, "Education16", {
  enumerable: true,
  get: function get() {
    return __importDefault(Education16_1)["default"];
  }
});