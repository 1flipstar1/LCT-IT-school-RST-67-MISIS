'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var Education16 = function Education16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M2.48746 6.06224L7.99999 3.5468L13.5127 6.06281L8.00012 8.8221L2.48746 6.06224ZM8.41522 2.08747L15.562 5.3493C16.1353 5.61097 16.1499 6.42019 15.5863 6.70227L12.9947 7.99951V10.7927C12.9947 11.2583 12.8174 11.7066 12.499 12.0463C10.063 14.6456 5.93651 14.6461 3.50082 12.046C3.18261 11.7063 3.00554 11.2583 3.00554 10.7929V7.99909L1.75857 7.3748V9.99897H0.258571V6.59924C-0.140895 6.25916 -0.0763612 5.58335 0.438164 5.34857L7.58488 2.08743C7.84858 1.9671 8.15152 1.96711 8.41522 2.08747ZM4.50554 8.75005V10.7929C4.50554 10.8774 4.53771 10.9588 4.59552 11.0205C6.43837 12.9877 9.56103 12.9876 11.4045 11.0206C11.4624 10.9588 11.4947 10.8772 11.4947 10.7927V8.75033L8.4477 10.2755C8.16594 10.4165 7.83418 10.4165 7.55243 10.2754L4.50554 8.75005Z',
    })
  );
};
Education16.displayName = 'Education16';
exports['default'] = Education16;
