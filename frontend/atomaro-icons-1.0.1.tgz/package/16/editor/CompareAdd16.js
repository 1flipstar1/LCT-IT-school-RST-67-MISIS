'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var CompareAdd16 = function CompareAdd16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      d: 'M1 3.25H13V4.75H1V3.25Z',
    }),
    ',',
    react_1['default'].createElement('path', {
      d: 'M9 7.25H1V8.75H9V7.25Z',
    }),
    ',',
    react_1['default'].createElement('path', {
      d: 'M5 11.25H1V12.75H5V11.25Z',
    }),
    ',',
    react_1['default'].createElement('path', {
      d: 'M11.25 15V12.75H9V11.25H11.25V9H12.75V11.25H15V12.75H12.75V15H11.25Z',
    })
  );
};
CompareAdd16.displayName = 'CompareAdd16';
exports['default'] = CompareAdd16;
