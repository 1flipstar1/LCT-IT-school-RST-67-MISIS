'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var Edit16 = function Edit16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M12.5484 3.10666L11.9731 2.49592C11.7894 2.30092 11.4847 2.28534 11.282 2.4606L10.2975 3.31223L11.555 4.66292L12.5133 3.82612C12.7269 3.63962 12.7428 3.31305 12.5484 3.10666ZM3.5 9.19198L9.16225 4.29419L10.4246 5.65004L4.87022 10.5002H3.5V9.19198ZM13.6403 2.07815L13.065 1.46741C12.3302 0.687385 11.1112 0.62508 10.3007 1.32613L2.34579 8.20706C2.1262 8.39701 2 8.67302 2 8.96337V11.0002C2 11.5525 2.44772 12.0002 3 12.0002H5.0578C5.29967 12.0002 5.53335 11.9126 5.71554 11.7535L13.4999 4.95598C14.3542 4.21 14.4179 2.9037 13.6403 2.07815ZM14 13.4996H2V14.9996H14V13.4996Z',
    })
  );
};
Edit16.displayName = 'Edit16';
exports['default'] = Edit16;
