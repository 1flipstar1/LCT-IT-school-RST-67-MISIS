'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var ColumnDelete16 = function ColumnDelete16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M12.0001 13.0607L13.9697 15.0303L15.0304 13.9697L2.03039 0.969666L0.969727 2.03033L4.00006 5.06066V14.25C4.00006 14.6642 4.33584 15 4.75006 15H11.2501C11.6643 15 12.0001 14.6642 12.0001 14.25V13.0607ZM10.5001 11.5607L5.50006 6.56066V13.5H10.5001V11.5607ZM12.0001 1.75V8.93928L10.5001 7.43928V2.5L5.56077 2.5L4.25095 1.19017C4.38353 1.07189 4.5584 0.999996 4.75006 0.999996H11.2501C11.6643 0.999996 12.0001 1.33578 12.0001 1.75Z',
    })
  );
};
ColumnDelete16.displayName = 'ColumnDelete16';
exports['default'] = ColumnDelete16;
