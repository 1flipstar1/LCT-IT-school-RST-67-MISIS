"use strict";

var __importDefault = this && this.__importDefault || function (mod) {
  return mod && mod.__esModule ? mod : {
    "default": mod
  };
};
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Value16 = exports.Text16 = exports.TextUnderline16 = exports.TextSuperscript16 = exports.TextSubscript16 = exports.TextStrikethrough16 = exports.TextSearch16 = exports.TextItalic16 = exports.TextCapsLock16 = exports.TextBold16 = exports.StartOfLine16 = exports.SortUp16 = exports.SortDown16 = exports.Sigma16 = exports.Scissors16 = exports.RowDelete16 = exports.RowBelow16 = exports.RowAbove16 = exports.Quote16 = exports.Pencil16 = exports.Numbers16 = exports.MiddleOfLine16 = exports.MarketingFunnel16 = exports.Marker16 = exports.ListNumbered16 = exports.ListChecked16 = exports.ListBulleted16 = exports.LineSpacing16 = exports.LetterSpacing16 = exports.Hashtag16 = exports.Equals16 = exports.EndOfLine16 = exports.Edit16 = exports.DragVerticalLines16 = exports.DragVerticalDots16 = exports.DragHorizontalLines16 = exports.DragHorizontalDots16 = exports.DividerVertical16 = exports.DividerHorizontal16 = exports.DividerDot16 = exports.Crop16 = exports.CompareAdded16 = exports.CompareAdd16 = exports.ColumnDelete16 = exports.CellsMerge16 = exports.Bullet16 = exports.AlignRight16 = exports.AlignLeft16 = exports.AlignJustify16 = exports.AlignCenter16 = void 0;
var AlignCenter16_1 = require("./AlignCenter16");
Object.defineProperty(exports, "AlignCenter16", {
  enumerable: true,
  get: function get() {
    return __importDefault(AlignCenter16_1)["default"];
  }
});
var AlignJustify16_1 = require("./AlignJustify16");
Object.defineProperty(exports, "AlignJustify16", {
  enumerable: true,
  get: function get() {
    return __importDefault(AlignJustify16_1)["default"];
  }
});
var AlignLeft16_1 = require("./AlignLeft16");
Object.defineProperty(exports, "AlignLeft16", {
  enumerable: true,
  get: function get() {
    return __importDefault(AlignLeft16_1)["default"];
  }
});
var AlignRight16_1 = require("./AlignRight16");
Object.defineProperty(exports, "AlignRight16", {
  enumerable: true,
  get: function get() {
    return __importDefault(AlignRight16_1)["default"];
  }
});
var Bullet16_1 = require("./Bullet16");
Object.defineProperty(exports, "Bullet16", {
  enumerable: true,
  get: function get() {
    return __importDefault(Bullet16_1)["default"];
  }
});
var CellsMerge16_1 = require("./CellsMerge16");
Object.defineProperty(exports, "CellsMerge16", {
  enumerable: true,
  get: function get() {
    return __importDefault(CellsMerge16_1)["default"];
  }
});
var ColumnDelete16_1 = require("./ColumnDelete16");
Object.defineProperty(exports, "ColumnDelete16", {
  enumerable: true,
  get: function get() {
    return __importDefault(ColumnDelete16_1)["default"];
  }
});
var CompareAdd16_1 = require("./CompareAdd16");
Object.defineProperty(exports, "CompareAdd16", {
  enumerable: true,
  get: function get() {
    return __importDefault(CompareAdd16_1)["default"];
  }
});
var CompareAdded16_1 = require("./CompareAdded16");
Object.defineProperty(exports, "CompareAdded16", {
  enumerable: true,
  get: function get() {
    return __importDefault(CompareAdded16_1)["default"];
  }
});
var Crop16_1 = require("./Crop16");
Object.defineProperty(exports, "Crop16", {
  enumerable: true,
  get: function get() {
    return __importDefault(Crop16_1)["default"];
  }
});
var DividerDot16_1 = require("./DividerDot16");
Object.defineProperty(exports, "DividerDot16", {
  enumerable: true,
  get: function get() {
    return __importDefault(DividerDot16_1)["default"];
  }
});
var DividerHorizontal16_1 = require("./DividerHorizontal16");
Object.defineProperty(exports, "DividerHorizontal16", {
  enumerable: true,
  get: function get() {
    return __importDefault(DividerHorizontal16_1)["default"];
  }
});
var DividerVertical16_1 = require("./DividerVertical16");
Object.defineProperty(exports, "DividerVertical16", {
  enumerable: true,
  get: function get() {
    return __importDefault(DividerVertical16_1)["default"];
  }
});
var DragHorizontalDots16_1 = require("./DragHorizontalDots16");
Object.defineProperty(exports, "DragHorizontalDots16", {
  enumerable: true,
  get: function get() {
    return __importDefault(DragHorizontalDots16_1)["default"];
  }
});
var DragHorizontalLines16_1 = require("./DragHorizontalLines16");
Object.defineProperty(exports, "DragHorizontalLines16", {
  enumerable: true,
  get: function get() {
    return __importDefault(DragHorizontalLines16_1)["default"];
  }
});
var DragVerticalDots16_1 = require("./DragVerticalDots16");
Object.defineProperty(exports, "DragVerticalDots16", {
  enumerable: true,
  get: function get() {
    return __importDefault(DragVerticalDots16_1)["default"];
  }
});
var DragVerticalLines16_1 = require("./DragVerticalLines16");
Object.defineProperty(exports, "DragVerticalLines16", {
  enumerable: true,
  get: function get() {
    return __importDefault(DragVerticalLines16_1)["default"];
  }
});
var Edit16_1 = require("./Edit16");
Object.defineProperty(exports, "Edit16", {
  enumerable: true,
  get: function get() {
    return __importDefault(Edit16_1)["default"];
  }
});
var EndOfLine16_1 = require("./EndOfLine16");
Object.defineProperty(exports, "EndOfLine16", {
  enumerable: true,
  get: function get() {
    return __importDefault(EndOfLine16_1)["default"];
  }
});
var Equals16_1 = require("./Equals16");
Object.defineProperty(exports, "Equals16", {
  enumerable: true,
  get: function get() {
    return __importDefault(Equals16_1)["default"];
  }
});
var Hashtag16_1 = require("./Hashtag16");
Object.defineProperty(exports, "Hashtag16", {
  enumerable: true,
  get: function get() {
    return __importDefault(Hashtag16_1)["default"];
  }
});
var LetterSpacing16_1 = require("./LetterSpacing16");
Object.defineProperty(exports, "LetterSpacing16", {
  enumerable: true,
  get: function get() {
    return __importDefault(LetterSpacing16_1)["default"];
  }
});
var LineSpacing16_1 = require("./LineSpacing16");
Object.defineProperty(exports, "LineSpacing16", {
  enumerable: true,
  get: function get() {
    return __importDefault(LineSpacing16_1)["default"];
  }
});
var ListBulleted16_1 = require("./ListBulleted16");
Object.defineProperty(exports, "ListBulleted16", {
  enumerable: true,
  get: function get() {
    return __importDefault(ListBulleted16_1)["default"];
  }
});
var ListChecked16_1 = require("./ListChecked16");
Object.defineProperty(exports, "ListChecked16", {
  enumerable: true,
  get: function get() {
    return __importDefault(ListChecked16_1)["default"];
  }
});
var ListNumbered16_1 = require("./ListNumbered16");
Object.defineProperty(exports, "ListNumbered16", {
  enumerable: true,
  get: function get() {
    return __importDefault(ListNumbered16_1)["default"];
  }
});
var Marker16_1 = require("./Marker16");
Object.defineProperty(exports, "Marker16", {
  enumerable: true,
  get: function get() {
    return __importDefault(Marker16_1)["default"];
  }
});
var MarketingFunnel16_1 = require("./MarketingFunnel16");
Object.defineProperty(exports, "MarketingFunnel16", {
  enumerable: true,
  get: function get() {
    return __importDefault(MarketingFunnel16_1)["default"];
  }
});
var MiddleOfLine16_1 = require("./MiddleOfLine16");
Object.defineProperty(exports, "MiddleOfLine16", {
  enumerable: true,
  get: function get() {
    return __importDefault(MiddleOfLine16_1)["default"];
  }
});
var Numbers16_1 = require("./Numbers16");
Object.defineProperty(exports, "Numbers16", {
  enumerable: true,
  get: function get() {
    return __importDefault(Numbers16_1)["default"];
  }
});
var Pencil16_1 = require("./Pencil16");
Object.defineProperty(exports, "Pencil16", {
  enumerable: true,
  get: function get() {
    return __importDefault(Pencil16_1)["default"];
  }
});
var Quote16_1 = require("./Quote16");
Object.defineProperty(exports, "Quote16", {
  enumerable: true,
  get: function get() {
    return __importDefault(Quote16_1)["default"];
  }
});
var RowAbove16_1 = require("./RowAbove16");
Object.defineProperty(exports, "RowAbove16", {
  enumerable: true,
  get: function get() {
    return __importDefault(RowAbove16_1)["default"];
  }
});
var RowBelow16_1 = require("./RowBelow16");
Object.defineProperty(exports, "RowBelow16", {
  enumerable: true,
  get: function get() {
    return __importDefault(RowBelow16_1)["default"];
  }
});
var RowDelete16_1 = require("./RowDelete16");
Object.defineProperty(exports, "RowDelete16", {
  enumerable: true,
  get: function get() {
    return __importDefault(RowDelete16_1)["default"];
  }
});
var Scissors16_1 = require("./Scissors16");
Object.defineProperty(exports, "Scissors16", {
  enumerable: true,
  get: function get() {
    return __importDefault(Scissors16_1)["default"];
  }
});
var Sigma16_1 = require("./Sigma16");
Object.defineProperty(exports, "Sigma16", {
  enumerable: true,
  get: function get() {
    return __importDefault(Sigma16_1)["default"];
  }
});
var SortDown16_1 = require("./SortDown16");
Object.defineProperty(exports, "SortDown16", {
  enumerable: true,
  get: function get() {
    return __importDefault(SortDown16_1)["default"];
  }
});
var SortUp16_1 = require("./SortUp16");
Object.defineProperty(exports, "SortUp16", {
  enumerable: true,
  get: function get() {
    return __importDefault(SortUp16_1)["default"];
  }
});
var StartOfLine16_1 = require("./StartOfLine16");
Object.defineProperty(exports, "StartOfLine16", {
  enumerable: true,
  get: function get() {
    return __importDefault(StartOfLine16_1)["default"];
  }
});
var TextBold16_1 = require("./TextBold16");
Object.defineProperty(exports, "TextBold16", {
  enumerable: true,
  get: function get() {
    return __importDefault(TextBold16_1)["default"];
  }
});
var TextCapsLock16_1 = require("./TextCapsLock16");
Object.defineProperty(exports, "TextCapsLock16", {
  enumerable: true,
  get: function get() {
    return __importDefault(TextCapsLock16_1)["default"];
  }
});
var TextItalic16_1 = require("./TextItalic16");
Object.defineProperty(exports, "TextItalic16", {
  enumerable: true,
  get: function get() {
    return __importDefault(TextItalic16_1)["default"];
  }
});
var TextSearch16_1 = require("./TextSearch16");
Object.defineProperty(exports, "TextSearch16", {
  enumerable: true,
  get: function get() {
    return __importDefault(TextSearch16_1)["default"];
  }
});
var TextStrikethrough16_1 = require("./TextStrikethrough16");
Object.defineProperty(exports, "TextStrikethrough16", {
  enumerable: true,
  get: function get() {
    return __importDefault(TextStrikethrough16_1)["default"];
  }
});
var TextSubscript16_1 = require("./TextSubscript16");
Object.defineProperty(exports, "TextSubscript16", {
  enumerable: true,
  get: function get() {
    return __importDefault(TextSubscript16_1)["default"];
  }
});
var TextSuperscript16_1 = require("./TextSuperscript16");
Object.defineProperty(exports, "TextSuperscript16", {
  enumerable: true,
  get: function get() {
    return __importDefault(TextSuperscript16_1)["default"];
  }
});
var TextUnderline16_1 = require("./TextUnderline16");
Object.defineProperty(exports, "TextUnderline16", {
  enumerable: true,
  get: function get() {
    return __importDefault(TextUnderline16_1)["default"];
  }
});
var Text16_1 = require("./Text16");
Object.defineProperty(exports, "Text16", {
  enumerable: true,
  get: function get() {
    return __importDefault(Text16_1)["default"];
  }
});
var Value16_1 = require("./Value16");
Object.defineProperty(exports, "Value16", {
  enumerable: true,
  get: function get() {
    return __importDefault(Value16_1)["default"];
  }
});