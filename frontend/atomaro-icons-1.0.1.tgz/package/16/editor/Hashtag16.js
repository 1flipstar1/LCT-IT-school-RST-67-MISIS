'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var Hashtag16 = function Hashtag16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M5.00465 10.4994L4.5691 13H6.09169L6.52723 10.4994H8.57513L8.13958 13H9.66216L10.0977 10.4994H13V8.99944H10.359L10.7067 7.00309H13V5.50309H10.968L11.404 3H9.88138L9.44539 5.50309H7.3975L7.83349 3H6.3109L5.87491 5.50309H3V7.00309H5.61364L5.26592 8.99944H3V10.4994H5.00465ZM6.7885 8.99944H8.8364L9.18412 7.00309L7.13623 7.00309L6.7885 8.99944Z',
    })
  );
};
Hashtag16.displayName = 'Hashtag16';
exports['default'] = Hashtag16;
