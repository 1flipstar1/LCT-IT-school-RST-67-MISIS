'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var Crop16 = function Crop16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M3.00098 4.5009V10.4991C3.00098 11.8798 4.12026 12.9991 5.50098 12.9991H11.499V15H12.999V12.9991H14.9995V11.4991H5.50098C4.94869 11.4991 4.50098 11.0514 4.50098 10.4991V1H3.00098V3.0009H1.00017V4.5009H3.00098ZM12.999 10V5.5009C12.999 4.12019 11.8797 3.0009 10.499 3.0009H6V4.5009H10.499C11.0513 4.5009 11.499 4.94861 11.499 5.5009V10H12.999Z',
    })
  );
};
Crop16.displayName = 'Crop16';
exports['default'] = Crop16;
