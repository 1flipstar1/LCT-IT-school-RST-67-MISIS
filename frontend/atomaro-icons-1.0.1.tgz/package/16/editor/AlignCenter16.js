'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var AlignCenter16 = function AlignCenter16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M15 2H1V3.55556H15V2Z',
    }),
    ',',
    react_1['default'].createElement('path', {
      d: 'M12 12.4444H4V14H12V12.4444Z',
    }),
    ',',
    react_1['default'].createElement('path', {
      d: 'M15 7.44444H1V9H15V7.44444Z',
    })
  );
};
AlignCenter16.displayName = 'AlignCenter16';
exports['default'] = AlignCenter16;
