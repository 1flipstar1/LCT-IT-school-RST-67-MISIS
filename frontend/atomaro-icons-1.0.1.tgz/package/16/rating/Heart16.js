'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var Heart16 = function Heart16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M2.00439 6.02177C2.00439 4.16812 3.30152 2.5022 5.25 2.5022C6.39923 2.5022 7.29536 3.07563 7.88139 3.85005C7.92317 3.90525 7.96347 3.96158 8.00231 4.01892C8.04069 3.96202 8.08052 3.90612 8.12181 3.85133C8.70583 3.07612 9.60028 2.5022 10.75 2.5022C12.6958 2.5022 14.0027 4.16514 14.0027 6.02177C14.0027 7.70649 12.9854 9.17468 11.8756 10.3458C11.0214 11.2472 10.0133 12.0698 9.18693 12.7442C8.93341 12.9511 8.69699 13.144 8.48737 13.321C8.20796 13.5568 7.79917 13.5568 7.51976 13.321C7.31014 13.144 7.07372 12.9511 6.8202 12.7442C5.99383 12.0698 4.98575 11.2472 4.13158 10.3458C3.02175 9.17468 2.00439 7.70649 2.00439 6.02177ZM8.75417 6.50024H7.25417C7.25417 5.88644 7.04925 5.23618 6.68527 4.7552C6.33172 4.288 5.85077 4.0022 5.25 4.0022C4.29944 4.0022 3.50439 4.81623 3.50439 6.02177C3.50439 7.10662 4.17428 8.21018 5.22035 9.31404C6.00148 10.1383 6.89879 10.871 7.71315 11.5359C7.81127 11.616 7.9082 11.6951 8.00356 11.7733C8.09893 11.6951 8.19586 11.616 8.29398 11.5359C9.10834 10.871 10.0057 10.1383 10.7868 9.31404C11.8329 8.21018 12.5027 7.10662 12.5027 6.02177C12.5027 4.81922 11.7032 4.0022 10.75 4.0022C10.1497 4.0022 9.67125 4.2875 9.31986 4.75392C8.95783 5.23446 8.75417 5.885 8.75417 6.50024Z',
    })
  );
};
Heart16.displayName = 'Heart16';
exports['default'] = Heart16;
