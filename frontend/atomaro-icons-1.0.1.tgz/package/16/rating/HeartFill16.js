'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var HeartFill16 = function HeartFill16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M5.25 2.5022C3.30152 2.5022 2.00439 4.16812 2.00439 6.02177C2.00439 7.70649 3.02175 9.17468 4.13158 10.3458C4.98575 11.2472 5.99383 12.0698 6.8202 12.7442C7.07372 12.9511 7.31014 13.144 7.51976 13.321C7.79917 13.5568 8.20796 13.5568 8.48737 13.321C8.69699 13.144 8.9334 12.9511 9.18691 12.7442L9.18693 12.7442L9.18695 12.7442C10.0133 12.0698 11.0214 11.2472 11.8756 10.3458C12.9854 9.17468 14.0027 7.70649 14.0027 6.02177C14.0027 4.16514 12.6958 2.5022 10.75 2.5022C9.60028 2.5022 8.70583 3.07612 8.12181 3.85133C8.08052 3.90612 8.04069 3.96202 8.00231 4.01892C7.96347 3.96158 7.92317 3.90525 7.88139 3.85005C7.29536 3.07563 6.39923 2.5022 5.25 2.5022Z',
    })
  );
};
HeartFill16.displayName = 'HeartFill16';
exports['default'] = HeartFill16;
