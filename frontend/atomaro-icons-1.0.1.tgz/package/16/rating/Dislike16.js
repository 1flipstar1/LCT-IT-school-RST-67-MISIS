'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var Dislike16 = function Dislike16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M8.99994 14.2281L8.99993 12.9999L8.99993 11.4999L10.4999 11.4999L12.4947 11.4999C14.0101 11.4999 15.1771 10.1623 14.9716 8.66088L14.4149 4.59312C14.2115 3.10729 12.9422 1.99987 11.4425 1.99989L3.99994 2L3 2.00023C1.89543 2.00023 1 2.89566 1 4.00023V9.50023C1 10.6048 1.89543 11.5002 3 11.5002H4H4.15139L5.59602 14.918C5.87323 15.5738 6.51607 16 7.22808 16C8.20665 16 8.99994 15.2067 8.99994 14.2281ZM5.5 10.8381L6.97767 14.334C7.0202 14.4346 7.11883 14.5 7.22808 14.5C7.37822 14.5 7.49994 14.3783 7.49994 14.2281L7.49993 11.4999C7.49993 11.102 7.65797 10.7205 7.93927 10.4392C8.22058 10.1579 8.60211 9.99985 8.99993 9.99985L12.4947 9.99985C13.1008 9.99985 13.5676 9.46485 13.4854 8.86426L12.9287 4.7965C12.8271 4.05359 12.1924 3.49988 11.4426 3.49989L5.5 3.49998V10.0002V10.8381ZM3.99994 10.0002H3C2.72386 10.0002 2.5 9.77638 2.5 9.50023V4.00023C2.5 3.72409 2.72386 3.50023 3 3.50023H3.99994L3.99994 10.0002Z',
    })
  );
};
Dislike16.displayName = 'Dislike16';
exports['default'] = Dislike16;
