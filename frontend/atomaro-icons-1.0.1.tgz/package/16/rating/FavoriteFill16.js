'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var FavoriteFill16 = function FavoriteFill16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      d: 'M3 4C3 2.89543 3.89543 2 5 2H11C12.1046 2 13 2.89543 13 4V12.9815C13 13.7346 12.199 14.2174 11.533 13.8657L8 12L4.46697 13.8657C3.80101 14.2174 3 13.7346 3 12.9815V4Z',
    })
  );
};
FavoriteFill16.displayName = 'FavoriteFill16';
exports['default'] = FavoriteFill16;
