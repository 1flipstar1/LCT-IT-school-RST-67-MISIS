'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var Favorite16 = function Favorite16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M8 10.3037L8.70045 10.6736L11.5 12.152V4C11.5 3.72386 11.2761 3.5 11 3.5H5C4.72386 3.5 4.5 3.72386 4.5 4V12.152L7.29955 10.6736L8 10.3037ZM8 12L11.533 13.8657C12.199 14.2174 13 13.7346 13 12.9814V4C13 2.89543 12.1046 2 11 2H5C3.89543 2 3 2.89543 3 4V12.9814C3 13.7346 3.801 14.2174 4.46697 13.8657L8 12Z',
    })
  );
};
Favorite16.displayName = 'Favorite16';
exports['default'] = Favorite16;
