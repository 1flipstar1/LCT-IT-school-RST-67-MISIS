'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var AttentionStroke16 = function AttentionStroke16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M13.5003 8.00065C13.5003 11.0386 11.0376 13.5013 7.99967 13.5013C4.96175 13.5013 2.49902 11.0386 2.49902 8.00065C2.49902 4.96273 4.96175 2.5 7.99967 2.5C11.0376 2.5 13.5003 4.96273 13.5003 8.00065ZM15.0003 8.00065C15.0003 11.867 11.866 15.0013 7.99967 15.0013C4.13332 15.0013 0.999023 11.867 0.999023 8.00065C0.999023 4.1343 4.13332 1 7.99967 1C11.866 1 15.0003 4.1343 15.0003 8.00065ZM8.60577 9.20667H7.39365L7.19971 6.77714V4H8.79971V6.77714L8.60577 9.20667ZM8.79971 12H7.19971V10.4H8.79971V12Z',
    })
  );
};
AttentionStroke16.displayName = 'AttentionStroke16';
exports['default'] = AttentionStroke16;
