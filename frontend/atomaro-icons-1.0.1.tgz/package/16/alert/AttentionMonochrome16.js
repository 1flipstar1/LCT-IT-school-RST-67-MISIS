'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var AttentionMonochrome16 = function AttentionMonochrome16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      opacity: '0.1',
      d: 'M15.0003 8.00065C15.0003 11.867 11.866 15.0013 7.99967 15.0013C4.13332 15.0013 0.999023 11.867 0.999023 8.00065C0.999023 4.1343 4.13332 1 7.99967 1C11.866 1 15.0003 4.1343 15.0003 8.00065Z',
      fill: '#F29100',
    }),
    ',',
    react_1['default'].createElement('path', {
      d: 'M7.39365 9.20667H8.60577L8.79971 6.77714V4H7.19971V6.77714L7.39365 9.20667Z',
      fill: '#F29100',
    }),
    ',',
    react_1['default'].createElement('path', {
      d: 'M7.19971 12H8.79971V10.4H7.19971V12Z',
      fill: '#F29100',
    })
  );
};
AttentionMonochrome16.displayName = 'AttentionMonochrome16';
exports['default'] = AttentionMonochrome16;
