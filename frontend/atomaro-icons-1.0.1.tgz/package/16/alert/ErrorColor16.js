'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var ErrorColor16 = function ErrorColor16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      opacity: '0.7',
      d: 'M15 8C15 11.866 11.866 15 8 15C4.13401 15 1 11.866 1 8C1 4.13401 4.13401 1 8 1C11.866 1 15 4.13401 15 8Z',
      fill: '#D91528',
    }),
    ',',
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M8.00078 9.06164L5.70118 11.3612L4.6418 10.2993L6.9401 8.001L4.64268 5.70367L5.70204 4.64171L8.00077 6.94035L10.2987 4.64245L11.3581 5.7044L9.06145 8.00099L11.359 10.2985L10.2996 11.3604L8.00078 9.06164Z',
      fill: 'white',
    })
  );
};
ErrorColor16.displayName = 'ErrorColor16';
exports['default'] = ErrorColor16;
