'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var HelpMonochrome16 = function HelpMonochrome16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      opacity: '0.1',
      d: 'M15 8C15 11.866 11.866 15 8 15C4.13401 15 1 11.866 1 8C1 4.13401 4.13401 1 8 1C11.866 1 15 4.13401 15 8Z',
      fill: '#0055FF',
    }),
    ',',
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M8.79806 9.5H7.19806V9.42969C7.19806 8.74622 7.50056 8.25585 8.24005 7.66202C8.97954 7.06819 9.29633 6.80109 9.29633 6.22967C9.29633 5.64704 8.73421 5.33203 8.13108 5.33203C7.52795 5.33203 6.89575 5.67446 6.89575 6.36913C6.89575 6.51479 6.94904 6.74166 6.99386 6.8537L5.6746 7.14C5.57376 6.92712 5.46997 6.59941 5.46997 6.26328C5.46997 5.14284 6.49524 4 8.09747 4C9.7221 4 10.7363 4.86274 10.7363 6.12883C10.7363 7.02517 10.4879 7.49291 9.36751 8.45648C8.96416 8.80382 8.79806 9.00701 8.79806 9.5ZM8.79806 11.9999H7.19806V10.4H8.79806V11.9999Z',
      fill: '#0055FF',
    })
  );
};
HelpMonochrome16.displayName = 'HelpMonochrome16';
exports['default'] = HelpMonochrome16;
