'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var HelpStroke16 = function HelpStroke16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M13.5013 8.00065C13.5013 11.0386 11.0386 13.5013 8.00065 13.5013C4.96273 13.5013 2.5 11.0386 2.5 8.00065C2.5 4.96273 4.96273 2.5 8.00065 2.5C11.0386 2.5 13.5013 4.96273 13.5013 8.00065ZM15.0013 8.00065C15.0013 11.867 11.867 15.0013 8.00065 15.0013C4.1343 15.0013 1 11.867 1 8.00065C1 4.1343 4.1343 1 8.00065 1C11.867 1 15.0013 4.1343 15.0013 8.00065ZM7.19806 9.5H8.79806C8.79806 9.00701 8.96416 8.80382 9.36751 8.45648C10.4879 7.49291 10.7363 7.02518 10.7363 6.12883C10.7363 4.86274 9.7221 4 8.09747 4C6.49524 4 5.46997 5.14284 5.46997 6.26328C5.46997 6.59941 5.57376 6.92712 5.6746 7.14L6.99386 6.8537C6.94904 6.74166 6.89575 6.51479 6.89575 6.36913C6.89575 5.67446 7.52795 5.33203 8.13108 5.33203C8.73421 5.33203 9.29633 5.64704 9.29633 6.22967C9.29633 6.80109 8.97954 7.06819 8.24005 7.66202C7.50056 8.25585 7.19806 8.74622 7.19806 9.42969V9.5ZM7.19806 11.9999H8.79806V10.4H7.19806V11.9999Z',
    })
  );
};
HelpStroke16.displayName = 'HelpStroke16';
exports['default'] = HelpStroke16;
