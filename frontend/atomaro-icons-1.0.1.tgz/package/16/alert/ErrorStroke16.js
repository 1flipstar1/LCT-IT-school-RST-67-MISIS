'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var ErrorStroke16 = function ErrorStroke16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M8 13.499C11.0376 13.499 13.5 11.0365 13.5 7.99898C13.5 4.96142 11.0376 2.49898 8 2.49898C4.96243 2.49898 2.5 4.96142 2.5 7.99898C2.5 11.0365 4.96243 13.499 8 13.499ZM8 14.999C11.866 14.999 15 11.865 15 7.99898C15 4.13299 11.866 0.998982 8 0.998982C4.13401 0.998982 1 4.13299 1 7.99898C1 11.865 4.13401 14.999 8 14.999ZM9.06144 7.99996L11.359 10.2974L10.2996 11.3594L8.00077 9.06061L5.70116 11.3602L4.64179 10.2982L6.94009 7.99997L4.64267 5.70264L5.70203 4.64067L8.00076 6.93932L10.2987 4.64142L11.3581 5.70337L9.06144 7.99996Z',
    })
  );
};
ErrorStroke16.displayName = 'ErrorStroke16';
exports['default'] = ErrorStroke16;
