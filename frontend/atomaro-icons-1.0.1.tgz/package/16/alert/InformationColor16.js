'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var InformationColor16 = function InformationColor16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      opacity: '0.7',
      d: 'M15 8C15 11.866 11.866 15 8 15C4.13401 15 1 11.866 1 8C1 4.13401 4.13401 1 8 1C11.866 1 15 4.13401 15 8Z',
      fill: '#1998FF',
    }),
    ',',
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M8.96593 5.848L7.03393 5.848L7.03394 4L8.96593 4L8.96593 5.848ZM8.50195 7L7 7L7 8.5L7.50196 8.5L7.50196 10.5L7 10.5L7 12L9.5 12L9.5 10.5L9.00195 10.5L9.00195 7.5C9.00195 7.22386 8.7781 7 8.50195 7Z',
      fill: 'white',
    })
  );
};
InformationColor16.displayName = 'InformationColor16';
exports['default'] = InformationColor16;
