"use strict";

var __importDefault = this && this.__importDefault || function (mod) {
  return mod && mod.__esModule ? mod : {
    "default": mod
  };
};
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.TimeStroke16 = exports.TimeMonochrome16 = exports.TimeColor16 = exports.StopStroke16 = exports.SkipStroke16 = exports.SkipMonochrome16 = exports.SkipColor16 = exports.OkStroke16 = exports.OkMonochrome16 = exports.OkColor16 = exports.NoneStroke16 = exports.NoneMonochrome16 = exports.NoneColor16 = exports.InformationStroke16 = exports.InformationMonochrome16 = exports.InformationColor16 = exports.HelpStroke16 = exports.HelpMonochrome16 = exports.HelpColor16 = exports.ErrorStroke16 = exports.ErrorMonochrome16 = exports.ErrorColor16 = exports.AttentionStroke16 = exports.AttentionMonochrome16 = exports.AttentionColor16 = void 0;
var AttentionColor16_1 = require("./AttentionColor16");
Object.defineProperty(exports, "AttentionColor16", {
  enumerable: true,
  get: function get() {
    return __importDefault(AttentionColor16_1)["default"];
  }
});
var AttentionMonochrome16_1 = require("./AttentionMonochrome16");
Object.defineProperty(exports, "AttentionMonochrome16", {
  enumerable: true,
  get: function get() {
    return __importDefault(AttentionMonochrome16_1)["default"];
  }
});
var AttentionStroke16_1 = require("./AttentionStroke16");
Object.defineProperty(exports, "AttentionStroke16", {
  enumerable: true,
  get: function get() {
    return __importDefault(AttentionStroke16_1)["default"];
  }
});
var ErrorColor16_1 = require("./ErrorColor16");
Object.defineProperty(exports, "ErrorColor16", {
  enumerable: true,
  get: function get() {
    return __importDefault(ErrorColor16_1)["default"];
  }
});
var ErrorMonochrome16_1 = require("./ErrorMonochrome16");
Object.defineProperty(exports, "ErrorMonochrome16", {
  enumerable: true,
  get: function get() {
    return __importDefault(ErrorMonochrome16_1)["default"];
  }
});
var ErrorStroke16_1 = require("./ErrorStroke16");
Object.defineProperty(exports, "ErrorStroke16", {
  enumerable: true,
  get: function get() {
    return __importDefault(ErrorStroke16_1)["default"];
  }
});
var HelpColor16_1 = require("./HelpColor16");
Object.defineProperty(exports, "HelpColor16", {
  enumerable: true,
  get: function get() {
    return __importDefault(HelpColor16_1)["default"];
  }
});
var HelpMonochrome16_1 = require("./HelpMonochrome16");
Object.defineProperty(exports, "HelpMonochrome16", {
  enumerable: true,
  get: function get() {
    return __importDefault(HelpMonochrome16_1)["default"];
  }
});
var HelpStroke16_1 = require("./HelpStroke16");
Object.defineProperty(exports, "HelpStroke16", {
  enumerable: true,
  get: function get() {
    return __importDefault(HelpStroke16_1)["default"];
  }
});
var InformationColor16_1 = require("./InformationColor16");
Object.defineProperty(exports, "InformationColor16", {
  enumerable: true,
  get: function get() {
    return __importDefault(InformationColor16_1)["default"];
  }
});
var InformationMonochrome16_1 = require("./InformationMonochrome16");
Object.defineProperty(exports, "InformationMonochrome16", {
  enumerable: true,
  get: function get() {
    return __importDefault(InformationMonochrome16_1)["default"];
  }
});
var InformationStroke16_1 = require("./InformationStroke16");
Object.defineProperty(exports, "InformationStroke16", {
  enumerable: true,
  get: function get() {
    return __importDefault(InformationStroke16_1)["default"];
  }
});
var NoneColor16_1 = require("./NoneColor16");
Object.defineProperty(exports, "NoneColor16", {
  enumerable: true,
  get: function get() {
    return __importDefault(NoneColor16_1)["default"];
  }
});
var NoneMonochrome16_1 = require("./NoneMonochrome16");
Object.defineProperty(exports, "NoneMonochrome16", {
  enumerable: true,
  get: function get() {
    return __importDefault(NoneMonochrome16_1)["default"];
  }
});
var NoneStroke16_1 = require("./NoneStroke16");
Object.defineProperty(exports, "NoneStroke16", {
  enumerable: true,
  get: function get() {
    return __importDefault(NoneStroke16_1)["default"];
  }
});
var OkColor16_1 = require("./OkColor16");
Object.defineProperty(exports, "OkColor16", {
  enumerable: true,
  get: function get() {
    return __importDefault(OkColor16_1)["default"];
  }
});
var OkMonochrome16_1 = require("./OkMonochrome16");
Object.defineProperty(exports, "OkMonochrome16", {
  enumerable: true,
  get: function get() {
    return __importDefault(OkMonochrome16_1)["default"];
  }
});
var OkStroke16_1 = require("./OkStroke16");
Object.defineProperty(exports, "OkStroke16", {
  enumerable: true,
  get: function get() {
    return __importDefault(OkStroke16_1)["default"];
  }
});
var SkipColor16_1 = require("./SkipColor16");
Object.defineProperty(exports, "SkipColor16", {
  enumerable: true,
  get: function get() {
    return __importDefault(SkipColor16_1)["default"];
  }
});
var SkipMonochrome16_1 = require("./SkipMonochrome16");
Object.defineProperty(exports, "SkipMonochrome16", {
  enumerable: true,
  get: function get() {
    return __importDefault(SkipMonochrome16_1)["default"];
  }
});
var SkipStroke16_1 = require("./SkipStroke16");
Object.defineProperty(exports, "SkipStroke16", {
  enumerable: true,
  get: function get() {
    return __importDefault(SkipStroke16_1)["default"];
  }
});
var StopStroke16_1 = require("./StopStroke16");
Object.defineProperty(exports, "StopStroke16", {
  enumerable: true,
  get: function get() {
    return __importDefault(StopStroke16_1)["default"];
  }
});
var TimeColor16_1 = require("./TimeColor16");
Object.defineProperty(exports, "TimeColor16", {
  enumerable: true,
  get: function get() {
    return __importDefault(TimeColor16_1)["default"];
  }
});
var TimeMonochrome16_1 = require("./TimeMonochrome16");
Object.defineProperty(exports, "TimeMonochrome16", {
  enumerable: true,
  get: function get() {
    return __importDefault(TimeMonochrome16_1)["default"];
  }
});
var TimeStroke16_1 = require("./TimeStroke16");
Object.defineProperty(exports, "TimeStroke16", {
  enumerable: true,
  get: function get() {
    return __importDefault(TimeStroke16_1)["default"];
  }
});