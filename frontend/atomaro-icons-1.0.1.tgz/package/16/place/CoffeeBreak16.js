'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var CoffeeBreak16 = function CoffeeBreak16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M7.49302 2.12336C7.43933 2.94579 7.22714 3.87281 6.75023 4.99672L5.3694 4.41078C5.79115 3.41688 5.95513 2.6548 5.99621 2.02564C6.03734 1.39555 5.95817 0.862653 5.84898 0.300786L7.32144 0.0146484C7.4392 0.620632 7.54665 1.30184 7.49302 2.12336ZM4.60867 7.5L4.9121 11.1251C4.97715 11.9024 5.62695 12.5 6.40687 12.5H9.59312C10.373 12.5 11.0228 11.9024 11.0879 11.1251L11.3913 7.5H4.60867ZM3.0009 6.27519L3.41733 11.2503C3.54743 12.8047 4.84703 14 6.40687 14H9.59312C11.153 14 12.4526 12.8047 12.5827 11.2503L12.9991 6.27519C13.0115 6.12707 12.8946 6 12.746 6H3.25402C3.10538 6 2.9885 6.12707 3.0009 6.27519ZM9.85875 4.99577C10.2166 4.11408 10.4092 3.31622 10.4872 2.57883L8.99549 2.42114C8.93325 3.00986 8.7775 3.67125 8.46887 4.43165L9.85875 4.99577Z',
    })
  );
};
CoffeeBreak16.displayName = 'CoffeeBreak16';
exports['default'] = CoffeeBreak16;
