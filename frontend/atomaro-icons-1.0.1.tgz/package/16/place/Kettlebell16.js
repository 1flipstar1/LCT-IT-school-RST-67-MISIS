'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var Kettlebell16 = function Kettlebell16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M10.3282 1.36437C8.82388 0.879246 7.19982 0.879736 5.69572 1.36065C4.08382 1.87603 3.15692 3.57756 3.61451 5.21269L4.11945 7.01703C3.11915 7.96226 2.50003 9.27053 2.50003 10.716C2.50003 12.4898 3.25997 14.0433 4.49987 15.0002H11.4999C12.7275 14.0581 13.5 12.4898 13.5 10.716C13.5 9.26785 12.8786 7.95739 11.875 7.01176L12.3847 5.19591C12.8401 3.57363 11.9319 1.88151 10.3282 1.36437ZM10.5726 6.10127L10.9405 4.79053C11.1781 3.94434 10.7043 3.06172 9.86786 2.79197C8.66307 2.40345 7.35974 2.40341 6.15254 2.78939C5.30397 3.06071 4.82045 3.95598 5.05902 4.80845L5.42163 6.10419C6.19067 5.71612 7.06829 5.49624 8.00003 5.49624C8.92942 5.49624 9.80497 5.71502 10.5726 6.10127ZM4.00003 10.716C4.00003 8.73459 5.71602 6.99624 8.00003 6.99624C10.284 6.99624 12 8.73459 12 10.716C12 11.8623 11.5754 12.8416 10.9347 13.5002H5.06579C4.41681 12.8348 4.00003 11.8639 4.00003 10.716Z',
    })
  );
};
Kettlebell16.displayName = 'Kettlebell16';
exports['default'] = Kettlebell16;
