'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var IconStatic16_1 = __importDefault(require('../../IconStatic16'));
var DarkTheme16 = function DarkTheme16(props) {
  return react_1['default'].createElement(
    IconStatic16_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      'clip-rule': 'evenodd',
      d: 'M1.93109 11.4907C1.80214 11.267 1.98566 11.0002 2.24385 11.0002C5.58792 11.0002 8.48769 8.16384 8.48769 4.7564C8.48769 3.67227 8.204 2.5976 7.66593 1.65802C7.50332 1.37408 7.67277 1 7.99997 1C11.7496 1 15 4.18124 15 8C15 11.866 11.866 15 7.99997 15C5.51859 15 3.16225 13.6266 1.93109 11.4907ZM4.43261 12.1866C5.39379 13.0065 6.63965 13.5 7.99997 13.5C11.0375 13.5 13.5 11.0376 13.5 8C13.5 5.56772 11.9211 3.50421 9.7324 2.7784C9.89901 3.41047 9.98769 4.07362 9.98769 4.7564C9.98769 8.27307 7.64356 11.2422 4.43261 12.1866Z',
    })
  );
};
DarkTheme16.displayName = 'DarkTheme16';
exports['default'] = DarkTheme16;
