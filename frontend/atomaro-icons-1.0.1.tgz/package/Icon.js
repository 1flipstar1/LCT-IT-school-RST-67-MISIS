'use strict';
var PropTypes = require('prop-types');

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __rest =
  (this && this.__rest) ||
  function (s, e) {
    var t = {};
    for (var p in s)
      if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === 'function')
      for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
          t[p[i]] = s[p[i]];
      }
    return t;
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var constants_1 = require('./constants');
var styles_1 = require('./styles');
var Icon = function Icon(props) {
  var _a = props.size,
    size = _a === void 0 ? constants_1.DEFAULT_ICON_SIZE : _a,
    _b = props.viewBox,
    viewBox = _b === void 0 ? '0 0 24 24' : _b,
    children = props.children,
    restProps = __rest(props, ['size', 'viewBox', 'children']);
  var sizeStr = size <= 1 ? ''.concat(size * 100, '%') : size;
  return react_1['default'].createElement(
    styles_1.StyledSVG,
    __assign(
      {
        width: sizeStr,
        height: sizeStr,
        viewBox: viewBox,
        'aria-hidden': 'true',
        xmlns: 'http://www.w3.org/2000/svg',
      },
      restProps
    ),
    children
  );
};

Icon.propTypes = {
  children: PropTypes.node,
  /**
   * Задает размер иконки
   * если <= 1 то задается в процентах (например 0,5 - 50%)
   *  @default 24
   */
  size: PropTypes.number,
  /**
   * Задает viewBox
   *  @default "0 0 24 24"
   */
  viewBox: PropTypes.string,
};

Icon.displayName = 'Icon';
exports['default'] = Icon;
