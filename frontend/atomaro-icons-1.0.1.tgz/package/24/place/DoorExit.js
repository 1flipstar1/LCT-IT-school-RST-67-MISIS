'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var DoorExit = function DoorExit(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M7 3.5H17C17.2761 3.5 17.5 3.72386 17.5 4V20C17.5 20.2761 17.2761 20.5 17 20.5H7C6.72386 20.5 6.5 20.2761 6.5 20V12.749H10.4401L8.71431 14.4748L9.77497 15.5354L12.7802 12.5302C13.0731 12.2374 13.0731 11.7625 12.7802 11.4696L9.77496 8.46435L8.7143 9.52502L10.4382 11.249H6.5V4C6.5 3.72386 6.72386 3.5 7 3.5ZM5 11.249V4C5 2.89543 5.89543 2 7 2H17C18.1046 2 19 2.89543 19 4V20C19 21.1046 18.1046 22 17 22H7C5.89543 22 5 21.1046 5 20V12.749H3V11.249H5Z',
    })
  );
};
DoorExit.displayName = 'DoorExit';
exports['default'] = DoorExit;
