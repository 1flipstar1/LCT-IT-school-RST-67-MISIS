'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Backyard = function Backyard(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M14.0029 3.5H16.0029C17.9359 3.5 19.5029 5.067 19.5029 7V14C19.5029 15.8925 18.0009 17.4342 16.124 17.4979C16.0095 17.3554 15.8855 17.2208 15.7529 17.0953V11.8107L18.5333 9.03033L17.4726 7.96967L15.7529 9.68934V7H14.2529V12.6893L12.5333 10.9697L11.4726 12.0303L14.2529 14.8107V16.1992C13.8597 16.0699 13.4395 16 13.0029 16C12.9187 16 12.8351 16.0026 12.7521 16.0077C12.1639 15.2928 11.3988 14.729 10.5237 14.3831C10.51 14.2573 10.5029 14.1295 10.5029 14V7C10.5029 5.067 12.0699 3.5 14.0029 3.5ZM9.00298 14.0224C9.00295 14.015 9.00293 14.0075 9.00293 14V7C9.00293 4.23858 11.2415 2 14.0029 2H16.0029C18.7644 2 21.0029 4.23858 21.0029 7V14C21.0029 16.4701 19.2118 18.5218 16.8575 18.9273C16.9523 19.2687 17.0029 19.6284 17.0029 20C17.0029 20.1707 16.9922 20.3389 16.9715 20.5039H21.0029V22.0039H3.00293V22V20.5039V20.5V19.5C3.00293 16.4624 5.46536 14 8.50293 14C8.67149 14 8.83828 14.0076 9.00298 14.0224ZM11.5938 16.9608L12.0804 17.5522L12.8448 17.5049C12.8969 17.5016 12.9497 17.5 13.0029 17.5C14.3836 17.5 15.5029 18.6193 15.5029 20C15.5029 20.1718 15.4858 20.3389 15.4532 20.5H4.50293V19.5C4.50293 17.2909 6.29379 15.5 8.50293 15.5C9.74713 15.5 10.8578 16.0663 11.5938 16.9608Z',
    })
  );
};
Backyard.displayName = 'Backyard';
exports['default'] = Backyard;
