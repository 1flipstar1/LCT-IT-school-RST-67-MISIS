'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Door = function Door(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M17 20.5L7 20.5C6.72386 20.5 6.5 20.2761 6.5 20L6.5 4C6.5 3.72386 6.72386 3.5 7 3.5L17 3.5C17.2761 3.5 17.5 3.72386 17.5 4L17.5 20C17.5 20.2761 17.2761 20.5 17 20.5ZM19 20C19 21.1046 18.1046 22 17 22L7 22C5.89543 22 5 21.1046 5 20L5 4C5 2.89543 5.89543 2 7 2L17 2C18.1046 2 19 2.89543 19 4L19 20ZM9.50977 14L9.50977 10L8.00977 10L8.00977 14L9.50977 14Z',
    })
  );
};
Door.displayName = 'Door';
exports['default'] = Door;
