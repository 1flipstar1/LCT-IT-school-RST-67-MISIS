'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var BrushRepair = function BrushRepair(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M15.9755 5.43026L16.1368 4.60213L15.5133 4.03401L15.0227 3.587C14.043 2.69427 12.5081 2.838 11.711 3.8971L6.32353 11.0551C5.71752 11.8603 5.80491 12.9908 6.52746 13.6931L6.73368 13.8936L4.0655 16.0003C2.76855 17.0243 2.63545 18.9433 3.77861 20.1367C4.95051 21.3601 6.93138 21.2704 7.98793 19.946L10.1158 17.2788L10.238 17.4048C10.9381 18.1268 12.0653 18.2164 12.8706 17.6139L20.0974 12.2072C21.1844 11.394 21.3094 9.81026 20.3634 8.83649L17.5721 5.96311L16.8307 5.19989L15.9398 5.61331L15.9755 5.43026ZM15.4631 7.48838L15.5856 7.43155L16.4967 7.00876L19.288 9.88213C19.6033 10.2067 19.5616 10.7346 19.1993 11.0057L14.9774 14.1643L9.77671 8.96128L12.909 4.79958C13.1747 4.44654 13.6863 4.39864 14.0129 4.69621L14.5035 5.14322L14.26 6.39277L14.2342 6.52532L14.0655 7.39133L13.9995 7.73023C13.9604 7.93059 14.1649 8.0908 14.35 8.00491L14.6631 7.85963L15.4631 7.48838ZM8.86572 10.1717L7.52155 11.9576C7.37005 12.1589 7.39189 12.4415 7.57253 12.6171L8.80157 13.8118C8.8765 13.8847 8.89526 13.9917 8.86048 14.0817C8.84496 14.1218 8.81881 14.1586 8.78223 14.1875L8.6817 14.2668L4.99456 17.178C4.39236 17.6535 4.33056 18.5445 4.86135 19.0987C5.40549 19.6667 6.32525 19.625 6.81583 19.0101L9.74626 15.3369L9.82906 15.2331C9.85783 15.197 9.89429 15.1712 9.93404 15.1559C10.0241 15.1211 10.131 15.1399 10.2038 15.215L11.3143 16.3601C11.4894 16.5406 11.7712 16.563 11.9725 16.4124L13.764 15.0721L8.86572 10.1717Z',
    })
  );
};
BrushRepair.displayName = 'BrushRepair';
exports['default'] = BrushRepair;
