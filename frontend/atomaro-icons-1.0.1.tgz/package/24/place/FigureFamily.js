'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var FigureFamily = function FigureFamily(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M8.5 6.5C9.32843 6.5 10 5.82843 10 5C10 4.17157 9.32843 3.5 8.5 3.5C7.67157 3.5 7 4.17157 7 5C7 5.82843 7.67157 6.5 8.5 6.5ZM8.5 8C10.1569 8 11.5 6.65685 11.5 5C11.5 3.34315 10.1569 2 8.5 2C6.84315 2 5.5 3.34315 5.5 5C5.5 6.65685 6.84315 8 8.5 8ZM16 9.5C16.5523 9.5 17 9.05228 17 8.5C17 7.94772 16.5523 7.5 16 7.5C15.4477 7.5 15 7.94772 15 8.5C15 9.05228 15.4477 9.5 16 9.5ZM16 11C17.3807 11 18.5 9.88071 18.5 8.5C18.5 7.11929 17.3807 6 16 6C14.6193 6 13.5 7.11929 13.5 8.5C13.5 9.88071 14.6193 11 16 11ZM15.0032 20V16H13.5032V17V20C13.5032 21.1046 14.3986 22 15.5032 22H16.5032C17.6077 22 18.5032 21.1046 18.5032 20V18L20.0032 17L19.4029 14.0082C19.1686 12.8404 18.1429 12 16.9518 12H14.0492C14.0337 12 14.0182 11.9999 14.0028 11.9996L11.8819 9.8787C11.3193 9.31608 10.5563 9 9.7606 9H7.0604C5.81908 9 4.70597 9.76448 4.26036 10.9231L2.5 15.5L5.50326 17V20C5.50326 21.1046 6.39869 22 7.50326 22L9.50326 22C10.6078 22 11.5033 21.1046 11.5033 20V17V16H10.0033V20C10.0033 20.2761 9.7794 20.5 9.50326 20.5L7.50326 20.5C7.22712 20.5 7.00326 20.2761 7.00326 20V17V16.0725L6.1735 15.6581L4.38911 14.7668L5.66038 11.4615C5.88318 10.8822 6.43974 10.5 7.0604 10.5H9.7606C10.1584 10.5 10.54 10.658 10.8213 10.9394L12.9421 13.0602L13.37 13.4881L13.975 13.4993C13.9997 13.4998 14.0244 13.5 14.0492 13.5H16.9518C17.4282 13.5 17.8385 13.8361 17.9322 14.3033L18.3347 16.3095L17.6711 16.7519L17.0032 17.1972V18V20C17.0032 20.2761 16.7793 20.5 16.5032 20.5H15.5032C15.227 20.5 15.0032 20.2761 15.0032 20Z',
    })
  );
};
FigureFamily.displayName = 'FigureFamily';
exports['default'] = FigureFamily;
