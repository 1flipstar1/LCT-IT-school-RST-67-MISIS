'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var EscalatorUp = function EscalatorUp(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M4.03031 4.5L6.46973 4.5L3 7.96967L4.06065 9.03034L7.53034 5.56071L7.53034 8.00001H9.03034L9.03034 3.75C9.03034 3.33579 8.69456 3.00001 8.28034 3L4.03031 3L4.03031 4.5ZM18.0015 15H16.2515L9.65146 21H6.00147C3.79233 21 2.00146 19.2091 2.00146 17C2.00146 14.7909 3.79233 13 6.00146 13H7.75146L14.3515 7H18.0015C20.2106 7 22.0015 8.79086 22.0015 11C22.0015 13.2091 20.2106 15 18.0015 15ZM6.00147 19.5H9.07155L15.2425 13.8901L15.6716 13.5H16.2515H18.0015C19.3822 13.5 20.5015 12.3807 20.5015 11C20.5015 9.61929 19.3822 8.5 18.0015 8.5H14.9314L8.76047 14.1099L8.33138 14.5H7.75146H6.00146C4.62075 14.5 3.50146 15.6193 3.50146 17C3.50146 18.3807 4.62075 19.5 6.00147 19.5Z',
    })
  );
};
EscalatorUp.displayName = 'EscalatorUp';
exports['default'] = EscalatorUp;
