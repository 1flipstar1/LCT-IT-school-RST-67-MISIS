'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var City = function City(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M12.5029 4.96673V16.2908C11.1849 16.8243 10.2159 18.04 10.0339 19.5L9.00293 19.5002L5.50293 19.5V8.20668L12.5029 4.96673ZM16.6523 17.0031C15.9467 16.3789 15.0191 16 14.0029 16L14.0029 3.40196C14.0029 3.03683 13.6243 2.79484 13.2929 2.94821L4.58289 6.97964C4.22927 7.14331 4.00293 7.49748 4.00293 7.88714V19.5002H2.00293V21.0003H22.0029V19.5002H19.8581C19.6603 18.8357 19.2704 18.2537 18.7529 17.8189V15.4055C20.0469 15.0725 21.0029 13.8979 21.0029 12.5V10C21.0029 8.34315 19.6598 7 18.0029 7C16.3461 7 15.0029 8.34315 15.0029 10V12.5C15.0029 13.8979 15.959 15.0725 17.2529 15.4055V17.0805C17.0583 17.0381 16.8576 17.0118 16.6523 17.0031ZM9.50293 10.0002H11.0029V11.5002H9.50293H8.50293H7.00293V10.0002H8.50293H9.50293ZM11.0027 13.0003H9.5027H8.5027H7.0027V14.5003H8.5027H9.5027H11.0027V13.0003ZM8.50269 16.0004H9.50293V17.5004H8.50269H8.00293H7.00269V16.0004H8.00293H8.50269ZM16.0573 18.4795L15.6584 18.1266C15.2165 17.7356 14.639 17.5 14.0029 17.5C12.7935 17.5 11.7846 18.3589 11.5529 19.5H18.2353C17.9029 18.9254 17.293 18.5314 16.5894 18.5018L16.0573 18.4795ZM19.5029 10V12.5C19.5029 13.3284 18.8314 14 18.0029 14C17.1745 14 16.5029 13.3284 16.5029 12.5V10C16.5029 9.17157 17.1745 8.5 18.0029 8.5C18.8314 8.5 19.5029 9.17157 19.5029 10Z',
    })
  );
};
City.displayName = 'City';
exports['default'] = City;
