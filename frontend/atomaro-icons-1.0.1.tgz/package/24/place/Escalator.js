'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Escalator = function Escalator(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M10.502 5.5C11.0542 5.5 11.502 5.05228 11.502 4.5C11.502 3.94772 11.0542 3.5 10.502 3.5C9.94967 3.5 9.50195 3.94772 9.50195 4.5C9.50195 5.05228 9.94967 5.5 10.502 5.5ZM10.502 7C11.8827 7 13.002 5.88071 13.002 4.5C13.002 3.11929 11.8827 2 10.502 2C9.12124 2 8.00195 3.11929 8.00195 4.5C8.00195 5.88071 9.12124 7 10.502 7ZM11.502 10.686V10.5C11.502 9.94772 11.0542 9.5 10.502 9.5C9.94967 9.5 9.50195 9.94772 9.50195 10.5V12.0814L11.502 10.686ZM12.8795 9.72497C12.5533 8.72364 11.6121 8 10.502 8C9.12124 8 8.00195 9.11929 8.00195 10.5V13.1279L7.00977 13.8201C6.84194 13.9372 6.64223 14 6.43759 14H6.00195C3.79281 14 2.00195 15.7909 2.00195 18C2.00195 20.2091 3.79282 22 6.00196 22H8.33759C8.54223 22 8.74194 21.9372 8.90977 21.8201L16.9941 16.1799C17.162 16.0628 17.3617 16 17.5663 16H18.002C20.2111 16 22.002 14.2091 22.002 12C22.002 9.79086 20.2111 8 18.002 8H15.6663C15.4617 8 15.262 8.06278 15.0941 8.17987L12.8795 9.72497ZM7.86604 20.5C8.07068 20.5 8.2704 20.4372 8.43823 20.3201L16.3937 14.7698L16.5226 14.6799C16.6904 14.5628 16.8901 14.5 17.0948 14.5H17.252H18.002C19.3827 14.5 20.502 13.3807 20.502 12C20.502 10.6193 19.3827 9.5 18.002 9.5H16.1379C15.9332 9.5 15.7335 9.56278 15.5657 9.67987L7.61023 15.2302L7.48132 15.3201C7.31349 15.4372 7.11377 15.5 6.90913 15.5H6.75195H6.00195C4.62124 15.5 3.50195 16.6193 3.50195 18C3.50195 19.3807 4.62124 20.5 6.00196 20.5H7.86604Z',
    })
  );
};
Escalator.displayName = 'Escalator';
exports['default'] = Escalator;
