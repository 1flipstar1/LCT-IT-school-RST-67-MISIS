'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Broom = function Broom(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M18.1422 11.1647L16.5047 9.53354L21.9997 4.05992L20.9411 2.99719L15.442 8.47491L13.89 6.92885C12.7162 5.75954 10.813 5.75954 9.63919 6.92885L9.29453 7.27219L9.29076 7.26842C7.42384 9.06763 5.09631 10.3163 2.56482 10.8768L2.15224 10.9681C2.03438 10.9942 1.96842 11.1201 2.01408 11.2319L2.26006 11.8339C2.31626 11.9714 2.37442 12.1078 2.43448 12.2429L2.43448 12.2429C2.4613 12.3033 2.4885 12.3634 2.51607 12.4232L2.51633 12.4238C4.91624 17.6331 10.1716 21 15.945 21C15.9795 21 16.0121 20.9837 16.0327 20.956L16.3976 20.4653C17.4039 19.1121 17.8934 17.444 17.7782 15.7618L17.7874 15.7526L18.1422 15.3992C19.316 14.2299 19.316 12.334 18.1422 11.1647ZM9.21277 9.32821L9.28438 9.39954L13.7317 13.8298L16.2928 16.3905C16.264 17.498 15.9053 18.5754 15.258 19.4823C10.4359 19.2333 6.10701 16.3776 3.99997 12.052C5.89566 11.4831 7.66476 10.5582 9.21277 9.32821ZM14.7957 12.7725L16.7247 14.694L17.0795 14.3406C17.6664 13.7559 17.6664 12.808 17.0795 12.2233L12.8273 7.98747C12.2404 7.40281 11.2888 7.40281 10.7019 7.98747L10.3553 8.33276L14.7957 12.7725Z',
    })
  );
};
Broom.displayName = 'Broom';
exports['default'] = Broom;
