'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Bed = function Bed(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M16.0029 3.5H18.7024L16.1403 6.79349C15.9644 7.0196 15.9327 7.32615 16.0585 7.58349C16.1844 7.84083 16.4458 8.00401 16.7323 8.00401H22V6.50401H18.2659L20.8281 3.21051C21.004 2.98441 21.0357 2.67786 20.9098 2.42052C20.784 2.16318 20.5226 2 20.2361 2H16.0029V3.5ZM11.6991 7.51562H9.00293V6.01562H13.2361C13.5228 6.01562 13.7844 6.17906 13.9101 6.43671C14.0358 6.69436 14.0037 7.00115 13.8273 7.22713L11.2692 10.504H15.0128V12.004H9.73228C9.44559 12.004 9.18398 11.8406 9.05825 11.5829C8.93252 11.3253 8.96467 11.0185 9.14109 10.7925L11.6991 7.51562ZM3.49902 12.5093L3.49902 14H3.5H7.41287C7.02765 13.1223 6.1509 12.5093 5.13096 12.5093H3.49902ZM3.49902 11.0093L3.49902 9H1.99902V22H3H3.49902H3.5V20.0029H20.5V22H22V17C22 15.3431 20.6569 14 19 14H8.99544C8.55158 12.2799 6.98966 11.0093 5.13096 11.0093H3.49902ZM3.5 18.5029H20.5V17C20.5 16.1716 19.8284 15.5 19 15.5H3.5V18.5029Z',
    })
  );
};
Bed.displayName = 'Bed';
exports['default'] = Bed;
