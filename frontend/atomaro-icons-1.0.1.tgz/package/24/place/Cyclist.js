'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Cyclist = function Cyclist(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M15.5 5.5C15.5 6.05228 15.0523 6.5 14.5 6.5C13.9477 6.5 13.5 6.05228 13.5 5.5C13.5 4.94772 13.9477 4.5 14.5 4.5C15.0523 4.5 15.5 4.94772 15.5 5.5ZM17 5.5C17 6.88071 15.8807 8 14.5 8C13.1193 8 12 6.88071 12 5.5C12 4.11929 13.1193 3 14.5 3C15.8807 3 17 4.11929 17 5.5ZM8.5 17C8.5 18.3807 7.38071 19.5 6 19.5C4.61929 19.5 3.5 18.3807 3.5 17C3.5 15.6193 4.61929 14.5 6 14.5C7.38071 14.5 8.5 15.6193 8.5 17ZM10 17C10 19.2091 8.20914 21 6 21C3.79086 21 2 19.2091 2 17C2 14.7908 3.79086 13 6 13C8.20914 13 10 14.7908 10 17ZM18 19.5C19.3807 19.5 20.5 18.3807 20.5 17C20.5 15.6193 19.3807 14.5 18 14.5C16.6193 14.5 15.5 15.6193 15.5 17C15.5 18.3807 16.6193 19.5 18 19.5ZM18 21C20.2091 21 22 19.2091 22 17C22 14.7908 20.2091 13 18 13C15.7909 13 14 14.7908 14 17C14 19.2091 15.7909 21 18 21ZM11.0599 9.94359C11.436 9.56751 12.0407 9.55161 12.436 9.90741L13.5705 10.9285C13.9836 11.3003 14.5198 11.5061 15.0756 11.5061H17V10.0061H15.0756C14.8904 10.0061 14.7116 9.93747 14.5739 9.81352L13.4394 8.79248C12.4511 7.90298 10.9395 7.94272 9.99925 8.88293L8.18066 10.7015C7.87498 11.0072 7.88549 11.5059 8.20374 11.7985L11.2584 14.6063C11.4129 14.7483 11.5009 14.9486 11.5009 15.1585V19.9998H13.0009V15.1585C13.0009 14.5289 12.737 13.9281 12.2735 13.502L9.78707 11.2164L11.0599 9.94359Z',
    })
  );
};
Cyclist.displayName = 'Cyclist';
exports['default'] = Cyclist;
