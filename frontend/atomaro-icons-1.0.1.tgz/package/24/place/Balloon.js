'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Balloon = function Balloon(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M15.4556 13.227C16.4294 11.7476 17.0001 9.78621 17.0001 8C17.0001 5.56749 14.6629 3.5 12.0001 3.5C9.33721 3.5 7 5.56751 7 8C7 9.79116 7.56313 11.754 8.52735 13.2322C9.4953 14.7161 10.707 15.5 11.9795 15.5C13.2548 15.5 14.4776 14.7129 15.4556 13.227ZM12.75 16.936C16.234 16.3506 18.5001 11.8602 18.5001 8C18.5001 4.57203 15.3138 2 12.0001 2C8.68634 2 5.5 4.57203 5.5 8C5.5 11.8751 7.74766 16.3853 11.25 16.9426V17.5C11.25 18.1904 10.6904 18.75 10 18.75H8.5C6.98122 18.75 5.75 19.9812 5.75 21.5V22H7.25V21.5C7.25 20.8096 7.80964 20.25 8.5 20.25H10C11.5188 20.25 12.75 19.0188 12.75 17.5V16.936ZM12 4.48779C14.0125 4.48779 15.5 6.10014 15.5 8H14C14 6.89235 13.1483 5.98779 12 5.98779V4.48779Z',
    })
  );
};
Balloon.displayName = 'Balloon';
exports['default'] = Balloon;
