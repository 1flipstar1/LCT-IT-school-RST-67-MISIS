'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Armchair = function Armchair(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M16 4.5H8C7.17157 4.5 6.5 5.17157 6.5 6V9.06301C7.36261 9.28503 8 10.0681 8 11V12H16V11C16 10.0681 16.6374 9.28503 17.5 9.06301V6C17.5 5.17157 16.8284 4.5 16 4.5ZM19 9V6C19 4.34315 17.6569 3 16 3H8C6.34315 3 5 4.34315 5 6V9H4C2.89543 9 2 9.89543 2 11V20C2 20.5523 2.44772 21 3 21H7C7.55228 21 8 20.5523 8 20H16C16 20.5523 16.4477 21 17 21H21C21.5523 21 22 20.5523 22 20V11C22 9.89543 21.1046 9 20 9H19ZM6.5 11C6.5 10.7239 6.27614 10.5 6 10.5H4C3.72386 10.5 3.5 10.7239 3.5 11V19.5H5.67709C5.26188 19.1335 5 18.5973 5 18V14C5 13.0681 5.63739 12.285 6.5 12.063V11ZM20.5 11C20.5 10.7239 20.2761 10.5 20 10.5H18C17.7239 10.5 17.5 10.7239 17.5 11V12.063C18.3626 12.285 19 13.0681 19 14V18C19 18.5973 18.7381 19.1335 18.3229 19.5H20.5V11ZM7 13.5H17C17.2761 13.5 17.5 13.7239 17.5 14V18C17.5 18.2761 17.2761 18.5 17 18.5H7C6.72386 18.5 6.5 18.2761 6.5 18V14C6.5 13.7239 6.72386 13.5 7 13.5Z',
    })
  );
};
Armchair.displayName = 'Armchair';
exports['default'] = Armchair;
