'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Helicopter = function Helicopter(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M22.0029 6.50366H15.2529V8.00001H13.7529V6.50366H7.00291V5.00366H22.0029V6.50366ZM11.6711 16.5966C10.6779 15.6333 9.3793 13.797 9.0708 10.5H13.7635C13.8441 12.3606 14.3942 13.7383 15.633 14.6127C16.7682 15.4141 18.3574 15.691 20.2908 15.7412C20.212 15.9775 20.1143 16.1968 20.0002 16.3938C19.5837 17.1125 18.9877 17.5 18.1993 17.5H14.8131C13.3929 17.5 12.3342 17.2399 11.6711 16.5966ZM20.5193 14.2457C20.5177 13.9743 20.4943 13.6965 20.447 13.4171C20.2153 12.0492 19.6992 11.3514 19.2614 10.9897C18.8025 10.6104 18.3084 10.5 17.992 10.5H15.2649C15.3422 12.0578 15.7923 12.8892 16.498 13.3873C17.2882 13.9451 18.5546 14.2097 20.5193 14.2457ZM17.992 9.00001L10.003 9.00001H5.00293L4.51539 8.02493C4.20132 7.39679 3.55931 7.00001 2.85703 7.00001C1.83304 7.00001 1.00293 7.83012 1.00293 8.85411V11C1.00293 12.1046 1.89836 13 3.00293 13H4.57588C5.69095 13 6.4162 11.8265 5.91752 10.8292L5.75293 10.5H7.56488C7.88295 14.2465 9.36756 16.452 10.6267 17.6733C11.7225 18.7363 13.2865 19 14.8131 19H18.1993C21.0139 19 22.4058 16 21.926 13.1667C21.3614 9.83334 19.2443 9.00001 17.992 9.00001ZM3.17375 8.69575L4.57588 11.5H3.00293C2.72679 11.5 2.50293 11.2762 2.50293 11V8.85411C2.50293 8.65855 2.66147 8.50001 2.85703 8.50001C2.99116 8.50001 3.11377 8.57579 3.17375 8.69575Z',
    })
  );
};
Helicopter.displayName = 'Helicopter';
exports['default'] = Helicopter;
