'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Breaking = function Breaking(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M12.4736 13.5107V15.0107V16.8111L15.7063 10.4896H13.0263H11.5263V8.98961V7.18915L8.29354 13.5107H10.9736H12.4736ZM6.60878 13.5107L11.5263 3.89469L11.8885 3.18646L12.3257 2.3316L12.4025 2.18135C12.5603 1.87276 13.0263 1.985 13.0263 2.3316V2.50036V3.46051V4.25599V7.48961V8.98961H14.5263H16.4734H16.5236H17.2607H17.7496C17.9364 8.98961 18.0572 9.18709 17.9721 9.35344L17.7496 9.78869L17.4139 10.445L17.3911 10.4896L12.4736 20.1056L12.1114 20.8138L11.6742 21.6687L11.5974 21.8189C11.4396 22.1275 10.9736 22.0153 10.9736 21.6687V21.4999V20.5398V19.7443V16.5107V15.0107H9.47357H7.52645H7.47632H6.73919H6.25033C6.06349 15.0107 5.94268 14.8132 6.02775 14.6468L6.25033 14.2116L6.58595 13.5553L6.60878 13.5107Z',
    })
  );
};
Breaking.displayName = 'Breaking';
exports['default'] = Breaking;
