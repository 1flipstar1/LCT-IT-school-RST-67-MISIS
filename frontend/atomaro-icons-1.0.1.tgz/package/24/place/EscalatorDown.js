'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var EscalatorDown = function EscalatorDown(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M8.00045 7.5301L5.56103 7.53009L9.03076 4.06043L7.97011 2.99976L4.50042 6.46938L4.50042 4.03009H3.00042L3.00042 8.28009C3.00042 8.6943 3.33621 9.03009 3.75042 9.03009L8.00045 9.03009L8.00045 7.5301ZM18.0015 15.0301H16.2515L9.65146 21.0301H6.00147C3.79233 21.0301 2.00146 19.2392 2.00146 17.0301C2.00146 14.821 3.79233 13.0301 6.00146 13.0301H7.75146L14.3515 7.03009H18.0015C20.2106 7.03009 22.0015 8.82096 22.0015 11.0301C22.0015 13.2392 20.2106 15.0301 18.0015 15.0301ZM6.00147 19.5301H9.07155L15.2425 13.9202L15.6716 13.5301H16.2515H18.0015C19.3822 13.5301 20.5015 12.4108 20.5015 11.0301C20.5015 9.64938 19.3822 8.53009 18.0015 8.53009H14.9314L8.76047 14.14L8.33138 14.5301H7.75146H6.00146C4.62075 14.5301 3.50146 15.6494 3.50146 17.0301C3.50146 18.4108 4.62075 19.5301 6.00147 19.5301Z',
    })
  );
};
EscalatorDown.displayName = 'EscalatorDown';
exports['default'] = EscalatorDown;
