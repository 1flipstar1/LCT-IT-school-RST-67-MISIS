'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Cleaver = function Cleaver(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M16.7725 4.57337L21.2472 7.82385C20.3309 9.98973 18.7639 12.2141 17.0401 14.0995C15.4395 15.8502 13.8278 17.1743 12.6449 17.8698L10.6128 15.7649L10.6356 15.7416L8.46098 13.461L16.2558 4.67537C16.3621 4.55557 16.4688 4.51589 16.5425 4.50717C16.6134 4.4988 16.6899 4.51336 16.7725 4.57337ZM7.40887 12.3577L15.129 3.65617C15.7924 2.90847 16.8332 2.78542 17.6256 3.361L22.8856 7.1819C22.9838 7.2532 23.0257 7.39006 22.9837 7.51204C21.1368 12.8692 15.4449 18.4372 12.4912 19.6463C12.4058 19.6812 12.3133 19.6565 12.2463 19.5871L9.58079 16.8261L6.09852 20.4069C5.30796 21.2198 3.99956 21.1913 3.22471 20.3444L2.20179 19.2264C1.9378 18.9378 1.9327 18.4955 2.19004 18.207L6.41307 13.4735L7.40872 12.3575L7.40887 12.3577ZM7.43668 14.5911L3.75573 18.717L4.31226 19.3253C4.50597 19.537 4.83307 19.5441 5.03071 19.3409L8.53241 15.7402L8.4661 15.6715L7.43668 14.5911ZM17.6709 7.06489C17.6709 7.52864 17.3248 7.90458 16.8979 7.90458C16.471 7.90458 16.1249 7.52864 16.1249 7.06489C16.1249 6.60115 16.471 6.22521 16.8979 6.22521C17.3248 6.22521 17.6709 6.60115 17.6709 7.06489Z',
    })
  );
};
Cleaver.displayName = 'Cleaver';
exports['default'] = Cleaver;
