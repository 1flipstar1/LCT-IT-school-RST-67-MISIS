'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Food = function Food(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M16.2791 2C15.1737 2 14.232 2.80299 14.0574 3.89452L13.7205 6H8.25282C8.10525 6 7.98874 6.12534 7.9995 6.27253L8.34522 11H8.00003C5.23861 11 3.00003 13.2386 3.00003 16V17V18.5V19C3.00003 20.6569 4.34318 22 6.00003 22H12.9671H13H17.062C18.634 22 19.9393 20.7866 20.054 19.2188L21.0008 6.27252C21.0115 6.12534 20.895 6 20.7475 6H15.2396L15.5385 4.13151C15.5967 3.76766 15.9106 3.5 16.2791 3.5H19V2H16.2791ZM9.59327 7.5L9.84923 11H11C13.7615 11 16 13.2386 16 16V17V18.5V19C16 19.5464 15.8539 20.0587 15.5987 20.5H17.062C17.848 20.5 18.5007 19.8933 18.558 19.1094L19.407 7.5H9.59327ZM12.9671 20.5H13C13.8285 20.5 14.5 19.8284 14.5 19V18.5H4.50003V19C4.50003 19.8284 5.1716 20.5 6.00003 20.5H12.9671ZM8.00003 12.5H11C12.933 12.5 14.5 14.067 14.5 16V17H4.50003V16C4.50003 14.067 6.06703 12.5 8.00003 12.5Z',
    })
  );
};
Food.displayName = 'Food';
exports['default'] = Food;
