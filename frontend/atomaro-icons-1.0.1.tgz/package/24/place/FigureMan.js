'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var FigureMan = function FigureMan(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M13.5 5C13.5 5.82843 12.8284 6.5 12 6.5C11.1716 6.5 10.5 5.82843 10.5 5C10.5 4.17157 11.1716 3.5 12 3.5C12.8284 3.5 13.5 4.17157 13.5 5ZM15 5C15 6.65685 13.6569 8 12 8C10.3431 8 9 6.65685 9 5C9 3.34315 10.3431 2 12 2C13.6569 2 15 3.34315 15 5ZM16.5 16L15 17V20C15 21.1046 14.1046 22 13 22L11 22C9.89543 22 9 21.1046 9 20V17L7.5 16L7.50941 11.993C7.51329 10.3389 8.85529 9 10.5094 9L13.5 9C15.1569 9 16.5 10.3431 16.5 12L16.5 16ZM9.83205 15.7519L9.00188 15.1985L9.0094 11.9965C9.01134 11.1694 9.68235 10.5 10.5094 10.5H13.5C14.3284 10.5 15 11.1716 15 12V15.1972L14.1679 15.7519L13.5 16.1972V17V20C13.5 20.2761 13.2761 20.5 13 20.5H11C10.7239 20.5 10.5 20.2761 10.5 20V17V16.1972L9.83205 15.7519Z',
    })
  );
};
FigureMan.displayName = 'FigureMan';
exports['default'] = FigureMan;
