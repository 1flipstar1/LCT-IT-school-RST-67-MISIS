'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Clothes = function Clothes(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M11.999 5.49988C11.178 5.49985 10.5105 6.16618 10.5105 6.97914C10.5105 7.41018 10.6985 7.81979 11.0253 8.10081L11.369 8.3963C12.2454 9.14986 12.7496 10.2482 12.7496 11.4041V11.5127L20.441 14.9571C21.389 15.3816 21.9992 16.3234 21.9992 17.3622C21.9992 18.8175 20.8194 19.9974 19.364 19.9974H4.63521C3.17982 19.9974 2 18.8175 2 17.3622C2 16.3234 2.61018 15.3816 3.55818 14.9571L11.2496 11.5127V11.4041C11.2496 10.6853 10.9361 10.0023 10.3911 9.53369L10.0474 9.23819C9.38914 8.67221 9.01048 7.84727 9.01048 6.97914C9.01048 5.32967 10.3577 3.99983 11.9991 3.99988C13.6507 3.99993 15.0061 5.33805 15.0061 6.9977V8.00239H13.5061V6.9977C13.5061 6.17453 12.8303 5.4999 11.999 5.49988ZM11.9996 12.8204L4.17124 16.3261C3.76286 16.509 3.5 16.9147 3.5 17.3622C3.5 17.9891 4.00825 18.4974 4.63521 18.4974H19.364C19.991 18.4974 20.4992 17.9891 20.4992 17.3622C20.4992 16.9147 20.2364 16.509 19.828 16.3261L11.9996 12.8204Z',
    })
  );
};
Clothes.displayName = 'Clothes';
exports['default'] = Clothes;
