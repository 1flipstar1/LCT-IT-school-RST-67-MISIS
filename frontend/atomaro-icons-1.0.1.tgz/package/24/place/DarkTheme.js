'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var DarkTheme = function DarkTheme(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M4.59319 16.4956C4.56174 16.4525 4.53068 16.409 4.50002 16.3653C4.34335 16.1416 4.19719 15.9101 4.06224 15.6715C3.88759 15.3626 4.14516 15 4.50002 15C4.78061 15 5.05759 14.9846 5.33018 14.9546C5.34577 14.9529 5.36134 14.9511 5.3769 14.9493C5.37697 14.9493 5.37703 14.9493 5.37709 14.9493C9.10597 14.5149 12 11.3454 12 7.5C12 6.17374 11.6558 4.92788 11.0518 3.84691C10.8468 3.48008 11.0637 3 11.4839 3C16.1872 3 20 6.80558 20 11.5C20 16.1944 16.1872 20 11.4839 20C8.65285 20 6.14443 18.6211 4.59601 16.4995C4.59507 16.4982 4.59413 16.4969 4.59319 16.4956ZM6.38005 16.3033C7.66008 17.6569 9.47352 18.5 11.4839 18.5C15.3615 18.5 18.5 15.3633 18.5 11.5C18.5 8.17206 16.1711 5.38334 13.0471 4.67431C13.341 5.56391 13.5 6.51426 13.5 7.5C13.5 11.8258 10.4481 15.4388 6.38005 16.3033Z',
    })
  );
};
DarkTheme.displayName = 'DarkTheme';
exports['default'] = DarkTheme;
