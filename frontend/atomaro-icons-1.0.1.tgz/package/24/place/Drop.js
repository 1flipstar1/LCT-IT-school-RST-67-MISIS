'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Drop = function Drop(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M17 14.791C17 12.3944 16.0354 9.97491 12.0025 4.6593C7.96771 9.95662 7 11.931 7 14.791C7 17.3277 9.17308 19.5 12 19.5C14.8269 19.5 17 17.3277 17 14.791ZM18.5 14.791C18.5 11.8179 17.2129 9.01031 13.0073 3.50276C12.4937 2.83025 11.5099 2.83359 10.9959 3.50576C6.81572 8.9728 5.5 11.3289 5.5 14.791C5.5 18.2201 8.41015 21 12 21C15.5899 21 18.5 18.2201 18.5 14.791ZM14.25 14.001C14.25 14.4182 14.0271 14.9955 13.5879 15.4786C13.1578 15.9517 12.597 16.251 12 16.251V17.751C13.1172 17.751 14.0565 17.1931 14.6978 16.4876C15.33 15.7922 15.75 14.8695 15.75 14.001H14.25Z',
    })
  );
};
Drop.displayName = 'Drop';
exports['default'] = Drop;
