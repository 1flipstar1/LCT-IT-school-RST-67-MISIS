'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Barbeque = function Barbeque(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M11.5711 6.45598C11.5238 7.18738 11.3355 8.00849 10.9148 8.99992L9.53397 8.41399C9.8994 7.5528 10.0395 6.89691 10.0743 6.35911C10.1091 5.82031 10.0413 5.36383 9.94616 4.87483C9.92927 4.78804 9.91149 4.70035 9.89345 4.61144C9.7025 3.67011 9.48387 2.59238 10.0126 1L11.4361 1.47264C11.0356 2.67903 11.1833 3.41436 11.3655 4.32151C11.383 4.40866 11.4009 4.49743 11.4185 4.58832C11.5221 5.12069 11.6184 5.72558 11.5711 6.45598ZM14.2418 3.99535C14.5572 5.29012 14.802 6.83693 13.9286 8.98874L12.5387 8.42463C13.2489 6.67476 13.0595 5.47976 12.7844 4.35034L14.2418 3.99535ZM20.003 10H18.503H4.00305C4.00306 10.5126 4.05128 11.0142 4.14343 11.5C4.57272 13.7631 5.9553 15.6888 7.85773 16.8436L6.3066 20.7215L7.69932 21.2785L9.21101 17.4993C10.0802 17.8231 11.021 18 12.003 18C12.985 18 13.9257 17.8231 14.7949 17.4993L16.3066 21.2785L17.6993 20.7215L16.1482 16.8436C18.0506 15.6888 19.4332 13.7631 19.8625 11.5C19.9547 11.0141 20.003 10.5127 20.003 10ZM5.67697 11.5H18.329C17.6518 14.3667 15.0765 16.5 12.003 16.5C8.92941 16.5 6.3541 14.3667 5.67697 11.5Z',
    })
  );
};
Barbeque.displayName = 'Barbeque';
exports['default'] = Barbeque;
