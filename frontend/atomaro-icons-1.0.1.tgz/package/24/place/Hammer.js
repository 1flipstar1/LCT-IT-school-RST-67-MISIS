'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Hammer = function Hammer(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M17.098 8.56172L17.098 8.56174C17.3308 9.05908 17.8002 9.40417 18.3443 9.47798L18.3443 9.47798L18.3602 9.48014L18.3603 9.48014C18.7794 9.53699 19.1691 9.72697 19.4721 10.0221L20.0105 10.5465L17.3056 13.3637C17.1125 13.5647 16.7923 13.5691 16.5938 13.3734L11.8781 8.72348C11.9526 8.45921 11.9881 8.18563 11.9821 7.90821C11.9657 7.14561 11.6387 6.46504 11.1583 5.97652C10.8488 5.66187 10.4575 5.4085 10.0123 5.26171C12.1893 3.82924 15.2454 4.60293 16.4055 7.0819L17.098 8.56172ZM11.075 10.0382L11.0869 10.0499L12.98 11.9166L5.59575 19.305C5.40049 19.5004 5.08336 19.5009 4.8875 19.3061L3.69948 18.1248C3.50371 17.9301 3.50322 17.6141 3.69838 17.4188L11.075 10.0382ZM10.1857 8.80606C11.1897 7.48168 9.43431 5.79036 8.10916 7.08709L8.07128 7.04996L6.99992 5.99971L8.07072 4.94889L8.28782 4.73584C11.1914 1.88641 16.0397 2.76143 17.7641 6.44611L18.4566 7.92593C18.4733 7.96157 18.5069 7.9863 18.5459 7.99159L18.5618 7.99375C19.2995 8.09379 19.9855 8.42816 20.5187 8.94757L21.9181 10.3106C22.032 10.4216 22.0351 10.6037 21.9249 10.7185L18.3875 14.4026C17.6153 15.2068 16.3346 15.2243 15.5407 14.4415L14.0482 12.9698L6.65976 20.3623C5.87875 21.1438 4.61021 21.1457 3.82677 20.3667L2.63875 19.1854C1.85569 18.4067 1.85373 17.1426 2.63436 16.3615L10.1857 8.80606Z',
    })
  );
};
Hammer.displayName = 'Hammer';
exports['default'] = Hammer;
