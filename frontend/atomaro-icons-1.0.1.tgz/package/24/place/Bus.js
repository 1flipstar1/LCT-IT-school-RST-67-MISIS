'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Bus = function Bus(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M5.5022 19V17.5H5.5V13.4267C9.91557 14.1295 14.0844 14.1296 18.5 13.4267V18.4332V18.4826L18.5022 18.5159V19C18.5022 19.2761 18.2783 19.5 18.0022 19.5H15.9913L15.5238 18.4091L15.1341 17.5H14.1451H9.85934H8.87025L8.48062 18.4091L8.0131 19.5H6.0022C5.72606 19.5 5.5022 19.2761 5.5022 19ZM18.5 11.9072C14.0741 12.6361 9.92594 12.636 5.5 11.9072V5C5.5 4.17157 6.17157 3.5 7 3.5H17C17.8284 3.5 18.5 4.17157 18.5 5V11.9072ZM7 2C5.34315 2 4 3.34315 4 5V5.4834C2.92242 5.49566 1.99927 6.36448 1.99927 7.49564V11.0005H3.49927V7.49564C3.49927 7.22418 3.72075 6.99568 4 6.98377V17.5V19H4.0022C4.0022 20.1046 4.89763 21 6.0022 21H8.3428C8.74283 21 9.10437 20.7616 9.26195 20.3939L9.85934 19H14.1451L14.7424 20.3939C14.9 20.7616 15.2616 21 15.6616 21H18.0022C19.1068 21 20.0022 20.1046 20.0022 19V18.5C20.0022 18.4775 20.0015 18.4553 20 18.4332V6.98376C20.2795 6.99537 20.5013 7.22401 20.5013 7.49566V11.0005H22.0013V7.49566C22.0013 6.36428 21.0778 5.49536 20 5.48341V5C20 3.34315 18.6569 2 17 2H7ZM6.5646 14.5027L9.56252 14.7527L9.43787 16.2475L6.43994 15.9975L6.5646 14.5027ZM14.4378 14.7528L17.4399 14.5028L17.5643 15.9976L14.5623 16.2476L14.4378 14.7528Z',
    })
  );
};
Bus.displayName = 'Bus';
exports['default'] = Bus;
