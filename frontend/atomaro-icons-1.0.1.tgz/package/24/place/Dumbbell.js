'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Dumbbell = function Dumbbell(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M7.5 7.5V16.5H6V7.5H7.5ZM8.75 6C8.88807 6 9 6.11193 9 6.25V11.25L15 11.25V6.25C15 6.11193 15.1119 6 15.25 6H19.25C19.3881 6 19.5 6.11193 19.5 6.25V17.75C19.5 17.8881 19.3881 18 19.25 18H15.25C15.1119 18 15 17.8881 15 17.75V12.75L9 12.75V17.75C9 17.8881 8.88807 18 8.75 18H4.75C4.61193 18 4.5 17.8881 4.5 17.75V6.25C4.5 6.11193 4.61193 6 4.75 6H8.75ZM16.5 7.5V16.5H18V7.5H16.5ZM3.53125 9L3.53125 15H2.03125V9H3.53125ZM22.0312 15V9H20.5312V15H22.0312Z',
    })
  );
};
Dumbbell.displayName = 'Dumbbell';
exports['default'] = Dumbbell;
