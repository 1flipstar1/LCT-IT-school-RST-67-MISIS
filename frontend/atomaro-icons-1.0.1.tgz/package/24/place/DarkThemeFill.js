'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var DarkThemeFill = function DarkThemeFill(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M4.50002 15C8.64216 15 12 11.6421 12 7.5C12 6.17374 11.6558 4.92788 11.0518 3.84691C10.8468 3.48008 11.0637 3 11.4839 3C16.1872 3 20 6.80558 20 11.5C20 16.1944 16.1872 20 11.4839 20C8.29944 20 5.52318 18.2554 4.06224 15.6715C3.88759 15.3626 4.14516 15 4.50002 15Z',
    })
  );
};
DarkThemeFill.displayName = 'DarkThemeFill';
exports['default'] = DarkThemeFill;
