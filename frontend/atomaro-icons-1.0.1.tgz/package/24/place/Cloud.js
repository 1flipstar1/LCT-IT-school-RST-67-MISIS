'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Cloud = function Cloud(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M6.42437 11.3731L6.598 10.5085C7.0572 8.2219 9.07919 6.5 11.5 6.5C13.5853 6.5 15.3758 7.77693 16.1257 9.59727L16.4676 10.4273L17.3606 10.5182C19.1235 10.6978 20.5 12.1891 20.5 14C20.5 15.933 18.933 17.5 17 17.5H6.5C4.84315 17.5 3.5 16.1569 3.5 14.5C3.5 13.1645 4.37365 12.0292 5.58444 11.6419L6.42437 11.3731ZM17 19C19.7614 19 22 16.7614 22 14C22 11.4116 20.0332 9.28264 17.5126 9.02596C16.5393 6.66322 14.2139 5 11.5 5C8.35069 5 5.7245 7.23971 5.12736 10.2132C3.31336 10.7936 2 12.4934 2 14.5C2 16.9853 4.01472 19 6.5 19H17Z',
    })
  );
};
Cloud.displayName = 'Cloud';
exports['default'] = Cloud;
