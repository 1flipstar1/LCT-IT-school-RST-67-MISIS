'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var ChristmasTree = function ChristmasTree(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M9.8797 14.7285L10.4683 13.3487L9.08857 12.7602L8.9543 12.7029L12 5.3569L15.0457 12.7029L14.9114 12.7602L13.5317 13.3487L14.1203 14.7285L15.7293 18.4999H12.75V15.9999H11.25V18.4999H8.27072L9.8797 14.7285ZM11.25 19.9999H7.6308H7.60394H6.96447H6.37846C6.19916 19.9999 6.07815 19.8168 6.14851 19.6518L6.37846 19.1128L6.62939 18.5247L6.63993 18.4999L7.91143 15.5196L8.5 14.1399L7.22762 13.5971L7.22419 13.5956C7.10047 13.5406 7.04276 13.3968 7.09478 13.2714L11.1881 3.39864L11.2985 3.13235L11.6732 2.22864L11.7691 1.99739C11.8543 1.79172 12.1457 1.79172 12.2309 1.99739L12.3268 2.22864L12.7015 3.13236L12.8119 3.39864L16.9052 13.2714C16.9572 13.3968 16.8995 13.5406 16.7758 13.5956L16.7724 13.5971L15.5 14.1399L16.0886 15.5196L17.3601 18.4999L17.3706 18.5247L17.6215 19.1128L17.8515 19.6518C17.9219 19.8168 17.8009 19.9999 17.6215 19.9999H17.0355H16.3961H16.3692H12.75V21.9999H11.25V19.9999Z',
    })
  );
};
ChristmasTree.displayName = 'ChristmasTree';
exports['default'] = ChristmasTree;
