'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var CoffeeBreak = function CoffeeBreak(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M10.0284 5.45598C9.98103 6.18737 9.79272 7.00849 9.37202 7.99992L7.9912 7.41399C8.35663 6.5528 8.49669 5.89691 8.53149 5.35911C8.56636 4.82031 8.49854 4.36383 8.40339 3.87483C8.38651 3.78807 8.36873 3.70042 8.3507 3.61155L8.35068 3.61143C8.15972 2.6701 7.9411 1.59238 8.46979 0L9.89338 0.472644C9.49285 1.67903 9.64054 2.41436 9.82275 3.32151C9.84026 3.40867 9.85809 3.49742 9.87577 3.58832C9.97937 4.12069 10.0756 4.72558 10.0284 5.45598ZM5.24448 19.1256L4.60831 11.5009H16.366L15.7298 19.1256C15.6649 19.903 15.0151 20.5009 14.235 20.5009H6.73929C5.95921 20.5009 5.30934 19.903 5.24448 19.1256ZM3.74967 19.2503L3.0009 10.276C2.98854 10.1279 3.10541 10.0009 3.25402 10.0009H17.7203C17.8689 10.0009 17.9857 10.1279 17.9734 10.276L17.8295 12.0008H19C20.1045 12.0008 21 12.8962 21 14.0008V17.0008C21 18.6576 19.6568 20.0008 18 20.0008H17.064C16.65 21.1737 15.5326 22.0009 14.235 22.0009H6.73929C5.17914 22.0009 3.87939 20.8051 3.74967 19.2503ZM17.2871 18.5008H18C18.8284 18.5008 19.5 17.8292 19.5 17.0008V14.0008C19.5 13.7246 19.2761 13.5008 19 13.5008H17.7043L17.2871 18.5008ZM12.3855 7.98874C13.2588 5.83693 13.0141 4.29012 12.6987 2.99535L11.2413 3.35034C11.5164 4.47976 11.7058 5.67476 10.9956 7.42463L12.3855 7.98874Z',
    })
  );
};
CoffeeBreak.displayName = 'CoffeeBreak';
exports['default'] = CoffeeBreak;
