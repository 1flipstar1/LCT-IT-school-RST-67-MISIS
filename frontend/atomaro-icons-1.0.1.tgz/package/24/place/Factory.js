'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Factory = function Factory(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M17.0053 3.44268C14.2413 4.26272 12.563 4.12922 11.0399 3.92199C10.9123 3.90464 10.7867 3.88695 10.6623 3.86944C9.36023 3.68615 8.19209 3.52171 6.34212 3.95116L6.00293 2.49001C8.13077 1.99605 9.53951 2.19542 10.8654 2.38307C10.9915 2.40091 11.1169 2.41866 11.2421 2.43569C12.6227 2.62353 14.0756 2.74728 16.5786 2.00464L17.0053 3.44268ZM7.39197 18.5H4.61451L4.65041 18L5.39961 7.50003H6.60625L7.39197 18.5ZM8.32436 10.5L8.89579 18.5H19.5029V13.5H18.0029H16.5029V12H18.0029H19.5029V10.5H13.9136H8.32436ZM21.0029 12V10.5V9.00003H19.5029H8.21722L8.0361 6.46441C8.01741 6.20275 7.79969 6.00003 7.53737 6.00003H4.46849C4.20617 6.00003 3.98845 6.20275 3.96976 6.46441L3.04119 19.4644L3.04037 19.4786L3.00293 20H3.53992H4.50679H8.46594H19.5029H21.0029V18.5V13.5V12Z',
    })
  );
};
Factory.displayName = 'Factory';
exports['default'] = Factory;
