'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var FigureWoman = function FigureWoman(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M13.4999 5C13.4999 5.82843 12.8284 6.5 11.9999 6.5C11.1715 6.5 10.4999 5.82843 10.4999 5C10.4999 4.17157 11.1715 3.5 11.9999 3.5C12.8284 3.5 13.4999 4.17157 13.4999 5ZM14.9999 5C14.9999 6.65685 13.6568 8 11.9999 8C10.3431 8 8.99994 6.65685 8.99994 5C8.99994 3.34315 10.3431 2 11.9999 2C13.6568 2 14.9999 3.34315 14.9999 5ZM17.5624 16.5L15.0014 18V20C15.0014 21.1046 14.106 22 13.0014 22L11.0014 22C9.89683 22 9.0014 21.1046 9.0014 20V18L6.56244 16.5L8.75473 10.9054C9.20511 9.75613 10.3135 9 11.5479 9H12.4732C13.6902 9 14.7867 9.73524 15.2487 10.8612L17.5624 16.5ZM9.78721 16.7223L8.41668 15.8794L10.1513 11.4527C10.3765 10.8781 10.9307 10.5 11.5479 10.5H12.4732C13.0817 10.5 13.6299 10.8676 13.8609 11.4306L15.6801 15.8641L14.2433 16.7057L13.5014 17.1402V18V20C13.5014 20.2761 13.2775 20.5 13.0014 20.5H11.0014C10.7253 20.5 10.5014 20.2761 10.5014 20V18V17.1615L9.78721 16.7223Z',
    })
  );
};
FigureWoman.displayName = 'FigureWoman';
exports['default'] = FigureWoman;
