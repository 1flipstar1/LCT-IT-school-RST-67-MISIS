'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var BackyardTree = function BackyardTree(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M15.75 13.4441V11.8107L12.9697 9.03033L14.0303 7.96967L15.75 9.68934V7H17.25V9.68934L18.9697 7.96967L20.0303 9.03033L17.25 11.8107V13.4441C19.6556 13.0823 21.5 11.0065 21.5 8.5C21.5 5.73858 19.2614 3.5 16.5 3.5C13.7386 3.5 11.5 5.73858 11.5 8.5C11.5 11.0065 13.3444 13.0823 15.75 13.4441ZM15.75 14.9572C12.5134 14.5853 10 11.8362 10 8.5C10 4.91015 12.9101 2 16.5 2C20.0899 2 23 4.91015 23 8.5C23 11.8362 20.4866 14.5853 17.25 14.9572V22H15.75V14.9572ZM13 15.9946L1 15.9946V17.4946L13 17.4946V15.9946ZM11.75 22V20.0112H13V18.5112H1V20.0112H2.25V22H3.75V20.0112H10.25V22H11.75Z',
    })
  );
};
BackyardTree.displayName = 'BackyardTree';
exports['default'] = BackyardTree;
