'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Administration = function Administration(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M11.2529 4.05071V2H12.7529V4.05071C15.2732 4.39435 17.2503 6.44532 17.4805 9H21.5029C21.7791 9 22.0029 9.22386 22.0029 9.5V19.5C22.0029 19.7761 21.7791 20 21.5029 20H19.0029V18.5H20.5029V10.5H17.4805H16.1096L15.9866 9.13463C15.803 7.09749 14.0887 5.5 12.0029 5.5C9.91719 5.5 8.20287 7.09749 8.0193 9.13463L7.89626 10.5H6.52535H3.50293V18.5H5.00293V20H2.50293C2.22679 20 2.00293 19.7761 2.00293 19.5V9.5C2.00293 9.22386 2.22679 9 2.50293 9H6.52535C6.75557 6.44532 8.73263 4.39435 11.2529 4.05071ZM8.00293 14.4659V18.5H11.3035V14.71H12.8035V18.5H16.0029V14.4659L12.0029 12.6477L8.00293 14.4659ZM12.0029 11L17.5029 13.5V18.5V20H16.0029H8.00293H6.50293V18.5V13.5L12.0029 11ZM12.5029 8.00049H14.0029V9.50049H12.5029H11.5029H10.0029V8.00049H11.5029H12.5029Z',
    })
  );
};
Administration.displayName = 'Administration';
exports['default'] = Administration;
