'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var DeliveryBus = function DeliveryBus(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M15.5 5.5H4C3.17157 5.5 2.5 6.17157 2.5 7V8.89943C7.33135 8.9088 11.6292 9.05147 15.5001 9.45544L15.5 5.5ZM17 5.5L17.0001 9.628C18.545 9.82298 20.0202 10.0649 21.4331 10.3626C21.3698 10.0437 21.2622 9.73409 21.1125 9.44299L19.5033 6.31398C19.2463 5.81418 18.7314 5.5 18.1694 5.5H17ZM2.5 15V10.3994C10.1064 10.4143 16.2745 10.7626 21.5 11.9114V16C21.5 16.2761 21.2761 16.5 21 16.5H20.9585C20.7205 15.0811 19.4865 14 18 14C16.5135 14 15.2795 15.0811 15.0415 16.5H8.95852C8.72048 15.0811 7.4865 14 6 14C4.61839 14 3.45492 14.934 3.10648 16.205C2.73846 15.9316 2.5 15.4937 2.5 15ZM20.8293 18H21C22.1046 18 23 17.1046 23 16V11.0437C23 10.2483 22.8102 9.46433 22.4464 8.75696L20.8372 5.62796C20.3232 4.62836 19.2934 4 18.1694 4H4C2.34315 4 1 5.34315 1 7V15C1 16.3538 1.89669 17.4981 3.12854 17.8715C3.5019 19.1033 4.64623 20 6 20C7.30622 20 8.41746 19.1652 8.82929 18H15.1707C15.5825 19.1652 16.6938 20 18 20C19.3062 20 20.4175 19.1652 20.8293 18ZM6 18.5C6.82843 18.5 7.5 17.8284 7.5 17C7.5 16.1716 6.82843 15.5 6 15.5C5.17157 15.5 4.5 16.1716 4.5 17C4.5 17.8284 5.17157 18.5 6 18.5ZM18 18.5C18.8284 18.5 19.5 17.8284 19.5 17C19.5 16.1716 18.8284 15.5 18 15.5C17.1716 15.5 16.5 16.1716 16.5 17C16.5 17.8284 17.1716 18.5 18 18.5Z',
    })
  );
};
DeliveryBus.displayName = 'DeliveryBus';
exports['default'] = DeliveryBus;
