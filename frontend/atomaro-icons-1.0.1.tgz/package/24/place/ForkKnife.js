'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var ForkKnife = function ForkKnife(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M3.00005 2L3 7.99999C3 9.41019 3.72976 10.65 4.83224 11.3622C4.86371 11.3826 4.8818 11.4184 4.87869 11.4557L4.24914 19.0103C4.11502 20.6197 5.38506 22 7 22C8.61494 22 9.88498 20.6197 9.75086 19.0103L9.12131 11.4557C9.1182 11.4184 9.13629 11.3826 9.16776 11.3622C10.2702 10.65 11 9.41019 11 7.99999V2H9.5V7.99999C9.5 8.87981 9.04666 9.65464 8.35376 10.1023C7.86837 10.4159 7.57631 10.9781 7.62649 11.5803L8.25604 19.1349C8.31728 19.8698 7.73738 20.5 7 20.5C6.26261 20.5 5.68272 19.8698 5.74396 19.1349L6.37351 11.5803C6.42369 10.9781 6.13163 10.4159 5.64624 10.1023C4.95334 9.65464 4.5 8.87981 4.5 8L4.50005 2H3.00005ZM6.25 8.26437V2H7.75V8.26437C7.75 8.67858 7.41421 9.01437 7 9.01437C6.58579 9.01437 6.25 8.67858 6.25 8.26437ZM16.6734 20.5H17.5V4.68875C16.3214 5.89266 15.6254 7.62401 15.2449 9.53026C14.8654 11.4312 14.8469 13.2977 14.8946 14.4984C15.8377 14.587 16.5526 15.4215 16.4724 16.3858L16.1751 19.9585C16.1508 20.25 16.3809 20.5 16.6734 20.5ZM19 21.25V3.59427V3.50451V2.3596V2.10651C19 2.03677 18.9284 1.98926 18.8636 2.01493C18.7891 2.04443 18.7156 2.07496 18.643 2.10651C18.2745 2.26672 17.9313 2.45301 17.6115 2.66191C17.5741 2.6864 17.5369 2.71121 17.5 2.73632C12.7346 5.98404 13.3354 14.3406 13.4771 15.7785C13.4894 15.9039 13.5945 15.9907 13.7205 15.9907H14.7284C14.8746 15.9907 14.9896 16.1157 14.9775 16.2614L14.6803 19.8341C14.5832 21.0001 15.5034 22 16.6734 22H18.25C18.6643 22 19 21.6642 19 21.25Z',
    })
  );
};
ForkKnife.displayName = 'ForkKnife';
exports['default'] = ForkKnife;
