'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var FigureManWoman = function FigureManWoman(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M8 5C8 5.82843 7.32842 6.5 6.5 6.5C5.67157 6.5 5 5.82843 5 5C5 4.17157 5.67157 3.5 6.5 3.5C7.32842 3.5 8 4.17157 8 5ZM9.5 5C9.5 6.65685 8.15685 8 6.5 8C4.84314 8 3.5 6.65685 3.5 5C3.5 3.34315 4.84314 2 6.5 2C8.15685 2 9.5 3.34315 9.5 5ZM18.939 5C18.939 5.82843 18.2674 6.5 17.439 6.5C16.6105 6.5 15.939 5.82843 15.939 5C15.939 4.17157 16.6105 3.5 17.439 3.5C18.2674 3.5 18.939 4.17157 18.939 5ZM20.439 5C20.439 6.65685 19.0958 8 17.439 8C15.7821 8 14.439 6.65685 14.439 5C14.439 3.34315 15.7821 2 17.439 2C19.0958 2 20.439 3.34315 20.439 5ZM9.5 17L11 16V12C11 10.3431 9.65685 9 8 9L5.0094 9C3.35529 9 2.01329 10.3389 2.00941 11.993L2 16L3.5 17V20C3.5 21.1046 4.39543 22 5.5 22L7.5 22C8.60457 22 9.5 21.1046 9.5 20V17ZM3.50188 15.1985L4.33205 15.7519L5 16.1972V17V20C5 20.2761 5.22385 20.5 5.5 20.5H7.5C7.77614 20.5 8 20.2761 8 20V17V16.1972L8.66795 15.7519L9.5 15.1972V12C9.5 11.1716 8.82842 10.5 8 10.5H5.0094C4.18235 10.5 3.51134 11.1694 3.5094 11.9965L3.50188 15.1985ZM23 16.5L20.439 18V20C20.439 21.1046 19.5435 22 18.439 22L16.439 22C15.3344 22 14.439 21.1046 14.439 20V18L12 16.5L14.1923 10.9054C14.6427 9.75613 15.7511 9 16.9855 9H17.9108C19.1278 9 20.2242 9.73524 20.6862 10.8612L23 16.5ZM15.2248 16.7223L13.8542 15.8794L15.5889 11.4527C15.8141 10.8781 16.3683 10.5 16.9855 10.5H17.9108C18.5193 10.5 19.0675 10.8676 19.2985 11.4306L21.1177 15.8641L19.6809 16.7057L18.939 17.1402V18V20C18.939 20.2761 18.7151 20.5 18.439 20.5H16.439C16.1628 20.5 15.939 20.2761 15.939 20V18V17.1615L15.2248 16.7223Z',
    })
  );
};
FigureManWoman.displayName = 'FigureManWoman';
exports['default'] = FigureManWoman;
