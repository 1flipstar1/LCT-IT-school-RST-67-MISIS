'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var FolderAdd = function FolderAdd(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M13.0607 6.06066L12.6213 6.5H12H3.5V11H2V6C2 5.44772 2.44772 5 3 5H12L13.1213 3.87868C13.6839 3.31607 14.447 3 15.2426 3H21C21.5523 3 22 3.44772 22 4V18C22 19.6569 20.6569 21 19 21H12V19.5H19C19.8284 19.5 20.5 18.8284 20.5 18V4.5H15.2426C14.8448 4.5 14.4633 4.65803 14.182 4.93934L13.0607 6.06066ZM5.25 21V17.75H2V16.25H5.25V13H6.75V16.25H10V17.75H6.75V21H5.25Z',
    })
  );
};
FolderAdd.displayName = 'FolderAdd';
exports['default'] = FolderAdd;
