'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Archive = function Archive(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M18 4.5H6C5.72386 4.5 5.5 4.72386 5.5 5V6H18.5V5C18.5 4.72386 18.2761 4.5 18 4.5ZM20 6.26756V5C20 3.89543 19.1046 3 18 3H6C4.89543 3 4 3.89543 4 5V6.26756C3.4022 6.61337 3 7.25972 3 8V11C2.44772 11 2 11.4477 2 12V18C2 19.6569 3.34315 21 5 21H19C20.6569 21 22 19.6569 22 18V10C22 9.44772 21.5523 9 21 9V8C21 7.25972 20.5978 6.61337 20 6.26756ZM5 7.5H19C19.2761 7.5 19.5 7.72386 19.5 8V9H11.2426C10.447 9 9.68393 9.31607 9.12132 9.87868L8 11H4.5V8C4.5 7.72386 4.72386 7.5 5 7.5ZM8.62132 12.5L9.06066 12.0607L10.182 10.9393C10.4633 10.658 10.8448 10.5 11.2426 10.5H20.5V18C20.5 18.8284 19.8284 19.5 19 19.5H5C4.17157 19.5 3.5 18.8284 3.5 18V12.5H8H8.62132ZM14 14.25H18V12.75H14V14.25Z',
    })
  );
};
Archive.displayName = 'Archive';
exports['default'] = Archive;
