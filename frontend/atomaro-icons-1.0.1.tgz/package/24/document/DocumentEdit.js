'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var DocumentEdit = function DocumentEdit(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M18 20.5H13V22H18C19.1046 22 20 21.1046 20 20V8.40053C20 7.86033 19.7815 7.3431 19.3942 6.96654L14.8679 2.56601C14.4946 2.20306 13.9944 2 13.4737 2H6C4.89543 2 4 2.89543 4 4V14H5.5V4C5.5 3.72386 5.72386 3.5 6 3.5H13.4737C13.6039 3.5 13.7289 3.55076 13.8223 3.6415L18.3485 8.04203C18.4454 8.13617 18.5 8.26548 18.5 8.40053V20C18.5 20.2761 18.2761 20.5 18 20.5ZM13.8324 12.6574C13.6487 12.4621 13.3436 12.4465 13.141 12.622L12.199 13.4377L13.4101 14.7399L14.3265 13.9388C14.5398 13.7524 14.5557 13.4261 14.3616 13.2197L13.8324 12.6574ZM5.5 19.2386L11.0643 14.4203L12.2802 15.7276L6.82018 20.5007H5.5V19.2386ZM15.454 12.1918C16.2306 13.0172 16.167 14.3223 15.3137 15.0681L7.66607 21.7536C7.48383 21.9129 7.24998 22.0007 7.00792 22.0007H5C4.44772 22.0007 4 21.553 4 21.0007V19.0102C4 18.72 4.12603 18.4441 4.34539 18.2542L12.159 11.4881C12.9698 10.7861 14.1899 10.8484 14.9248 11.6295L15.454 12.1918Z',
    })
  );
};
DocumentEdit.displayName = 'DocumentEdit';
exports['default'] = DocumentEdit;
