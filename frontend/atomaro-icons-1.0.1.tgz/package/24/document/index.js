"use strict";

var __importDefault = this && this.__importDefault || function (mod) {
  return mod && mod.__esModule ? mod : {
    "default": mod
  };
};
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.SVG = exports.SQL = exports.Reading = exports.RAR = exports.PS = exports.PPTX = exports.PPT = exports.PNG = exports.PDF = exports.ODT = exports.ODS = exports.ODP = exports.Music = exports.Media = exports.MSG = exports.MPP = exports.MPEG = exports.MP3 = exports.MD = exports.JSON = exports.JS = exports.JPG = exports.JFIF = exports.Infographics = exports.HTML = exports.GIF = exports.Folder = exports.FolderShared = exports.FolderDetails = exports.FolderAdd = exports.FolderOpen = exports.FolderOpenFill = exports.FolderFill = exports.FIG = exports.EXE = exports.DocumentText = exports.DocumentSearch = exports.DocumentImage = exports.DocumentEdit = exports.DocumentAdd = exports.DOTX = exports.DOCX = exports.DOCM = exports.DOC = exports.CSV = exports.CSS = exports.Arhive = exports.Archive = exports.APP = exports.AI = void 0;
exports.ZIP = exports.XLSX = exports.XLSM = exports.XLSB = exports.XLS = exports.XD = exports.WEBP = exports.WAV = exports.VSDX = exports.VSD = exports.Table = exports.TXT = exports.TIFF = exports.TIF = exports.Snippet = exports.SevenZIP = exports.Script = void 0;
var AI_1 = require("./AI");
Object.defineProperty(exports, "AI", {
  enumerable: true,
  get: function get() {
    return __importDefault(AI_1)["default"];
  }
});
var APP_1 = require("./APP");
Object.defineProperty(exports, "APP", {
  enumerable: true,
  get: function get() {
    return __importDefault(APP_1)["default"];
  }
});
var Archive_1 = require("./Archive");
Object.defineProperty(exports, "Archive", {
  enumerable: true,
  get: function get() {
    return __importDefault(Archive_1)["default"];
  }
});
var Arhive_1 = require("./Arhive");
Object.defineProperty(exports, "Arhive", {
  enumerable: true,
  get: function get() {
    return __importDefault(Arhive_1)["default"];
  }
});
var CSS_1 = require("./CSS");
Object.defineProperty(exports, "CSS", {
  enumerable: true,
  get: function get() {
    return __importDefault(CSS_1)["default"];
  }
});
var CSV_1 = require("./CSV");
Object.defineProperty(exports, "CSV", {
  enumerable: true,
  get: function get() {
    return __importDefault(CSV_1)["default"];
  }
});
var DOC_1 = require("./DOC");
Object.defineProperty(exports, "DOC", {
  enumerable: true,
  get: function get() {
    return __importDefault(DOC_1)["default"];
  }
});
var DOCM_1 = require("./DOCM");
Object.defineProperty(exports, "DOCM", {
  enumerable: true,
  get: function get() {
    return __importDefault(DOCM_1)["default"];
  }
});
var DOCX_1 = require("./DOCX");
Object.defineProperty(exports, "DOCX", {
  enumerable: true,
  get: function get() {
    return __importDefault(DOCX_1)["default"];
  }
});
var DOTX_1 = require("./DOTX");
Object.defineProperty(exports, "DOTX", {
  enumerable: true,
  get: function get() {
    return __importDefault(DOTX_1)["default"];
  }
});
var DocumentAdd_1 = require("./DocumentAdd");
Object.defineProperty(exports, "DocumentAdd", {
  enumerable: true,
  get: function get() {
    return __importDefault(DocumentAdd_1)["default"];
  }
});
var DocumentEdit_1 = require("./DocumentEdit");
Object.defineProperty(exports, "DocumentEdit", {
  enumerable: true,
  get: function get() {
    return __importDefault(DocumentEdit_1)["default"];
  }
});
var DocumentImage_1 = require("./DocumentImage");
Object.defineProperty(exports, "DocumentImage", {
  enumerable: true,
  get: function get() {
    return __importDefault(DocumentImage_1)["default"];
  }
});
var DocumentSearch_1 = require("./DocumentSearch");
Object.defineProperty(exports, "DocumentSearch", {
  enumerable: true,
  get: function get() {
    return __importDefault(DocumentSearch_1)["default"];
  }
});
var DocumentText_1 = require("./DocumentText");
Object.defineProperty(exports, "DocumentText", {
  enumerable: true,
  get: function get() {
    return __importDefault(DocumentText_1)["default"];
  }
});
var EXE_1 = require("./EXE");
Object.defineProperty(exports, "EXE", {
  enumerable: true,
  get: function get() {
    return __importDefault(EXE_1)["default"];
  }
});
var FIG_1 = require("./FIG");
Object.defineProperty(exports, "FIG", {
  enumerable: true,
  get: function get() {
    return __importDefault(FIG_1)["default"];
  }
});
var FolderFill_1 = require("./FolderFill");
Object.defineProperty(exports, "FolderFill", {
  enumerable: true,
  get: function get() {
    return __importDefault(FolderFill_1)["default"];
  }
});
var FolderOpenFill_1 = require("./FolderOpenFill");
Object.defineProperty(exports, "FolderOpenFill", {
  enumerable: true,
  get: function get() {
    return __importDefault(FolderOpenFill_1)["default"];
  }
});
var FolderOpen_1 = require("./FolderOpen");
Object.defineProperty(exports, "FolderOpen", {
  enumerable: true,
  get: function get() {
    return __importDefault(FolderOpen_1)["default"];
  }
});
var FolderAdd_1 = require("./FolderAdd");
Object.defineProperty(exports, "FolderAdd", {
  enumerable: true,
  get: function get() {
    return __importDefault(FolderAdd_1)["default"];
  }
});
var FolderDetails_1 = require("./FolderDetails");
Object.defineProperty(exports, "FolderDetails", {
  enumerable: true,
  get: function get() {
    return __importDefault(FolderDetails_1)["default"];
  }
});
var FolderShared_1 = require("./FolderShared");
Object.defineProperty(exports, "FolderShared", {
  enumerable: true,
  get: function get() {
    return __importDefault(FolderShared_1)["default"];
  }
});
var Folder_1 = require("./Folder");
Object.defineProperty(exports, "Folder", {
  enumerable: true,
  get: function get() {
    return __importDefault(Folder_1)["default"];
  }
});
var GIF_1 = require("./GIF");
Object.defineProperty(exports, "GIF", {
  enumerable: true,
  get: function get() {
    return __importDefault(GIF_1)["default"];
  }
});
var HTML_1 = require("./HTML");
Object.defineProperty(exports, "HTML", {
  enumerable: true,
  get: function get() {
    return __importDefault(HTML_1)["default"];
  }
});
var Infographics_1 = require("./Infographics");
Object.defineProperty(exports, "Infographics", {
  enumerable: true,
  get: function get() {
    return __importDefault(Infographics_1)["default"];
  }
});
var JFIF_1 = require("./JFIF");
Object.defineProperty(exports, "JFIF", {
  enumerable: true,
  get: function get() {
    return __importDefault(JFIF_1)["default"];
  }
});
var JPG_1 = require("./JPG");
Object.defineProperty(exports, "JPG", {
  enumerable: true,
  get: function get() {
    return __importDefault(JPG_1)["default"];
  }
});
var JS_1 = require("./JS");
Object.defineProperty(exports, "JS", {
  enumerable: true,
  get: function get() {
    return __importDefault(JS_1)["default"];
  }
});
var JSON_1 = require("./JSON");
Object.defineProperty(exports, "JSON", {
  enumerable: true,
  get: function get() {
    return __importDefault(JSON_1)["default"];
  }
});
var MD_1 = require("./MD");
Object.defineProperty(exports, "MD", {
  enumerable: true,
  get: function get() {
    return __importDefault(MD_1)["default"];
  }
});
var MP3_1 = require("./MP3");
Object.defineProperty(exports, "MP3", {
  enumerable: true,
  get: function get() {
    return __importDefault(MP3_1)["default"];
  }
});
var MPEG_1 = require("./MPEG");
Object.defineProperty(exports, "MPEG", {
  enumerable: true,
  get: function get() {
    return __importDefault(MPEG_1)["default"];
  }
});
var MPP_1 = require("./MPP");
Object.defineProperty(exports, "MPP", {
  enumerable: true,
  get: function get() {
    return __importDefault(MPP_1)["default"];
  }
});
var MSG_1 = require("./MSG");
Object.defineProperty(exports, "MSG", {
  enumerable: true,
  get: function get() {
    return __importDefault(MSG_1)["default"];
  }
});
var Media_1 = require("./Media");
Object.defineProperty(exports, "Media", {
  enumerable: true,
  get: function get() {
    return __importDefault(Media_1)["default"];
  }
});
var Music_1 = require("./Music");
Object.defineProperty(exports, "Music", {
  enumerable: true,
  get: function get() {
    return __importDefault(Music_1)["default"];
  }
});
var ODP_1 = require("./ODP");
Object.defineProperty(exports, "ODP", {
  enumerable: true,
  get: function get() {
    return __importDefault(ODP_1)["default"];
  }
});
var ODS_1 = require("./ODS");
Object.defineProperty(exports, "ODS", {
  enumerable: true,
  get: function get() {
    return __importDefault(ODS_1)["default"];
  }
});
var ODT_1 = require("./ODT");
Object.defineProperty(exports, "ODT", {
  enumerable: true,
  get: function get() {
    return __importDefault(ODT_1)["default"];
  }
});
var PDF_1 = require("./PDF");
Object.defineProperty(exports, "PDF", {
  enumerable: true,
  get: function get() {
    return __importDefault(PDF_1)["default"];
  }
});
var PNG_1 = require("./PNG");
Object.defineProperty(exports, "PNG", {
  enumerable: true,
  get: function get() {
    return __importDefault(PNG_1)["default"];
  }
});
var PPT_1 = require("./PPT");
Object.defineProperty(exports, "PPT", {
  enumerable: true,
  get: function get() {
    return __importDefault(PPT_1)["default"];
  }
});
var PPTX_1 = require("./PPTX");
Object.defineProperty(exports, "PPTX", {
  enumerable: true,
  get: function get() {
    return __importDefault(PPTX_1)["default"];
  }
});
var PS_1 = require("./PS");
Object.defineProperty(exports, "PS", {
  enumerable: true,
  get: function get() {
    return __importDefault(PS_1)["default"];
  }
});
var RAR_1 = require("./RAR");
Object.defineProperty(exports, "RAR", {
  enumerable: true,
  get: function get() {
    return __importDefault(RAR_1)["default"];
  }
});
var Reading_1 = require("./Reading");
Object.defineProperty(exports, "Reading", {
  enumerable: true,
  get: function get() {
    return __importDefault(Reading_1)["default"];
  }
});
var SQL_1 = require("./SQL");
Object.defineProperty(exports, "SQL", {
  enumerable: true,
  get: function get() {
    return __importDefault(SQL_1)["default"];
  }
});
var SVG_1 = require("./SVG");
Object.defineProperty(exports, "SVG", {
  enumerable: true,
  get: function get() {
    return __importDefault(SVG_1)["default"];
  }
});
var Script_1 = require("./Script");
Object.defineProperty(exports, "Script", {
  enumerable: true,
  get: function get() {
    return __importDefault(Script_1)["default"];
  }
});
var SevenZIP_1 = require("./SevenZIP");
Object.defineProperty(exports, "SevenZIP", {
  enumerable: true,
  get: function get() {
    return __importDefault(SevenZIP_1)["default"];
  }
});
var Snippet_1 = require("./Snippet");
Object.defineProperty(exports, "Snippet", {
  enumerable: true,
  get: function get() {
    return __importDefault(Snippet_1)["default"];
  }
});
var TIF_1 = require("./TIF");
Object.defineProperty(exports, "TIF", {
  enumerable: true,
  get: function get() {
    return __importDefault(TIF_1)["default"];
  }
});
var TIFF_1 = require("./TIFF");
Object.defineProperty(exports, "TIFF", {
  enumerable: true,
  get: function get() {
    return __importDefault(TIFF_1)["default"];
  }
});
var TXT_1 = require("./TXT");
Object.defineProperty(exports, "TXT", {
  enumerable: true,
  get: function get() {
    return __importDefault(TXT_1)["default"];
  }
});
var Table_1 = require("./Table");
Object.defineProperty(exports, "Table", {
  enumerable: true,
  get: function get() {
    return __importDefault(Table_1)["default"];
  }
});
var VSD_1 = require("./VSD");
Object.defineProperty(exports, "VSD", {
  enumerable: true,
  get: function get() {
    return __importDefault(VSD_1)["default"];
  }
});
var VSDX_1 = require("./VSDX");
Object.defineProperty(exports, "VSDX", {
  enumerable: true,
  get: function get() {
    return __importDefault(VSDX_1)["default"];
  }
});
var WAV_1 = require("./WAV");
Object.defineProperty(exports, "WAV", {
  enumerable: true,
  get: function get() {
    return __importDefault(WAV_1)["default"];
  }
});
var WEBP_1 = require("./WEBP");
Object.defineProperty(exports, "WEBP", {
  enumerable: true,
  get: function get() {
    return __importDefault(WEBP_1)["default"];
  }
});
var XD_1 = require("./XD");
Object.defineProperty(exports, "XD", {
  enumerable: true,
  get: function get() {
    return __importDefault(XD_1)["default"];
  }
});
var XLS_1 = require("./XLS");
Object.defineProperty(exports, "XLS", {
  enumerable: true,
  get: function get() {
    return __importDefault(XLS_1)["default"];
  }
});
var XLSB_1 = require("./XLSB");
Object.defineProperty(exports, "XLSB", {
  enumerable: true,
  get: function get() {
    return __importDefault(XLSB_1)["default"];
  }
});
var XLSM_1 = require("./XLSM");
Object.defineProperty(exports, "XLSM", {
  enumerable: true,
  get: function get() {
    return __importDefault(XLSM_1)["default"];
  }
});
var XLSX_1 = require("./XLSX");
Object.defineProperty(exports, "XLSX", {
  enumerable: true,
  get: function get() {
    return __importDefault(XLSX_1)["default"];
  }
});
var ZIP_1 = require("./ZIP");
Object.defineProperty(exports, "ZIP", {
  enumerable: true,
  get: function get() {
    return __importDefault(ZIP_1)["default"];
  }
});