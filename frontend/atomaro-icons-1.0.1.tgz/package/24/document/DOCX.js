'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var DOCX = function DOCX(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M3.5 20C3.5 20.2761 3.72386 20.5 4 20.5H12V22H4C2.89543 22 2 21.1046 2 20H3.5ZM3.5 8V4C3.5 3.72386 3.72386 3.5 4 3.5H12.4773C12.6069 3.5 12.7315 3.55036 12.8247 3.64045L16.3474 7.04456C16.4449 7.13877 16.5 7.26854 16.5 7.40411V8H18V7.40411C18 6.8618 17.7798 6.34274 17.3898 5.96589L13.8671 2.56178C13.4942 2.20142 12.9959 2 12.4773 2H4C2.89543 2 2 2.89543 2 4V8H3.5ZM1.5 11.5H2.75C3.44036 11.5 4 12.0596 4 12.75V15.25C4 15.9404 3.44036 16.5 2.75 16.5H1.5V11.5ZM0 10H1.5H2.75C4.26878 10 5.5 11.2312 5.5 12.75V15.25C5.5 16.7688 4.26878 18 2.75 18H1.5H0V16.5V11.5V10ZM17 15.25V15H18.5V15.25C18.5 16.7688 17.2688 18 15.75 18C14.2312 18 13 16.7688 13 15.25V12.75C13 11.2312 14.2312 10 15.75 10C17.2688 10 18.5 11.2312 18.5 12.75V13H17V12.75C17 12.0596 16.4404 11.5 15.75 11.5C15.0596 11.5 14.5 12.0596 14.5 12.75V15.25C14.5 15.9404 15.0596 16.5 15.75 16.5C16.4404 16.5 17 15.9404 17 15.25ZM10.5 15.25V12.75C10.5 12.0596 9.94036 11.5 9.25 11.5C8.55964 11.5 8 12.0596 8 12.75V15.25C8 15.9404 8.55964 16.5 9.25 16.5C9.94036 16.5 10.5 15.9404 10.5 15.25ZM9.25 10C7.73122 10 6.5 11.2312 6.5 12.75V15.25C6.5 16.7688 7.73122 18 9.25 18C10.7688 18 12 16.7688 12 15.25V12.75C12 11.2312 10.7688 10 9.25 10ZM22.3762 10H24.0042L22.3161 14.0002L24.004 18H22.376L21.5021 15.9292L20.6283 18H19.0002L20.6881 14.0002L19 10H20.628L21.5021 12.0713L22.3762 10Z',
    })
  );
};
DOCX.displayName = 'DOCX';
exports['default'] = DOCX;
