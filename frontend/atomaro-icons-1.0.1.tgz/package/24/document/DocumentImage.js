'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var DocumentImage = function DocumentImage(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M6 20.5H18C18.2761 20.5 18.5 20.2761 18.5 20V18.6439L14.976 15.7133L13.45 16.8578C13.1739 17.0649 12.7922 17.0568 12.5251 16.8383L7.5224 12.7452L5.50076 14.5583L5.5 14.5575V20C5.5 20.2761 5.72386 20.5 6 20.5ZM5.5 12.5441V4C5.5 3.72386 5.72386 3.5 6 3.5H13.4737C13.6039 3.5 13.7289 3.55076 13.8223 3.6415L18.3485 8.04203C18.4454 8.13617 18.5 8.26548 18.5 8.40053V16.693L15.4795 14.1812C15.2125 13.9591 14.8279 13.9494 14.55 14.1578L13.0201 15.3052L7.97493 11.1773C7.68872 10.9432 7.27454 10.9526 6.99924 11.1995L5.5 12.5441ZM6 2C4.89543 2 4 2.89543 4 4V20C4 21.1046 4.89543 22 6 22H18C19.1046 22 20 21.1046 20 20V8.40053C20 7.86033 19.7815 7.3431 19.3942 6.96654L14.8679 2.56601C14.4946 2.20306 13.9944 2 13.4737 2H6ZM13 10.5C13 9.67157 13.6716 9 14.5 9C15.3284 9 16 9.67157 16 10.5C16 11.3284 15.3284 12 14.5 12C13.6716 12 13 11.3284 13 10.5Z',
    })
  );
};
DocumentImage.displayName = 'DocumentImage';
exports['default'] = DocumentImage;
