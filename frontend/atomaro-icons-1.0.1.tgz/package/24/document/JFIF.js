'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var JFIF = function JFIF(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M4 20.5H12V22H4C2.89543 22 2 21.1046 2 20H3.5C3.5 20.2761 3.72386 20.5 4 20.5ZM3.5 8V4C3.5 3.72386 3.72386 3.5 4 3.5H12.4773C12.6069 3.5 12.7315 3.55036 12.8247 3.64045L16.3474 7.04456C16.4449 7.13877 16.5 7.26854 16.5 7.40411V8H18V7.40411C18 6.8618 17.7798 6.34274 17.3898 5.96589L13.8671 2.56178C13.4942 2.20142 12.9959 2 12.4773 2H4C2.89543 2 2 2.89543 2 4V8H3.5ZM0 18H1.75C3.26878 18 4.5 16.7688 4.5 15.25V11.5V10H3H1V11.5H3V15.25C3 15.9404 2.44036 16.5 1.75 16.5H0V18ZM5.5 10H10V11.5H7.00195V13.4999H9.5V14.9999H7.00195V18.0012H5.50195V14.9999H5.5V13.4999H5.50195V11.5H5.5V10ZM16.5 10H21V11.5H18.002V13.4999H20.5V14.9999H18.002V18.0012H16.502V14.9999H16.5V13.4999H16.502V11.5H16.5V10ZM15.5 10H11V11.5H12.52V16.502H11V18.002H15.5V16.502H14.02V11.5H15.5V10Z',
    })
  );
};
JFIF.displayName = 'JFIF';
exports['default'] = JFIF;
