'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var FolderFill = function FolderFill(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M15.2426 3L21 3C21.5523 3 22 3.44772 22 4L22 18C22 19.6569 20.6569 21 19 21L5 21C3.34315 21 2 19.6569 2 18L2 6C2 5.44772 2.44772 5 3 5L12 5L13.1213 3.87868C13.6839 3.31607 14.447 3 15.2426 3ZM6 17.25H10L10 15.75L6 15.75V17.25Z',
    })
  );
};
FolderFill.displayName = 'FolderFill';
exports['default'] = FolderFill;
