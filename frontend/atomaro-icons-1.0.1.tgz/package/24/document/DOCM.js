'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var DOCM = function DOCM(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M4 20.5H12V22H4C2.89543 22 2 21.1046 2 20H3.5C3.5 20.2761 3.72386 20.5 4 20.5ZM3.5 8V4C3.5 3.72386 3.72386 3.5 4 3.5H12.4773C12.6069 3.5 12.7315 3.55036 12.8247 3.64045L16.3474 7.04456C16.4449 7.13877 16.5 7.26854 16.5 7.40411V8H18V7.40411C18 6.8618 17.7798 6.34274 17.3898 5.96589L13.8671 2.56178C13.4942 2.20142 12.9959 2 12.4773 2H4C2.89543 2 2 2.89543 2 4V8H3.5ZM2.75 11.5H1.5V16.5H2.75C3.44036 16.5 4 15.9404 4 15.25V12.75C4 12.0596 3.44036 11.5 2.75 11.5ZM1.5 10H0V11.5V16.5V18H1.5H2.75C4.26878 18 5.5 16.7688 5.5 15.25V12.75C5.5 11.2312 4.26878 10 2.75 10H1.5ZM16 15V15.25C16 15.9404 15.4404 16.5 14.75 16.5C14.0596 16.5 13.5 15.9404 13.5 15.25V12.75C13.5 12.0596 14.0596 11.5 14.75 11.5C15.4404 11.5 16 12.0596 16 12.75V13H17.5V12.75C17.5 11.2312 16.2688 10 14.75 10C13.2312 10 12 11.2312 12 12.75V15.25C12 16.7688 13.2312 18 14.75 18C16.2688 18 17.5 16.7688 17.5 15.25V15H16ZM10 12.75V15.25C10 15.9404 9.44036 16.5 8.75 16.5C8.05964 16.5 7.5 15.9404 7.5 15.25V12.75C7.5 12.0596 8.05964 11.5 8.75 11.5C9.44036 11.5 10 12.0596 10 12.75ZM6 12.75C6 11.2312 7.23122 10 8.75 10C10.2688 10 11.5 11.2312 11.5 12.75V15.25C11.5 16.7688 10.2688 18 8.75 18C7.23122 18 6 16.7688 6 15.25V12.75ZM22.4555 10H23.9436L23.9961 10.0088V18H22.4961V14.4662L21.7068 16.7454L21.2723 18H20.7238L20.2894 16.7454L19.5 14.4662V18H18V10.0088L18.0525 10H19.5406L20.9981 14.2082L22.4555 10Z',
    })
  );
};
DOCM.displayName = 'DOCM';
exports['default'] = DOCM;
