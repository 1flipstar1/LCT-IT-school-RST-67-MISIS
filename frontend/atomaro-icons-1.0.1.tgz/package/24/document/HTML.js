'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var HTML = function HTML(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M12 20.5H4C3.72386 20.5 3.5 20.2761 3.5 20H2C2 21.1046 2.89543 22 4 22H12V20.5ZM3.5 4V8H2V4C2 2.89543 2.89543 2 4 2H12.4773C12.9959 2 13.4942 2.20142 13.8671 2.56178L17.3898 5.96589C17.7798 6.34274 18 6.8618 18 7.40411V8H16.5V7.40411C16.5 7.26854 16.4449 7.13877 16.3474 7.04456L12.8247 3.64045C12.7315 3.55036 12.6069 3.5 12.4773 3.5H4C3.72386 3.5 3.5 3.72386 3.5 4ZM1.49756 9.99414L1.49756 13.5073H3.98878L3.98878 9.99998H5.48878L5.48878 18L3.98878 18L3.98878 15.0073H1.49756L1.49756 18L-0.00243562 18L-0.00244141 9.99414H1.49756ZM21.0061 16.5049V10H19.5061V16.5049V18V18.0049H23.5V16.5049H21.0061ZM6.5061 10.0022H11.01V11.5022H9.50806V18.0001H8.00806V11.5022H6.5061V10.0022ZM16.4584 10H17.9465L17.9991 10.0088V18H16.4991V14.4662L15.7097 16.7454L15.2752 18H14.7268L14.2923 16.7454L13.5029 14.4662V18H12.0029V10.0088L12.0555 10H13.5436L15.001 14.2082L16.4584 10Z',
    })
  );
};
HTML.displayName = 'HTML';
exports['default'] = HTML;
