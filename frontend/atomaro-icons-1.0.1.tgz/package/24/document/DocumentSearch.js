'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var DocumentSearch = function DocumentSearch(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M6 20.5H10V22H6C4.89543 22 4 21.1046 4 20V4C4 2.89543 4.89543 2 6 2H13.4737C13.9944 2 14.4946 2.20306 14.8679 2.56601L19.3942 6.96654C19.7815 7.3431 20 7.86033 20 8.40053V12H18.5V8.40053C18.5 8.26548 18.4454 8.13617 18.3485 8.04203L13.8223 3.6415C13.7289 3.55076 13.6039 3.5 13.4737 3.5H6C5.72386 3.5 5.5 3.72386 5.5 4V20C5.5 20.2761 5.72386 20.5 6 20.5ZM16 20.5C17.3807 20.5 18.5 19.3807 18.5 18C18.5 16.6193 17.3807 15.5 16 15.5C14.6193 15.5 13.5 16.6193 13.5 18C13.5 19.3807 14.6193 20.5 16 20.5ZM16 22C16.8335 22 17.6074 21.7451 18.2481 21.309L19.9697 23.0305L21.0304 21.9698L19.3088 20.2484C19.745 19.6076 20 18.8336 20 18C20 15.7909 18.2091 14 16 14C13.7909 14 12 15.7909 12 18C12 20.2091 13.7909 22 16 22Z',
    })
  );
};
DocumentSearch.displayName = 'DocumentSearch';
exports['default'] = DocumentSearch;
