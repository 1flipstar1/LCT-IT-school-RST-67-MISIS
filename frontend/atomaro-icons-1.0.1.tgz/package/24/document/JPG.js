'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var JPG = function JPG(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M4 20.5H12V22H4C2.89543 22 2 21.1046 2 20V4C2 2.89543 2.89543 2 4 2H12.4773C12.9959 2 13.4942 2.20142 13.8671 2.56178L17.3898 5.96589C17.7798 6.34274 18 6.8618 18 7.40411V8H16.5V7.40411C16.5 7.26854 16.4449 7.13877 16.3474 7.04456L12.8247 3.64045C12.7315 3.55036 12.6069 3.5 12.4773 3.5H4C3.72386 3.5 3.5 3.72386 3.5 4V20C3.5 20.2761 3.72386 20.5 4 20.5ZM7.75 18H6V16.5H7.75C8.44036 16.5 9 15.9404 9 15.25V11.5H7V10H9H10.5V11.5V15.25C10.5 16.7688 9.26878 18 7.75 18ZM13.4944 16L13.4944 18H11.9944L11.9944 10H12H13.4944H13.5H14.75C16.2688 10 17.5 11.2312 17.5 12.75V13.25C17.5 14.7688 16.2688 16 14.75 16H13.5H13.4944ZM14.75 11.5H13.5V14.5H14.75C15.4404 14.5 16 13.9404 16 13.25V12.75C16 12.0596 15.4404 11.5 14.75 11.5ZM24.002 14.5V13.9971H21.502V15.4971H22.502V16.5H21.252C20.5616 16.5 20.002 15.9404 20.002 15.25V12.75C20.002 12.0596 20.5616 11.5 21.252 11.5C21.9423 11.5 22.502 12.0596 22.502 12.75V13H24.002V12.75C24.002 11.2312 22.7707 10 21.252 10C19.7332 10 18.502 11.2312 18.502 12.75V15.25C18.502 16.7688 19.7332 18 21.252 18H23.502C23.7781 18 24.002 17.7761 24.002 17.5V15.4971V14.5Z',
    })
  );
};
JPG.displayName = 'JPG';
exports['default'] = JPG;
