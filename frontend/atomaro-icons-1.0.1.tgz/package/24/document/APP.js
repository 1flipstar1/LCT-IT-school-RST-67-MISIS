'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var APP = function APP(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M4 20.5H12V22H4C2.89543 22 2 21.1046 2 20V4C2 2.89543 2.89543 2 4 2H12.4773C12.9959 2 13.4942 2.20142 13.8671 2.56178L17.3898 5.96589C17.7798 6.34274 18 6.8618 18 7.40411V8H16.5V7.40411C16.5 7.26854 16.4449 7.13877 16.3474 7.04456L12.8247 3.64045C12.7315 3.55036 12.6069 3.5 12.4773 3.5H4C3.72386 3.5 3.5 3.72386 3.5 4V20C3.5 20.2761 3.72386 20.5 4 20.5ZM9.20354 10H6.79374L5 18H6.53724L6.98365 16.009H9.01363L9.46004 18H10.9973L9.20354 10ZM8.6773 14.509L7.99864 11.4822L7.31998 14.509H8.6773ZM13.4963 16L13.4963 18H11.9963L11.9963 10H12.0027H13.4963H13.5027H14.7471C16.2659 10 17.4971 11.2312 17.4971 12.75V13.25C17.4971 14.7688 16.2659 16 14.7471 16H13.5027H13.4963ZM14.7471 11.5H13.5027V14.5H14.7471C15.4375 14.5 15.9971 13.9404 15.9971 13.25V12.75C15.9971 12.0596 15.4375 11.5 14.7471 11.5ZM19.9932 16L19.9932 18H18.4932L18.4932 10H18.4995H19.9932H19.9995H21.2439C22.7627 10 23.9939 11.2312 23.9939 12.75V13.25C23.9939 14.7688 22.7627 16 21.2439 16H19.9995H19.9932ZM21.2439 11.5H19.9995V14.5H21.2439C21.9343 14.5 22.4939 13.9404 22.4939 13.25V12.75C22.4939 12.0596 21.9343 11.5 21.2439 11.5Z',
    })
  );
};
APP.displayName = 'APP';
exports['default'] = APP;
