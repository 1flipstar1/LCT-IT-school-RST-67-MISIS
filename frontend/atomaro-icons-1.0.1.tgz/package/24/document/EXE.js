'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var EXE = function EXE(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M4 20.5H12V22H4C2.89543 22 2 21.1046 2 20V4C2 2.89543 2.89543 2 4 2H12.4773C12.9959 2 13.4942 2.20142 13.8671 2.56178L17.3898 5.96589C17.7798 6.34274 18 6.8618 18 7.40411V8H16.5V7.40411C16.5 7.26854 16.4449 7.13877 16.3474 7.04456L12.8247 3.64045C12.7315 3.55036 12.6069 3.5 12.4773 3.5H4C3.72386 3.5 3.5 3.72386 3.5 4V20C3.5 20.2761 3.72386 20.5 4 20.5ZM16.4974 10H14.8693L13.9953 12.0711L13.1213 10H11.4932L13.1812 14L11.4932 18H13.1213L13.9953 15.929L14.8693 18H16.4974L14.8093 14L16.4974 10ZM6 10.0007H10.5V11.5007H7.50171V13.2499H10V14.7499H7.50171V16.5008H10.5V18.0008H6V16.5008H6.00171V14.7499H6V13.2499H6.00171V11.5007H6V10.0007ZM21.9978 10.0007H17.4978V11.5007H17.4995V13.2499H17.4978V14.7499H17.4995V16.5008H17.4978V18.0008H21.9978V16.5008H18.9995V14.7499H21.4978V13.2499H18.9995V11.5007H21.9978V10.0007Z',
    })
  );
};
EXE.displayName = 'EXE';
exports['default'] = EXE;
