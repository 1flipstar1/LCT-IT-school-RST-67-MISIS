'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var FolderOpen = function FolderOpen(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M14.0607 6.06066L13.6213 6.5H13L4.50001 6.5L4.50001 9H9.00001L9.37501 9L15.1711 9C16.1942 9 17.0885 9.69023 17.3477 10.6799L19.4544 18.7237C19.5742 19.181 19.9875 19.5 20.4603 19.5C21.0345 19.5 21.5 19.0345 21.5 18.4602L21.5 4.5L16.2426 4.5C15.8448 4.5 15.4633 4.65803 15.182 4.93934L14.0607 6.06066ZM3.00001 6L3.00001 9H1.75001C1.52053 9 1.30369 9.10505 1.16145 9.28513C1.01922 9.4652 0.967252 9.70048 1.0204 9.92372L3.15451 18.887C3.44946 20.1257 4.55631 21 5.82972 21L20.4603 21H20.5V20.9997C21.8843 20.9785 23 19.8496 23 18.4602L23 4C23 3.44772 22.5523 3 22 3L16.2426 3C15.447 3 14.6839 3.31607 14.1213 3.87868L13 5L4.00001 5C3.44772 5 3.00001 5.44772 3.00001 6ZM18.0034 19.1037C18.0394 19.2412 18.0862 19.3736 18.1429 19.5L5.82972 19.5C5.2509 19.5 4.74778 19.1026 4.61372 18.5395L2.69954 10.5H3.00001H4.50001H9.00001L9.37501 10.5L15.1711 10.5C15.5122 10.5 15.8103 10.7301 15.8967 11.06L18.0034 19.1037ZM6 17.4725H10V15.9725L6 15.9725L6 17.4725Z',
    })
  );
};
FolderOpen.displayName = 'FolderOpen';
exports['default'] = FolderOpen;
