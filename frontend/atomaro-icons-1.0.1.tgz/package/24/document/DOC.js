'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var DOC = function DOC(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M4 20.5H12V22H4C2.89543 22 2 21.1046 2 20V4C2 2.89543 2.89543 2 4 2H12.4773C12.9959 2 13.4942 2.20142 13.8671 2.56178L17.3898 5.96589C17.7798 6.34274 18 6.8618 18 7.40411V8H16.5V7.40411C16.5 7.26854 16.4449 7.13877 16.3474 7.04456L12.8247 3.64045C12.7315 3.55036 12.6069 3.5 12.4773 3.5H4C3.72386 3.5 3.5 3.72386 3.5 4V20C3.5 20.2761 3.72386 20.5 4 20.5ZM6.99316 11.5H8.24316C8.93352 11.5 9.49316 12.0596 9.49316 12.75V15.25C9.49316 15.9404 8.93352 16.5 8.24316 16.5H6.99316V11.5ZM5.49316 10H6.99316H8.24316C9.76195 10 10.9932 11.2312 10.9932 12.75V15.25C10.9932 16.7688 9.76195 18 8.24316 18H6.99316H5.49316V16.5V11.5V10ZM22.5295 15.25V15H24.0295V15.25C24.0295 16.7688 22.7983 18 21.2795 18C19.7608 18 18.5295 16.7688 18.5295 15.25V12.75C18.5295 11.2312 19.7608 10 21.2795 10C22.7983 10 24.0295 11.2312 24.0295 12.75V13H22.5295V12.75C22.5295 12.0596 21.9699 11.5 21.2795 11.5C20.5892 11.5 20.0295 12.0596 20.0295 12.75V15.25C20.0295 15.9404 20.5892 16.5 21.2795 16.5C21.9699 16.5 22.5295 15.9404 22.5295 15.25ZM16.0115 15.25V12.75C16.0115 12.0596 15.4518 11.5 14.7615 11.5C14.0711 11.5 13.5115 12.0596 13.5115 12.75V15.25C13.5115 15.9404 14.0711 16.5 14.7615 16.5C15.4518 16.5 16.0115 15.9404 16.0115 15.25ZM14.7615 10C13.2427 10 12.0115 11.2312 12.0115 12.75V15.25C12.0115 16.7688 13.2427 18 14.7615 18C16.2803 18 17.5115 16.7688 17.5115 15.25V12.75C17.5115 11.2312 16.2803 10 14.7615 10Z',
    })
  );
};
DOC.displayName = 'DOC';
exports['default'] = DOC;
