'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var FIG = function FIG(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M4.76562 20.5H12.7656V22H4.76562C3.66106 22 2.76562 21.1046 2.76562 20V4C2.76562 2.89543 3.66106 2 4.76562 2H13.2429C13.7615 2 14.2598 2.20142 14.6327 2.56178L18.1554 5.96589C18.5454 6.34274 18.7656 6.8618 18.7656 7.40411V8H17.2656V7.40411C17.2656 7.26854 17.2106 7.13877 17.1131 7.04456L13.5903 3.64045C13.4971 3.55036 13.3725 3.5 13.2429 3.5H4.76562C4.48948 3.5 4.26562 3.72386 4.26562 4V20C4.26562 20.2761 4.48948 20.5 4.76562 20.5ZM23.7551 14.5V13.9971H21.2551V15.4971H22.2551V16.5H21.0051C20.3148 16.5 19.7551 15.9404 19.7551 15.25V12.75C19.7551 12.0596 20.3148 11.5 21.0051 11.5C21.6955 11.5 22.2551 12.0596 22.2551 12.75V13H23.7551V12.75C23.7551 11.2312 22.5239 10 21.0051 10C19.4863 10 18.2551 11.2312 18.2551 12.75V15.25C18.2551 16.7688 19.4863 18 21.0051 18H23.2551C23.5313 18 23.7551 17.7761 23.7551 17.5V15.4971V14.5ZM17.2893 10.0095H12.7893V11.5095H14.3095V16.5118H12.7893V18.0118H17.2893V16.5118H15.8095V11.5095H17.2893V10.0095ZM11.2656 10.0105H6.76562V11.5105H6.76733V13.5103H6.76562V15.0103H6.76733V18.0117H8.26733V15.0103H10.7656V13.5103H8.26733V11.5105H11.2656V10.0105Z',
    })
  );
};
FIG.displayName = 'FIG';
exports['default'] = FIG;
