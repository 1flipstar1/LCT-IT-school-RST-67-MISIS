'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var FolderShared = function FolderShared(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M12.6214 6.5L13.0607 6.06066L14.182 4.93934C14.4633 4.65803 14.8449 4.5 15.2427 4.5H20.5V18C20.5 18.8284 19.8285 19.5 19 19.5H12V21H19C20.6569 21 22 19.6569 22 18V4C22 3.44772 21.5523 3 21 3H15.2427C14.447 3 13.684 3.31607 13.1214 3.87868L12 5H3.00004C2.44776 5 2.00004 5.44772 2.00004 6V9H3.50004V6.5H12H12.6214ZM6.00004 14.5C6.55233 14.5 7.00004 14.0523 7.00004 13.5C7.00004 12.9477 6.55233 12.5 6.00004 12.5C5.44776 12.5 5.00004 12.9477 5.00004 13.5C5.00004 14.0523 5.44776 14.5 6.00004 14.5ZM6.00004 16C7.38075 16 8.50004 14.8807 8.50004 13.5C8.50004 12.1193 7.38075 11 6.00004 11C4.61933 11 3.50004 12.1193 3.50004 13.5C3.50004 14.8807 4.61933 16 6.00004 16ZM10 21H8.5C8.5 19.6193 7.38071 18.5 6 18.5C4.61929 18.5 3.5 19.6193 3.5 21H2.00004V21.0183L2 21C2 18.7909 3.79086 17 6 17C8.20914 17 10 18.7909 10 21Z',
    })
  );
};
FolderShared.displayName = 'FolderShared';
exports['default'] = FolderShared;
