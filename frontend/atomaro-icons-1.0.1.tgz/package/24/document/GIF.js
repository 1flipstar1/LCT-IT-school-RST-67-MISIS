'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var GIF = function GIF(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M4 20.5H12V22H4C2.89543 22 2 21.1046 2 20V4C2 2.89543 2.89543 2 4 2H12.4773C12.9959 2 13.4942 2.20142 13.8671 2.56178L17.3898 5.96589C17.7798 6.34274 18 6.8618 18 7.40411V8H16.5V7.40411C16.5 7.26854 16.4449 7.13877 16.3474 7.04456L12.8247 3.64045C12.7315 3.55036 12.6069 3.5 12.4773 3.5H4C3.72386 3.5 3.5 3.72386 3.5 4V20C3.5 20.2761 3.72386 20.5 4 20.5ZM11.5477 14.5V13.9971H9.04773V15.4971H10.0477V16.5H8.79773C8.10737 16.5 7.54773 15.9404 7.54773 15.25V12.75C7.54773 12.0596 8.10737 11.5 8.79773 11.5C9.48809 11.5 10.0477 12.0596 10.0477 12.75V13H11.5477V12.75C11.5477 11.2312 10.3165 10 8.79773 10C7.27895 10 6.04773 11.2312 6.04773 12.75V15.25C6.04773 16.7688 7.27895 18 8.79773 18H11.0477C11.3239 18 11.5477 17.7761 11.5477 17.5V15.4971V14.5ZM17.5237 10.0095H13.0237V11.5095H14.5439V16.5118H13.0237V18.0118H17.5237V16.5118H16.0439V11.5095H17.5237V10.0095ZM23.5 10.0105H19V11.5105H19.0017V13.5103H19V15.0103H19.0017V18.0117H20.5017V15.0103H23V13.5103H20.5017V11.5105H23.5V10.0105Z',
    })
  );
};
GIF.displayName = 'GIF';
exports['default'] = GIF;
