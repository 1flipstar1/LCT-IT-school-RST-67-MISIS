'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var JS = function JS(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M3.5 20C3.5 20.2761 3.72386 20.5 4 20.5H12V22H4C2.89543 22 2 21.1046 2 20V4C2 2.89543 2.89543 2 4 2H12.4773C12.9959 2 13.4942 2.20142 13.8671 2.56178L17.3898 5.96589C17.7798 6.34274 18 6.8618 18 7.40411V8H16.5V7.40411C16.5 7.26854 16.4449 7.13877 16.3474 7.04456L12.8247 3.64045C12.7315 3.55036 12.6069 3.5 12.4773 3.5H4C3.72386 3.5 3.5 3.72386 3.5 4V20ZM7 18H8.75C10.2688 18 11.5 16.7688 11.5 15.25V11.5V10H10H8V11.5H10V15.25C10 15.9404 9.44036 16.5 8.75 16.5H7V18ZM12.99 12.3201C12.99 11.0429 14.0253 10.0076 15.3025 10.0076H17.5V11.5076H15.3025C14.8538 11.5076 14.49 11.8714 14.49 12.3201C14.49 12.6832 14.7308 13.0023 15.0801 13.1017L16.3238 13.4557C17.3175 13.7386 18.003 14.6464 18.003 15.6796C18.003 16.9567 16.9678 17.9919 15.6907 17.9919L13 17.9918L13 16.4918L15.6907 16.4919C16.1393 16.4919 16.503 16.1282 16.503 15.6796C16.503 15.3167 16.2622 14.9978 15.9131 14.8984L14.6694 14.5444C13.6755 14.2615 12.99 13.3535 12.99 12.3201Z',
    })
  );
};
JS.displayName = 'JS';
exports['default'] = JS;
