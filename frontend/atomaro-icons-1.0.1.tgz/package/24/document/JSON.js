'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var JSON = function JSON(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M12 20.5H4C3.72386 20.5 3.5 20.2761 3.5 20H2C2 21.1046 2.89543 22 4 22H12V20.5ZM3.5 4V8H2V4C2 2.89543 2.89543 2 4 2H12.4773C12.9959 2 13.4942 2.20142 13.8671 2.56178L17.3898 5.96589C17.7798 6.34274 18 6.8618 18 7.40411V8H16.5V7.40411C16.5 7.26854 16.4449 7.13877 16.3474 7.04456L12.8247 3.64045C12.7315 3.55036 12.6069 3.5 12.4773 3.5H4C3.72386 3.5 3.5 3.72386 3.5 4ZM0 18H1.75C3.26878 18 4.5 16.7688 4.5 15.25V11.5V10H3H1V11.5H3V15.25C3 15.9404 2.44036 16.5 1.75 16.5H0V18ZM5.98995 12.3201C5.98995 11.0429 7.02533 10.0076 8.30253 10.0076H10.5V11.5076H8.30253C7.85375 11.5076 7.48995 11.8714 7.48995 12.3201C7.48995 12.6832 7.73084 13.0023 8.08006 13.1017L9.3238 13.4557C10.3175 13.7386 11.003 14.6464 11.003 15.6796C11.003 16.9567 9.96777 17.9919 8.69073 17.9919L5.99999 17.9918L6.00001 16.4918L8.69075 16.4919C9.13935 16.4919 9.50302 16.1282 9.50302 15.6796C9.50302 15.3167 9.26222 14.9978 8.91314 14.8984L7.6694 14.5444C6.67552 14.2615 5.98995 13.3535 5.98995 12.3201ZM16.0115 15.25V12.75C16.0115 12.0596 15.4518 11.5 14.7615 11.5C14.0711 11.5 13.5115 12.0596 13.5115 12.75V15.25C13.5115 15.9404 14.0711 16.5 14.7615 16.5C15.4518 16.5 16.0115 15.9404 16.0115 15.25ZM14.7615 10C13.2427 10 12.0115 11.2312 12.0115 12.75V15.25C12.0115 16.7688 13.2427 18 14.7615 18C16.2803 18 17.5115 16.7688 17.5115 15.25V12.75C17.5115 11.2312 16.2803 10 14.7615 10ZM22.5001 10H24.0001V18H22.4107L19.9807 13.1634L19.9807 18H18.4807L18.4807 10H20.0701L22.5001 14.8366V10Z',
    })
  );
};
JSON.displayName = 'JSON';
exports['default'] = JSON;
