'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var FolderOpenFill = function FolderOpenFill(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M2.99991 10H1.30916C0.649786 10 0.170903 10.627 0.344396 11.2631L2.39701 18.7894C2.75296 20.0945 3.93844 21 5.2913 21L18.952 21C18.8689 20.8539 18.7974 20.6993 18.7391 20.5372L15.1837 10.6613C15.0409 10.2645 14.6645 10 14.2428 10L2.99991 10ZM22.9999 19.5319L22.9999 4C22.9999 3.44772 22.5522 3 21.9999 3L16.2426 3C15.4469 3 14.6838 3.31607 14.1212 3.87868L12.9999 5L3.99991 5C3.44762 5 2.99991 5.44772 2.99991 6L2.99991 8.5L14.2428 8.5C15.2971 8.5 16.238 9.1613 16.5951 10.1532L20.1504 20.0291C20.3601 20.6116 20.9127 21 21.5318 21C22.3426 21 22.9999 20.3427 22.9999 19.5319ZM9.00015 18.5145H5.00015V17.0145H9.00015V18.5145Z',
    })
  );
};
FolderOpenFill.displayName = 'FolderOpenFill';
exports['default'] = FolderOpenFill;
