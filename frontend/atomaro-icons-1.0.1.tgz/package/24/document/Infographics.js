'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Infographics = function Infographics(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M18.5 20C18.5 20.2761 18.2761 20.5 18 20.5H6C5.72386 20.5 5.5 20.2761 5.5 20V4C5.5 3.72386 5.72386 3.5 6 3.5H13.4737C13.6039 3.5 13.7289 3.55076 13.8223 3.6415L18.3485 8.04203C18.4454 8.13617 18.5 8.26548 18.5 8.40053V20ZM4 4C4 2.89543 4.89543 2 6 2H13.4737C13.9944 2 14.4946 2.20306 14.8679 2.56601L19.3942 6.96654C19.7815 7.3431 20 7.86033 20 8.40053V20C20 21.1046 19.1046 22 18 22H6C4.89543 22 4 21.1046 4 20V4ZM15.5 13C15.5 14.933 13.933 16.5 12 16.5C11.3049 16.5 10.6572 16.2974 10.1126 15.948L12.2374 13.8232C12.5656 13.495 12.75 13.0499 12.75 12.5858V9.58054C14.3226 9.92388 15.5 11.3244 15.5 13ZM10.8889 13.0504L9.05197 14.8874C8.7026 14.3428 8.5 13.6951 8.5 13C8.5 12.4183 8.6419 11.8698 8.89298 11.3871L10.8889 13.0504ZM11.25 11.3987L9.85369 10.2351C10.2577 9.92102 10.7325 9.69353 11.25 9.58054V11.3987ZM17 13C17 15.7614 14.7614 18 12 18C9.23858 18 7 15.7614 7 13C7 10.2386 9.23858 8 12 8C14.7614 8 17 10.2386 17 13Z',
    })
  );
};
Infographics.displayName = 'Infographics';
exports['default'] = Infographics;
