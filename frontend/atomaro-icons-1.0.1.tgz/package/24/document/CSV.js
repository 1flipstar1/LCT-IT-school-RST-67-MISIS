'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var CSV = function CSV(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M4 20.5C3.72386 20.5 3.5 20.2761 3.5 20V4C3.5 3.72386 3.72386 3.5 4 3.5H12.4773C12.6069 3.5 12.7315 3.55036 12.8247 3.64045L16.3474 7.04456C16.4449 7.13877 16.5 7.26854 16.5 7.40411V8H18V7.40411C18 6.8618 17.7798 6.34274 17.3898 5.96589L13.8671 2.56178C13.4942 2.20142 12.9959 2 12.4773 2H4C2.89543 2 2 2.89543 2 4V20C2 21.1046 2.89543 22 4 22H12V20.5H4ZM10 15.25V15H11.5V15.25C11.5 16.7688 10.2688 18 8.75 18C7.23122 18 6 16.7688 6 15.25V12.75C6 11.2312 7.23122 10 8.75 10C10.2688 10 11.5 11.2312 11.5 12.75V13H10V12.75C10 12.0596 9.44036 11.5 8.75 11.5C8.05964 11.5 7.5 12.0596 7.5 12.75V15.25C7.5 15.9404 8.05964 16.5 8.75 16.5C9.44036 16.5 10 15.9404 10 15.25ZM14.7995 10C13.5223 10 12.4869 11.0354 12.4869 12.3126C12.4869 13.3459 13.1725 14.2539 14.1664 14.5368L15.4101 14.8908C15.7592 14.9902 16 15.3091 16 15.672C16 16.1207 15.6363 16.4843 15.1877 16.4843L12.497 16.4843L12.497 17.9843L15.1877 17.9843C16.4648 17.9843 17.5 16.9491 17.5 15.672C17.5 14.6388 16.8145 13.731 15.8208 13.4481L14.577 13.0941C14.2278 12.9947 13.9869 12.6757 13.9869 12.3126C13.9869 11.8638 14.3507 11.5 14.7995 11.5H16.997V10H14.7995ZM19.6686 18H21.8992L23.5681 10H22.0358L20.7839 16.001L19.5323 10H18L19.6686 18Z',
    })
  );
};
CSV.displayName = 'CSV';
exports['default'] = CSV;
