'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var DOTX = function DOTX(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M3.5 20C3.5 20.2761 3.72386 20.5 4 20.5H12V22H4C2.89543 22 2 21.1046 2 20H3.5ZM3.5 8V4C3.5 3.72386 3.72386 3.5 4 3.5H12.4773C12.6069 3.5 12.7315 3.55036 12.8247 3.64045L16.3474 7.04456C16.4449 7.13877 16.5 7.26854 16.5 7.40411V8H18V7.40411C18 6.8618 17.7798 6.34274 17.3898 5.96589L13.8671 2.56178C13.4942 2.20142 12.9959 2 12.4773 2H4C2.89543 2 2 2.89543 2 4V8H3.5ZM2.75 11.5H1.5V16.5H2.75C3.44036 16.5 4 15.9404 4 15.25V12.75C4 12.0596 3.44036 11.5 2.75 11.5ZM1.5 10H0V11.5V16.5V18H1.5H2.75C4.26878 18 5.5 16.7688 5.5 15.25V12.75C5.5 11.2312 4.26878 10 2.75 10H1.5ZM10.5 12.75V15.25C10.5 15.9404 9.94036 16.5 9.25 16.5C8.55964 16.5 8 15.9404 8 15.25V12.75C8 12.0596 8.55964 11.5 9.25 11.5C9.94036 11.5 10.5 12.0596 10.5 12.75ZM6.5 12.75C6.5 11.2312 7.73122 10 9.25 10C10.7688 10 12 11.2312 12 12.75V15.25C12 16.7688 10.7688 18 9.25 18C7.73122 18 6.5 16.7688 6.5 15.25V12.75ZM23.0042 10H21.3762L20.5021 12.0713L19.628 10H18L19.6881 14.0002L18.0002 18H19.6283L20.5021 15.9292L21.376 18H23.004L21.3161 14.0002L23.0042 10ZM17.0039 10H12.5V11.5H14.002V17.9981H15.502V11.5H17.0039V10Z',
    })
  );
};
DOTX.displayName = 'DOTX';
exports['default'] = DOTX;
