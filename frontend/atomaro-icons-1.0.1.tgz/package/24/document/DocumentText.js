'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var DocumentText = function DocumentText(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M18 20.5H6C5.72386 20.5 5.5 20.2761 5.5 20V4C5.5 3.72386 5.72386 3.5 6 3.5H13.4737C13.6039 3.5 13.7289 3.55076 13.8223 3.6415L18.3485 8.04203C18.4454 8.13617 18.5 8.26548 18.5 8.40053V20C18.5 20.2761 18.2761 20.5 18 20.5ZM4 4C4 2.89543 4.89543 2 6 2H13.4737C13.9944 2 14.4946 2.20306 14.8679 2.56601L19.3942 6.96654C19.7815 7.3431 20 7.86033 20 8.40053V20C20 21.1046 19.1046 22 18 22H6C4.89543 22 4 21.1046 4 20V4ZM16 10.5H8V9H16V10.5ZM8 13.75H16V12.25H8V13.75ZM8 17H16V15.5H8V17Z',
    })
  );
};
DocumentText.displayName = 'DocumentText';
exports['default'] = DocumentText;
