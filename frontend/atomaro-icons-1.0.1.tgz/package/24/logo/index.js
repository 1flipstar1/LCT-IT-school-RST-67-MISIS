"use strict";

var __importDefault = this && this.__importDefault || function (mod) {
  return mod && mod.__esModule ? mod : {
    "default": mod
  };
};
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.YandexDisk = exports.YandexDiskFill = exports.Wink = exports.WinkFill = exports.Windows = exports.WindowsFill = exports.WhatsApp = exports.Wargaming = exports.Vkontakte = exports.VkontakteFill = exports.Viber = exports.Twitter = exports.TwitterFill = exports.Telegram = exports.TelegramFill = exports.TamTam = exports.Sber = exports.Rostelecom = exports.RostelecomSmartHome = exports.RostelecomSmartHomeFill = exports.RostelecomFill = exports.Onlime = exports.OnlimeFill = exports.Odnoklassniki = exports.OdnoklassnikiFill = exports.MicrosoftOffice = exports.Mailru = exports.MYGAMES = exports.Licey = exports.LiceyFill = exports.Kluch = exports.KluchFill = exports.Googleplus = exports.GooglePlay = exports.GooglePlayFill = exports.Gitlab = exports.GitlabFill = exports.Github = exports.GithubFill = exports.FourGame = exports.Flutter = exports.FlutterFill = exports.Flickr = exports.FlickrFill = exports.EsetNod = exports.DrWeb = exports.Apple = exports.AppleFill = exports.Android = exports.AndroidFill = void 0;
exports.Youtube = exports.YoutubeFill = exports.Yandex = exports.YandexFill = void 0;
var AndroidFill_1 = require("./AndroidFill");
Object.defineProperty(exports, "AndroidFill", {
  enumerable: true,
  get: function get() {
    return __importDefault(AndroidFill_1)["default"];
  }
});
var Android_1 = require("./Android");
Object.defineProperty(exports, "Android", {
  enumerable: true,
  get: function get() {
    return __importDefault(Android_1)["default"];
  }
});
var AppleFill_1 = require("./AppleFill");
Object.defineProperty(exports, "AppleFill", {
  enumerable: true,
  get: function get() {
    return __importDefault(AppleFill_1)["default"];
  }
});
var Apple_1 = require("./Apple");
Object.defineProperty(exports, "Apple", {
  enumerable: true,
  get: function get() {
    return __importDefault(Apple_1)["default"];
  }
});
var DrWeb_1 = require("./DrWeb");
Object.defineProperty(exports, "DrWeb", {
  enumerable: true,
  get: function get() {
    return __importDefault(DrWeb_1)["default"];
  }
});
var EsetNod_1 = require("./EsetNod");
Object.defineProperty(exports, "EsetNod", {
  enumerable: true,
  get: function get() {
    return __importDefault(EsetNod_1)["default"];
  }
});
var FlickrFill_1 = require("./FlickrFill");
Object.defineProperty(exports, "FlickrFill", {
  enumerable: true,
  get: function get() {
    return __importDefault(FlickrFill_1)["default"];
  }
});
var Flickr_1 = require("./Flickr");
Object.defineProperty(exports, "Flickr", {
  enumerable: true,
  get: function get() {
    return __importDefault(Flickr_1)["default"];
  }
});
var FlutterFill_1 = require("./FlutterFill");
Object.defineProperty(exports, "FlutterFill", {
  enumerable: true,
  get: function get() {
    return __importDefault(FlutterFill_1)["default"];
  }
});
var Flutter_1 = require("./Flutter");
Object.defineProperty(exports, "Flutter", {
  enumerable: true,
  get: function get() {
    return __importDefault(Flutter_1)["default"];
  }
});
var FourGame_1 = require("./FourGame");
Object.defineProperty(exports, "FourGame", {
  enumerable: true,
  get: function get() {
    return __importDefault(FourGame_1)["default"];
  }
});
var GithubFill_1 = require("./GithubFill");
Object.defineProperty(exports, "GithubFill", {
  enumerable: true,
  get: function get() {
    return __importDefault(GithubFill_1)["default"];
  }
});
var Github_1 = require("./Github");
Object.defineProperty(exports, "Github", {
  enumerable: true,
  get: function get() {
    return __importDefault(Github_1)["default"];
  }
});
var GitlabFill_1 = require("./GitlabFill");
Object.defineProperty(exports, "GitlabFill", {
  enumerable: true,
  get: function get() {
    return __importDefault(GitlabFill_1)["default"];
  }
});
var Gitlab_1 = require("./Gitlab");
Object.defineProperty(exports, "Gitlab", {
  enumerable: true,
  get: function get() {
    return __importDefault(Gitlab_1)["default"];
  }
});
var GooglePlayFill_1 = require("./GooglePlayFill");
Object.defineProperty(exports, "GooglePlayFill", {
  enumerable: true,
  get: function get() {
    return __importDefault(GooglePlayFill_1)["default"];
  }
});
var GooglePlay_1 = require("./GooglePlay");
Object.defineProperty(exports, "GooglePlay", {
  enumerable: true,
  get: function get() {
    return __importDefault(GooglePlay_1)["default"];
  }
});
var Googleplus_1 = require("./Googleplus");
Object.defineProperty(exports, "Googleplus", {
  enumerable: true,
  get: function get() {
    return __importDefault(Googleplus_1)["default"];
  }
});
var KluchFill_1 = require("./KluchFill");
Object.defineProperty(exports, "KluchFill", {
  enumerable: true,
  get: function get() {
    return __importDefault(KluchFill_1)["default"];
  }
});
var Kluch_1 = require("./Kluch");
Object.defineProperty(exports, "Kluch", {
  enumerable: true,
  get: function get() {
    return __importDefault(Kluch_1)["default"];
  }
});
var LiceyFill_1 = require("./LiceyFill");
Object.defineProperty(exports, "LiceyFill", {
  enumerable: true,
  get: function get() {
    return __importDefault(LiceyFill_1)["default"];
  }
});
var Licey_1 = require("./Licey");
Object.defineProperty(exports, "Licey", {
  enumerable: true,
  get: function get() {
    return __importDefault(Licey_1)["default"];
  }
});
var MYGAMES_1 = require("./MYGAMES");
Object.defineProperty(exports, "MYGAMES", {
  enumerable: true,
  get: function get() {
    return __importDefault(MYGAMES_1)["default"];
  }
});
var Mailru_1 = require("./Mailru");
Object.defineProperty(exports, "Mailru", {
  enumerable: true,
  get: function get() {
    return __importDefault(Mailru_1)["default"];
  }
});
var MicrosoftOffice_1 = require("./MicrosoftOffice");
Object.defineProperty(exports, "MicrosoftOffice", {
  enumerable: true,
  get: function get() {
    return __importDefault(MicrosoftOffice_1)["default"];
  }
});
var OdnoklassnikiFill_1 = require("./OdnoklassnikiFill");
Object.defineProperty(exports, "OdnoklassnikiFill", {
  enumerable: true,
  get: function get() {
    return __importDefault(OdnoklassnikiFill_1)["default"];
  }
});
var Odnoklassniki_1 = require("./Odnoklassniki");
Object.defineProperty(exports, "Odnoklassniki", {
  enumerable: true,
  get: function get() {
    return __importDefault(Odnoklassniki_1)["default"];
  }
});
var OnlimeFill_1 = require("./OnlimeFill");
Object.defineProperty(exports, "OnlimeFill", {
  enumerable: true,
  get: function get() {
    return __importDefault(OnlimeFill_1)["default"];
  }
});
var Onlime_1 = require("./Onlime");
Object.defineProperty(exports, "Onlime", {
  enumerable: true,
  get: function get() {
    return __importDefault(Onlime_1)["default"];
  }
});
var RostelecomFill_1 = require("./RostelecomFill");
Object.defineProperty(exports, "RostelecomFill", {
  enumerable: true,
  get: function get() {
    return __importDefault(RostelecomFill_1)["default"];
  }
});
var RostelecomSmartHomeFill_1 = require("./RostelecomSmartHomeFill");
Object.defineProperty(exports, "RostelecomSmartHomeFill", {
  enumerable: true,
  get: function get() {
    return __importDefault(RostelecomSmartHomeFill_1)["default"];
  }
});
var RostelecomSmartHome_1 = require("./RostelecomSmartHome");
Object.defineProperty(exports, "RostelecomSmartHome", {
  enumerable: true,
  get: function get() {
    return __importDefault(RostelecomSmartHome_1)["default"];
  }
});
var Rostelecom_1 = require("./Rostelecom");
Object.defineProperty(exports, "Rostelecom", {
  enumerable: true,
  get: function get() {
    return __importDefault(Rostelecom_1)["default"];
  }
});
var Sber_1 = require("./Sber");
Object.defineProperty(exports, "Sber", {
  enumerable: true,
  get: function get() {
    return __importDefault(Sber_1)["default"];
  }
});
var TamTam_1 = require("./TamTam");
Object.defineProperty(exports, "TamTam", {
  enumerable: true,
  get: function get() {
    return __importDefault(TamTam_1)["default"];
  }
});
var TelegramFill_1 = require("./TelegramFill");
Object.defineProperty(exports, "TelegramFill", {
  enumerable: true,
  get: function get() {
    return __importDefault(TelegramFill_1)["default"];
  }
});
var Telegram_1 = require("./Telegram");
Object.defineProperty(exports, "Telegram", {
  enumerable: true,
  get: function get() {
    return __importDefault(Telegram_1)["default"];
  }
});
var TwitterFill_1 = require("./TwitterFill");
Object.defineProperty(exports, "TwitterFill", {
  enumerable: true,
  get: function get() {
    return __importDefault(TwitterFill_1)["default"];
  }
});
var Twitter_1 = require("./Twitter");
Object.defineProperty(exports, "Twitter", {
  enumerable: true,
  get: function get() {
    return __importDefault(Twitter_1)["default"];
  }
});
var Viber_1 = require("./Viber");
Object.defineProperty(exports, "Viber", {
  enumerable: true,
  get: function get() {
    return __importDefault(Viber_1)["default"];
  }
});
var VkontakteFill_1 = require("./VkontakteFill");
Object.defineProperty(exports, "VkontakteFill", {
  enumerable: true,
  get: function get() {
    return __importDefault(VkontakteFill_1)["default"];
  }
});
var Vkontakte_1 = require("./Vkontakte");
Object.defineProperty(exports, "Vkontakte", {
  enumerable: true,
  get: function get() {
    return __importDefault(Vkontakte_1)["default"];
  }
});
var Wargaming_1 = require("./Wargaming");
Object.defineProperty(exports, "Wargaming", {
  enumerable: true,
  get: function get() {
    return __importDefault(Wargaming_1)["default"];
  }
});
var WhatsApp_1 = require("./WhatsApp");
Object.defineProperty(exports, "WhatsApp", {
  enumerable: true,
  get: function get() {
    return __importDefault(WhatsApp_1)["default"];
  }
});
var WindowsFill_1 = require("./WindowsFill");
Object.defineProperty(exports, "WindowsFill", {
  enumerable: true,
  get: function get() {
    return __importDefault(WindowsFill_1)["default"];
  }
});
var Windows_1 = require("./Windows");
Object.defineProperty(exports, "Windows", {
  enumerable: true,
  get: function get() {
    return __importDefault(Windows_1)["default"];
  }
});
var WinkFill_1 = require("./WinkFill");
Object.defineProperty(exports, "WinkFill", {
  enumerable: true,
  get: function get() {
    return __importDefault(WinkFill_1)["default"];
  }
});
var Wink_1 = require("./Wink");
Object.defineProperty(exports, "Wink", {
  enumerable: true,
  get: function get() {
    return __importDefault(Wink_1)["default"];
  }
});
var YandexDiskFill_1 = require("./YandexDiskFill");
Object.defineProperty(exports, "YandexDiskFill", {
  enumerable: true,
  get: function get() {
    return __importDefault(YandexDiskFill_1)["default"];
  }
});
var YandexDisk_1 = require("./YandexDisk");
Object.defineProperty(exports, "YandexDisk", {
  enumerable: true,
  get: function get() {
    return __importDefault(YandexDisk_1)["default"];
  }
});
var YandexFill_1 = require("./YandexFill");
Object.defineProperty(exports, "YandexFill", {
  enumerable: true,
  get: function get() {
    return __importDefault(YandexFill_1)["default"];
  }
});
var Yandex_1 = require("./Yandex");
Object.defineProperty(exports, "Yandex", {
  enumerable: true,
  get: function get() {
    return __importDefault(Yandex_1)["default"];
  }
});
var YoutubeFill_1 = require("./YoutubeFill");
Object.defineProperty(exports, "YoutubeFill", {
  enumerable: true,
  get: function get() {
    return __importDefault(YoutubeFill_1)["default"];
  }
});
var Youtube_1 = require("./Youtube");
Object.defineProperty(exports, "Youtube", {
  enumerable: true,
  get: function get() {
    return __importDefault(Youtube_1)["default"];
  }
});