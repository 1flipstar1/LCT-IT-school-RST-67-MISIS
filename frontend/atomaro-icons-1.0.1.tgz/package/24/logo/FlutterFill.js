'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var FlutterFill = function FlutterFill(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M7.17768 14.8232L19.5738 2.42677C19.7313 2.26928 19.6197 2 19.397 2H14.1036C14.0372 2 13.9737 2.02634 13.9268 2.07322L4.17674 11.8232C4.0791 11.9208 4.07911 12.0792 4.17677 12.1768L6.82415 14.8233C6.92179 14.9209 7.08006 14.9209 7.17768 14.8232ZM13.9999 16L19.5731 10.4268C19.7306 10.2693 19.6191 10 19.3964 10H14.1035C14.0372 10 13.9736 10.0263 13.9267 10.0732L10.8232 13.1768L8.17669 15.8232C8.07906 15.9209 8.07906 16.0791 8.17669 16.1768H8.1767L8.47308 16.4732L13.9265 21.9268C13.9734 21.9737 14.037 22 14.1033 22H19.3962C19.6189 22 19.7304 21.7307 19.5729 21.5732L13.9999 16Z',
    })
  );
};
FlutterFill.displayName = 'FlutterFill';
exports['default'] = FlutterFill;
