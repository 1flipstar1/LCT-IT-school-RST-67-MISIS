'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var GitlabFill = function GitlabFill(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      d: 'M2.13645 12.4817L5.18591 3.34368C5.33594 2.8941 5.96897 2.88609 6.13033 3.33173L8.42333 9.66461H15.578L17.871 3.33173C18.0324 2.88609 18.6654 2.8941 18.8154 3.34368L21.8649 12.4817C22.1441 13.3184 21.8422 14.2394 21.1217 14.7483L12.2892 20.9875C12.1162 21.1097 11.8851 21.1097 11.7122 20.9875L2.87968 14.7483C2.15917 14.2394 1.8572 13.3184 2.13645 12.4817Z',
    })
  );
};
GitlabFill.displayName = 'GitlabFill';
exports['default'] = GitlabFill;
