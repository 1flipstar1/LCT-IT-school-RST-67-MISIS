'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var GooglePlayFill = function GooglePlayFill(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M16.9421 15.0832C16.8407 15.1427 16.7116 15.1235 16.6318 15.0372L13.9849 12.1696C13.8965 12.0738 13.8965 11.9262 13.9849 11.8305L16.6307 8.9641C16.7105 8.87773 16.8396 8.85856 16.941 8.91805L18.8877 10.0604C20.3694 10.9298 20.3694 13.0721 18.8877 13.9415L16.9421 15.0832ZM15.1765 16.1192C15.3141 16.0385 15.3419 15.8513 15.2337 15.734L12.9913 13.3048C12.8924 13.1975 12.7229 13.1975 12.6239 13.3048L5.87835 20.6125C5.75315 20.7482 5.81462 20.9658 5.99798 20.9871C6.45566 21.0403 6.93962 20.9526 7.38872 20.6891L15.1765 16.1192ZM4.60015 19.7858C4.49125 19.9037 4.30019 19.8898 4.22914 19.7458C4.08343 19.4505 4 19.114 4 18.7485V5.25341C4 4.88737 4.08367 4.55045 4.22978 4.25483C4.3009 4.11094 4.49188 4.09703 4.60075 4.21497L11.6304 11.8305C11.7188 11.9262 11.7188 12.0738 11.6304 12.1696L4.60015 19.7858ZM5.99961 3.01465C5.81617 3.03583 5.7546 3.25351 5.87985 3.38919L12.6239 10.6953C12.7229 10.8025 12.8924 10.8025 12.9913 10.6953L15.2326 8.26724C15.3408 8.15002 15.313 7.9628 15.1755 7.88206L7.38872 3.31284C6.94015 3.04962 6.45681 2.96185 5.99961 3.01465Z',
    })
  );
};
GooglePlayFill.displayName = 'GooglePlayFill';
exports['default'] = GooglePlayFill;
