'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Gitlab = function Gitlab(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M16.6302 11.1646H15.578H8.42333H7.37115L7.01293 10.1753L5.69871 6.54561L3.55931 12.9565C3.4895 13.1657 3.56499 13.3959 3.74512 13.5232L12.0007 19.3548L20.2562 13.5232C20.4364 13.3959 20.5119 13.1657 20.442 12.9565L18.3026 6.54561L16.9884 10.1753L16.6302 11.1646ZM17.5375 4.25282L15.578 9.66461H8.42333L6.46384 4.25282L6.42654 4.1498L6.26505 3.7038L6.13033 3.33173C5.96897 2.88609 5.33594 2.8941 5.18591 3.34368L5.06065 3.71904L4.9105 4.16898L4.87581 4.27291L2.13645 12.4817C1.8572 13.3184 2.15917 14.2394 2.87968 14.7483L11.7122 20.9875C11.8851 21.1097 12.1162 21.1097 12.2892 20.9875L21.1217 14.7483C21.8422 14.2394 22.1441 13.3184 21.8649 12.4817L19.1255 4.27292L19.0909 4.16898L18.9407 3.71904L18.8154 3.34368C18.6654 2.8941 18.0324 2.88609 17.871 3.33173L17.7363 3.7038L17.5748 4.1498L17.5375 4.25282Z',
    })
  );
};
Gitlab.displayName = 'Gitlab';
exports['default'] = Gitlab;
