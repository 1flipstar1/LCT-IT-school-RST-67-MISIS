'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Android = function Android(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M7.35321 9.02908C10.3656 7.59276 14.1015 7.65992 17.0463 9.23058L18.8293 5.66455L20.1709 6.33537L18.3175 10.0423C20.2931 11.5382 21.7116 13.8559 21.9609 16.9954C22.0047 17.546 21.5524 18 21.0001 18H3.00012C2.44784 18 1.99557 17.546 2.0393 16.9954C2.3039 13.6644 3.88463 11.2585 6.05045 9.77767L4.3293 6.33537L5.67094 5.66455L7.35321 9.02908ZM20.398 16.5C19.7386 11.8512 15.962 9.49996 12.0001 9.49996C8.03822 9.49996 4.2616 11.8512 3.60227 16.5H20.398ZM7.29301 14.7071C7.48055 14.8946 7.7349 15 8.00012 15C8.26534 15 8.51969 14.8946 8.70723 14.7071C8.89476 14.5195 9.00012 14.2652 9.00012 14C9.00012 13.7347 8.89476 13.4804 8.70723 13.2929C8.51969 13.1053 8.26534 13 8.00012 13C7.7349 13 7.48055 13.1053 7.29301 13.2929C7.10548 13.4804 7.00012 13.7347 7.00012 14C7.00012 14.2652 7.10548 14.5195 7.29301 14.7071ZM16.0001 15C15.7349 15 15.4805 14.8946 15.293 14.7071C15.1055 14.5195 15.0001 14.2652 15.0001 14C15.0001 13.7347 15.1055 13.4804 15.293 13.2929C15.4805 13.1053 15.7349 13 16.0001 13C16.2653 13 16.5197 13.1053 16.7072 13.2929C16.8948 13.4804 17.0001 13.7347 17.0001 14C17.0001 14.2652 16.8948 14.5195 16.7072 14.7071C16.5197 14.8946 16.2653 15 16.0001 15Z',
    })
  );
};
Android.displayName = 'Android';
exports['default'] = Android;
