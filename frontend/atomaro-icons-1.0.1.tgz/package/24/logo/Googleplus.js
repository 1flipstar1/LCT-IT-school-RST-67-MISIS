'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Googleplus = function Googleplus(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      d: 'M1.00449 12C0.861378 8.39101 4.16175 5.0648 7.93347 5.02153C9.85582 4.86448 11.726 5.5795 13.1808 6.74569C12.5841 7.37417 11.9769 7.99538 11.3283 8.57696C10.0476 7.83168 8.50559 7.26372 7.00878 7.76814C4.59455 8.42657 3.1325 11.1568 4.02591 13.419C4.76578 15.7816 7.76603 17.0782 10.1174 16.0857C11.3349 15.6682 12.1377 14.6062 12.4899 13.45C11 13.45 8.30341 13.45 8.30341 13.45L8.29993 11C8.29993 11 13.1808 11 15.288 11C15.4311 12.9484 15.131 15.05 13.8086 16.6138C11.9977 18.846 8.65218 19.5011 5.93056 18.6254C3.04215 17.7167 0.94162 14.9206 1.00449 12ZM19 9.00119H21V11H23V13H21V15H19V13H17V11H19V9.00119Z',
    })
  );
};
Googleplus.displayName = 'Googleplus';
exports['default'] = Googleplus;
