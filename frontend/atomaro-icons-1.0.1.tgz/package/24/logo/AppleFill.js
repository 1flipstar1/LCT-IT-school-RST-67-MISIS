'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var AppleFill = function AppleFill(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      d: 'M17.6972 11.6276C17.7269 14.6555 20.4739 15.6585 20.5 15.6765C20.479 15.7481 20.0684 17.1151 19.0609 18.5189C18.1883 19.7352 17.2881 20.9494 15.8649 20.9751C14.4614 20.9987 14.0167 20.1783 12.4195 20.1818C10.8179 20.1818 10.3203 20.9549 8.99796 21.0001C7.6205 21.0515 6.5738 19.6859 5.70119 18.4731C3.90447 15.994 2.53427 11.4623 4.37016 8.39423C5.28701 6.87233 6.9198 5.91446 8.6904 5.88668C10.0425 5.86445 11.3155 6.75286 12.1359 6.75286C12.9613 6.75286 14.5092 5.68524 16.1377 5.83875C16.8152 5.86514 18.7265 6.09992 19.956 7.8177C19.8566 7.87466 17.6733 9.09301 17.6972 11.6276ZM15.0685 4.19807C14.3424 5.04133 13.147 5.7026 11.9785 5.6123C11.8167 4.46758 12.4021 3.26868 13.0788 2.5185C13.8303 1.67593 15.1019 1.04731 16.1522 1.00146C16.2871 2.17605 15.7939 3.35134 15.0685 4.19807Z',
    })
  );
};
AppleFill.displayName = 'AppleFill';
exports['default'] = AppleFill;
