'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var EsetNod = function EsetNod(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M12 20.064C8.36803 20.064 6.50112 19.408 5.46661 18.3632C4.42803 17.3142 3.8 15.4426 3.8 11.864C3.8 8.17324 4.42726 6.31962 5.44697 5.30246C6.46776 4.28424 8.32256 3.66401 12 3.66401C15.659 3.66401 17.5202 4.30872 18.5467 5.34295C19.5763 6.38031 20.2 8.24493 20.2 11.864C20.2 15.4784 19.5702 17.3446 18.5365 18.3835C17.505 19.4202 15.6411 20.064 12 20.064ZM2 11.864C2 4.30151 4.46875 1.86401 12 1.86401C19.5312 1.86401 22 4.42646 22 11.864C22 19.3015 19.5 21.864 12 21.864C4.5 21.864 2 19.239 2 11.864ZM13.5198 10.7081C13.5198 9.32643 12.9672 9.18826 11.8618 9.18826C10.6183 9.18826 10.342 9.60277 10.342 10.8463H13.5198V10.7081ZM12 16.6494C8.26941 16.6494 7.4404 15.4059 7.4404 11.9516C7.4404 8.35925 8.13125 7.11572 11.8618 7.11572C15.4542 7.11572 16.4214 8.08291 16.4214 11.9516V12.3662H10.2038C10.2038 14.0242 10.4801 14.5769 11.8618 14.5769C12.829 14.5769 13.5198 14.4387 13.5198 13.4715H16.5596C16.5596 14.8532 16.1451 15.6822 15.316 16.0967C14.487 16.5112 13.3817 16.6494 12 16.6494Z',
    })
  );
};
EsetNod.displayName = 'EsetNod';
exports['default'] = EsetNod;
