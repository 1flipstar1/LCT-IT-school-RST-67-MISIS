'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var GooglePlay = function GooglePlay(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M5.57516 3.10596C6.14728 2.92386 6.79814 2.96629 7.38872 3.31284L18.8877 10.0604C20.3694 10.9298 20.3694 13.0721 18.8877 13.9415L7.38872 20.6891C5.88877 21.5692 4 20.4876 4 18.7485V5.25341C4 4.25504 4.62245 3.47335 5.43646 3.15509L5.5359 3.06339L5.57516 3.10596ZM5.50017 5.23718C5.50006 5.24257 5.5 5.24798 5.5 5.25341V18.7485C5.5 18.7672 5.50066 18.7858 5.50195 18.804L11.7458 12.0093L5.50017 5.23718ZM12.7642 10.901L7.34776 5.02798L14.3729 9.15031L12.7642 10.901ZM12.7662 13.1157L7.42417 18.9291L14.3692 14.8538L12.7662 13.1157ZM15.6932 14.0769L13.7846 12.0074L15.6964 9.92692L18.1285 11.3541C18.6224 11.6439 18.6224 12.358 18.1285 12.6478L15.6932 14.0769Z',
    })
  );
};
GooglePlay.displayName = 'GooglePlay';
exports['default'] = GooglePlay;
