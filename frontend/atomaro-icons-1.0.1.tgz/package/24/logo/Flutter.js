'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Flutter = function Flutter(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M4.07322 11.3232L13.3234 2.07322C13.3702 2.02634 13.4338 2 13.5001 2H18.2758H18.5649H19.5436H19.7936C20.0163 2 20.1278 2.26929 19.9703 2.42678L19.7936 2.60355L19.1015 3.29555L18.8971 3.5L7.57322 14.8232C7.47559 14.9209 7.3173 14.9209 7.21967 14.8232L4.07322 11.6768C3.97559 11.5791 3.97559 11.4209 4.07322 11.3232ZM16.7757 3.5H14.0179L6.01777 11.5L7.39647 12.8787L16.7757 3.5ZM18.2751 11H18.5642H19.5429H19.7929C20.0156 11 20.1271 11.2693 19.9697 11.4268L19.7929 11.6036L19.1009 12.2956L18.8964 12.5L15.3963 16.0001L19.9695 20.5732C20.127 20.7307 20.0155 21 19.7927 21H13.4999C13.4335 21 13.37 20.9737 13.3231 20.9268L11.7209 19.3245C11.7205 19.324 11.7201 19.3236 11.7197 19.3232L11.5732 19.1768L8.57322 16.1768C8.47559 16.0791 8.47559 15.9209 8.57322 15.8232L13.3232 11.0732C13.3701 11.0263 13.4337 11 13.5 11H18.2751ZM16.7751 12.5H14.0177L10.5178 16L11.8964 17.3787L16.7751 12.5Z',
    })
  );
};
Flutter.displayName = 'Flutter';
exports['default'] = Flutter;
