'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var GithubFill = function GithubFill(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M12 2C6.475 2 2 6.35878 2 11.7403C2 16.0504 4.8625 19.6908 8.8375 20.9814C9.3375 21.0666 9.525 20.7744 9.525 20.5187C9.525 20.2874 9.5125 19.5203 9.5125 18.7046C7 19.1551 6.35 18.108 6.15 17.5601C6.0375 17.2801 5.55 16.4156 5.125 16.1843C4.775 16.0017 4.275 15.5512 5.1125 15.539C5.9 15.5268 6.4625 16.2452 6.65 16.5374C7.55 18.0106 8.9875 17.5966 9.5625 17.341C9.65 16.7078 9.9125 16.2817 10.2 16.0382C7.975 15.7947 5.65 14.9546 5.65 11.2289C5.65 10.1697 6.0375 9.29304 6.675 8.61122C6.575 8.36772 6.225 7.36934 6.775 6.03005C6.775 6.03005 7.6125 5.77436 9.525 7.02843C10.325 6.80927 11.175 6.69969 12.025 6.69969C12.875 6.69969 13.725 6.80927 14.525 7.02843C16.4375 5.76219 17.275 6.03005 17.275 6.03005C17.825 7.36934 17.475 8.36772 17.375 8.61122C18.0125 9.29304 18.4 10.1575 18.4 11.2289C18.4 14.9668 16.0625 15.7947 13.8375 16.0382C14.2 16.3426 14.5125 16.927 14.5125 17.8401C14.5125 19.1429 14.5 20.19 14.5 20.5187C14.5 20.7744 14.6875 21.0788 15.1875 20.9814C17.1727 20.3286 18.8977 19.0859 20.1198 17.4282C21.3419 15.7704 21.9995 13.7811 22 11.7403C22 6.35878 17.525 2 12 2Z',
    })
  );
};
GithubFill.displayName = 'GithubFill';
exports['default'] = GithubFill;
