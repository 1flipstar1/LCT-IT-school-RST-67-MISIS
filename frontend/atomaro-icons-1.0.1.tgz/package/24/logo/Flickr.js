'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Flickr = function Flickr(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M7 9.5C5.61929 9.5 4.5 10.6193 4.5 12C4.5 13.3807 5.61929 14.5 7 14.5C8.38071 14.5 9.5 13.3807 9.5 12C9.5 10.6193 8.38071 9.5 7 9.5ZM17 9.5C15.6193 9.5 14.5 10.6193 14.5 12C14.5 13.3807 15.6193 14.5 17 14.5C18.3807 14.5 19.5 13.3807 19.5 12C19.5 10.6193 18.3807 9.5 17 9.5ZM3 12C3 9.79086 4.79086 8 7 8C9.20914 8 11 9.79086 11 12C11 14.2091 9.20914 16 7 16C4.79086 16 3 14.2091 3 12ZM13 12C13 9.79086 14.7909 8 17 8C19.2091 8 21 9.79086 21 12C21 14.2091 19.2091 16 17 16C14.7909 16 13 14.2091 13 12Z',
    })
  );
};
Flickr.displayName = 'Flickr';
exports['default'] = Flickr;
