'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var AttentionMonochrome = function AttentionMonochrome(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      opacity: '0.1',
      d: 'M22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12Z',
      fill: '#F29100',
    }),
    ',',
    react_1['default'].createElement('path', {
      d: 'M11.2977 13.5312H12.6977L12.9217 10.602V7.19995H11.0737V10.602L11.2977 13.5312ZM11.0737 17H12.9217V15.068H11.0737V17Z',
      fill: '#F29100',
    })
  );
};
AttentionMonochrome.displayName = 'AttentionMonochrome';
exports['default'] = AttentionMonochrome;
