'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var InformationColor = function InformationColor(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      opacity: '0.7',
      d: 'M22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12Z',
      fill: '#1998FF',
    }),
    ',',
    react_1['default'].createElement('path', {
      d: 'M10.5 10H12.502C12.7781 10 13.002 10.2239 13.002 10.5L13.002 15.5H14L14 17H10.5V15.5H11.502L11.502 11.5L10.5 11.5V10Z',
      fill: 'white',
    }),
    ',',
    react_1['default'].createElement('path', {
      d: 'M11.0339 8.348H12.9659V6.5H11.0339V8.348Z',
      fill: 'white',
    })
  );
};
InformationColor.displayName = 'InformationColor';
exports['default'] = InformationColor;
