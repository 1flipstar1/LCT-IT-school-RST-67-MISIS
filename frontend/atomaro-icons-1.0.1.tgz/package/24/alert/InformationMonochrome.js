'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var InformationMonochrome = function InformationMonochrome(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      opacity: '0.1',
      d: 'M22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12Z',
      fill: '#1998FF',
    }),
    ',',
    react_1['default'].createElement('path', {
      d: 'M12.9659 8.348H11.0339V6.5H12.9659V8.348Z',
      fill: '#1998FF',
    }),
    ',',
    react_1['default'].createElement('path', {
      d: 'M12.502 10H10.5V11.5L11.502 11.5L11.502 15.5H10.5V17H14L14 15.5H13.002L13.002 10.5C13.002 10.2239 12.7781 10 12.502 10Z',
      fill: '#1998FF',
    })
  );
};
InformationMonochrome.displayName = 'InformationMonochrome';
exports['default'] = InformationMonochrome;
