'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var HelpStroke = function HelpStroke(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M20.5 12C20.5 16.6944 16.6944 20.5 12 20.5C7.30558 20.5 3.5 16.6944 3.5 12C3.5 7.30558 7.30558 3.5 12 3.5C16.6944 3.5 20.5 7.30558 20.5 12ZM22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12ZM12.7502 14.088H10.9862V13.864C10.9862 13.01 11.2662 12.478 12.1902 11.736C13.1142 10.994 13.4782 10.504 13.4782 9.79C13.4782 9.062 12.8762 8.6 12.0222 8.6C11.1682 8.6 10.4402 9.118 10.4402 9.986C10.4402 10.168 10.4822 10.364 10.5382 10.504L8.9282 10.84C8.8022 10.574 8.7322 10.252 8.7322 9.832C8.7322 8.432 9.9782 7.004 11.9802 7.004C14.0102 7.004 15.2142 8.082 15.2142 9.664C15.2142 10.784 14.8082 11.47 13.4082 12.674C12.9042 13.108 12.7502 13.472 12.7502 14.088ZM12.7922 17H10.9442V15.068H12.7922V17Z',
    })
  );
};
HelpStroke.displayName = 'HelpStroke';
exports['default'] = HelpStroke;
