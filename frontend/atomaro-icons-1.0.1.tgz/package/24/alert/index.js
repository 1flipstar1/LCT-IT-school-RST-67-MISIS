"use strict";

var __importDefault = this && this.__importDefault || function (mod) {
  return mod && mod.__esModule ? mod : {
    "default": mod
  };
};
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.TimeStroke = exports.TimeMonochrome = exports.TimeColor = exports.StopStroke = exports.SkipStroke = exports.SkipMonochrome = exports.SkipColor = exports.OkStroke = exports.OkMonochrome = exports.OkColor = exports.NoneStroke = exports.NoneMonochrome = exports.NoneColor = exports.InformationStroke = exports.InformationMonochrome = exports.InformationColor = exports.HelpStroke = exports.HelpMonochrome = exports.HelpColor = exports.ErrorStroke = exports.ErrorMonochrome = exports.ErrorColor = exports.AttentionStroke = exports.AttentionMonochrome = exports.AttentionColor = void 0;
var AttentionColor_1 = require("./AttentionColor");
Object.defineProperty(exports, "AttentionColor", {
  enumerable: true,
  get: function get() {
    return __importDefault(AttentionColor_1)["default"];
  }
});
var AttentionMonochrome_1 = require("./AttentionMonochrome");
Object.defineProperty(exports, "AttentionMonochrome", {
  enumerable: true,
  get: function get() {
    return __importDefault(AttentionMonochrome_1)["default"];
  }
});
var AttentionStroke_1 = require("./AttentionStroke");
Object.defineProperty(exports, "AttentionStroke", {
  enumerable: true,
  get: function get() {
    return __importDefault(AttentionStroke_1)["default"];
  }
});
var ErrorColor_1 = require("./ErrorColor");
Object.defineProperty(exports, "ErrorColor", {
  enumerable: true,
  get: function get() {
    return __importDefault(ErrorColor_1)["default"];
  }
});
var ErrorMonochrome_1 = require("./ErrorMonochrome");
Object.defineProperty(exports, "ErrorMonochrome", {
  enumerable: true,
  get: function get() {
    return __importDefault(ErrorMonochrome_1)["default"];
  }
});
var ErrorStroke_1 = require("./ErrorStroke");
Object.defineProperty(exports, "ErrorStroke", {
  enumerable: true,
  get: function get() {
    return __importDefault(ErrorStroke_1)["default"];
  }
});
var HelpColor_1 = require("./HelpColor");
Object.defineProperty(exports, "HelpColor", {
  enumerable: true,
  get: function get() {
    return __importDefault(HelpColor_1)["default"];
  }
});
var HelpMonochrome_1 = require("./HelpMonochrome");
Object.defineProperty(exports, "HelpMonochrome", {
  enumerable: true,
  get: function get() {
    return __importDefault(HelpMonochrome_1)["default"];
  }
});
var HelpStroke_1 = require("./HelpStroke");
Object.defineProperty(exports, "HelpStroke", {
  enumerable: true,
  get: function get() {
    return __importDefault(HelpStroke_1)["default"];
  }
});
var InformationColor_1 = require("./InformationColor");
Object.defineProperty(exports, "InformationColor", {
  enumerable: true,
  get: function get() {
    return __importDefault(InformationColor_1)["default"];
  }
});
var InformationMonochrome_1 = require("./InformationMonochrome");
Object.defineProperty(exports, "InformationMonochrome", {
  enumerable: true,
  get: function get() {
    return __importDefault(InformationMonochrome_1)["default"];
  }
});
var InformationStroke_1 = require("./InformationStroke");
Object.defineProperty(exports, "InformationStroke", {
  enumerable: true,
  get: function get() {
    return __importDefault(InformationStroke_1)["default"];
  }
});
var NoneColor_1 = require("./NoneColor");
Object.defineProperty(exports, "NoneColor", {
  enumerable: true,
  get: function get() {
    return __importDefault(NoneColor_1)["default"];
  }
});
var NoneMonochrome_1 = require("./NoneMonochrome");
Object.defineProperty(exports, "NoneMonochrome", {
  enumerable: true,
  get: function get() {
    return __importDefault(NoneMonochrome_1)["default"];
  }
});
var NoneStroke_1 = require("./NoneStroke");
Object.defineProperty(exports, "NoneStroke", {
  enumerable: true,
  get: function get() {
    return __importDefault(NoneStroke_1)["default"];
  }
});
var OkColor_1 = require("./OkColor");
Object.defineProperty(exports, "OkColor", {
  enumerable: true,
  get: function get() {
    return __importDefault(OkColor_1)["default"];
  }
});
var OkMonochrome_1 = require("./OkMonochrome");
Object.defineProperty(exports, "OkMonochrome", {
  enumerable: true,
  get: function get() {
    return __importDefault(OkMonochrome_1)["default"];
  }
});
var OkStroke_1 = require("./OkStroke");
Object.defineProperty(exports, "OkStroke", {
  enumerable: true,
  get: function get() {
    return __importDefault(OkStroke_1)["default"];
  }
});
var SkipColor_1 = require("./SkipColor");
Object.defineProperty(exports, "SkipColor", {
  enumerable: true,
  get: function get() {
    return __importDefault(SkipColor_1)["default"];
  }
});
var SkipMonochrome_1 = require("./SkipMonochrome");
Object.defineProperty(exports, "SkipMonochrome", {
  enumerable: true,
  get: function get() {
    return __importDefault(SkipMonochrome_1)["default"];
  }
});
var SkipStroke_1 = require("./SkipStroke");
Object.defineProperty(exports, "SkipStroke", {
  enumerable: true,
  get: function get() {
    return __importDefault(SkipStroke_1)["default"];
  }
});
var StopStroke_1 = require("./StopStroke");
Object.defineProperty(exports, "StopStroke", {
  enumerable: true,
  get: function get() {
    return __importDefault(StopStroke_1)["default"];
  }
});
var TimeColor_1 = require("./TimeColor");
Object.defineProperty(exports, "TimeColor", {
  enumerable: true,
  get: function get() {
    return __importDefault(TimeColor_1)["default"];
  }
});
var TimeMonochrome_1 = require("./TimeMonochrome");
Object.defineProperty(exports, "TimeMonochrome", {
  enumerable: true,
  get: function get() {
    return __importDefault(TimeMonochrome_1)["default"];
  }
});
var TimeStroke_1 = require("./TimeStroke");
Object.defineProperty(exports, "TimeStroke", {
  enumerable: true,
  get: function get() {
    return __importDefault(TimeStroke_1)["default"];
  }
});