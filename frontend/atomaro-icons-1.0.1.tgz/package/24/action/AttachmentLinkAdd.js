'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var AttachmentLinkAdd = function AttachmentLinkAdd(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M11.5291 12.5817C12.0542 13.2055 12.1367 14.0754 11.7765 14.7765C11.7468 14.8344 11.6696 14.844 11.6236 14.7979L10.4343 13.6082C8.47508 11.6482 8.47501 8.47048 10.4341 6.51046L12.4773 4.46637C14.4275 2.51525 17.5895 2.51519 19.5398 4.46622C21.4901 6.41726 21.4902 9.58057 19.54 11.5317L16.6002 14.4728C16.5341 14.5389 16.4195 14.486 16.4241 14.3925C16.4514 13.8345 16.4072 13.2737 16.2915 12.7249C16.2844 12.6915 16.2945 12.6568 16.3186 12.6327L18.4795 10.4708C19.8441 9.10564 19.844 6.89226 18.4794 5.52712C17.1148 4.16199 14.9023 4.16203 13.5378 5.52723L11.4946 7.57132C10.1211 8.94542 10.1212 11.1732 11.4947 12.5473L11.5291 12.5817ZM12.4735 11.4214C11.9484 10.7976 11.8659 9.92768 12.2261 9.22656C12.2558 9.16864 12.333 9.15907 12.379 9.20512L13.5683 10.3949C15.5275 12.3548 15.5276 15.5326 13.5685 17.4926L11.5253 19.5367C9.57508 21.4878 6.41307 21.4879 4.46277 19.5368C2.51247 17.5858 2.5124 14.4225 4.46263 12.4714L7.40237 9.53029C7.46852 9.46411 7.58309 9.51709 7.57851 9.61055C7.55117 10.1685 7.59538 10.7294 7.71113 11.2782C7.71817 11.3115 7.70807 11.3462 7.68397 11.3704L5.52309 13.5322C4.15852 14.8974 4.15856 17.1108 5.52319 18.4759C6.88782 19.8411 9.10027 19.841 10.4648 18.4758L12.508 16.4317C13.8815 15.0576 13.8814 12.8298 12.5079 11.4558L12.4735 11.4214ZM19.75 21L19.75 18.7499L22.0001 18.7499L22 17.2499L19.75 17.2499L19.7501 15.0001L18.2501 15L18.25 17.25L16 17.25L16.0001 18.75L18.25 18.75L18.25 21L19.75 21Z',
    })
  );
};
AttachmentLinkAdd.displayName = 'AttachmentLinkAdd';
exports['default'] = AttachmentLinkAdd;
