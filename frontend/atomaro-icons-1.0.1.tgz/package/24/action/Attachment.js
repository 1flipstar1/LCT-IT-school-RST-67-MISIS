'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Attachment = function Attachment(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M16 4.49239C16.8024 4.61753 17.5467 5.00017 18.1173 5.58805C19.5473 7.06147 19.5297 9.40995 18.0778 10.8618L17.7808 11.1589L14.3438 14.5959L10.5031 18.4365C9.12524 19.8143 6.88908 19.8071 5.52019 18.4203C4.16005 17.0425 4.17156 14.8237 5.5459 13.46L11.1776 7.87188C11.7153 7.33834 12.5832 7.34001 13.1188 7.87562C13.656 8.41273 13.656 9.28359 13.1189 9.82071L7.21179 15.7278L8.27245 16.7884L14.1795 10.8814C15.3024 9.75845 15.3024 7.93782 14.1795 6.81493C13.0596 5.69517 11.2452 5.69168 10.1211 6.80711L4.48937 12.3952C2.52805 14.3414 2.51163 17.5077 4.45268 19.4741C6.40621 21.4531 9.59742 21.4635 11.5638 19.4972L15.4044 15.6565L18.8414 12.2196L19.1385 11.9225C21.17 9.89101 21.1945 6.60499 19.1937 4.54337C18.3408 3.66461 17.2105 3.1136 16 2.97949V4.49239Z',
    })
  );
};
Attachment.displayName = 'Attachment';
exports['default'] = Attachment;
