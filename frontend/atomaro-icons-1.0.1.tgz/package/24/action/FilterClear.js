'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var FilterClear = function FilterClear(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M4.5 6.26711V5.5H19.5V6.26711L14.4079 10.4733L15.3632 11.6297L14.4079 10.4733C13.8329 10.9482 13.5 11.655 13.5 12.4007V15.2135C13.5 15.7333 13.2309 16.216 12.7888 16.4893L10.5 17.9044V12.4007C10.5 11.655 10.1671 10.9482 9.59212 10.4733L4.5 6.26711ZM15 12.4007C15 12.1024 15.1332 11.8197 15.3632 11.6297L21 6.97364V5C21 4.44772 20.5523 4 20 4H4C3.44772 4 3 4.44772 3 5V6.97364L8.63685 11.6297C8.86683 11.8197 9 12.1024 9 12.4007V19.2498C9 19.8372 9.64474 20.1966 10.1444 19.8877L13.5776 17.7652C14.4618 17.2185 15 16.253 15 15.2135V12.4007ZM17.0606 20.0027L19.0014 18.062L20.9422 20.0027L22.0029 18.942L20.0621 17.0013L22.0029 15.0607L20.9422 14L19.0014 15.9407L17.0606 14L16 15.0607L17.9408 17.0013L16 18.942L17.0606 20.0027Z',
    })
  );
};
FilterClear.displayName = 'FilterClear';
exports['default'] = FilterClear;
