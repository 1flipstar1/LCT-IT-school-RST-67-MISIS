'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var HeartList = function HeartList(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M3 8.97831C3 6.24655 5.16494 4 7.87453 4C9.68144 4 11.1613 5.11296 11.9997 6.75774C12.8375 5.11306 14.3165 4 16.1236 4C18.8332 4 20.9981 6.24655 20.9981 8.97831C20.9981 11.4006 19.4893 13.5485 17.7652 15.3159C16.4435 16.6709 14.8908 17.902 13.5947 18.9297L13.5946 18.9298C13.1916 19.2493 12.8134 19.5492 12.4747 19.827L12.0251 20.1957L12 20.1773V18.2811C12.2322 18.0949 12.4727 17.9042 12.7189 17.7089L12.719 17.7089C14.0029 16.6905 15.4437 15.5477 16.6915 14.2685C18.3554 12.5628 19.4981 10.7843 19.4981 8.97831C19.4981 7.03961 17.9698 5.5 16.1236 5.5C14.4105 5.5 12.75 7.24547 12.75 10H12H11.25C11.25 7.24596 9.58796 5.5 7.87453 5.5C6.02829 5.5 4.5 7.03961 4.5 8.97831C4.5 9.29401 4.55972 9.63607 4.67439 10H3.12102C3.04298 9.65848 3 9.31691 3 8.97831ZM10 13.5H2V12H10V13.5ZM2 16.75H10V15.25H2V16.75ZM2 20H10V18.5H2V20Z',
    })
  );
};
HeartList.displayName = 'HeartList';
exports['default'] = HeartList;
