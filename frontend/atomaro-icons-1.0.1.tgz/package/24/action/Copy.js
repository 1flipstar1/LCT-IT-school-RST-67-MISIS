'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Copy = function Copy(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M8 6H4C3.44772 6 3 6.44772 3 7V21C3 21.5523 3.44772 22 4 22H15C15.5523 22 16 21.5523 16 21V18H20C20.5523 18 21 17.5523 21 17V5C21 3.34315 19.6569 2 18 2H9C8.44772 2 8 2.44772 8 3V6ZM9.5 6H13C14.6569 6 16 7.34315 16 9V16.5H19.5V5C19.5 4.17157 18.8284 3.5 18 3.5H9.5V6ZM4.5 20.5V7.5H13C13.8284 7.5 14.5 8.17157 14.5 9V20.5H4.5Z',
    })
  );
};
Copy.displayName = 'Copy';
exports['default'] = Copy;
