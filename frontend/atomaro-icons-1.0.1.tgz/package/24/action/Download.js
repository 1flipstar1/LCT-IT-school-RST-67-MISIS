'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Download = function Download(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M8 8.5H9.5V7V4.5H14.5V7V8.5H16H17.8787L12 14.3787L6.12132 8.5H8ZM8 4V5.5V7H6.5H4.91421C4.02331 7 3.57714 8.07714 4.20711 8.70711L11.2929 15.7929C11.6834 16.1834 12.3166 16.1834 12.7071 15.7929L19.7929 8.70711C20.4229 8.07714 19.9767 7 19.0858 7H17.5H16V5.5V4C16 3.44772 15.5523 3 15 3H9C8.44772 3 8 3.44772 8 4ZM2 19V16H3.5V19C3.5 19.2761 3.72386 19.5 4 19.5H20C20.2761 19.5 20.5 19.2761 20.5 19V16H22V19C22 20.1046 21.1046 21 20 21H4C2.89543 21 2 20.1046 2 19Z',
    })
  );
};
Download.displayName = 'Download';
exports['default'] = Download;
