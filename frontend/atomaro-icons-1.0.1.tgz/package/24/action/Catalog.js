'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Catalog = function Catalog(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M4.5 8L4.5 6C4.5 5.17157 5.17157 4.5 6 4.5L8 4.5C8.82843 4.5 9.5 5.17157 9.5 6V8C9.5 8.82843 8.82843 9.5 8 9.5H6C5.17157 9.5 4.5 8.82843 4.5 8ZM6 11C4.34315 11 3 9.65685 3 8V6C3 4.34315 4.34315 3 6 3H8C9.65685 3 11 4.34315 11 6V8C11 9.65685 9.65685 11 8 11H6ZM14.5 8V6C14.5 5.17157 15.1716 4.5 16 4.5L18 4.5C18.8284 4.5 19.5 5.17157 19.5 6V8C19.5 8.82843 18.8284 9.5 18 9.5H16C15.1716 9.5 14.5 8.82843 14.5 8ZM16 11C14.3431 11 13 9.65685 13 8V6C13 4.34315 14.3431 3 16 3H18C19.6569 3 21 4.34315 21 6V8C21 9.65685 19.6569 11 18 11H16ZM4.5 16L4.5 18C4.5 18.8284 5.17157 19.5 6 19.5H8C8.82843 19.5 9.5 18.8284 9.5 18V16C9.5 15.1716 8.82843 14.5 8 14.5H6C5.17157 14.5 4.5 15.1716 4.5 16ZM3 18C3 19.6569 4.34315 21 6 21H8C9.65685 21 11 19.6569 11 18V16C11 14.3431 9.65685 13 8 13H6C4.34315 13 3 14.3431 3 16V18ZM14.4584 15.9392L15.9585 14.4388C16.5442 13.8529 17.4938 13.8529 18.0795 14.4388L19.5795 15.9392C20.1652 16.5251 20.1652 17.4749 19.5795 18.0608L18.0795 19.5612C17.4938 20.1471 16.5442 20.1471 15.9585 19.5612L14.4584 18.0608C13.8727 17.4749 13.8727 16.5251 14.4584 15.9392ZM13.3979 19.1216C12.2265 17.9499 12.2265 16.0501 13.3979 14.8784L14.8979 13.378C16.0693 12.2062 17.9686 12.2062 19.14 13.378L20.64 14.8784C21.8115 16.0501 21.8115 17.9499 20.64 19.1216L19.14 20.622C17.9686 21.7938 16.0694 21.7938 14.8979 20.622L13.3979 19.1216Z',
    })
  );
};
Catalog.displayName = 'Catalog';
exports['default'] = Catalog;
