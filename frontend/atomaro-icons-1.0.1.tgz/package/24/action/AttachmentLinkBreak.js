'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var AttachmentLinkBreak = function AttachmentLinkBreak(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M8.99325 5.98999L7.99325 1.98999L6.53804 2.35379L7.53804 6.35379L8.99325 5.98999ZM10.8016 8.83287L14.2163 5.41831C15.4219 4.21277 17.3765 4.21277 18.5821 5.4183C19.7877 6.62384 19.7877 8.5784 18.5821 9.78394L15.1674 13.1985L16.2281 14.2591L19.6428 10.8446C21.4342 9.05327 21.4342 6.14897 19.6428 4.35766C17.8514 2.56635 14.947 2.56636 13.1556 4.35767L9.74093 7.77223L10.8016 8.83287ZM8.83291 10.8015L7.77223 9.74086L4.35714 13.1558C2.56576 14.9471 2.56576 17.8514 4.35714 19.6427C6.14853 21.434 9.05294 21.434 10.8443 19.6427L14.2594 16.2278L13.1987 15.1671L9.78364 18.5821C8.57805 19.7876 6.62341 19.7876 5.41782 18.5821C4.21224 17.3765 4.21224 15.422 5.41783 14.2164L8.83291 10.8015ZM21.6306 17.4464L17.6306 16.4464L17.9944 14.9912L21.9944 15.9912L21.6306 17.4464ZM15.0068 18.01L16.0068 22.01L17.462 21.6462L16.462 17.6462L15.0068 18.01ZM2.36942 6.55366L6.36942 7.55366L6.00562 9.00887L2.00562 8.00887L2.36942 6.55366Z',
    })
  );
};
AttachmentLinkBreak.displayName = 'AttachmentLinkBreak';
exports['default'] = AttachmentLinkBreak;
