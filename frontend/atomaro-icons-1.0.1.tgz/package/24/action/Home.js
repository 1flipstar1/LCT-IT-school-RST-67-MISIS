'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Home = function Home(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M18.4927 10.983L17.516 11.3466V12.3887V18.0005C17.516 18.829 16.8445 19.5005 16.016 19.5005H15V19.5V14C15 12.8954 14.1046 12 13 12H11C9.89543 12 9 12.8954 9 14V19.5V19.5005H7.99273C7.16431 19.5005 6.49273 18.829 6.49273 18.0005V12.3887V11.3456L5.51478 10.9825L4.04584 10.4372L12.0021 4.61948L19.9548 10.4387L18.4927 10.983ZM21.3481 11.5205L19.016 12.3887V18.0005C19.016 19.6574 17.6729 21.0005 16.016 21.0005H7.99273C6.33588 21.0005 4.99273 19.6574 4.99273 18.0005V12.3887L2.65219 11.5198C1.90514 11.2425 1.76672 10.2455 2.40997 9.77514L11.412 3.19278C11.7636 2.93567 12.2412 2.93575 12.5927 3.19298L21.5897 9.77631C22.2324 10.2465 22.0944 11.2427 21.3481 11.5205ZM11 13.5H13C13.2761 13.5 13.5 13.7239 13.5 14V19.5H10.5V14C10.5 13.7239 10.7239 13.5 11 13.5Z',
    })
  );
};
Home.displayName = 'Home';
exports['default'] = Home;
