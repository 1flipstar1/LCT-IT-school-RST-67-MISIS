'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Equaliser = function Equaliser(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M7.5 14.5C8.60457 14.5 9.5 15.3954 9.5 16.5C9.5 17.6046 8.60457 18.5 7.5 18.5C6.39543 18.5 5.5 17.6046 5.5 16.5C5.5 15.3954 6.39543 14.5 7.5 14.5ZM11 16.5C11 14.8244 9.82259 13.4239 8.25 13.0805L8.25 2.00004L6.75 2.00004L6.75 13.0805C5.17741 13.4239 4 14.8244 4 16.5C4 18.1756 5.17741 19.5761 6.75 19.9195V22H8.25V19.9195C9.82259 19.5761 11 18.1756 11 16.5ZM14.75 10.9195L14.75 22H16.25L16.25 10.9195C17.8226 10.5761 19 9.17556 19 7.5C19 5.82444 17.8226 4.42388 16.25 4.08055V2H14.75V4.08055C13.1774 4.42388 12 5.82444 12 7.5C12 9.17556 13.1774 10.5761 14.75 10.9195ZM15.5 5.5C16.6046 5.5 17.5 6.39543 17.5 7.5C17.5 8.60457 16.6046 9.5 15.5 9.5C14.3954 9.5 13.5 8.60457 13.5 7.5C13.5 6.39543 14.3954 5.5 15.5 5.5Z',
    })
  );
};
Equaliser.displayName = 'Equaliser';
exports['default'] = Equaliser;
