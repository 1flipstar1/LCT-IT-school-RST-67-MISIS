'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var CloudDownload = function CloudDownload(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M6.42437 10.3731L6.598 9.50853C7.0572 7.2219 9.07919 5.5 11.5 5.5C13.5853 5.5 15.3758 6.77693 16.1257 8.59727L16.4676 9.42729L17.3606 9.51824C19.1235 9.69775 20.5 11.1891 20.5 13C20.5 14.933 18.933 16.5 17 16.5V18C19.7614 18 22 15.7614 22 13C22 10.4116 20.0332 8.28264 17.5126 8.02596C16.5393 5.66322 14.2139 4 11.5 4C8.35069 4 5.7245 6.23971 5.12736 9.21319C3.31336 9.79356 2 11.4934 2 13.5C2 15.9853 4.01472 18 6.5 18H7V16.5H6.5C4.84315 16.5 3.5 15.1569 3.5 13.5C3.5 12.1645 4.37365 11.0292 5.58444 10.6419L6.42437 10.3731ZM13.9455 16.2227L12.7493 17.4286L12.7493 12H11.2493L11.2493 17.4293L10.0524 16.2227L8.99603 17.2877L11.4707 19.7825C11.7624 20.0766 12.2354 20.0766 12.5271 19.7825L15.0018 17.2877L13.9455 16.2227Z',
    })
  );
};
CloudDownload.displayName = 'CloudDownload';
exports['default'] = CloudDownload;
