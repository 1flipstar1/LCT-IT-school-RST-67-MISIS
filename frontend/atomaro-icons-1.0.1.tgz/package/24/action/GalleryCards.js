'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var GalleryCards = function GalleryCards(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M4.5 10.5L4.5 5.5C4.5 4.94772 4.94772 4.5 5.5 4.5L8.5 4.5C9.05228 4.5 9.5 4.94772 9.5 5.5V10.5C9.5 11.0523 9.05228 11.5 8.5 11.5H5.5C4.94772 11.5 4.5 11.0523 4.5 10.5ZM5.5 13C4.11929 13 3 11.8807 3 10.5V5.5C3 4.11929 4.11929 3 5.5 3H8.5C9.88071 3 11 4.11929 11 5.5V10.5C11 11.8807 9.88071 13 8.5 13H5.5ZM14.5 6.5V5.5C14.5 4.94772 14.9477 4.5 15.5 4.5L18.5 4.5C19.0523 4.5 19.5 4.94772 19.5 5.5V6.5C19.5 7.05228 19.0523 7.5 18.5 7.5H15.5C14.9477 7.5 14.5 7.05228 14.5 6.5ZM15.5 9C14.1193 9 13 7.88071 13 6.5V5.5C13 4.11929 14.1193 3 15.5 3H18.5C19.8807 3 21 4.11929 21 5.5V6.5C21 7.88071 19.8807 9 18.5 9H15.5ZM14.5 13.5V18.5C14.5 19.0523 14.9477 19.5 15.5 19.5H18.5C19.0523 19.5 19.5 19.0523 19.5 18.5V13.5C19.5 12.9477 19.0523 12.5 18.5 12.5H15.5C14.9477 12.5 14.5 12.9477 14.5 13.5ZM13 18.5C13 19.8807 14.1193 21 15.5 21H18.5C19.8807 21 21 19.8807 21 18.5V13.5C21 12.1193 19.8807 11 18.5 11H15.5C14.1193 11 13 12.1193 13 13.5V18.5ZM4.5 18.5V17.5C4.5 16.9477 4.94772 16.5 5.5 16.5H8.5C9.05228 16.5 9.5 16.9477 9.5 17.5V18.5C9.5 19.0523 9.05228 19.5 8.5 19.5H5.5C4.94772 19.5 4.5 19.0523 4.5 18.5ZM5.5 21C4.11929 21 3 19.8807 3 18.5V17.5C3 16.1193 4.11929 15 5.5 15H8.5C9.88071 15 11 16.1193 11 17.5V18.5C11 19.8807 9.88071 21 8.5 21H5.5Z',
    })
  );
};
GalleryCards.displayName = 'GalleryCards';
exports['default'] = GalleryCards;
