'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var EqualiserСlear = function EqualiserСlear(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M9.5 16.5C9.5 15.3954 8.60457 14.5 7.5 14.5C6.39543 14.5 5.5 15.3954 5.5 16.5C5.5 17.6046 6.39543 18.5 7.5 18.5C8.60457 18.5 9.5 17.6046 9.5 16.5ZM8.25 13.0805C9.82259 13.4239 11 14.8244 11 16.5C11 18.1756 9.82259 19.5761 8.25 19.9195V22H6.75V19.9195C5.17741 19.5761 4 18.1756 4 16.5C4 14.8244 5.17741 13.4239 6.75 13.0805L6.75 2.00004L8.25 2.00004L8.25 13.0805ZM14.75 14L14.75 10.9195C13.1774 10.5761 12 9.17556 12 7.5C12 5.82444 13.1774 4.42388 14.75 4.08055V2H16.25V4.08055C17.8226 4.42388 19 5.82444 19 7.5C19 9.17556 17.8226 10.5761 16.25 10.9195L16.25 14H14.75ZM17.5 7.5C17.5 6.39543 16.6046 5.5 15.5 5.5C14.3954 5.5 13.5 6.39543 13.5 7.5C13.5 8.60457 14.3954 9.5 15.5 9.5C16.6046 9.5 17.5 8.60457 17.5 7.5ZM13.5303 15.9973L15.5 17.9669L17.4697 15.9973L18.5303 17.058L16.5607 19.0275L18.4726 20.9393L17.4119 22L15.5 20.0882L13.5881 21.9999L12.5275 20.9392L14.4393 19.0275L12.4697 17.058L13.5303 15.9973Z',
    })
  );
};
EqualiserСlear.displayName = 'EqualiserСlear';
exports['default'] = EqualiserСlear;
