'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Backspace = function Backspace(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M5.48796 5.5H21C21.8284 5.5 22.5 6.17157 22.5 7V17C22.5 17.8284 21.8284 18.5 21 18.5H5.48796C5.12119 18.5 4.78385 18.2992 4.60896 17.9768L1.6254 12.4768C1.46406 12.1794 1.46406 11.8206 1.6254 11.5232L4.60896 6.02317C4.78385 5.70078 5.12119 5.5 5.48796 5.5ZM3.29046 5.30793C3.72768 4.50196 4.57103 4 5.48796 4H21C22.6568 4 24 5.34315 24 7V17C24 18.6569 22.6568 20 21 20H5.48796C4.57103 20 3.72768 19.498 3.29046 18.6921L0.3069 13.1921C-0.096441 12.4485 -0.0964406 11.5515 0.306901 10.8079L3.29046 5.30793ZM8.89363 15.0468L11.9399 12.0005L8.89392 8.95449L9.95458 7.89383L13.0006 10.9398L16.0466 7.89383L17.1072 8.95449L14.0612 12.0005L17.1075 15.0468L16.0469 16.1075L13.0006 13.0612L9.95429 16.1075L8.89363 15.0468Z',
    })
  );
};
Backspace.displayName = 'Backspace';
exports['default'] = Backspace;
