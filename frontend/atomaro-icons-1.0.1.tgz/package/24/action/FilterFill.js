'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var FilterFill = function FilterFill(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      d: 'M20 4H4C3.44772 4 3 4.44772 3 5V7L8.64018 11.7002C8.86818 11.8901 9 12.1716 9 12.4684V19.3906C9 19.9794 9.64736 20.3386 10.1469 20.027L13.5877 17.8809C14.4661 17.333 15 16.3708 15 15.3355V12.4684C15 12.1716 15.1318 11.8901 15.3598 11.7002L21 7V5C21 4.44772 20.5523 4 20 4Z',
    })
  );
};
FilterFill.displayName = 'FilterFill';
exports['default'] = FilterFill;
