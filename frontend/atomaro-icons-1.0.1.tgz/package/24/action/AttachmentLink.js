'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var AttachmentLink = function AttachmentLink(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M11.7765 14.7764C12.1366 14.0753 12.0542 13.2054 11.529 12.5816L11.4947 12.5472C10.1211 11.1732 10.1211 8.94535 11.4946 7.57125L13.5377 5.52716C14.9023 4.16197 17.1148 4.16193 18.4794 5.52706C19.844 6.8922 19.8441 9.10557 18.4795 10.4708L16.3186 12.6326C16.2945 12.6567 16.2844 12.6915 16.2914 12.7248C16.4072 13.2736 16.4514 13.8344 16.4241 14.3924C16.4195 14.4859 16.5341 14.5389 16.6002 14.4727L19.5399 11.5316C21.4902 9.58051 21.4901 6.4172 19.5398 4.46616C17.5895 2.51513 14.4275 2.51519 12.4773 4.46631L10.4341 6.5104C8.47497 8.47042 8.47504 11.6482 10.4342 13.6081L11.6236 14.7979C11.6696 14.8439 11.7467 14.8343 11.7765 14.7764ZM12.2261 9.22644C11.8659 9.92756 11.9484 10.7975 12.4735 11.4213L12.5079 11.4557C13.8814 12.8297 13.8815 15.0575 12.508 16.4316L10.4648 18.4757C9.10027 19.8409 6.88782 19.8409 5.52319 18.4758C4.15856 17.1107 4.15852 14.8973 5.52309 13.5321L7.68397 11.3702C7.70807 11.3461 7.71817 11.3114 7.71113 11.278C7.59538 10.7293 7.55117 10.1684 7.57851 9.61044C7.58309 9.51698 7.46852 9.46399 7.40237 9.53017L4.46263 12.4712C2.5124 14.4224 2.51247 17.5857 4.46277 19.5367C6.41307 21.4877 9.57508 21.4877 11.5253 19.5366L13.5685 17.4925C15.5276 15.5325 15.5275 12.3547 13.5683 10.3948L12.379 9.205C12.333 9.15895 12.2558 9.16852 12.2261 9.22644Z',
    })
  );
};
AttachmentLink.displayName = 'AttachmentLink';
exports['default'] = AttachmentLink;
