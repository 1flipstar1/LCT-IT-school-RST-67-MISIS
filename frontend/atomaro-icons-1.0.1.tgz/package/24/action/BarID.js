'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var BarID = function BarID(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M5 5H7V6.5H5C4.17157 6.5 3.5 7.17157 3.5 8V10H2V8C2 6.34315 3.34315 5 5 5ZM17 5V6.5H19C19.8284 6.5 20.5 7.17157 20.5 8V10H22V8C22 6.34315 20.6569 5 19 5H17ZM19 17.5H17V19H19C20.6569 19 22 17.6569 22 16V14H20.5V16C20.5 16.8284 19.8284 17.5 19 17.5ZM3.5 16V14H2V16C2 17.6569 3.34315 19 5 19H7V17.5H5C4.17157 17.5 3.5 16.8284 3.5 16ZM7.01978 9V15H8.51978V9H7.01978ZM11.25 15V9H12.75V15H11.25ZM15.5186 9V15H17.0186V9H15.5186Z',
    })
  );
};
BarID.displayName = 'BarID';
exports['default'] = BarID;
