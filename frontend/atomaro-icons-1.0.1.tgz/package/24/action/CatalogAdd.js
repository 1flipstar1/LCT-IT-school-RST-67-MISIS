'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var CatalogAdd = function CatalogAdd(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M4.5 6L4.5 8C4.5 8.82843 5.17157 9.5 6 9.5H8C8.82843 9.5 9.5 8.82843 9.5 8V6C9.5 5.17157 8.82843 4.5 8 4.5L6 4.5C5.17157 4.5 4.5 5.17157 4.5 6ZM3 8C3 9.65685 4.34315 11 6 11H8C9.65685 11 11 9.65685 11 8V6C11 4.34315 9.65685 3 8 3H6C4.34315 3 3 4.34315 3 6V8ZM14.5 6V8C14.5 8.82843 15.1716 9.5 16 9.5H18C18.8284 9.5 19.5 8.82843 19.5 8V6C19.5 5.17157 18.8284 4.5 18 4.5L16 4.5C15.1716 4.5 14.5 5.17157 14.5 6ZM13 8C13 9.65685 14.3431 11 16 11H18C19.6569 11 21 9.65685 21 8V6C21 4.34315 19.6569 3 18 3H16C14.3431 3 13 4.34315 13 6V8ZM4.5 18L4.5 16C4.5 15.1716 5.17157 14.5 6 14.5H8C8.82843 14.5 9.5 15.1716 9.5 16V18C9.5 18.8284 8.82843 19.5 8 19.5H6C5.17157 19.5 4.5 18.8284 4.5 18ZM6 21C4.34315 21 3 19.6569 3 18V16C3 14.3431 4.34315 13 6 13H8C9.65685 13 11 14.3431 11 16V18C11 19.6569 9.65685 21 8 21H6ZM16.25 21V17.75H13V16.25H16.25V13H17.75V16.25H21V17.75H17.75V21H16.25Z',
    })
  );
};
CatalogAdd.displayName = 'CatalogAdd';
exports['default'] = CatalogAdd;
