'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var FaceID = function FaceID(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M8 3H6C4.34315 3 3 4.34315 3 6V7.99999H4.5V6C4.5 5.17157 5.17157 4.5 6 4.5H8V3ZM16 4.5V3H18C19.6569 3 21 4.34315 21 6V7.99999H19.5V6C19.5 5.17157 18.8284 4.5 18 4.5H16ZM16 19.5H18C18.8284 19.5 19.5 18.8284 19.5 18V16H21V18C21 19.6569 19.6569 21 18 21H16V19.5ZM4.5 16V18C4.5 18.8284 5.17157 19.5 6 19.5H8V21H6C4.34315 21 3 19.6569 3 18V16H4.5ZM7.01562 10V8H8.51562V10H7.01562ZM11.4921 8L11.4921 11.0063C11.4921 11.2781 11.2718 11.4984 11 11.4984V12.9984C12.1002 12.9984 12.9921 12.1065 12.9921 11.0063L12.9921 8H11.4921ZM15.5266 10V8H17.0266V10H15.5266ZM14.9904 13.9801C14.1666 14.7127 13.1026 15.1174 12.0003 15.1174C10.8979 15.1175 9.83387 14.7129 9.01003 13.9805L8.01337 15.1015C9.11182 16.0781 10.5305 16.6175 12.0003 16.6174C13.4701 16.6173 14.8888 16.0778 15.9871 15.101L14.9904 13.9801Z',
    })
  );
};
FaceID.displayName = 'FaceID';
exports['default'] = FaceID;
