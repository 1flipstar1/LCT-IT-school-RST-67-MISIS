'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var BackspaceFill = function BackspaceFill(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M4.90932 4C4.35041 4 3.83786 4.31074 3.57938 4.80628L0.188856 11.3063C-0.0378866 11.741 -0.037887 12.259 0.188856 12.6937L3.57938 19.1937C3.83786 19.6893 4.35041 20 4.90932 20H20.9999C22.6568 20 23.9999 18.6569 23.9999 17V7C23.9999 5.34315 22.6568 4 20.9999 4H4.90932ZM8.8937 15.0467L11.9399 12.0005L8.89381 8.9544L9.95446 7.89373L13.0006 10.9398L16.0466 7.89373L17.1073 8.9544L14.0612 12.0005L17.1074 15.0467L16.0468 16.1074L13.0006 13.0612L9.95436 16.1074L8.8937 15.0467Z',
    })
  );
};
BackspaceFill.displayName = 'BackspaceFill';
exports['default'] = BackspaceFill;
