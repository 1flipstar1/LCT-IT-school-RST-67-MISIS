'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Checklist = function Checklist(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M8.06006 8.9861L12.0078 12.9399L21.9351 3L22.9951 4.06133L12.5377 14.532C12.3971 14.6727 12.2064 14.7518 12.0076 14.7518C11.8088 14.7518 11.6182 14.6727 11.4776 14.5319L6.99992 10.0473L8.06006 8.9861ZM6 4.50003H16.5V3.00003H6C4.34315 3.00003 3 4.34318 3 6.00003V18C3 19.6569 4.34315 21 6 21H18C19.6569 21 21 19.6569 21 18L21 12H19.5V18C19.5 18.8285 18.8284 19.5 18 19.5H6C5.17157 19.5 4.5 18.8285 4.5 18V6.00003C4.5 5.1716 5.17157 4.50003 6 4.50003Z',
    })
  );
};
Checklist.displayName = 'Checklist';
exports['default'] = Checklist;
