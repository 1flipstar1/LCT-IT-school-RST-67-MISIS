'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var ImageRotation = function ImageRotation(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M15.7802 3.06066L14.5709 4.27005H15C18.7279 4.27005 21.75 7.29213 21.75 11.02V12H20.25V11.02C20.25 8.12055 17.8995 5.77005 15 5.77005H14.5503L15.7802 7.00001L14.7196 8.06065L12.2196 5.56064C11.9267 5.26774 11.9267 4.79287 12.2196 4.49998L14.7196 2L15.7802 3.06066ZM5.5 19V18.2834L7.46704 16.6623L11.6536 20.5H7C6.17157 20.5 5.5 19.8284 5.5 19ZM6.8485 15.2283L5.5 16.3397L5.5 12C5.5 11.1716 6.17157 10.5 7 10.5H14C14.8284 10.5 15.5 11.1716 15.5 12V19C15.5 19.8284 14.8284 20.5 14 20.5H13.8735L8.16021 15.2628C7.79271 14.926 7.23322 14.9112 6.8485 15.2283ZM7 22C5.34315 22 4 20.6569 4 19V12C4 10.3431 5.34315 9 7 9H14C15.6569 9 17 10.3431 17 12V19C17 20.6569 15.6569 22 14 22H7ZM13.5 13.75C13.5 14.4404 12.9404 15 12.25 15C11.5596 15 11 14.4404 11 13.75C11 13.0596 11.5596 12.5 12.25 12.5C12.9404 12.5 13.5 13.0596 13.5 13.75Z',
    })
  );
};
ImageRotation.displayName = 'ImageRotation';
exports['default'] = ImageRotation;
