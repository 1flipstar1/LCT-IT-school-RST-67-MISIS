'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var CheckEdit = function CheckEdit(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M17.261 4.7904L15.9036 6.14857L17.8456 8.09171L19.2067 6.72992C19.5964 6.33999 19.5964 5.70884 19.2067 5.31892L18.6784 4.7904C18.2873 4.39908 17.6521 4.39907 17.261 4.7904ZM8.64764 13.4084L14.8432 7.20951L16.7853 9.15265L10.5865 15.3547C10.4926 15.4487 10.3651 15.5015 10.2321 15.5015L8.5015 15.5015L8.50149 13.7611C8.5015 13.6289 8.55405 13.502 8.64764 13.4084ZM10.2321 17C10.764 17 11.274 16.7888 11.6495 16.413L20.2698 7.78818C21.2441 6.81336 21.244 5.23548 20.2697 4.26066L19.7415 3.73215C18.7637 2.75384 17.1757 2.75383 16.198 3.73214L7.58457 12.3501C7.21022 12.7247 7 13.2321 7 13.7611V16.5005C7 16.7763 7.22408 17 7.5005 17L10.2321 17ZM6 4.49998H12V2.99998H6C4.34315 2.99998 3 4.34313 3 5.99999V18C3 19.6568 4.34315 21 6 21H18C19.6569 21 21 19.6568 21 18V12H19.5V18C19.5 18.8284 18.8284 19.5 18 19.5H6C5.17157 19.5 4.5 18.8284 4.5 18V5.99999C4.5 5.17156 5.17157 4.49998 6 4.49998Z',
    })
  );
};
CheckEdit.displayName = 'CheckEdit';
exports['default'] = CheckEdit;
