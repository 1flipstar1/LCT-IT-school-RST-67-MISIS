'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Attention = function Attention(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M2.70778 18.2568L10.7002 4.25308C11.2759 3.24446 12.7301 3.24445 13.3057 4.25308L21.2982 18.2568C21.8689 19.2568 21.1468 20.5003 19.9954 20.5003H4.01053C2.85915 20.5003 2.13705 19.2568 2.70778 18.2568ZM1.40503 17.5132L9.39746 3.50955C10.5488 1.4923 13.4571 1.4923 14.6085 3.50955L22.6009 17.5132C23.7424 19.5132 22.2982 22.0003 19.9954 22.0003H4.01053C1.70776 22.0003 0.263573 19.5132 1.40503 17.5132ZM11.2919 14.5597H12.7084L12.9351 11.5762V8.16586H11.0652V11.5762L11.2919 14.5597ZM11.0652 17.9899H12.9351V16.0532H11.0652V17.9899Z',
    })
  );
};
Attention.displayName = 'Attention';
exports['default'] = Attention;
