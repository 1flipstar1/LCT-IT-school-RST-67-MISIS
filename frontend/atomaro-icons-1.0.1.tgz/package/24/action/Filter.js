'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Filter = function Filter(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M4.5 5.5V6.29744L9.60046 10.5478C10.1704 11.0228 10.5 11.7264 10.5 12.4684V18.0389L12.7938 16.6082C13.2331 16.3342 13.5 15.8531 13.5 15.3355V12.4684C13.5 11.7264 13.8296 11.0228 14.3995 10.5478L19.5 6.29744V5.5H4.5ZM21 7L15.3598 11.7002C15.1318 11.8901 15 12.1716 15 12.4684V15.3355C15 16.3708 14.4661 17.333 13.5877 17.8809L10.1469 20.027C9.64736 20.3386 9 19.9794 9 19.3906V12.4684C9 12.1716 8.86818 11.8901 8.64018 11.7002L3 7V5C3 4.44772 3.44772 4 4 4H20C20.5523 4 21 4.44772 21 5V7Z',
    })
  );
};
Filter.displayName = 'Filter';
exports['default'] = Filter;
