'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Arrow = function Arrow(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M14.7402 13.3894C14.7044 13.256 14.7836 13.1189 14.9169 13.0832L16.1244 12.7597L18.3086 12.1744C18.5006 12.123 18.5587 11.8789 18.4104 11.7465L9.88901 4.13594C9.75467 4.01596 9.54138 4.07311 9.48503 4.24418L5.91054 15.0958C5.84835 15.2846 6.0207 15.467 6.21269 15.4155L8.39694 14.8302L9.60435 14.5067C9.73772 14.471 9.8748 14.5501 9.91054 14.6835L10.2341 15.8909L11.334 19.9961C11.3698 20.1295 11.5069 20.2086 11.6402 20.1729L15.9869 19.0082C16.1203 18.9724 16.1994 18.8354 16.1637 18.702L15.0637 14.5968L14.7402 13.3894ZM16.9008 15.6575L17.8067 19.0382C17.9496 19.5717 17.633 20.12 17.0996 20.263L11.304 21.8159C10.7705 21.9588 10.2222 21.6422 10.0793 21.1088L9.1734 17.728L8.84988 16.5206C8.81414 16.3872 8.67706 16.3081 8.54369 16.3438L7.33628 16.6674L5.26021 17.2236C4.49222 17.4294 3.80284 16.7 4.05159 15.9449L8.41848 2.68762C8.64388 2.00333 9.49705 1.77473 10.0344 2.25464L20.4448 11.5523C21.0379 12.0819 20.8055 13.0583 20.0375 13.2641L17.9615 13.8203L16.7541 14.1439C16.6207 14.1796 16.5415 14.3167 16.5773 14.4501L16.9008 15.6575Z',
    })
  );
};
Arrow.displayName = 'Arrow';
exports['default'] = Arrow;
