'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var ArrowLeftDown = function ArrowLeftDown(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M7.56249 17.4982H14.0015V18.9982H6.00182C5.44954 18.9982 5.00182 18.5505 5.00182 17.9982V9.99844H6.50182V16.4375L17.9391 5.00026L18.9998 6.06091L7.56249 17.4982Z',
    })
  );
};
ArrowLeftDown.displayName = 'ArrowLeftDown';
exports['default'] = ArrowLeftDown;
