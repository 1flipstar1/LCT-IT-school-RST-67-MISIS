'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var CheckLargeDouble = function CheckLargeDouble(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M1.05999 10.9539L6.0077 15.9079L15.9351 5.9679L16.9951 7.02923L6.53769 17.4999C6.24498 17.793 5.77041 17.793 5.4777 17.4999L0 12.0153L1.05999 10.9539ZM13.0079 15.9077L11.4631 14.3599L10.3994 15.4175L12.4775 17.4997C12.6181 17.6405 12.8087 17.7197 13.0076 17.7197C13.2064 17.7197 13.3971 17.6407 13.5377 17.4999L23.9951 7.02923L22.9351 5.9679L13.0079 15.9077Z',
    })
  );
};
CheckLargeDouble.displayName = 'CheckLargeDouble';
exports['default'] = CheckLargeDouble;
