'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var ChevronLeft = function ChevronLeft(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M8.47115 11.4692L13.9711 5.99979L15.0289 7.0634L10.0636 12.001L15.0289 16.9387L13.9711 18.0023L8.47115 12.5329C8.32959 12.3921 8.25 12.2007 8.25 12.001C8.25 11.8014 8.32959 11.61 8.47115 11.4692Z',
    })
  );
};
ChevronLeft.displayName = 'ChevronLeft';
exports['default'] = ChevronLeft;
