'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var CloseSmall = function CloseSmall(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M10.9399 12.0006L6.84839 16.0921L7.90905 17.1528L12.0005 13.0613L16.092 17.1528L17.1527 16.0921L13.0612 12.0006L17.1527 7.90911L16.092 6.84845L12.0005 10.9399L7.90906 6.84845L6.8484 7.90911L10.9399 12.0006Z',
    })
  );
};
CloseSmall.displayName = 'CloseSmall';
exports['default'] = CloseSmall;
