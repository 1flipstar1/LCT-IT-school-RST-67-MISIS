'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var GeolocationFill = function GeolocationFill(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      d: 'M19.9479 4.99909L14.1266 19.5381C14.0702 19.6815 13.9699 19.8034 13.8399 19.8862C13.71 19.9689 13.5572 20.0083 13.4035 19.9986C13.2498 19.9888 13.1031 19.9306 12.9846 19.8321C12.8661 19.7336 12.7819 19.6001 12.744 19.4507L11.1141 12.895L4.54879 11.2469C4.39951 11.209 4.26609 11.1247 4.16773 11.0061C4.06938 10.8875 4.01115 10.7407 4.00145 10.5868C3.99174 10.4329 4.03105 10.28 4.11371 10.1499C4.19638 10.0198 4.31814 9.91937 4.46147 9.86297L19.0019 4.05216C19.1342 3.99918 19.279 3.98621 19.4186 4.01486C19.5581 4.04351 19.6862 4.11252 19.7869 4.21334C19.8876 4.31416 19.9565 4.44236 19.9852 4.58203C20.0138 4.72171 20.0008 4.86672 19.9479 4.99909Z',
    })
  );
};
GeolocationFill.displayName = 'GeolocationFill';
exports['default'] = GeolocationFill;
