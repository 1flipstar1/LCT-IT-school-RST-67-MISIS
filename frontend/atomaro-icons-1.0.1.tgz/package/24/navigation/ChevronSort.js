'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var ChevronSort = function ChevronSort(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M6.91211 9.02848L11.4699 4.46972C11.6106 4.32904 11.8014 4.25 12.0003 4.25C12.1993 4.25 12.3901 4.32904 12.5307 4.46972L17.0886 9.02848L16.0278 10.089L12.0003 6.06077L7.97288 10.089L6.91211 9.02848ZM6.91213 14.9715L11.47 19.5303C11.6106 19.671 11.8014 19.75 12.0004 19.75C12.1993 19.75 12.3901 19.671 12.5307 19.5303L17.0886 14.9715L16.0278 13.911L12.0004 17.9392L7.9729 13.911L6.91213 14.9715Z',
    })
  );
};
ChevronSort.displayName = 'ChevronSort';
exports['default'] = ChevronSort;
