'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var ArrowLeft = function ArrowLeft(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M6.81731 12.749L11.0289 16.9388L9.97105 18.0022L4.47105 12.5307C4.32955 12.39 4.25 12.1986 4.25 11.999C4.25 11.7994 4.32955 11.6081 4.47105 11.4673L9.97105 5.99585L11.0289 7.05926L6.81737 11.249L20 11.249L20 12.749L6.81731 12.749Z',
    })
  );
};
ArrowLeft.displayName = 'ArrowLeft';
exports['default'] = ArrowLeft;
