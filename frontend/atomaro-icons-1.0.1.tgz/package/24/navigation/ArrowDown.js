'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var ArrowDown = function ArrowDown(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M12.749 17.1827L16.9388 12.9711L18.0022 14.0289L12.5307 19.5289C12.39 19.6704 12.1986 19.75 11.999 19.75C11.7994 19.75 11.6081 19.6704 11.4673 19.5289L5.99585 14.0289L7.05926 12.9711L11.249 17.1826L11.249 4H12.749L12.749 17.1827Z',
    })
  );
};
ArrowDown.displayName = 'ArrowDown';
exports['default'] = ArrowDown;
