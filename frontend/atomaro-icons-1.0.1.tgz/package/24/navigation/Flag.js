'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Flag = function Flag(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M20 5.39149V5.38634V4.80557V4.05164C20 3.95255 19.909 3.87846 19.8119 3.89858L19.0737 4.05164L18.505 4.16955L18.5 4.1706L17.1054 4.45974C15.4179 4.80964 13.6616 4.58074 12.1201 3.80998C10.4328 2.96638 8.49382 2.77438 6.67391 3.27071L4 3.99994V3.99997V15.3589V21H5.5V15.6291L6.75199 15.3196C8.51589 14.8836 10.38 15.1436 11.9572 16.0457C13.5853 16.9768 15.5166 17.2227 17.326 16.7292L19.9005 16.0271C19.9592 16.0111 20 15.9577 20 15.8968V5.39149ZM5.5 14.084L6.39202 13.8635C8.53026 13.3349 10.7899 13.6501 12.7019 14.7436C13.9845 15.4771 15.5059 15.6708 16.9314 15.2821L18.5 14.8543V5.7025L17.41 5.9285C15.3922 6.34686 13.2924 6.07318 11.4492 5.15163C10.0921 4.47307 8.53244 4.31863 7.06858 4.71786L5.5 5.14564V14.084Z',
    })
  );
};
Flag.displayName = 'Flag';
exports['default'] = Flag;
