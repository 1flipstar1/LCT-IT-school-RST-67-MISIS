'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var ArrowRightDown = function ArrowRightDown(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M17.4995 16.4374L17.4995 9.99834H18.9995L18.9995 17.9981C18.9995 18.5503 18.5518 18.9981 17.9995 18.9981L9.99979 18.9981V17.4981L16.4389 17.4981L5.0016 6.06078L6.06226 5.00012L17.4995 16.4374Z',
    })
  );
};
ArrowRightDown.displayName = 'ArrowRightDown';
exports['default'] = ArrowRightDown;
