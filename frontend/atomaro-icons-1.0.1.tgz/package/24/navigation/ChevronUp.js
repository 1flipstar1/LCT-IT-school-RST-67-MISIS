'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var ChevronUp = function ChevronUp(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M12.53 9.21973L18.002 14.6928L16.9412 15.7534L11.9996 10.8108L7.05797 15.7534L5.99721 14.6928L11.4692 9.21973C11.6099 9.07905 11.8006 9.00001 11.9996 9.00001C12.1985 9.00001 12.3893 9.07905 12.53 9.21973Z',
    })
  );
};
ChevronUp.displayName = 'ChevronUp';
exports['default'] = ChevronUp;
