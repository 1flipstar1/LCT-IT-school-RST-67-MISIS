'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var ArrowRightLeft = function ArrowRightLeft(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M15.4644 10.4753L17.1903 8.74939L4.99998 8.74939L4.99998 7.24939L17.1883 7.24939L15.4644 5.5255L16.5251 4.46484L19.5303 7.47008C19.8232 7.76297 19.8232 8.23784 19.5303 8.53073L16.5251 11.5359L15.4644 10.4753ZM8.28553 18.4743L6.55964 16.7484L18.75 16.7484V15.2484L6.56167 15.2484L8.28555 13.5245L7.22489 12.4639L4.21967 15.4691C3.92678 15.762 3.92678 16.2369 4.21967 16.5298L7.22488 19.535L8.28553 18.4743Z',
    })
  );
};
ArrowRightLeft.displayName = 'ArrowRightLeft';
exports['default'] = ArrowRightLeft;
