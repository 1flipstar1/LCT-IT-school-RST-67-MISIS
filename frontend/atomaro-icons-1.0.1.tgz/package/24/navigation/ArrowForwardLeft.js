'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var ArrowForwardLeft = function ArrowForwardLeft(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M6.56584 10.7508L10.7757 14.941L9.7175 16.0041L4.22036 10.5327C4.07895 10.3919 3.99945 10.2006 3.99945 10.0011C3.99945 9.80156 4.07895 9.61026 4.22036 9.46951L9.7175 3.99805L10.7757 5.06119L6.5664 9.25081L15.25 9.25081C17.3211 9.25081 19 10.9297 19 13.0008L19 20.0018L17.5 20.0018L17.5 13.0008C17.5 11.7582 16.4926 10.7508 15.25 10.7508L6.56584 10.7508Z',
    })
  );
};
ArrowForwardLeft.displayName = 'ArrowForwardLeft';
exports['default'] = ArrowForwardLeft;
