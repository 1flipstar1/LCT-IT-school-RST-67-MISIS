'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var ChevronRight = function ChevronRight(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M15.5577 11.4693L10.0577 5.99982L8.99996 7.06343L13.9652 12.0011L8.99996 16.9387L10.0577 18.0023L15.5577 12.5329C15.6992 12.3921 15.7788 12.2007 15.7788 12.0011C15.7788 11.8014 15.6992 11.61 15.5577 11.4693Z',
    })
  );
};
ChevronRight.displayName = 'ChevronRight';
exports['default'] = ChevronRight;
