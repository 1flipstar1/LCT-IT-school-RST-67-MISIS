'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var ArrowForwardRight = function ArrowForwardRight(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M16.4337 10.7508L12.2238 14.941L13.282 16.0041L18.7792 10.5327C18.9206 10.3919 19.0001 10.2006 19.0001 10.0011C19.0001 9.80156 18.9206 9.61026 18.7791 9.46951L13.282 3.99805L12.2238 5.06119L16.4331 9.25081L7.74951 9.25081C5.67845 9.25081 3.99951 10.9297 3.99951 13.0008L3.99951 20.0018L5.49951 20.0018L5.49951 13.0008C5.49951 11.7582 6.50687 10.7508 7.74951 10.7508L16.4337 10.7508Z',
    })
  );
};
ArrowForwardRight.displayName = 'ArrowForwardRight';
exports['default'] = ArrowForwardRight;
