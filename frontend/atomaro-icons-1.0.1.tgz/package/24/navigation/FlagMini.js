'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var FlagMini = function FlagMini(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M9.49023 4.52343V4.47625V3.74851V3.25032C9.49023 3.06432 9.68612 2.94345 9.85236 3.02688L10.2976 3.25032L10.9481 3.57673L10.9902 3.59789L17.8208 7.02559L17.8632 7.04688L18.301 7.26655L18.7805 7.50721C19.0747 7.65481 19.0747 8.07464 18.7805 8.22223L18.301 8.4629L17.8632 8.68257L17.8208 8.70386L10.9902 12.1316L10.9861 12.1336V17.0814C11.6453 17.1274 12.2712 17.2423 12.8003 17.4247C13.1457 17.5437 13.5327 17.7195 13.8631 17.9886C14.1818 18.2483 14.6371 18.7603 14.6371 19.5296C14.6371 20.299 14.1818 20.811 13.8631 21.0706C13.5327 21.3398 13.1457 21.5155 12.8003 21.6346C12.0949 21.8776 11.2175 22.0009 10.3186 22.0009C9.41963 22.0009 8.54221 21.8776 7.83685 21.6346C7.4914 21.5155 7.10445 21.3398 6.77406 21.0706C6.45538 20.811 6 20.299 6 19.5296C6 18.7603 6.45538 18.2483 6.77406 17.9886C7.10445 17.7195 7.4914 17.5437 7.83685 17.4247C8.32161 17.2576 8.88765 17.1472 9.48608 17.0944V7.86963H9.49023V4.52343ZM16.1486 7.86472L10.9902 10.4533V5.27616L16.1486 7.86472ZM9.48608 19.5248V18.6014C9.19126 18.6328 8.9171 18.6804 8.67237 18.7411L8.66632 18.7426C7.95965 18.9191 7.5 19.2059 7.5 19.5296C7.5 19.8534 7.95965 20.1401 8.66632 20.3166L8.67237 20.3181C9.13551 20.4331 9.70408 20.5009 10.3186 20.5009C10.9331 20.5009 11.5016 20.4331 11.9648 20.3181L11.9708 20.3166C12.6775 20.1401 13.1371 19.8534 13.1371 19.5296C13.1371 19.2059 12.6775 18.9191 11.9708 18.7426L11.9648 18.7411C11.675 18.6692 11.3439 18.6157 10.9861 18.5857V19.5248H9.48608Z',
    })
  );
};
FlagMini.displayName = 'FlagMini';
exports['default'] = FlagMini;
