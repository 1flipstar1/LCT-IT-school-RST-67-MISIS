'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var CloseLarge = function CloseLarge(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M10.9399 12.0006L4.99878 17.9417L6.05944 19.0024L12.0005 13.0612L17.9416 19.0024L19.0022 17.9417L13.0612 12.0006L19.0022 6.0595L17.9416 4.99884L12.0005 10.9399L6.05946 4.99884L4.9988 6.0595L10.9399 12.0006Z',
    })
  );
};
CloseLarge.displayName = 'CloseLarge';
exports['default'] = CloseLarge;
