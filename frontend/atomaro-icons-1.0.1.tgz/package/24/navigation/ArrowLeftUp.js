'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var ArrowLeftUp = function ArrowLeftUp(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M6.50195 7.56078L6.50195 13.9998H5.00195L5.00195 6.00011C5.00195 5.44783 5.44967 5.00011 6.00195 5.00011H14.0017V6.50011H7.56261L18.9999 17.9374L17.9392 18.998L6.50195 7.56078Z',
    })
  );
};
ArrowLeftUp.displayName = 'ArrowLeftUp';
exports['default'] = ArrowLeftUp;
