'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Fold = function Fold(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M21.0018 8.49816H16.5627L22 3.0609L20.9393 2.00024L15.5021 7.4375V2.99843H14.0021V8.99816C14.0021 9.55044 14.4498 9.99816 15.0021 9.99816H21.0018V8.49816ZM3.00017 15.5002H7.43922L2.00195 20.9375L3.06261 21.9981L8.49989 16.5609V21H9.99989V15.0002C9.99989 14.4479 9.55217 14.0002 8.99989 14.0002H3.00017V15.5002Z',
    })
  );
};
Fold.displayName = 'Fold';
exports['default'] = Fold;
