'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var ArrowUp = function ArrowUp(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M12.7532 6.81734L16.9429 11.0289L18.0063 9.97105L12.5349 4.47105C12.3941 4.32955 12.2028 4.25 12.0032 4.25C11.8036 4.25 11.6122 4.32955 11.4715 4.47105L6 9.97105L7.06342 11.0289L11.2532 6.81734L11.2532 20H12.7532L12.7532 6.81734Z',
    })
  );
};
ArrowUp.displayName = 'ArrowUp';
exports['default'] = ArrowUp;
