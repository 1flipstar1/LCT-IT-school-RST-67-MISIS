'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var ChevronDown = function ChevronDown(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M11.4691 15.5339L5.99707 10.0609L7.05783 9.00031L11.9994 13.9429L16.9411 9.00031L18.0018 10.0609L12.5298 15.5339C12.3892 15.6746 12.1984 15.7537 11.9994 15.7537C11.8005 15.7537 11.6097 15.6746 11.4691 15.5339Z',
    })
  );
};
ChevronDown.displayName = 'ChevronDown';
exports['default'] = ChevronDown;
