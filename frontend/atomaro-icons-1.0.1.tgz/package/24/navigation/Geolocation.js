'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Geolocation = function Geolocation(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M11.1141 12.895L12.744 19.4507C12.7819 19.6001 12.8661 19.7336 12.9846 19.8321C13.1031 19.9306 13.2498 19.9888 13.4035 19.9986C13.5572 20.0083 13.71 19.9689 13.8399 19.8862C13.9699 19.8034 14.0702 19.6815 14.1266 19.5381L19.9479 4.99909C20.0008 4.86672 20.0138 4.72171 19.9852 4.58203C19.9565 4.44236 19.8876 4.31416 19.7869 4.21334C19.6862 4.11252 19.5581 4.04351 19.4186 4.01486C19.279 3.98621 19.1342 3.99918 19.0019 4.05216L4.46147 9.86297C4.31814 9.91937 4.19638 10.0198 4.11371 10.1499C4.03105 10.28 3.99174 10.4329 4.00145 10.5868C4.01115 10.7407 4.06938 10.8875 4.16773 11.0061C4.26609 11.1247 4.39951 11.209 4.54879 11.2469L11.1141 12.895ZM7.22764 10.3729L11.4793 11.4401L12.3525 11.6593L12.5697 12.5331L13.6216 16.7637L17.8859 6.1135L7.22764 10.3729Z',
    })
  );
};
Geolocation.displayName = 'Geolocation';
exports['default'] = Geolocation;
