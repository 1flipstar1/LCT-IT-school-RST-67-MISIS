'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var BatteryChargeHalh = function BatteryChargeHalh(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M17.5 8.5H9.46875C9.19261 8.5 8.96875 8.72386 8.96875 9V11.6624H8.78898H8.49995H7.79641H7.65979C7.29866 11.6624 7.19989 12.1592 7.53356 12.2973L7.65979 12.3495L8.57688 12.7292L8.96875 12.8914V15C8.96875 15.2761 9.19261 15.5 9.46875 15.5H17.5C17.7761 15.5 18 15.2761 18 15V9C18 8.72386 17.7761 8.5 17.5 8.5ZM8.96875 12.8914V11.6624L9.92143 11.6624H9.99995V11.5156V11.4919V10.8719V10.2665C9.99995 10.0884 10.1808 9.96743 10.3454 10.0354L10.905 10.2665L11.478 10.5031L11.4999 10.5121L12.3672 10.8702L13.4183 11.3043L14.3361 11.6832L14.462 11.7352C14.796 11.8731 14.6974 12.3702 14.3361 12.3702H14.1998H13.4843H13.2069H12.0697H11.9843V12.5164V12.5404V13.1619V13.7658C11.9843 13.9439 11.8033 14.0649 11.6387 13.9968L11.0807 13.7658L10.5065 13.5281L10.4843 13.5189L9.62321 13.1624L8.96875 12.8914ZM4 7C2.89543 7 2 7.89543 2 9V15C2 16.1046 2.89543 17 4 17H17.5C18.6046 17 19.5 16.1046 19.5 15V9C19.5 7.89543 18.6046 7 17.5 7H4ZM21.9807 10V14H20.4807V10H21.9807Z',
    })
  );
};
BatteryChargeHalh.displayName = 'BatteryChargeHalh';
exports['default'] = BatteryChargeHalh;
