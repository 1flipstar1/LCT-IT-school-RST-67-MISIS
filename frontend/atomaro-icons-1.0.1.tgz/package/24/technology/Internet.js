'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Internet = function Internet(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M15.0398 19.9403C18.0102 18.8025 20.1792 16.0458 20.4674 12.75H16.9861C16.8776 15.678 16.1387 18.2551 15.0398 19.9403ZM12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22ZM8.9602 4.05969C5.98983 5.19753 3.82077 7.95418 3.53263 11.25H7.01385C7.1224 8.32202 7.86134 5.74493 8.9602 4.05969ZM8.51495 11.25C8.6057 8.98382 9.10247 7.00703 9.80611 5.59975C10.6312 3.94957 11.4935 3.5 12 3.5C12.5065 3.5 13.3688 3.94957 14.1939 5.59975C14.8975 7.00703 15.3943 8.98382 15.4851 11.25H8.51495ZM8.51495 12.75C8.6057 15.0162 9.10247 16.993 9.80611 18.4002C10.6312 20.0504 11.4935 20.5 12 20.5C12.5065 20.5 13.3688 20.0504 14.1939 18.4002C14.8975 16.993 15.3943 15.0162 15.4851 12.75H8.51495ZM7.01385 12.75C7.1224 15.678 7.86134 18.2551 8.9602 19.9403C5.98983 18.8025 3.82077 16.0458 3.53263 12.75H7.01385ZM16.9861 11.25C16.8776 8.32202 16.1387 5.74493 15.0398 4.05969C18.0102 5.19753 20.1792 7.95418 20.4674 11.25H16.9861Z',
    })
  );
};
Internet.displayName = 'Internet';
exports['default'] = Internet;
