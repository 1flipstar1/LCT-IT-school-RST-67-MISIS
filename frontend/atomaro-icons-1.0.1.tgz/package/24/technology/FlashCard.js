'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var FlashCard = function FlashCard(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M8 8C6.89543 8 6 8.89543 6 10V19C6 20.6569 7.34315 22 9 22H15C16.6569 22 18 20.6569 18 19V10C18 8.89543 17.1046 8 16 8V2.75C16 2.33579 15.6642 2 15.25 2H8.75C8.33579 2 8 2.33579 8 2.75V8ZM9.5 8H14.5V3.5H13.5V6H12.5V3.5H11.5V6H10.5V3.5H9.5V8ZM8 9.5H16C16.2761 9.5 16.5 9.72386 16.5 10V19C16.5 19.8284 15.8284 20.5 15 20.5H9C8.17157 20.5 7.5 19.8284 7.5 19V10C7.5 9.72386 7.72386 9.5 8 9.5Z',
    })
  );
};
FlashCard.displayName = 'FlashCard';
exports['default'] = FlashCard;
