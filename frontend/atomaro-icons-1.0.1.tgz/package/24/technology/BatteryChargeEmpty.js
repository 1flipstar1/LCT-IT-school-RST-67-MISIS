'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var BatteryChargeEmpty = function BatteryChargeEmpty(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M17.5 8.5H4C3.72386 8.5 3.5 8.72386 3.5 9V15C3.5 15.2761 3.72386 15.5 4 15.5H17.5C17.7761 15.5 18 15.2761 18 15V9C18 8.72386 17.7761 8.5 17.5 8.5ZM4 7C2.89543 7 2 7.89543 2 9V15C2 16.1046 2.89543 17 4 17H17.5C18.6046 17 19.5 16.1046 19.5 15V9C19.5 7.89543 18.6046 7 17.5 7H4ZM21.9807 10V14H20.4807V10H21.9807ZM8.57688 12.7292L9.62321 13.1624L10.4843 13.5189L10.5065 13.5281L11.0807 13.7658L11.6387 13.9968C11.8033 14.065 11.9843 13.944 11.9843 13.7658V13.1619V12.5404V12.5164V12.3703H12.0697H13.2069H13.4843H14.1998H14.3361C14.6974 12.3703 14.796 11.8731 14.462 11.7353L14.3361 11.6832L13.4183 11.3043L12.3672 10.8703L11.4999 10.5122L11.478 10.5031L10.905 10.2665L10.3454 10.0354C10.1808 9.96746 9.99995 10.0884 9.99995 10.2665V10.8719V11.4919V11.5156V11.6624H9.92143H8.78898H8.49995H7.79641H7.65979C7.29866 11.6624 7.19989 12.1592 7.53356 12.2973L7.65979 12.3496L8.57688 12.7292Z',
    })
  );
};
BatteryChargeEmpty.displayName = 'BatteryChargeEmpty';
exports['default'] = BatteryChargeEmpty;
