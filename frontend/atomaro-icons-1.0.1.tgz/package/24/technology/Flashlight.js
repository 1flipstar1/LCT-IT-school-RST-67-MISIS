'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Flashlight = function Flashlight(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M12.75 5V1H11.25V5H12.75ZM14.9255 5.02959L17.4966 1.96541L18.6457 2.92959L16.0745 5.99377L14.9255 5.02959ZM7.94254 6.0025L5.37139 2.93832L6.52046 1.97414L9.09161 5.03832L7.94254 6.0025ZM18.3524 10.5251L16.0996 12.7783L17.1603 13.8389L16.0996 12.7783C15.7152 13.1627 15.4993 13.6841 15.4993 14.2277V20.5C15.4993 21.0522 15.0516 21.5 14.4993 21.5H9.49927C8.94698 21.5 8.49927 21.0522 8.49927 20.5V14.2277C8.49927 13.6841 8.28336 13.1628 7.89901 12.7783L5.6464 10.5252C5.55266 10.4314 5.5 10.3043 5.5 10.1717V8.49995H18.4988V10.1716C18.4988 10.3042 18.4462 10.4314 18.3524 10.5251ZM16.9993 14.2277C16.9993 14.0819 17.0572 13.942 17.1603 13.8389L19.4132 11.5857C19.7882 11.2107 19.9988 10.702 19.9988 10.1716V7.74995C19.9988 7.33574 19.663 6.99995 19.2488 6.99995H4.75C4.33579 6.99995 4 7.33574 4 7.74995V10.1717C4 10.702 4.21065 11.2107 4.58561 11.5857L6.83822 13.8389C6.94134 13.942 6.99927 14.0819 6.99927 14.2277V20.5C6.99927 21.8807 8.11856 23 9.49927 23H14.4993C15.88 23 16.9993 21.8807 16.9993 20.5V14.2277ZM12.75 13V17H11.25V13H12.75Z',
    })
  );
};
Flashlight.displayName = 'Flashlight';
exports['default'] = Flashlight;
