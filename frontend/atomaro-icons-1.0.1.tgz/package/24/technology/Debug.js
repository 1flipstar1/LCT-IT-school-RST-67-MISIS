'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Debug = function Debug(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M21.0032 7.33045C20.0597 7.85141 19.0462 8.27915 17.9877 8.61367C17.9959 8.7414 18 8.87022 18 9V12.0241H21V13.5241H18V14C18 15.0888 17.71 16.1099 17.2029 16.9902C18.1695 17.4802 19.0932 18.1137 19.949 18.8906L18.9407 20.0012C18.1137 19.2504 17.2165 18.6524 16.2778 18.2072C15.1893 19.3138 13.6748 20 12 20C10.3252 20 8.81065 19.3138 7.7222 18.2072C6.78347 18.6524 5.88632 19.2504 5.05929 20.0012L4.05102 18.8906C4.90677 18.1137 5.83047 17.4803 6.79703 16.9902C6.29001 16.1099 5.99998 15.0888 5.99998 14V13.5241H3V12.0241H5.99998V9C5.99998 8.87018 6.0041 8.74133 6.01222 8.61356C4.95387 8.27905 3.94047 7.85135 2.99707 7.33045L3.72212 6.01732C4.52853 6.46258 5.39341 6.83338 6.29722 7.1297C7.08315 4.73182 9.33932 3 12 3C14.6607 3 16.9169 4.73187 17.7028 7.12981C18.6067 6.83346 19.4717 6.46264 20.2782 6.01732L21.0032 7.33045ZM12.75 9.50062C14.0184 9.45501 15.2799 9.2936 16.5 9.01637V14C16.5 16.4853 14.4853 18.5 12 18.5C9.5147 18.5 7.49998 16.4853 7.49998 14V9.01629C8.72001 9.29354 9.98157 9.45498 11.25 9.50061V13.5H12.75V9.50062ZM12 4.5C10.0281 4.5 8.35253 5.76824 7.74434 7.53352C10.4992 8.17426 13.5008 8.17429 16.2556 7.53359C15.6475 5.76828 13.9718 4.5 12 4.5Z',
    })
  );
};
Debug.displayName = 'Debug';
exports['default'] = Debug;
