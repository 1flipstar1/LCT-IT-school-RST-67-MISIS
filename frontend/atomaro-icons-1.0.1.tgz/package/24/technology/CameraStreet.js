'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var CameraStreet = function CameraStreet(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M3.93198 4.54457C5.0423 2.93218 7.25926 2.54402 8.85136 3.68325L22.7943 13.6602C23.0712 13.8583 23.0734 14.2693 22.7986 14.4703L20.6929 16.0109C19.1438 17.1443 17.1029 17.2803 15.4346 16.4124L14.1464 17.4334C13.1853 18.1952 11.836 18.2285 10.8385 17.5151L8.7328 16.0091L5.71803 18.4221C5.23034 18.8124 4.62428 19.0251 3.99962 19.0251H2.49099C2.43346 19.9597 2.01933 20.8402 1.2486 20.996C1.11327 21.0234 1 20.9084 1 20.7703V15.2612C1 15.1232 1.11327 15.0082 1.2486 15.0356C2.08151 15.204 2.49796 16.2187 2.49796 17.2334V17.5251H3.99962C4.28356 17.5251 4.55904 17.4284 4.78071 17.251L7.4651 15.1025L4.16789 12.7443C2.94875 11.8724 2.65237 10.1848 3.50148 8.94962L3.93734 8.3156L3.79793 8.21672C2.90579 7.58397 2.68742 6.35191 3.30775 5.45108L3.93198 4.54457ZM5.16098 9.18348L14.1217 15.539L13.2147 16.2579C12.7778 16.6041 12.1645 16.6193 11.7111 16.295L5.04048 11.5242C4.48633 11.1279 4.35161 10.3608 4.73757 9.79938L5.16098 9.18348ZM4.54317 6.30181L5.1674 5.3953C5.80187 4.47394 7.0687 4.25213 7.97847 4.90312L20.7975 14.0758L19.8072 14.8004C18.5919 15.6896 16.944 15.7017 15.7157 14.8305L4.66571 6.99322C4.44268 6.83503 4.38808 6.52702 4.54317 6.30181Z',
    })
  );
};
CameraStreet.displayName = 'CameraStreet';
exports['default'] = CameraStreet;
