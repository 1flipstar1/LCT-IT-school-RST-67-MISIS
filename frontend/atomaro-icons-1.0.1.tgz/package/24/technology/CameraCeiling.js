'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var CameraCeiling = function CameraCeiling(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M3.5 5.5L3.5 10C3.5 10.8284 4.17157 11.5 5 11.5L19 11.5C19.8284 11.5 20.5 10.8284 20.5 10L20.5 5.5L3.5 5.5ZM3 4C2.44771 4 2 4.44771 2 5L2 10C2 11.3226 2.8559 12.4453 4.04404 12.8445C4.46593 16.8658 7.86695 20 12 20C16.1331 20 19.5341 16.8658 19.956 12.8445C21.1441 12.4453 22 11.3226 22 10L22 5C22 4.44771 21.5523 4 21 4L3 4ZM18.4236 13L5.57645 13C6.05745 16.1151 8.75021 18.5 12 18.5C15.2498 18.5 17.9425 16.1151 18.4236 13ZM13.5 15.5C13.5 16.3284 12.8284 17 12 17C11.1716 17 10.5 16.3284 10.5 15.5C10.5 14.6716 11.1716 14 12 14C12.8284 14 13.5 14.6716 13.5 15.5Z',
    })
  );
};
CameraCeiling.displayName = 'CameraCeiling';
exports['default'] = CameraCeiling;
