'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var BluetoothOff = function BluetoothOff(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M6.65875 9.90433L3.01709 7.39956L3.86714 6.16367L21.0039 17.9505L20.1538 19.1864L16.4563 16.6432L13.7896 14.8344L11.75 13.4243V19.5312L14.7937 17.328L16.1143 18.2237L11.4398 21.6075C11.2115 21.7728 10.9099 21.7961 10.6589 21.668C10.4079 21.5398 10.25 21.2818 10.25 21V13.3356L6.2862 16.0147L5.44622 14.772L9.61945 11.9513L6.65875 9.90433ZM13.55 11.1051L17.7835 8.2437C17.9861 8.10673 18.1093 7.87956 18.1134 7.63501C18.1175 7.39046 18.0022 7.15925 17.8043 7.01551L11.4408 2.39319C11.2126 2.22745 10.9107 2.20372 10.6595 2.33177C10.4082 2.45981 10.25 2.71799 10.25 3V8.8404L11.75 9.86981V4.47176L16.0569 7.60021L12.2209 10.193L13.55 11.1051Z',
    })
  );
};
BluetoothOff.displayName = 'BluetoothOff';
exports['default'] = BluetoothOff;
