'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var FloppyDisk = function FloppyDisk(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M17.6969 6.34985L17.6819 6.33491L16.3131 4.94678C16.0312 4.66093 15.6465 4.5 15.2451 4.5H15V7C15 8.10457 14.1046 9 13 9H9C7.89543 9 7 8.10457 7 7V4.5H6C5.17157 4.5 4.5 5.17157 4.5 6V18C4.5 18.8284 5.17157 19.5 6 19.5H7V15C7 13.8954 7.89543 13 9 13H15C16.1046 13 17 13.8954 17 15V19.5H18C18.8284 19.5 19.5 18.8284 19.5 18V12V8.75512C19.5 8.35361 19.339 7.96886 19.0531 7.68697L17.6969 6.34985ZM17 21H15.5H8.5H7H6C4.34315 21 3 19.6569 3 18V6C3 4.34315 4.34315 3 6 3H7H8.5H12H13.5H15H15.2451C16.048 3 16.8174 3.32186 17.3812 3.89357L18.75 5.28169L20.1062 6.61881C20.6781 7.18259 21 7.9521 21 8.75512V12V18C21 19.6569 19.6569 21 18 21H17ZM15.5 19.5V15C15.5 14.7239 15.2761 14.5 15 14.5H9C8.72386 14.5 8.5 14.7239 8.5 15V19.5H15.5ZM12 4.5H13.5V7C13.5 7.27614 13.2761 7.5 13 7.5H9C8.72386 7.5 8.5 7.27614 8.5 7V4.5H12Z',
    })
  );
};
FloppyDisk.displayName = 'FloppyDisk';
exports['default'] = FloppyDisk;
