'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Console = function Console(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M16.9913 3.48169C12.5308 3.48169 8.96941 7.04298 8.96945 11.5035L7.46945 11.5212C7.4694 6.2254 11.7132 1.98169 17.009 1.98169L16.9913 3.48169ZM13.6538 8.16325C12.8537 8.96335 12.3609 10.1123 12.3609 11.5007L10.8609 11.5184C10.8609 9.76315 11.4908 8.21746 12.5994 7.10889C13.708 6.00032 15.2536 5.37036 17.0089 5.37037L16.9911 6.87037C15.6027 6.87036 14.4539 7.36315 13.6538 8.16325ZM18.0183 10.5279C18.0151 11.0829 17.7051 11.568 17.25 11.8215V14H18C20.2091 14 22 15.7908 22 18C22 20.2091 20.2091 22 18 22H6C3.79086 22 2 20.2091 2 18C2 15.7908 3.79086 14 6 14H15.75V11.7844C15.3408 11.5257 15.0709 11.0681 15.074 10.5453C15.0788 9.73224 15.7418 9.06923 16.5549 9.06442C17.3679 9.0596 18.0232 9.71481 18.0183 10.5279ZM15.75 15.5L6 15.5C4.61929 15.5 3.5 16.6192 3.5 18C3.5 19.3807 4.61929 20.5 6 20.5H18C19.3807 20.5 20.5 19.3807 20.5 18C20.5 16.6192 19.3807 15.5 18 15.5L17.25 15.5H15.75ZM6 17.25L18 17.25V18.75L6 18.75V17.25Z',
    })
  );
};
Console.displayName = 'Console';
exports['default'] = Console;
