'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Adaptive = function Adaptive(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M15 4.5H5C4.17157 4.5 3.5 5.17157 3.5 6V12C3.5 12.8284 4.17157 13.5 5 13.5H12V10C12 8.34315 13.3431 7 15 7H16.5V6C16.5 5.17157 15.8284 4.5 15 4.5ZM18 7H19C20.6569 7 22 8.34315 22 10V18C22 19.6569 20.6569 21 19 21H15C13.3431 21 12 19.6569 12 18H6V16.5H9.25L9.25 15H5C3.34315 15 2 13.6569 2 12V6C2 4.34315 3.34315 3 5 3H15C16.6569 3 18 4.34315 18 6V7ZM12 16.5V15H10.75L10.75 16.5H12ZM19 8.5H15C14.1716 8.5 13.5 9.17157 13.5 10V18C13.5 18.8284 14.1716 19.5 15 19.5H19C19.8284 19.5 20.5 18.8284 20.5 18V10C20.5 9.17157 19.8284 8.5 19 8.5ZM16 16.5H18V18H16V16.5Z',
    })
  );
};
Adaptive.displayName = 'Adaptive';
exports['default'] = Adaptive;
