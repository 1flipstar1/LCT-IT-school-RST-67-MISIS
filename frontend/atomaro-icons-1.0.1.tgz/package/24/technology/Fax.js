'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Fax = function Fax(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M5 4.50293H19C19.8284 4.50293 20.5 5.1745 20.5 6.00293V14.0029C20.5 14.8314 19.8284 15.5029 19 15.5029V11.0029C19 10.4506 18.5523 10.0029 18 10.0029H6C5.44772 10.0029 5 10.4506 5 11.0029L5 15.5029C4.17157 15.5029 3.5 14.8314 3.5 14.0029V6.00293C3.5 5.1745 4.17157 4.50293 5 4.50293ZM19 19.0029V17.0029C20.6569 17.0029 22 15.6598 22 14.0029V6.00293C22 4.34608 20.6569 3.00293 19 3.00293H5C3.34315 3.00293 2 4.34608 2 6.00293V14.0029C2 15.6598 3.34315 17.0029 5 17.0029L5 19.0029C5 20.1075 5.89543 21.0029 7 21.0029H17C18.1046 21.0029 19 20.1075 19 19.0029ZM17 19.5029H7C6.72386 19.5029 6.5 19.2791 6.5 19.0029V11.5029H17.5V19.0029C17.5 19.2791 17.2761 19.5029 17 19.5029ZM6 8.00109C6.55228 8.00109 7 7.55379 7 7.00201C7 6.45023 6.55228 6.00293 6 6.00293C5.44772 6.00293 5 6.45023 5 7.00201C5 7.55379 5.44772 8.00109 6 8.00109ZM11 7.00201C11 7.55379 10.5523 8.00109 10 8.00109C9.44772 8.00109 9 7.55379 9 7.00201C9 6.45023 9.44772 6.00293 10 6.00293C10.5523 6.00293 11 6.45023 11 7.00201ZM13 7.75098H19V6.25098H13V7.75098Z',
    })
  );
};
Fax.displayName = 'Fax';
exports['default'] = Fax;
