'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var AllDevices = function AllDevices(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M20 7.17071V6C20 4.34315 18.6569 3 17 3H5C3.34315 3 2 4.34315 2 6V15C2 16.6569 3.34314 18 5 18H12C12 19.6569 13.3431 21 15 21H19C20.6569 21 22 19.6569 22 18V10C22 8.69378 21.1652 7.58254 20 7.17071ZM18.5 7V6C18.5 5.17157 17.8284 4.5 17 4.5L5 4.5C4.17157 4.5 3.5 5.17157 3.5 6L3.5 15C3.5 15.8284 4.17157 16.5 5 16.5L12 16.5V10C12 8.34315 13.3431 7 15 7H18.5ZM13.5 10C13.5 9.17157 14.1716 8.5 15 8.5H19C19.8284 8.5 20.5 9.17157 20.5 10V18C20.5 18.8284 19.8284 19.5 19 19.5H15C14.1716 19.5 13.5 18.8284 13.5 18V10ZM18 18V16.5H16V18H18ZM6.5 9V12H5L5 9H6.5Z',
    })
  );
};
AllDevices.displayName = 'AllDevices';
exports['default'] = AllDevices;
