'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Broadcast = function Broadcast(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M1.99992 9.9624V11.4623C2.1716 11.4639 2.33211 11.4673 2.47954 11.4724L2.49239 11.4728H2.50525C6.96576 11.4728 10.5271 15.0341 10.5271 19.4946L10.5271 19.5155L10.5283 19.5364C10.534 19.64 10.5306 19.7962 10.5177 19.9999H12.021C12.031 19.8037 12.0336 19.6322 12.0271 19.4929C12.0167 14.2105 7.78372 9.97976 2.50046 9.97285C2.34573 9.96766 2.17828 9.96406 1.99992 9.9624ZM1.99992 13.3847V14.8885C2.18175 14.8771 2.35627 14.8681 2.52222 14.8616C3.90424 14.8649 5.04801 15.3571 5.84536 16.1544C6.64545 16.9545 7.13823 18.1034 7.13823 19.4918V19.4995L7.13839 19.5071C7.14128 19.6492 7.13688 19.8148 7.12607 19.9999H8.62876C8.63763 19.8191 8.64106 19.6521 8.63823 19.5021C8.63643 17.7499 8.0067 16.2071 6.89973 15.1001C5.79117 13.9915 4.2455 13.3615 2.49022 13.3616H2.47568L2.46116 13.3621C2.31374 13.3678 2.15973 13.3753 1.99992 13.3847ZM3.50885 20.0089C2.6755 20.004 1.99593 19.3244 1.99099 18.4911C1.98606 17.6577 2.65763 16.9861 3.49099 16.9911C4.32435 16.996 5.00392 17.6756 5.00885 18.5089C5.01379 19.3423 4.34221 20.0139 3.50885 20.0089Z',
    }),
    ',',
    react_1['default'].createElement('path', {
      d: 'M4.99992 5.5H18.9999C19.8284 5.5 20.4999 6.17157 20.4999 7V17C20.4999 17.8284 19.8284 18.5 18.9999 18.5H13.9999V20H18.9999C20.6568 20 21.9999 18.6569 21.9999 17V7C21.9999 5.34315 20.6568 4 18.9999 4H4.99992C3.34307 4 1.99992 5.34315 1.99992 7V8H3.49992V7C3.49992 6.17157 4.1715 5.5 4.99992 5.5Z',
    })
  );
};
Broadcast.displayName = 'Broadcast';
exports['default'] = Broadcast;
