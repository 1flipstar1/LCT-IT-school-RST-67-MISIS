'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var InternetCableThree = function InternetCableThree(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M12 20.5C12.3383 20.5 12.672 20.4802 13 20.4418V21.9506C12.6711 21.9833 12.3375 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C16.8379 2 20.8734 5.43552 21.8 10H20.2634C19.6044 7.26768 17.6255 5.04998 15.0393 4.05948C15.2633 4.40251 15.4736 4.78464 15.6674 5.20299C16.0514 6.0316 16.3596 6.97835 16.5826 8H15.0436C14.8503 7.20056 14.6011 6.46955 14.3064 5.83359C13.6375 4.38982 12.8849 3.74233 12.3564 3.56204C11.9668 3.42914 11.4384 3.46671 10.7553 4.18755C10.031 4.95206 9.34358 6.31089 8.91863 8.16044C8.69445 9.13612 8.55863 10.1833 8.51523 11.25H13V12.75H8.51522C8.53291 13.185 8.5661 13.6193 8.61503 14.0494C8.84227 16.0465 9.38559 17.7495 10.0922 18.922C10.816 20.1229 11.5102 20.4656 11.9237 20.4971L11.9235 20.4997C11.949 20.4999 11.9745 20.5 12 20.5ZM8.96075 19.9405C8.90897 19.8612 8.85788 19.7798 8.80752 19.6963C7.96043 18.2907 7.36888 16.3654 7.12465 14.2189C7.06937 13.7331 7.03258 13.2421 7.01408 12.75H3.53263C3.82079 16.046 5.9901 18.8028 8.96075 19.9405ZM8.96074 4.05948C8.31677 5.04542 7.79886 6.33544 7.45672 7.82455C7.20688 8.91192 7.05837 10.0724 7.01408 11.25H3.53263C3.82078 7.95398 5.9901 5.19719 8.96074 4.05948ZM16.5 13V11.5H17.5V13H16.5ZM15 13V11C15 10.4477 15.4477 10 16 10H18C18.5523 10 19 10.4477 19 11V13C19.5523 13 20 13.4477 20 14V17C20 18.3979 19.0439 19.5725 17.75 19.9055V22H16.25V19.9055C14.9561 19.5725 14 18.3979 14 17V14C14 13.4477 14.4477 13 15 13ZM15.5 14.5V17C15.5 17.8284 16.1716 18.5 17 18.5C17.8284 18.5 18.5 17.8284 18.5 17V14.5H17.5H16.5H15.5Z',
    })
  );
};
InternetCableThree.displayName = 'InternetCableThree';
exports['default'] = InternetCableThree;
