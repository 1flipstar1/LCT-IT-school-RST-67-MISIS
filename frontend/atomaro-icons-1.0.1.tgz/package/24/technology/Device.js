'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Device = function Device(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M13 4.5L11 4.5C10.015 4.5 9.19515 4.50083 8.5 4.51896L8.5 5C8.5 5.27614 8.72386 5.5 9 5.5L15 5.5C15.2761 5.5 15.5 5.27614 15.5 5L15.5 4.51897C14.8049 4.50083 13.985 4.5 13 4.5ZM17 4.6097C17.0645 4.617 17.1275 4.62477 17.1892 4.63307C18.1121 4.75715 18.5071 4.9716 18.7678 5.23223C19.0284 5.49287 19.2428 5.88786 19.3669 6.81078C19.4968 7.77686 19.5 9.07198 19.5 11L19.5 13C19.5 14.928 19.4968 16.2231 19.3669 17.1892C19.2428 18.1121 19.0284 18.5071 18.7678 18.7678C18.5071 19.0284 18.1121 19.2428 17.1892 19.3669C16.2231 19.4968 14.928 19.5 13 19.5L11 19.5C9.07198 19.5 7.77686 19.4968 6.81078 19.3669C5.88786 19.2428 5.49287 19.0284 5.23223 18.7678C4.9716 18.5071 4.75715 18.1121 4.63307 17.1892C4.50318 16.2231 4.5 14.928 4.5 13L4.5 11C4.5 9.07198 4.50318 7.77686 4.63307 6.81078C4.75715 5.88786 4.9716 5.49286 5.23223 5.23223C5.49287 4.9716 5.88786 4.75715 6.81078 4.63307C6.87249 4.62477 6.93553 4.61699 7 4.6097L7 5C7 6.10457 7.89543 7 9 7L15 7C16.1046 7 17 6.10457 17 5L17 4.6097ZM21 11C21 7.22876 21 5.34315 19.8284 4.17157C18.6569 3 16.7712 3 13 3L11 3C7.22876 3 5.34315 3 4.17157 4.17157C3 5.34314 3 7.22876 3 11L3 13C3 16.7712 3 18.6569 4.17157 19.8284C5.34314 21 7.22876 21 11 21L13 21C16.7712 21 18.6569 21 19.8284 19.8284C21 18.6569 21 16.7712 21 13L21 11ZM9 16.5C9 17.3284 8.32843 18 7.5 18C6.67157 18 6 17.3284 6 16.5C6 15.6716 6.67157 15 7.5 15C8.32843 15 9 15.6716 9 16.5ZM17 15.75L11 15.75L11 17.25L17 17.25L17 15.75Z',
    })
  );
};
Device.displayName = 'Device';
exports['default'] = Device;
