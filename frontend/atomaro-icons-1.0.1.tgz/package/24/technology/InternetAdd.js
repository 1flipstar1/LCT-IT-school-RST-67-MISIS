'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var InternetAdd = function InternetAdd(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M12 20.5C12.6889 20.5 13.3586 20.4181 14 20.2634V21.8C13.3538 21.9311 12.6849 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12C22 12.6849 21.9311 13.3538 21.8 14H20.2634C20.3613 13.5939 20.4301 13.1765 20.4674 12.75H16.9859C16.9701 13.1705 16.941 13.588 16.899 14H15.3905C15.436 13.59 15.4676 13.1723 15.4848 12.75H8.51522C8.53291 13.185 8.5661 13.6193 8.61503 14.0494C8.84227 16.0465 9.38559 17.7495 10.0922 18.922C10.816 20.1229 11.5102 20.4656 11.9237 20.4971L11.9235 20.4997C11.949 20.4999 11.9745 20.5 12 20.5ZM8.96075 19.9405C8.90897 19.8612 8.85788 19.7798 8.80752 19.6963C7.96043 18.2907 7.36888 16.3654 7.12465 14.2189C7.06937 13.7331 7.03258 13.2421 7.01408 12.75H3.53263C3.82079 16.046 5.9901 18.8028 8.96075 19.9405ZM8.51523 11.25H15.4848C15.4833 11.2142 15.4818 11.1784 15.4801 11.1425C15.385 9.10093 14.9563 7.2361 14.3064 5.83359C13.6375 4.38982 12.8849 3.74233 12.3564 3.56204C11.9668 3.42914 11.4384 3.46671 10.7553 4.18755C10.031 4.95206 9.34358 6.31089 8.91863 8.16044C8.69445 9.13612 8.55863 10.1833 8.51523 11.25ZM16.9859 11.25H20.4674C20.1792 7.95398 18.0099 5.19719 15.0393 4.05948C15.2633 4.40251 15.4736 4.78464 15.6674 5.20299C16.4156 6.81764 16.8764 8.8809 16.9785 11.0728C16.9812 11.1318 16.9837 11.1909 16.9859 11.25ZM8.96074 4.05948C8.31677 5.04542 7.79886 6.33544 7.45672 7.82455C7.20688 8.91192 7.05837 10.0724 7.01408 11.25H3.53263C3.82078 7.95398 5.9901 5.19719 8.96074 4.05948ZM17.75 21.5V19.25H15.5V17.75H17.75V15.5H19.25V17.75H21.5V19.25H19.25V21.5H17.75Z',
    })
  );
};
InternetAdd.displayName = 'InternetAdd';
exports['default'] = InternetAdd;
