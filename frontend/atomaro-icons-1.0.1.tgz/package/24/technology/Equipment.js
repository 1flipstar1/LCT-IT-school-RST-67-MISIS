'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Equipment = function Equipment(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M10.4817 11.5035C10.4817 7.04298 14.043 3.48169 18.5035 3.48169L18.5213 1.98169C13.2255 1.98169 8.98164 6.2254 8.98169 11.5212L10.4817 11.5035ZM13.8706 11.5007C13.8706 10.1123 14.3634 8.96339 15.1634 8.16329C15.9635 7.36319 17.1124 6.87041 18.5008 6.87041L18.5186 5.37041C16.7633 5.3704 15.2176 6.00037 14.1091 7.10894C13.0005 8.21751 12.3706 9.76319 12.3706 11.5185L13.8706 11.5007ZM18.25 11.8162C18.6999 11.5612 19.0056 11.079 19.0088 10.5279C19.0136 9.71485 18.3584 9.05965 17.5454 9.06446C16.7323 9.06927 16.0693 9.73228 16.0645 10.5453C16.0614 11.0722 16.3354 11.5328 16.75 11.7905V14H4C2.89543 14 2 14.8954 2 16V20C2 21.1046 2.89543 22 4 22H20C21.1046 22 22 21.1046 22 20V16C22 14.8954 21.1046 14 20 14H18.25V11.8162ZM20 15.5H4C3.72386 15.5 3.5 15.7239 3.5 16V20C3.5 20.2761 3.72386 20.5 4 20.5H20C20.2761 20.5 20.5 20.2761 20.5 20V16C20.5 15.7239 20.2761 15.5 20 15.5ZM11 17.25L18 17.25V18.75H11V17.25ZM7.5 19.5C8.32843 19.5 9 18.8284 9 18C9 17.1716 8.32843 16.5 7.5 16.5C6.67157 16.5 6 17.1716 6 18C6 18.8284 6.67157 19.5 7.5 19.5Z',
    })
  );
};
Equipment.displayName = 'Equipment';
exports['default'] = Equipment;
