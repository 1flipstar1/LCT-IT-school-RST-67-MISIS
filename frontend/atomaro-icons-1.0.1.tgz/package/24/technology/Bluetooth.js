'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Bluetooth = function Bluetooth(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M11.6595 2.33177C11.9108 2.20372 12.2127 2.22745 12.4408 2.39319L18.8043 7.01551C19.0023 7.15932 19.1177 7.39066 19.1135 7.63532C19.1092 7.87997 18.9859 8.10718 18.7831 8.24404L13.2045 12.0079L18.7831 15.7718C18.9861 15.9088 19.1094 16.1363 19.1135 16.3812C19.1175 16.6261 19.0017 16.8575 18.8034 17.0011L12.4398 21.6075C12.2116 21.7728 11.9099 21.7961 11.659 21.668C11.408 21.5398 11.2501 21.2818 11.2501 21V13.3266L5.78305 17.0153L4.94409 15.7718L10.5226 12.0079L4.94409 8.24404L5.78305 7.0006L11.2501 10.6892V3C11.2501 2.71799 11.4083 2.45981 11.6595 2.33177ZM12.7501 13.5108L17.0547 16.4152L12.7501 19.5312V13.5108ZM12.7501 10.5051V4.47176L17.0562 7.59966L12.7501 10.5051Z',
    })
  );
};
Bluetooth.displayName = 'Bluetooth';
exports['default'] = Bluetooth;
