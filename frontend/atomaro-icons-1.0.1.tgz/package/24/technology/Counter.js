'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Counter = function Counter(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M12 20.5C16.6944 20.5 20.5 16.6944 20.5 12C20.5 7.30558 16.6944 3.5 12 3.5C7.30558 3.5 3.5 7.30558 3.5 12C3.5 16.6944 7.30558 20.5 12 20.5ZM12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22ZM14 16.0078V17.5078H10V16.0078H14ZM7.5 12.5V10.5H9.51562V12.5H7.5ZM11.0156 12.5V10.5H12.9844V12.5H11.0156ZM14.4844 12.5H16.5V10.5H14.4844V12.5ZM6 9.25C6 9.11193 6.11193 9 6.25 9H17.75C17.8881 9 18 9.11193 18 9.25V13.75C18 13.8881 17.8881 14 17.75 14H6.25C6.11193 14 6 13.8881 6 13.75V9.25Z',
    })
  );
};
Counter.displayName = 'Counter';
exports['default'] = Counter;
