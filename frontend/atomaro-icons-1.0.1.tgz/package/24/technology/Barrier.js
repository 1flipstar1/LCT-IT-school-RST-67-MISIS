'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Barrier = function Barrier(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M17.0037 4.61359L11 8.01635V10.2761L18.0004 6.30837C18.4728 6.04066 18.6326 5.44424 18.3573 4.97624C18.0821 4.50824 17.476 4.34587 17.0037 4.61359ZM11 12V18.5V18.5157H20V20.0157H9V20H5.5H4V18.5V5.91697C4 4.8124 4.89543 3.91697 6 3.91697H9C10.1046 3.91697 11 4.8124 11 5.91697V6.29239L16.2433 3.32062C17.4363 2.64442 18.9671 3.05452 19.6623 4.23661C20.3575 5.4187 19.9539 6.92514 18.7608 7.60134L11 12ZM6 5.41697H9C9.27614 5.41697 9.5 5.64083 9.5 5.91697V7.25004H5.5V5.91697C5.5 5.64083 5.72386 5.41697 6 5.41697ZM5.5 8.75004H9.5V18.5H5.5V8.75004Z',
    })
  );
};
Barrier.displayName = 'Barrier';
exports['default'] = Barrier;
