'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var BroadcastOff = function BroadcastOff(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      d: 'M2 9.9624V11.4623C2.17168 11.4639 2.33219 11.4673 2.47961 11.4724L2.49247 11.4728H2.50532C6.96584 11.4728 10.5272 15.0341 10.5272 19.4946L10.5272 19.5155L10.5283 19.5364C10.5341 19.64 10.5306 19.7962 10.5177 19.9999H12.021C12.0311 19.8037 12.0337 19.6322 12.0272 19.4929C12.0168 14.2105 7.78379 9.97976 2.50054 9.97285C2.3458 9.96766 2.17836 9.96406 2 9.9624Z',
    }),
    ',',
    react_1['default'].createElement('path', {
      d: 'M2 13.3847V14.8885C2.18182 14.8771 2.35635 14.8681 2.52229 14.8616C3.90431 14.8649 5.04808 15.3571 5.84544 16.1544C6.64553 16.9545 7.13831 18.1034 7.13831 19.4918V19.4995L7.13846 19.5071C7.14136 19.6492 7.13696 19.8148 7.12615 19.9999H8.62883C8.63771 19.8191 8.64113 19.6521 8.6383 19.5021C8.6365 17.7499 8.00677 16.2071 6.89981 15.1001C5.79125 13.9915 4.24557 13.3615 2.4903 13.3616H2.47576L2.46124 13.3621C2.31382 13.3678 2.15981 13.3753 2 13.3847Z',
    }),
    ',',
    react_1['default'].createElement('path', {
      d: 'M3.50893 20.0089C2.67557 20.004 1.996 19.3244 1.99107 18.4911C1.98614 17.6577 2.65771 16.9861 3.49107 16.9911C4.32443 16.996 5.004 17.6756 5.00893 18.5089C5.01386 19.3423 4.34229 20.0139 3.50893 20.0089Z',
    }),
    ',',
    react_1['default'].createElement('path', {
      d: 'M18.9525 20L20.9697 22.0172L22.0304 20.9565L3.03039 1.95654L1.96973 3.0172L3.40881 4.45628C2.56263 4.98671 2 5.92765 2 7V8H3.5V7C3.5 6.33639 3.93093 5.77344 4.52822 5.5757L17.4525 18.5H14V20H18.9525Z',
    }),
    ',',
    react_1['default'].createElement('path', {
      d: 'M22 17C22 17.5252 21.8651 18.0188 21.628 18.4482L20.4716 17.2918C20.4902 17.1974 20.5 17.0999 20.5 17V7C20.5 6.17157 19.8284 5.5 19 5.5H8.6798L7.1798 4H19C20.6569 4 22 5.34315 22 7V17Z',
    })
  );
};
BroadcastOff.displayName = 'BroadcastOff';
exports['default'] = BroadcastOff;
