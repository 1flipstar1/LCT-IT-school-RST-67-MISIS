'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Book = function Book(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M12 4.5H17.5V15H8C7.45357 15 6.94126 15.1461 6.5 15.4013V6C6.5 5.17157 7.17157 4.5 8 4.5V7.77841C8 7.94669 8.16291 8.06691 8.32372 8.01729L10 7.5L11.6763 8.01729C11.8371 8.06691 12 7.94669 12 7.77841V4.5ZM8 19.5C7.17157 19.5 6.5 18.8284 6.5 18C6.5 17.1716 7.17157 16.5 8 16.5H17.5V19.5H8ZM19 4V15V16.5V20C19 20.5523 18.5523 21 18 21H8C6.34315 21 5 19.6569 5 18V6C5 4.34315 6.34315 3 8 3H18C18.5523 3 19 3.44772 19 4Z',
    })
  );
};
Book.displayName = 'Book';
exports['default'] = Book;
