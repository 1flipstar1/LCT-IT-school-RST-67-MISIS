'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Achievement = function Achievement(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M4 6.5H20C20.2761 6.5 20.5 6.72386 20.5 7V17C20.5 17.2761 20.2761 17.5 20 17.5H17.8465V14.8102C18.5597 14.0879 19 13.0953 19 12C19 9.79086 17.2091 8 15 8C12.7909 8 11 9.79086 11 12C11 13.0248 11.3853 13.9595 12.019 14.6672V17.5H4C3.72386 17.5 3.5 17.2761 3.5 17V7C3.5 6.72386 3.72386 6.5 4 6.5ZM12.019 19H4C2.89543 19 2 18.1046 2 17V7C2 5.89543 2.89543 5 4 5H20C21.1046 5 22 5.89543 22 7V17C22 18.1046 21.1046 19 20 19H17.8465V20.2241C17.8465 20.4656 17.7303 20.6922 17.5342 20.8331C17.3381 20.9741 17.0862 21.012 16.8574 20.935L14.9426 20.2909L13.006 20.9357C12.7773 21.0119 12.5259 20.9734 12.3304 20.8325C12.1349 20.6915 12.019 20.4652 12.019 20.2241V19ZM13.519 15.7169V19.1839L14.7069 18.7884C14.8614 18.7369 15.0285 18.7372 15.1829 18.7891L16.3465 19.1805V15.7677C15.9258 15.9181 15.4724 16 15 16C14.4768 16 13.9771 15.8996 13.519 15.7169ZM17.5 12C17.5 13.3807 16.3807 14.5 15 14.5C13.6193 14.5 12.5 13.3807 12.5 12C12.5 10.6193 13.6193 9.5 15 9.5C16.3807 9.5 17.5 10.6193 17.5 12ZM6 9.75H10V11.25H6V9.75ZM6 12.75H9V14.25H6V12.75Z',
    })
  );
};
Achievement.displayName = 'Achievement';
exports['default'] = Achievement;
