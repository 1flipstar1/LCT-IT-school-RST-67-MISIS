'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Education = function Education(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M2.58753 9.75619L12.0002 5.54782L21.413 9.75619L12.0002 13.9646L2.58753 9.75619ZM12.4084 4.08721L23.5566 9.0715C24.1484 9.33611 24.1484 10.1763 23.5566 10.4409L18.9957 12.48V15.8728C18.9957 16.6188 18.6635 17.3261 18.0893 17.8023C14.5593 20.7304 9.44477 20.7304 5.91475 17.8023C5.34056 17.3261 5.00832 16.6188 5.00832 15.8728V12.4816L3.23239 11.6876V15.4914H1.73239V11.017L0.443883 10.4409C-0.14796 10.1763 -0.147961 9.33611 0.443881 9.07151L11.5921 4.08721C11.8518 3.97109 12.1487 3.97109 12.4084 4.08721ZM6.50832 13.1522V15.8728C6.50832 16.1725 6.64177 16.4565 6.8724 16.6478C9.84708 19.1153 14.157 19.1153 17.1317 16.6478C17.3623 16.4565 17.4957 16.1725 17.4957 15.8728V13.1506L12.4084 15.4252C12.1487 15.5413 11.8518 15.5413 11.5921 15.4252L6.50832 13.1522Z',
    })
  );
};
Education.displayName = 'Education';
exports['default'] = Education;
