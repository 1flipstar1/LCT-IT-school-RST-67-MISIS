'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Globe = function Globe(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M18.5002 9.00019C18.5002 7.01106 17.71 5.10341 16.3035 3.69689L17.3642 2.63623C19.052 4.32406 20.0002 6.61324 20.0002 9.00018C20.0002 11.3871 19.052 13.6763 17.3642 15.3641C15.854 16.8743 13.8624 17.7923 11.7502 17.9689V19.4995H14.0002V20.9995H8.00018V19.4995H10.2502V17.9689C8.13793 17.7923 6.14637 16.8743 4.63623 15.3641L5.69689 14.3035C7.10341 15.71 9.01107 16.5002 11.0002 16.5002C12.9893 16.5002 14.897 15.71 16.3035 14.3035C17.71 12.897 18.5002 10.9893 18.5002 9.00019ZM11.0002 13.5C8.5149 13.5 6.50018 11.4853 6.50018 9.00004C6.50018 6.51476 8.5149 4.50005 11.0002 4.50005C13.4855 4.50005 15.5002 6.51476 15.5002 9.00004C15.5002 11.4853 13.4855 13.5 11.0002 13.5ZM5.00018 9.00004C5.00018 5.68634 7.68647 3.00005 11.0002 3.00005C14.3139 3.00005 17.0002 5.68634 17.0002 9.00004C17.0002 12.3137 14.3139 15 11.0002 15C7.68647 15 5.00018 12.3137 5.00018 9.00004Z',
    })
  );
};
Globe.displayName = 'Globe';
exports['default'] = Globe;
