'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Column = function Column(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M6.5 4.5H17.5C19.1569 4.5 20.5 5.84315 20.5 7.5C20.5 8.11627 20.3142 8.68915 19.9955 9.16564C19.9985 9.11081 20 9.05558 20 9C20 7.34315 18.6569 6 17 6C15.3431 6 14 7.34315 14 9C14 10.4865 15.0811 11.7205 16.5 11.9585V16.5H14.4941V13H12.9941V16.5H10.998V13H9.49805V16.5H7.5V11.9585C8.91886 11.7205 10 10.4865 10 9C10 7.34315 8.65685 6 7 6C5.34315 6 4 7.34315 4 9C4 9.05558 4.00151 9.11081 4.0045 9.16564C3.68582 8.68914 3.5 8.11627 3.5 7.5C3.5 5.84315 4.84315 4.5 6.5 4.5ZM22 7.5C22 9.81628 20.25 11.7238 18 11.9725V16.5V18H16.5H7.5H6V16.5V11.9725C3.75003 11.7238 2 9.81628 2 7.5C2 5.01472 4.01472 3 6.5 3H17.5C19.9853 3 22 5.01472 22 7.5ZM18.5 9C18.5 9.82843 17.8284 10.5 17 10.5C16.1716 10.5 15.5 9.82843 15.5 9C15.5 8.17157 16.1716 7.5 17 7.5C17.8284 7.5 18.5 8.17157 18.5 9ZM8.5 9C8.5 9.82843 7.82843 10.5 7 10.5C6.17157 10.5 5.5 9.82843 5.5 9C5.5 8.17157 6.17157 7.5 7 7.5C7.82843 7.5 8.5 8.17157 8.5 9ZM19.75 21C19.8881 21 20.0028 20.8869 19.9781 20.7511C19.8265 19.917 18.9133 19.5 18 19.5H6.00002C5.08674 19.5 4.17347 19.917 4.02192 20.7511C3.99723 20.8869 4.11193 21 4.25 21H19.75Z',
    })
  );
};
Column.displayName = 'Column';
exports['default'] = Column;
