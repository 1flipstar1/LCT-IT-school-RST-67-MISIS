'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Cross = function Cross(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M8 6.5V7.75C8 7.88807 7.88807 8 7.75 8H6.5H4.5H3.25C3.11193 8 3 8.11193 3 8.25V9.5V14.5V15.75C3 15.8881 3.11193 16 3.25 16H4.5H6.5H7.75C7.88807 16 8 16.1119 8 16.25V17.5V19.5V20.75C8 20.8881 8.11193 21 8.25 21H9.5H14.5H15.75C15.8881 21 16 20.8881 16 20.75V19.5V17.5V16.25C16 16.1119 16.1119 16 16.25 16H17.5H19.5H20.75C20.8881 16 21 15.8881 21 15.75V14.5V9.5V8.25C21 8.11193 20.8881 8 20.75 8H19.5H17.5H16.25C16.1119 8 16 7.88807 16 7.75V6.5V4.5V3.25C16 3.11193 15.8881 3 15.75 3H14.5H9.5H8.25C8.11193 3 8 3.11193 8 3.25V4.5V6.5ZM9.75 4.5C9.61193 4.5 9.5 4.61193 9.5 4.75V8V9.25C9.5 9.38807 9.38807 9.5 9.25 9.5H8H4.75C4.61193 9.5 4.5 9.61193 4.5 9.75V14.25C4.5 14.3881 4.61193 14.5 4.75 14.5H8H9.25C9.38807 14.5 9.5 14.6119 9.5 14.75V16V19.25C9.5 19.3881 9.61193 19.5 9.75 19.5H14.25C14.3881 19.5 14.5 19.3881 14.5 19.25V16V14.75C14.5 14.6119 14.6119 14.5 14.75 14.5H16H19.25C19.3881 14.5 19.5 14.3881 19.5 14.25V9.75C19.5 9.61193 19.3881 9.5 19.25 9.5H16H14.75C14.6119 9.5 14.5 9.38807 14.5 9.25V8V4.75C14.5 4.61193 14.3881 4.5 14.25 4.5H9.75Z',
    })
  );
};
Cross.displayName = 'Cross';
exports['default'] = Cross;
