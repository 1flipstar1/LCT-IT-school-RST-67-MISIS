'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Cup = function Cup(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M6 3H7.52069H16.4793H18L17.75 4.5L17.625 5.25H19.5H21V6.75V8.125C21 10.544 19.2822 12.5617 17 13.025V11.4801C18.4457 11.0498 19.5 9.71051 19.5 8.125V6.75H17.375L16.6576 11.0544C16.32 13.08 14.7236 14.6243 12.75 14.9405V17H13.6577C15.0343 17 16.2342 17.9369 16.5681 19.2724L16.625 19.5L17 21H15.4538H8.54616H7L7.375 19.5L7.4319 19.2724C7.76578 17.9369 8.96573 17 10.3423 17H11.25V14.9405C9.27644 14.6243 7.68 13.08 7.3424 11.0544L6.625 6.75H4.5V8.125C4.5 9.71051 5.55426 11.0498 7 11.4801V13.025C4.71776 12.5617 3 10.544 3 8.125V6.75V5.25H4.5H6.375L6.25 4.5L6 3ZM8.82199 10.8078L7.77069 4.5H16.2293L15.178 10.8078C14.9191 12.3614 13.575 13.5 12 13.5C10.425 13.5 9.08092 12.3614 8.82199 10.8078ZM8.92806 19.5C9.13784 18.9056 9.70185 18.5 10.3423 18.5H13.6577C14.2982 18.5 14.8622 18.9056 15.0719 19.5H8.92806Z',
    })
  );
};
Cup.displayName = 'Cup';
exports['default'] = Cup;
