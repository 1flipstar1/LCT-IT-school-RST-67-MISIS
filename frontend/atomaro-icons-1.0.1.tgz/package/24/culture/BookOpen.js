'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var BookOpen = function BookOpen(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M11.2498 18.9872C8.50571 17.7746 5.50716 17.2275 2.50021 17.3989L2.50002 5.64395L3.86863 5.5463C6.10377 5.38682 8.3493 5.63475 10.4958 6.27799L11.2498 6.50393V18.9872ZM12.7498 18.9876C15.494 17.7747 18.4928 17.2275 21.5 17.3989L21.4998 5.64395L20.1311 5.5463C17.896 5.38682 15.6505 5.63475 13.5039 6.27799L12.7498 6.504V18.9876ZM1 4.47997C0.999996 4.3488 1.10137 4.23993 1.23221 4.2306L3.76187 4.05011C6.17825 3.8777 8.60584 4.14572 10.9264 4.84112L11.9281 5.14131C11.9749 5.15533 12.0248 5.15533 12.0716 5.14131L13.0734 4.84112C15.3939 4.14572 17.8215 3.8777 20.2379 4.0501L22.7676 4.2306C22.8984 4.23993 22.9998 4.34879 22.9998 4.47996L23 18.7394C23 18.8844 22.8769 18.9991 22.7322 18.9887L21.6635 18.9125C18.3458 18.6758 15.0294 19.3909 12.1041 20.9737C12.0392 21.0088 11.961 21.0088 11.8962 20.9737C8.97081 19.3909 5.65444 18.6758 2.33673 18.9125L1.26803 18.9887C1.12332 18.9991 1.00024 18.8844 1.00024 18.7394L1 4.47997Z',
    })
  );
};
BookOpen.displayName = 'BookOpen';
exports['default'] = BookOpen;
