'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Backpack = function Backpack(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M6.08713 10.67L5.79549 14.6362C9.55909 17.112 14.4408 17.1121 18.2044 14.6363L17.9128 10.6701C17.74 8.31913 15.7822 6.5 13.4249 6.5H10.575C8.21776 6.5 6.25999 8.3191 6.08713 10.67ZM5.48272 18.89L5.67177 16.3189C9.59073 18.5512 14.4091 18.5512 18.3281 16.3189L18.5171 18.89C18.581 19.7594 17.8929 20.5 17.0211 20.5H6.97868C6.10692 20.5 5.41879 19.7594 5.48272 18.89ZM4.59117 10.56L3.98676 18.78C3.8589 20.5188 5.23516 22 6.97868 22H17.0211C18.7646 22 20.1409 20.5188 20.0131 18.78L19.4088 10.5601C19.2181 7.96662 17.3983 5.85855 14.9955 5.20801L14.9955 4.74977C14.9953 3.23108 13.7642 2 12.2455 2H11.7502C10.2315 2 9.00028 3.23108 9.00016 4.74978L9.00012 5.20918C6.59952 5.86105 4.78175 7.96812 4.59117 10.56ZM10.5001 5.00046L10.5002 4.7499C10.5002 4.05958 11.0598 3.5 11.7502 3.5H12.2455C12.9358 3.5 13.4954 4.05958 13.4955 4.7499L13.4955 5.00041C13.472 5.00014 13.4485 5 13.4249 5H10.575C10.55 5 10.5251 5.00015 10.5001 5.00046ZM10 13H14V11.5H10V13Z',
    })
  );
};
Backpack.displayName = 'Backpack';
exports['default'] = Backpack;
