'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var FirstAidKit = function FirstAidKit(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M7.99788 6.33184C8.20427 4.9903 9.35858 4 10.7159 4H13.2842C14.6415 4 15.7959 4.99031 16.0022 6.33184L16.105 7H19C20.1046 7 21 7.89543 21 9V17C21 18.6569 19.6569 20 18 20H6C4.34315 20 3 18.6569 3 17V9C3 7.89543 3.89543 7 5 7H7.89508L7.99788 6.33184ZM14.5197 6.55993L14.5874 7H9.41273L9.48043 6.55993C9.57425 5.95014 10.0989 5.5 10.7159 5.5H13.2842C13.9012 5.5 14.4259 5.95014 14.5197 6.55993ZM19 8.5H5C4.72386 8.5 4.5 8.72386 4.5 9V17C4.5 17.8284 5.17157 18.5 6 18.5H18C18.8284 18.5 19.5 17.8284 19.5 17V9C19.5 8.72386 19.2761 8.5 19 8.5ZM12.75 16.5V14.25H15V12.75H12.75V10.5H11.25V12.75H9V14.25H11.25V16.5H12.75Z',
    })
  );
};
FirstAidKit.displayName = 'FirstAidKit';
exports['default'] = FirstAidKit;
