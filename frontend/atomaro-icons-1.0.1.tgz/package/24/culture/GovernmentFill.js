'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var GovernmentFill = function GovernmentFill(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M12.0001 0L10.5001 1.4999L12 3L13.5 1.4999L12.0001 0ZM8.34 9H8.5V10V11H8.49998C7.67155 11 6.99998 10.3284 6.99998 9.5C6.99998 8.84207 7.42356 8.28308 8.0129 8.08085C7.83918 7.18532 7.28892 6.41667 5.99998 6L1 4V8.5C1 12.9283 3.53902 15.2532 6.21026 16.3762C6.72904 15.5278 7.55505 14.8878 8.53355 14.6108C8.5835 14.9421 8.68796 15.2578 8.83862 15.547C7.51663 16.1475 6.92442 17.4272 6.71728 18.5981C5.7759 18.2777 4.8875 18.4239 4.49945 19.4645L7.51009 20.4258C7.96791 19.3877 8.92296 18.6551 10.1018 18.2824L8.94751 22L12 23L14.9475 22L13.8709 18.281C15.0251 18.6533 15.9419 19.3864 16.4003 20.4258L19.411 19.4645C19.0229 18.4239 18.1345 18.2777 17.1931 18.5981C17.0517 17.4276 16.4774 16.1484 15.161 15.5476C15.312 15.2579 15.4167 14.9417 15.4666 14.6098C16.4468 14.8862 17.2742 15.5267 17.7936 16.3762C20.4649 15.2532 23.0039 12.9283 23.0039 8.5V4L18.0039 6C16.715 6.41667 16.1647 7.18532 15.991 8.08085C16.5803 8.28308 17.0039 8.84207 17.0039 9.5C17.0039 10.3284 16.3324 11 15.5039 11L15.5 11V10V9H15.6539C14.6035 9 14 7.5 14.4496 6.36703C16.4983 6.24676 16.5 4.49705 16.5 4.49411L13 3.99411V5C12.9972 5.04656 12.9949 5.0946 12.9925 5.14387V5.14388V5.1439C12.9631 5.74915 12.9247 6.53764 12 7C11.0641 6.53203 11.0304 5.72391 11.0053 5.12077L11.0053 5.12072L11.0053 5.12066C11.0036 5.07942 11.0019 5.03914 11 5V3.99411L7.5 4.49411C7.50761 4.5326 7.51364 4.58232 7.52072 4.64063C7.58106 5.13781 7.71718 6.25939 9.55084 6.36703C10 7.5 9.39087 9 8.34 9Z',
    })
  );
};
GovernmentFill.displayName = 'GovernmentFill';
exports['default'] = GovernmentFill;
