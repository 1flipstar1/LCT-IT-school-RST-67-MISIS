'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Contacts = function Contacts(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M5.5 20.5H17C17.8284 20.5 18.5 19.8284 18.5 19V5C18.5 4.17157 17.8284 3.5 17 3.5L5.5 3.5L5.5 20.5ZM17 22C18.6569 22 20 20.6569 20 19V5C20 3.34315 18.6569 2 17 2H5C4.44772 2 4 2.44772 4 3V6H2V7.5H4V11.25H2V12.75H4V16.5H2V18H4V21C4 21.5523 4.44772 22 5 22H17ZM7.98434 8.76517V9.43738C7.98434 13.07 10.9471 16.0096 14.5739 16.0096H15.2524C15.3147 16.0114 15.3766 16.0054 15.4369 15.992C15.7731 15.9179 16.0247 15.6181 16.0247 15.2596C16.0247 15.2492 16.0245 15.2387 16.024 15.2284V14.2062C16.024 13.896 15.833 13.6177 15.5434 13.5063L14.2992 13.0275C14.0478 12.9308 13.7638 12.9763 13.5552 13.1468L12.4529 14.0478C11.3845 13.5576 10.5141 12.7091 9.99817 11.6573L10.9321 10.522C11.1042 10.3129 11.1501 10.0272 11.0523 9.77461L10.5461 8.46818C10.4343 8.17943 10.1565 7.98912 9.84679 7.98912H8.75936C8.75106 7.98885 8.74271 7.98871 8.73434 7.98871C8.53916 7.98871 8.36139 8.06327 8.22796 8.18546C8.20363 8.20769 8.18065 8.23164 8.1592 8.25721C8.03942 8.40006 7.97794 8.5813 7.98434 8.76517Z',
    })
  );
};
Contacts.displayName = 'Contacts';
exports['default'] = Contacts;
