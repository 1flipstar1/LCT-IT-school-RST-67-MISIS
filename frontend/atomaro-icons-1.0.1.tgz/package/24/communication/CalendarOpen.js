'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var CalendarOpen = function CalendarOpen(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M15.5 6.5V4.5L8.5 4.5V6.5H7V4.5H6C5.17157 4.5 4.5 5.17157 4.5 6V8.01562L19.5 8.01562V6C19.5 5.17157 18.8284 4.5 18 4.5H17V6.5H15.5ZM4.5 18L4.5 9.51562L19.5 9.51562V15C19.5 15.0003 19.5 15.0006 19.5 15.0009H14.7539H14.2539C14.1158 15.0009 14.0039 15.1128 14.0039 15.2509L14.0039 15.7509L14.004 17.2532C14.004 18.4548 13.0621 19.4364 11.8763 19.5H6C5.17157 19.5 4.5 18.8284 4.5 18ZM11.912 21H14H15C17.7999 21 20.1518 19.0822 20.8139 16.4886C20.9354 16.0126 21 15.5138 21 15V6C21 4.34315 19.6569 3 18 3H17V1H15.5V3L8.5 3V1H7V3H6C4.34315 3 3 4.34315 3 6V18C3 19.6569 4.34315 21 6 21H11.2096C11.2228 21.0022 11.2363 21.0033 11.2501 21.0033H11.754C11.8069 21.0033 11.8596 21.0022 11.912 21ZM14.7567 19.5C15.226 18.8738 15.504 18.0959 15.504 17.2531L15.5039 16.7509C15.5039 16.6128 15.6159 16.5009 15.7539 16.5009H19.2436C18.6256 18.2482 16.959 19.5 15 19.5H14.7567Z',
    })
  );
};
CalendarOpen.displayName = 'CalendarOpen';
exports['default'] = CalendarOpen;
