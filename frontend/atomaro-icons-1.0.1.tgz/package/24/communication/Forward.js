'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Forward = function Forward(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M11.9894 3.05825C12.2552 2.93574 12.568 2.97906 12.7905 3.16919L21.2879 10.4297C21.4548 10.5723 21.5508 10.7808 21.5507 11.0002C21.5506 11.2197 21.4545 11.4281 21.2875 11.5705L12.7901 18.8209C12.5675 19.0108 12.2548 19.0539 11.9891 18.9314C11.7234 18.8088 11.5533 18.5429 11.5533 18.2503V14.8027C8.76372 15.1943 6.14817 17.74 5.7211 21.5828L4.33969 21.8974C2.96092 19.6913 2.52837 16.199 3.62196 13.1819C4.68605 10.2461 7.1888 7.77785 11.5534 7.30857L11.5533 3.73941C11.5533 3.44672 11.7236 3.18077 11.9894 3.05825ZM13.0533 5.36675L13.0534 7.99993C13.0534 8.39799 12.7425 8.72671 12.345 8.74879C8.14912 8.9819 5.95062 11.1591 5.03219 13.693C4.39122 15.4614 4.3705 17.4137 4.77314 19.0466C6.02652 15.5376 9.04505 13.2499 12.3033 13.2499C12.7175 13.2499 13.0533 13.5857 13.0533 13.9999V16.6245L19.6457 10.9995L13.0533 5.36675Z',
    })
  );
};
Forward.displayName = 'Forward';
exports['default'] = Forward;
