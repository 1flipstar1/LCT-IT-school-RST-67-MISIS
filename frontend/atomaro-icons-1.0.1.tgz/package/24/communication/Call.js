'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Call = function Call(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M3.7876 3.00093C3.77514 3.00031 3.76261 3 3.75 3C3.33579 3 3 3.33579 3 3.75V5.51761C3 14.0672 9.93324 20.9977 18.4825 20.9977H20.2504C20.6646 20.9977 21.0004 20.6619 21.0004 20.2477C21.0004 20.2347 21.0001 20.2219 20.9994 20.2091V16.6397C20.9994 16.3297 20.8087 16.0516 20.5194 15.94L16.27 14.3003C16.0181 14.2031 15.7334 14.2488 15.5246 14.42L11.5621 17.6678C9.38457 16.4252 7.5732 14.6142 6.33028 12.437L9.57985 8.47568C9.75123 8.26675 9.79698 7.98179 9.6996 7.72973L8.05808 3.48065C7.9464 3.19155 7.6684 3.00093 7.35848 3.00093L3.7876 3.00093ZM5.60014 10.962L8.14281 7.86239L6.8442 4.50093L4.5 4.50093V5.51761C4.5 7.44887 4.89176 9.28868 5.60014 10.962ZM18.4825 19.4977C16.5512 19.4977 14.7112 19.1061 13.0376 18.3979L16.1376 15.857L19.4994 17.1542V19.4977H18.4825Z',
    })
  );
};
Call.displayName = 'Call';
exports['default'] = Call;
