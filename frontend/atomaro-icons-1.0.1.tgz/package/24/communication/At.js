'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var At = function At(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M3.5 12.0002C3.50104 7.30706 7.30644 3.50415 12 3.50415C16.7179 3.50415 20.5 6.9842 20.5 11.9011C20.5 14.7584 19.0731 15.5288 18.2642 15.5288C17.7398 15.5288 17.3277 15.3697 17.0441 15.0754C16.7595 14.7802 16.5105 14.2513 16.5105 13.3266V7.49463H15.0105V8.43956C14.1077 7.54938 12.868 6.99998 11.5 6.99998C8.73858 6.99998 6.5 9.23856 6.5 12C6.5 14.7614 8.73858 17 11.5 17C13.0504 17 14.436 16.2943 15.3531 15.1867C15.5064 15.5423 15.7105 15.8533 15.964 16.1163C16.5934 16.7694 17.4332 17.0288 18.2642 17.0288C20.1663 17.0288 22 15.2946 22 11.9011C22 6.10744 17.4971 2.00415 12 2.00415C6.47858 2.00415 2.00123 6.47799 2 11.9998C1.99878 17.5097 6.21682 22 12 22H17V20.5H12C7.07119 20.5 3.49896 16.7076 3.5 12.0002ZM15 12C15 13.933 13.433 15.5 11.5 15.5C9.567 15.5 8 13.933 8 12C8 10.067 9.567 8.49998 11.5 8.49998C13.433 8.49998 15 10.067 15 12Z',
    })
  );
};
At.displayName = 'At';
exports['default'] = At;
