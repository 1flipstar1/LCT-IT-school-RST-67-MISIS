'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var CalendarAdd = function CalendarAdd(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M15.5 6.5V4.5L8.5 4.5V6.5H7V4.5H6C5.17157 4.5 4.5 5.17157 4.5 6V8.01562L19.5 8.01562V6C19.5 5.17157 18.8284 4.5 18 4.5H17V6.5H15.5ZM4.5 18L4.5 9.51562L19.5 9.51562V11H21V6C21 4.34315 19.6569 3 18 3H17V1H15.5V3H8.5V1H7V3H6C4.34315 3 3 4.34315 3 6V18C3 19.6569 4.34315 21 6 21H12V19.5H6C5.17157 19.5 4.5 18.8284 4.5 18ZM17.25 21V17.75H14V16.25H17.25V13H18.75V16.25H22V17.75H18.75V21H17.25Z',
    })
  );
};
CalendarAdd.displayName = 'CalendarAdd';
exports['default'] = CalendarAdd;
