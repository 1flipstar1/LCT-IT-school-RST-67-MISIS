'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Connect = function Connect(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M13.5 6C13.5 6.82843 12.8284 7.5 12 7.5C11.1716 7.5 10.5 6.82843 10.5 6C10.5 5.17157 11.1716 4.5 12 4.5C12.8284 4.5 13.5 5.17157 13.5 6ZM15 6C15 7.65685 13.6569 9 12 9C10.3431 9 9 7.65685 9 6C9 4.34315 10.3431 3 12 3C13.6569 3 15 4.34315 15 6ZM6.5 17C6.5 17.8284 5.82843 18.5 5 18.5C4.17157 18.5 3.5 17.8284 3.5 17C3.5 16.1716 4.17157 15.5 5 15.5C5.82843 15.5 6.5 16.1716 6.5 17ZM8 17C8 18.6569 6.65685 20 5 20C3.34315 20 2 18.6569 2 17C2 15.3431 3.34315 14 5 14C6.65685 14 8 15.3431 8 17ZM19 18.5C19.8284 18.5 20.5 17.8284 20.5 17C20.5 16.1716 19.8284 15.5 19 15.5C18.1716 15.5 17.5 16.1716 17.5 17C17.5 17.8284 18.1716 18.5 19 18.5ZM19 20C20.6569 20 22 18.6569 22 17C22 15.3431 20.6569 14 19 14C17.3431 14 16 15.3431 16 17C16 18.6569 17.3431 20 19 20ZM17.9887 13.1289C17.8675 11.1418 16.779 9.41592 15.1881 8.41615C15.4904 8.01788 15.7198 7.56122 15.8564 7.06608C17.913 8.30142 19.3285 10.4949 19.4854 13.0292C19.3263 13.0099 19.1643 13 19 13C18.6506 13 18.3117 13.0448 17.9887 13.1289ZM15.2965 18.5141C15.489 18.9846 15.7687 19.4103 16.1153 19.7711C14.9339 20.548 13.5197 21 12 21C10.4803 21 9.06611 20.548 7.88463 19.7711C8.23129 19.4103 8.51092 18.9846 8.70349 18.5141C9.64952 19.1373 10.7824 19.5 12 19.5C13.2176 19.5 14.3504 19.1373 15.2965 18.5141ZM4.99999 13C4.83566 13 4.67366 13.0099 4.51453 13.0292C4.67151 10.4949 6.08701 8.30142 8.14362 7.06607C8.2802 7.56122 8.50958 8.01788 8.81189 8.41615C7.22098 9.41592 6.13252 11.1418 6.01127 13.1289C5.68826 13.0448 5.34935 13 4.99999 13Z',
    })
  );
};
Connect.displayName = 'Connect';
exports['default'] = Connect;
