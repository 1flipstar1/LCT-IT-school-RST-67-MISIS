'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var ForwardFill = function ForwardFill(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M12.8008 3.16919C12.5782 2.97906 12.2654 2.93574 11.9996 3.05825C11.7338 3.18077 11.5635 3.44672 11.5636 3.73941L11.5636 7.30857C7.19906 7.77785 4.69631 10.2461 3.63222 13.1819C2.53863 16.199 2.97117 19.6913 4.34994 21.8974L5.73136 21.5828C6.15843 17.74 8.77397 15.1943 11.5635 14.8027V18.2503C11.5635 18.5429 11.7337 18.8088 11.9993 18.9314C12.265 19.0539 12.5777 19.0108 12.8003 18.8209L21.2978 11.5705C21.4647 11.4281 21.5609 11.2197 21.561 11.0002C21.561 10.7808 21.465 10.5723 21.2982 10.4297L12.8008 3.16919Z',
    })
  );
};
ForwardFill.displayName = 'ForwardFill';
exports['default'] = ForwardFill;
