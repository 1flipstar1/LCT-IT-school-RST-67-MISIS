'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Ghost = function Ghost(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M17.9641 19.6932L19.5 20.262V11C19.5 6.85786 16.1421 3.5 12 3.5C7.85786 3.5 4.5 6.85787 4.5 11V20.262L6.03594 19.6932C6.95398 19.3533 7.95784 19.3219 8.89529 19.604L11.5678 20.4082C11.8497 20.493 12.1503 20.493 12.4322 20.4082L15.1047 19.604C16.0422 19.3219 17.046 19.3533 17.9641 19.6932ZM3 21.0487C3 21.7121 3.66114 22.1722 4.2832 21.9419L6.55685 21.0999C7.16888 20.8732 7.83812 20.8524 8.46309 21.0404L11.1356 21.8446C11.6994 22.0142 12.3006 22.0142 12.8644 21.8446L15.5369 21.0404C16.1619 20.8524 16.8311 20.8732 17.4431 21.0999L19.7168 21.9419C20.3389 22.1722 21 21.7121 21 21.0487V11C21 6.02943 16.9706 2 12 2C7.02944 2 3 6.02944 3 11V21.0487ZM15.8263 8.21935L13.5774 8.98137C13.5242 9.13456 13.4954 9.29902 13.4954 9.47019C13.4954 10.2968 14.169 10.9668 14.9999 10.9668C15.8308 10.9668 16.5044 10.2968 16.5044 9.47019C16.5044 8.94726 16.2348 8.48696 15.8263 8.21935ZM10.4194 8.97234L8.18078 8.21378C7.76819 8.48067 7.49536 8.94335 7.49536 9.46941C7.49536 10.296 8.16895 10.9661 8.99988 10.9661C9.8308 10.9661 10.5044 10.296 10.5044 9.46941C10.5044 9.29516 10.4745 9.12786 10.4194 8.97234ZM9.40981 15.4431C10.9286 14.4525 13.0807 14.4469 14.5956 15.4418L15.419 14.188C13.4006 12.8624 10.6035 12.8738 8.59038 14.1867L9.40981 15.4431Z',
    })
  );
};
Ghost.displayName = 'Ghost';
exports['default'] = Ghost;
