'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Aim = function Aim(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M11.25 2V3.03081C6.87765 3.39152 3.39152 6.87765 3.03081 11.25H2V12.75H3.03081C3.39152 17.1223 6.87765 20.6085 11.25 20.9692V22H12.75V20.9692C17.1223 20.6085 20.6085 17.1223 20.9692 12.75H22V11.25H20.9692C20.6085 6.87765 17.1223 3.39152 12.75 3.03081V2H11.25ZM4.53703 11.25C4.88883 7.70669 7.70669 4.88883 11.25 4.53703V6H12.75V4.53703C16.2933 4.88883 19.1112 7.70669 19.463 11.25H18V12.75H19.463C19.1112 16.2933 16.2933 19.1112 12.75 19.463V18H11.25V19.463C7.70669 19.1112 4.88883 16.2933 4.53703 12.75H6V11.25H4.53703ZM12.0045 13.5031C12.8354 13.5031 13.509 12.8302 13.509 12C13.509 11.1698 12.8354 10.4969 12.0045 10.4969C11.1736 10.4969 10.5 11.1698 10.5 12C10.5 12.8302 11.1736 13.5031 12.0045 13.5031Z',
    })
  );
};
Aim.displayName = 'Aim';
exports['default'] = Aim;
