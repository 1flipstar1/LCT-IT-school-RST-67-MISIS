'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var CallEnd = function CallEnd(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M22.7434 14.1125C22.7525 14.1043 22.7616 14.0959 22.7704 14.0871C23.0655 13.7964 23.0655 13.3251 22.7704 13.0344L21.6738 11.9541C16.3313 6.69113 7.66818 6.69283 2.32597 11.9556L1.22912 13.0361C0.934042 13.3268 0.934042 13.7981 1.22912 14.0888C1.23741 14.0969 1.24583 14.1049 1.2544 14.1126L1.25385 14.1132L3.72629 16.3194C3.96006 16.528 4.30076 16.5716 4.58087 16.4287L8.15922 14.6042C8.38523 14.4889 8.53717 14.2693 8.56345 14.02L9.00146 9.86436C10.9686 9.3736 13.036 9.37374 15.003 9.86487L15.4394 14.035C15.4656 14.285 15.6181 14.5051 15.8448 14.6203L19.4048 16.4283C19.6841 16.5701 20.0232 16.5269 20.2567 16.3198L22.744 14.1133L22.7434 14.1125ZM16.5753 10.372L16.9007 13.4817L19.6333 14.8694L21.1396 13.5332L20.6052 13.0068C19.416 11.8353 18.0419 10.9571 16.5753 10.372ZM3.39455 13.0083C4.58488 11.8356 5.96055 10.9566 7.4287 10.3713L7.10245 13.4667L4.35205 14.8691L2.85847 13.5363L3.39455 13.0083Z',
    })
  );
};
CallEnd.displayName = 'CallEnd';
exports['default'] = CallEnd;
