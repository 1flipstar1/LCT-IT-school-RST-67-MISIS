'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var History = function History(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M14.9213 4.01777C12.965 3.30183 10.814 3.32919 8.87656 4.09468C7.19547 4.75889 5.93275 5.7156 4.60606 7.53235L6.28589 7.53235V9.03235L2.75351 9.03234C2.3393 9.03234 2.00352 8.69656 2.00352 8.28234L2.00352 4.75H3.50352V6.50056C4.93308 4.58537 6.38416 3.4666 8.32537 2.69962C10.6047 1.79905 13.1353 1.76685 15.4368 2.60914C17.7383 3.45142 19.6503 5.10953 20.8099 7.26863C21.9694 9.42773 22.2957 11.9375 21.7268 14.3213C21.158 16.7051 19.7335 18.797 17.7239 20.1998C15.7143 21.6026 13.2595 22.2186 10.8257 21.9308C8.39191 21.643 6.14852 20.4715 4.52153 18.6387C2.89454 16.8059 1.99723 14.4395 2.00001 11.9887L3.50001 11.9904C3.49765 14.0735 4.26036 16.085 5.6433 17.6429C7.02624 19.2008 8.93313 20.1966 11.0019 20.4412C13.0706 20.6858 15.1572 20.1622 16.8653 18.9699C18.5734 17.7775 19.7843 15.9994 20.2678 13.9731C20.7514 11.9469 20.474 9.81357 19.4884 7.97834C18.5028 6.1431 16.8776 4.73371 14.9213 4.01777ZM11.25 11.6644V7.03058H12.75V11.6644C12.75 11.9985 12.8838 12.3188 13.1216 12.5537L15.0271 14.4358L13.9729 15.503L12.0675 13.6208C11.5444 13.1042 11.25 12.3996 11.25 11.6644Z',
    })
  );
};
History.displayName = 'History';
exports['default'] = History;
