'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var HistoryAction = function HistoryAction(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M12 2H11.25V3.5H12C12.9885 3.5 13.9776 3.67239 14.9213 4.01777C16.8775 4.73371 18.5028 6.1431 19.4884 7.97834C20.474 9.81357 20.7514 11.9469 20.2678 13.9731C19.7842 15.9994 18.5734 17.7775 16.8653 18.9699C15.1571 20.1622 13.0706 20.6858 11.0019 20.4412C8.93311 20.1966 7.02623 19.2008 5.64328 17.6429L4.52151 18.6387C6.14851 20.4715 8.3919 21.643 10.8257 21.9308C13.2595 22.2186 15.7143 21.6026 17.7239 20.1998C19.7335 18.797 21.1579 16.7051 21.7268 14.3213C22.2957 11.9375 21.9694 9.42773 20.8099 7.26863C19.6503 5.10953 17.7383 3.45142 15.4368 2.60914C14.3265 2.20282 13.1629 2 12 2ZM12.75 7V11.6338C12.75 12.369 12.4556 13.0736 11.9325 13.5902L10.0271 15.4724L8.97294 14.4053L10.8784 12.5231C11.1162 12.2882 11.25 11.968 11.25 11.6338V7H12.75ZM9 3.50092C9 4.0527 8.55228 4.5 8 4.5C7.44772 4.5 7 4.0527 7 3.50092C7 2.94914 7.44772 2.50184 8 2.50184C8.55228 2.50184 9 2.94914 9 3.50092ZM4.5 7.49816C5.05228 7.49816 5.5 7.05086 5.5 6.49908C5.5 5.9473 5.05228 5.5 4.5 5.5C3.94772 5.5 3.5 5.9473 3.5 6.49908C3.5 7.05086 3.94772 7.49816 4.5 7.49816ZM4 10.9991C4 11.5509 3.55228 11.9982 3 11.9982C2.44772 11.9982 2 11.5509 2 10.9991C2 10.4473 2.44772 10 3 10C3.55228 10 4 10.4473 4 10.9991ZM3.5 16.4982C4.05228 16.4982 4.5 16.0509 4.5 15.4991C4.5 14.9473 4.05228 14.5 3.5 14.5C2.94772 14.5 2.5 14.9473 2.5 15.4991C2.5 16.0509 2.94772 16.4982 3.5 16.4982Z',
    })
  );
};
HistoryAction.displayName = 'HistoryAction';
exports['default'] = HistoryAction;
