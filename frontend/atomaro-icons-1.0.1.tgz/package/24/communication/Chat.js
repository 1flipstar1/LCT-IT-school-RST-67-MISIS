'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Chat = function Chat(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M7 12.4893H6.64618L6.32966 12.6474L3.5 14.061L3.5 5C3.5 4.17157 4.17157 3.5 5 3.5L15 3.5C15.8284 3.5 16.5 4.17157 16.5 5V10.9893C16.5 11.8177 15.8284 12.4893 15 12.4893L7 12.4893ZM7.5 13.9893L7.5 16.9857C7.5 17.8141 8.17157 18.4857 9 18.4857L17 18.4857H17.3773L17.7097 18.6642L20.5 20.1627V10.9955C20.5 10.1671 19.8284 9.49554 19 9.49554H18V10.9893C18 12.6461 16.6569 13.9893 15 13.9893L7.5 13.9893ZM18 7.99554V5C18 3.34315 16.6569 2 15 2H5C3.34315 2 2 3.34314 2 5L2 14.8697C2 15.6129 2.78202 16.0964 3.4469 15.7642L6 14.4888V16.9857C6 18.6426 7.34315 19.9857 9 19.9857L17 19.9857L20.5269 21.8797C21.1931 22.2375 22 21.7549 22 20.9987V10.9955C22 9.33869 20.6569 7.99554 19 7.99554H18Z',
    })
  );
};
Chat.displayName = 'Chat';
exports['default'] = Chat;
