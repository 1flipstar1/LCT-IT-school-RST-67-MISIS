'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var CallNocoming = function CallNocoming(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M3.75 3C3.76261 3 3.77514 3.00031 3.7876 3.00093L7.35848 3.00093C7.6684 3.00093 7.9464 3.19155 8.05808 3.48065L9.6996 7.72973C9.79698 7.98179 9.75123 8.26675 9.57985 8.47568L6.33028 12.437C7.5732 14.6142 9.38457 16.4252 11.5621 17.6678L15.5246 14.42C15.7334 14.2488 16.0181 14.2031 16.27 14.3003L20.5194 15.94C20.8087 16.0516 20.9994 16.3297 20.9994 16.6397V20.2091C21.0001 20.2219 21.0004 20.2347 21.0004 20.2477C21.0004 20.6619 20.6646 20.9977 20.2504 20.9977H18.4825C9.93324 20.9977 3 14.0672 3 5.51761V3.75C3 3.33579 3.33579 3 3.75 3ZM8.14281 7.86239L5.60014 10.962C4.89176 9.28868 4.5 7.44887 4.5 5.51761V4.50093L6.8442 4.50093L8.14281 7.86239ZM13.0376 18.3979C14.7112 19.1061 16.5512 19.4977 18.4825 19.4977H19.4994V17.1542L16.1376 15.857L13.0376 18.3979ZM15.0623 9.99829L17.5005 7.56011L19.9388 9.99829L20.9994 8.93762L18.5612 6.49946L20.9994 4.06133L19.9387 3.00066L17.5005 5.43881L15.0623 3.00066L14.0017 4.06133L16.4399 6.49946L14.0017 8.93762L15.0623 9.99829Z',
    })
  );
};
CallNocoming.displayName = 'CallNocoming';
exports['default'] = CallNocoming;
