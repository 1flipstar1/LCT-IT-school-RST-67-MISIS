'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Comments = function Comments(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M16.5662 16.6668C16.3537 16.5572 16.118 16.5 15.8788 16.5H8C6.067 16.5 4.5 14.933 4.5 13V7C4.5 6.17157 5.17157 5.5 6 5.5H18C18.8284 5.5 19.5 6.17157 19.5 7V16V18V18.1795L16.5662 16.6668ZM6 4C4.34315 4 3 5.34315 3 7V13C3 15.7614 5.23858 18 8 18H15.8788L19.5417 19.8887C20.2073 20.2319 21 19.7487 21 18.9999V18V16V7C21 5.34315 19.6569 4 18 4H6ZM16 12.25H8V13.75H16V12.25ZM16 8.25H8V9.75H16V8.25Z',
    })
  );
};
Comments.displayName = 'Comments';
exports['default'] = Comments;
