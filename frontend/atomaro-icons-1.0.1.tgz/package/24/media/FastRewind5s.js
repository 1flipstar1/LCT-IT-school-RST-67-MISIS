'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var FastRewind5s = function FastRewind5s(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M11.7805 2.03014L9.56067 4.25H12.008H12.0312V4.25005C16.9874 4.2669 21 8.28986 21 13.25C21 18.2206 16.9706 22.25 12 22.25C7.02944 22.25 3 18.2206 3 13.25C3 10.8554 3.93518 8.67924 5.46024 7.0668L6.5214 8.12796C5.26755 9.46852 4.5 11.2696 4.5 13.25C4.5 17.3921 7.85786 20.75 12 20.75C16.1421 20.75 19.5 17.3921 19.5 13.25C19.5 9.11228 16.1493 5.75716 12.0133 5.75001V5.75H9.5655L11.7805 7.965L10.7198 9.02566L7.2221 5.52791C6.9292 5.23502 6.9292 4.76015 7.2221 4.46725L10.7199 0.969482L11.7805 2.03014ZM9.98897 10.1018H14.0875V11.3998H10.9993L10.8888 12.4289C11.2627 12.1991 11.752 12.0998 12.1605 12.0998C12.9004 12.0998 13.4839 12.3199 13.8826 12.7174C14.2812 13.1148 14.4835 13.678 14.4835 14.3418C14.4835 15.6866 13.4731 16.7278 11.9715 16.7278C11.1741 16.7278 10.5938 16.5016 10.2121 16.1427C9.83037 15.7837 9.65747 15.3014 9.65747 14.8098C9.65747 14.7796 9.65989 14.723 9.6633 14.6696C9.66656 14.6184 9.67134 14.5595 9.67741 14.5292L9.69438 14.4444L11.0805 14.5179L11.0621 14.6282C11.0538 14.6779 11.0455 14.7623 11.0455 14.8188C11.0455 15.0303 11.1342 15.2015 11.2911 15.3223C11.4504 15.445 11.6858 15.5198 11.9805 15.5198C12.3147 15.5198 12.5911 15.4144 12.7837 15.2208C12.9762 15.0273 13.0955 14.7352 13.0955 14.3418C13.0955 13.9857 12.9815 13.7068 12.7908 13.5172C12.6 13.3274 12.3233 13.2178 11.9805 13.2178C11.5694 13.2178 11.1364 13.4116 10.83 13.7436L10.7892 13.7878L9.72328 13.5083L9.98897 10.1018Z',
    })
  );
};
FastRewind5s.displayName = 'FastRewind5s';
exports['default'] = FastRewind5s;
