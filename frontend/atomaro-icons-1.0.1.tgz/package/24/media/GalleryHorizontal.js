'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var GalleryHorizontal = function GalleryHorizontal(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M16 4.5H8C7.17157 4.5 6.5 5.17157 6.5 6V18C6.5 18.8284 7.17157 19.5 8 19.5H16C16.8284 19.5 17.5 18.8284 17.5 18V6C17.5 5.17157 16.8284 4.5 16 4.5ZM8 3C6.34315 3 5 4.34315 5 6V18C5 19.6569 6.34315 21 8 21H16C17.6569 21 19 19.6569 19 18V6C19 4.34315 17.6569 3 16 3H8ZM21.7511 17.9781C21.8869 18.0028 22 17.8881 22 17.75V6.25C22 6.11193 21.8869 5.99723 21.7511 6.02192C20.917 6.17347 20.5 7.08674 20.5 8.00002V16C20.5 16.9133 20.917 17.8265 21.7511 17.9781ZM2 17.75C2 17.8881 2.11307 18.0028 2.24892 17.9781C3.08297 17.8265 3.5 16.9133 3.5 16V8.00002C3.5 7.08674 3.08297 6.17347 2.24892 6.02192C2.11307 5.99723 2 6.11193 2 6.25V17.75Z',
    })
  );
};
GalleryHorizontal.displayName = 'GalleryHorizontal';
exports['default'] = GalleryHorizontal;
