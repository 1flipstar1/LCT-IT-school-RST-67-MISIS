'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Headphones = function Headphones(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M12 3.5C7.30558 3.5 3.5 7.30558 3.5 12V12.9959L7.81077 14.0055C8.09951 14.0731 8.3213 14.3045 8.3766 14.5958L9.40038 19.9893C9.45913 20.2988 9.30254 20.6091 9.01869 20.7458L6.13131 22.1356C5.7665 22.3112 5.32825 22.1987 5.09313 21.8691L4.63122 21.2215C3.15221 19.1481 2.26438 16.7203 2.05055 14.1971L2.05048 14.1962C2.04624 14.1461 2.04227 14.096 2.03856 14.0459C2.02513 13.8644 2.01519 13.6824 2.00877 13.5H2V13.0017V12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12V13.0017V13.5H21.9912C21.9848 13.6824 21.9749 13.8644 21.9614 14.0459C21.9577 14.096 21.9538 14.1461 21.9495 14.1962L21.9494 14.1971C21.7356 16.7203 20.8478 19.1481 19.3688 21.2215L18.9069 21.8691C18.6718 22.1987 18.2335 22.3112 17.8687 22.1356L14.9813 20.7458C14.6975 20.6091 14.5409 20.2988 14.5996 19.9893L15.6234 14.5958C15.6787 14.3045 15.9005 14.0731 16.1892 14.0055L20.5 12.9959V12C20.5 7.30558 16.6944 3.5 12 3.5ZM6.99387 15.3547L3.59618 14.559C3.85409 16.639 4.62586 18.631 5.85238 20.3505L5.98762 20.5401L7.8115 19.6621L6.99387 15.3547ZM17.0061 15.3547L20.4038 14.559C20.1459 16.639 19.3741 18.631 18.1476 20.3505L18.0124 20.5401L16.1885 19.6621L17.0061 15.3547Z',
    })
  );
};
Headphones.displayName = 'Headphones';
exports['default'] = Headphones;
