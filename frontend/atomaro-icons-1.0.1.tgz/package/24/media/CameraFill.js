'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var CameraFill = function CameraFill(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M5 6C3.34315 6 2 7.34315 2 9V13C2 15.7614 4.23858 18 7 18H13C14.6569 18 16 16.6569 16 15V9C16 7.34315 14.6569 6 13 6H5ZM18.5347 9.10285C17.8775 9.67267 17.5 10.4997 17.5 11.3695V12.6289C17.5 13.4997 17.8783 14.3274 18.5367 14.8973L20.7592 16.8209C21.2449 17.2414 22 16.8963 22 16.2538V7.74126C22 7.0985 21.2443 6.75353 20.7587 7.1746L18.5347 9.10285Z',
    })
  );
};
CameraFill.displayName = 'CameraFill';
exports['default'] = CameraFill;
