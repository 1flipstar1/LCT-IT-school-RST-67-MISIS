'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var FocusRecords = function FocusRecords(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M16 19.5H19C19.2761 19.5 19.5 19.2761 19.5 19V16H21V19C21 20.1046 20.1046 21 19 21H16V19.5ZM4.5 16V19C4.5 19.2761 4.72386 19.5 5 19.5H8V21H5C3.89543 21 3 20.1046 3 19V16H4.5ZM8 4.5H5C4.72386 4.5 4.5 4.72386 4.5 5V8H3V5C3 3.89543 3.89543 3 5 3H8V4.5ZM9.84717 8.896H9.09717V9.646V15.0003H10.5972V13.4972H12.0056L12.8789 14.9995H14.6139L13.6068 13.267C14.3741 12.894 14.903 12.1071 14.903 11.1966C14.903 9.92601 13.873 8.896 12.6024 8.896H9.84717ZM12.6024 11.9972H10.5972V10.396H12.6024C13.0446 10.396 13.403 10.7544 13.403 11.1966C13.403 11.6387 13.0446 11.9972 12.6024 11.9972ZM18.5 8C19.8807 8 21 6.88071 21 5.5C21 4.11929 19.8807 3 18.5 3C17.1193 3 16 4.11929 16 5.5C16 6.88071 17.1193 8 18.5 8Z',
    })
  );
};
FocusRecords.displayName = 'FocusRecords';
exports['default'] = FocusRecords;
