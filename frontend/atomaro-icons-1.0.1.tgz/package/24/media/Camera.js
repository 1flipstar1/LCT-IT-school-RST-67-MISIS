'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Camera = function Camera(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M5 7.5H13C13.8284 7.5 14.5 8.17157 14.5 9V15C14.5 15.8284 13.8284 16.5 13 16.5H7C5.067 16.5 3.5 14.933 3.5 13V9C3.5 8.17157 4.17157 7.5 5 7.5ZM2 9C2 7.34315 3.34315 6 5 6H13C14.6569 6 16 7.34315 16 9V15C16 16.6569 14.6569 18 13 18H7C4.23858 18 2 15.7614 2 13V9ZM19.5201 10.2382L20.5 9.39264V14.611L19.5189 13.7627C19.1894 13.4778 19 13.0637 19 12.628V11.3738C19 10.9377 19.1898 10.5231 19.5201 10.2382ZM17.5 11.3738C17.5 10.5015 17.8797 9.67238 18.5402 9.1025L20.76 7.18705C21.246 6.7677 22 7.11297 22 7.75489V16.251C22 16.8932 21.2453 17.2384 20.7595 16.8183L18.5378 14.8974C17.8788 14.3275 17.5 13.4993 17.5 12.628V11.3738Z',
    })
  );
};
Camera.displayName = 'Camera';
exports['default'] = Camera;
