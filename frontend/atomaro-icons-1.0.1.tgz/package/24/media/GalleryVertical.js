'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var GalleryVertical = function GalleryVertical(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M4.5 8L4.5 16C4.5 16.8284 5.17157 17.5 6 17.5L18 17.5C18.8284 17.5 19.5 16.8284 19.5 16L19.5 8C19.5 7.17157 18.8284 6.5 18 6.5L6 6.5C5.17157 6.5 4.5 7.17157 4.5 8ZM3 16C3 17.6569 4.34315 19 6 19L18 19C19.6569 19 21 17.6569 21 16L21 8C21 6.34315 19.6569 5 18 5L6 5C4.34315 5 3 6.34315 3 8L3 16ZM17.9781 2.24892C18.0028 2.11307 17.8881 2 17.75 2L6.25 2C6.11193 2 5.99723 2.11307 6.02192 2.24892C6.17347 3.08297 7.08674 3.5 8.00002 3.5L16 3.5C16.9133 3.5 17.8265 3.08297 17.9781 2.24892ZM17.75 22C17.8881 22 18.0028 21.8869 17.9781 21.7511C17.8265 20.917 16.9133 20.5 16 20.5L8.00002 20.5C7.08674 20.5 6.17347 20.917 6.02192 21.7511C5.99723 21.8869 6.11193 22 6.25 22L17.75 22Z',
    })
  );
};
GalleryVertical.displayName = 'GalleryVertical';
exports['default'] = GalleryVertical;
