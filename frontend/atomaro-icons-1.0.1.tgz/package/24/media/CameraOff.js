'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var CameraOff = function CameraOff(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M17.0304 18.9697L2.03039 3.96967L0.969727 5.03033L2.84862 6.90922C2.32345 7.44953 2.00006 8.187 2.00006 9V13C2.00006 15.7614 4.23863 18 7.00006 18H13.0001C13.286 18 13.5627 17.96 13.8246 17.8852L15.9697 20.0303L17.0304 18.9697ZM3.50006 9C3.50006 8.60121 3.65567 8.23877 3.9095 7.9701L12.4394 16.5H7.00006C5.06706 16.5 3.50006 14.933 3.50006 13V9ZM15.8853 15.8246C15.96 15.5626 16.0001 15.286 16.0001 15V9C16.0001 7.34314 14.6569 6 13.0001 6H6.06072L7.56072 7.5H13.0001C13.8285 7.5 14.5001 8.17157 14.5001 9V14.4393L15.8853 15.8246ZM19.5201 10.2382L20.5 9.39264V14.611L19.5189 13.7627C19.1894 13.4778 19 13.0637 19 12.628V11.3738C19 10.9377 19.1898 10.5231 19.5201 10.2382ZM17.5 11.3738C17.5 10.5015 17.8797 9.67238 18.5402 9.1025L20.76 7.18705C21.246 6.7677 22 7.11297 22 7.75489V16.251C22 16.8932 21.2453 17.2384 20.7595 16.8183L18.5378 14.8974C17.8788 14.3275 17.5 13.4993 17.5 12.628V11.3738Z',
    })
  );
};
CameraOff.displayName = 'CameraOff';
exports['default'] = CameraOff;
