'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var CameraOffFill = function CameraOffFill(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M2.03039 3.96967L17.0304 18.9697L15.9697 20.0303L13.8246 17.8852C13.5627 17.96 13.286 18 13.0001 18H7.00006C4.23863 18 2.00006 15.7614 2.00006 13V9C2.00006 8.187 2.32345 7.44953 2.84862 6.90922L0.969727 5.03033L2.03039 3.96967ZM15.8853 15.8246C15.96 15.5626 16.0001 15.286 16.0001 15V9C16.0001 7.34314 14.6569 6 13.0001 6H6.06072L15.8853 15.8246ZM17.5001 11.3738C17.5001 10.5015 17.8798 9.67237 18.5402 9.10249L20.7601 7.18705C21.2461 6.76769 22.0001 7.11296 22.0001 7.75488V16.2509C22.0001 16.8932 21.2454 17.2384 20.7595 16.8183L18.5379 14.8974C17.8788 14.3275 17.5001 13.4993 17.5001 12.628V11.3738Z',
    })
  );
};
CameraOffFill.displayName = 'CameraOffFill';
exports['default'] = CameraOffFill;
