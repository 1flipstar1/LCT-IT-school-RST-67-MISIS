"use strict";

var __importDefault = this && this.__importDefault || function (mod) {
  return mod && mod.__esModule ? mod : {
    "default": mod
  };
};
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ScreenHD = exports.ScreenControl = exports.Screen4K = exports.Play = exports.PlayObject = exports.PlayPrevious = exports.PlayNext = exports.PlayFill = exports.Photo = exports.Pause = exports.PauseObject = exports.PauseFill = exports.PackTV = exports.PackContent = exports.Overview6Screen = exports.Overview4Screen = exports.Overview2Screen = exports.Overview1Screen = exports.Minimize = exports.Microphone = exports.MicrophoneTalker = exports.MicrophoneMute = exports.MicrophoneMuteFill = exports.MicrophoneFill = exports.Melody = exports.Megaphone = exports.Maximize = exports.Live = exports.Image = exports.Headphones = exports.GalleryVertical = exports.GalleryHorizontal = exports.FocusVR = exports.FocusRecords = exports.FocusAR = exports.Focus3D = exports.FastRewind = exports.FastRewind5s = exports.FastRewind30s = exports.FastRewind15s = exports.FastRewind10s = exports.FastForward = exports.FastForward5s = exports.FastForward30s = exports.FastForward15s = exports.FastForward10s = exports.Camera = exports.CameraOff = exports.CameraOffFill = exports.CameraFill = void 0;
exports.ZoomOut = exports.ZoomIn = exports.VolumeUp = exports.VolumeUpFill = exports.VolumeOff = exports.VolumeOffFill = exports.VolumeDown = exports.VolumeDownFill = exports.Voice = exports.Translation = exports.Subtitles = exports.SubtitlesFill = exports.SpeedPlayback = exports.Speed8х = exports.Speed6х = exports.Speed4х = exports.Speed2х = exports.Speed1х = exports.ScreenTV = exports.ScreenSubscription = exports.ScreenSettings = void 0;
var CameraFill_1 = require("./CameraFill");
Object.defineProperty(exports, "CameraFill", {
  enumerable: true,
  get: function get() {
    return __importDefault(CameraFill_1)["default"];
  }
});
var CameraOffFill_1 = require("./CameraOffFill");
Object.defineProperty(exports, "CameraOffFill", {
  enumerable: true,
  get: function get() {
    return __importDefault(CameraOffFill_1)["default"];
  }
});
var CameraOff_1 = require("./CameraOff");
Object.defineProperty(exports, "CameraOff", {
  enumerable: true,
  get: function get() {
    return __importDefault(CameraOff_1)["default"];
  }
});
var Camera_1 = require("./Camera");
Object.defineProperty(exports, "Camera", {
  enumerable: true,
  get: function get() {
    return __importDefault(Camera_1)["default"];
  }
});
var FastForward10s_1 = require("./FastForward10s");
Object.defineProperty(exports, "FastForward10s", {
  enumerable: true,
  get: function get() {
    return __importDefault(FastForward10s_1)["default"];
  }
});
var FastForward15s_1 = require("./FastForward15s");
Object.defineProperty(exports, "FastForward15s", {
  enumerable: true,
  get: function get() {
    return __importDefault(FastForward15s_1)["default"];
  }
});
var FastForward30s_1 = require("./FastForward30s");
Object.defineProperty(exports, "FastForward30s", {
  enumerable: true,
  get: function get() {
    return __importDefault(FastForward30s_1)["default"];
  }
});
var FastForward5s_1 = require("./FastForward5s");
Object.defineProperty(exports, "FastForward5s", {
  enumerable: true,
  get: function get() {
    return __importDefault(FastForward5s_1)["default"];
  }
});
var FastForward_1 = require("./FastForward");
Object.defineProperty(exports, "FastForward", {
  enumerable: true,
  get: function get() {
    return __importDefault(FastForward_1)["default"];
  }
});
var FastRewind10s_1 = require("./FastRewind10s");
Object.defineProperty(exports, "FastRewind10s", {
  enumerable: true,
  get: function get() {
    return __importDefault(FastRewind10s_1)["default"];
  }
});
var FastRewind15s_1 = require("./FastRewind15s");
Object.defineProperty(exports, "FastRewind15s", {
  enumerable: true,
  get: function get() {
    return __importDefault(FastRewind15s_1)["default"];
  }
});
var FastRewind30s_1 = require("./FastRewind30s");
Object.defineProperty(exports, "FastRewind30s", {
  enumerable: true,
  get: function get() {
    return __importDefault(FastRewind30s_1)["default"];
  }
});
var FastRewind5s_1 = require("./FastRewind5s");
Object.defineProperty(exports, "FastRewind5s", {
  enumerable: true,
  get: function get() {
    return __importDefault(FastRewind5s_1)["default"];
  }
});
var FastRewind_1 = require("./FastRewind");
Object.defineProperty(exports, "FastRewind", {
  enumerable: true,
  get: function get() {
    return __importDefault(FastRewind_1)["default"];
  }
});
var Focus3D_1 = require("./Focus3D");
Object.defineProperty(exports, "Focus3D", {
  enumerable: true,
  get: function get() {
    return __importDefault(Focus3D_1)["default"];
  }
});
var FocusAR_1 = require("./FocusAR");
Object.defineProperty(exports, "FocusAR", {
  enumerable: true,
  get: function get() {
    return __importDefault(FocusAR_1)["default"];
  }
});
var FocusRecords_1 = require("./FocusRecords");
Object.defineProperty(exports, "FocusRecords", {
  enumerable: true,
  get: function get() {
    return __importDefault(FocusRecords_1)["default"];
  }
});
var FocusVR_1 = require("./FocusVR");
Object.defineProperty(exports, "FocusVR", {
  enumerable: true,
  get: function get() {
    return __importDefault(FocusVR_1)["default"];
  }
});
var GalleryHorizontal_1 = require("./GalleryHorizontal");
Object.defineProperty(exports, "GalleryHorizontal", {
  enumerable: true,
  get: function get() {
    return __importDefault(GalleryHorizontal_1)["default"];
  }
});
var GalleryVertical_1 = require("./GalleryVertical");
Object.defineProperty(exports, "GalleryVertical", {
  enumerable: true,
  get: function get() {
    return __importDefault(GalleryVertical_1)["default"];
  }
});
var Headphones_1 = require("./Headphones");
Object.defineProperty(exports, "Headphones", {
  enumerable: true,
  get: function get() {
    return __importDefault(Headphones_1)["default"];
  }
});
var Image_1 = require("./Image");
Object.defineProperty(exports, "Image", {
  enumerable: true,
  get: function get() {
    return __importDefault(Image_1)["default"];
  }
});
var Live_1 = require("./Live");
Object.defineProperty(exports, "Live", {
  enumerable: true,
  get: function get() {
    return __importDefault(Live_1)["default"];
  }
});
var Maximize_1 = require("./Maximize");
Object.defineProperty(exports, "Maximize", {
  enumerable: true,
  get: function get() {
    return __importDefault(Maximize_1)["default"];
  }
});
var Megaphone_1 = require("./Megaphone");
Object.defineProperty(exports, "Megaphone", {
  enumerable: true,
  get: function get() {
    return __importDefault(Megaphone_1)["default"];
  }
});
var Melody_1 = require("./Melody");
Object.defineProperty(exports, "Melody", {
  enumerable: true,
  get: function get() {
    return __importDefault(Melody_1)["default"];
  }
});
var MicrophoneFill_1 = require("./MicrophoneFill");
Object.defineProperty(exports, "MicrophoneFill", {
  enumerable: true,
  get: function get() {
    return __importDefault(MicrophoneFill_1)["default"];
  }
});
var MicrophoneMuteFill_1 = require("./MicrophoneMuteFill");
Object.defineProperty(exports, "MicrophoneMuteFill", {
  enumerable: true,
  get: function get() {
    return __importDefault(MicrophoneMuteFill_1)["default"];
  }
});
var MicrophoneMute_1 = require("./MicrophoneMute");
Object.defineProperty(exports, "MicrophoneMute", {
  enumerable: true,
  get: function get() {
    return __importDefault(MicrophoneMute_1)["default"];
  }
});
var MicrophoneTalker_1 = require("./MicrophoneTalker");
Object.defineProperty(exports, "MicrophoneTalker", {
  enumerable: true,
  get: function get() {
    return __importDefault(MicrophoneTalker_1)["default"];
  }
});
var Microphone_1 = require("./Microphone");
Object.defineProperty(exports, "Microphone", {
  enumerable: true,
  get: function get() {
    return __importDefault(Microphone_1)["default"];
  }
});
var Minimize_1 = require("./Minimize");
Object.defineProperty(exports, "Minimize", {
  enumerable: true,
  get: function get() {
    return __importDefault(Minimize_1)["default"];
  }
});
var Overview1Screen_1 = require("./Overview1Screen");
Object.defineProperty(exports, "Overview1Screen", {
  enumerable: true,
  get: function get() {
    return __importDefault(Overview1Screen_1)["default"];
  }
});
var Overview2Screen_1 = require("./Overview2Screen");
Object.defineProperty(exports, "Overview2Screen", {
  enumerable: true,
  get: function get() {
    return __importDefault(Overview2Screen_1)["default"];
  }
});
var Overview4Screen_1 = require("./Overview4Screen");
Object.defineProperty(exports, "Overview4Screen", {
  enumerable: true,
  get: function get() {
    return __importDefault(Overview4Screen_1)["default"];
  }
});
var Overview6Screen_1 = require("./Overview6Screen");
Object.defineProperty(exports, "Overview6Screen", {
  enumerable: true,
  get: function get() {
    return __importDefault(Overview6Screen_1)["default"];
  }
});
var PackContent_1 = require("./PackContent");
Object.defineProperty(exports, "PackContent", {
  enumerable: true,
  get: function get() {
    return __importDefault(PackContent_1)["default"];
  }
});
var PackTV_1 = require("./PackTV");
Object.defineProperty(exports, "PackTV", {
  enumerable: true,
  get: function get() {
    return __importDefault(PackTV_1)["default"];
  }
});
var PauseFill_1 = require("./PauseFill");
Object.defineProperty(exports, "PauseFill", {
  enumerable: true,
  get: function get() {
    return __importDefault(PauseFill_1)["default"];
  }
});
var PauseObject_1 = require("./PauseObject");
Object.defineProperty(exports, "PauseObject", {
  enumerable: true,
  get: function get() {
    return __importDefault(PauseObject_1)["default"];
  }
});
var Pause_1 = require("./Pause");
Object.defineProperty(exports, "Pause", {
  enumerable: true,
  get: function get() {
    return __importDefault(Pause_1)["default"];
  }
});
var Photo_1 = require("./Photo");
Object.defineProperty(exports, "Photo", {
  enumerable: true,
  get: function get() {
    return __importDefault(Photo_1)["default"];
  }
});
var PlayFill_1 = require("./PlayFill");
Object.defineProperty(exports, "PlayFill", {
  enumerable: true,
  get: function get() {
    return __importDefault(PlayFill_1)["default"];
  }
});
var PlayNext_1 = require("./PlayNext");
Object.defineProperty(exports, "PlayNext", {
  enumerable: true,
  get: function get() {
    return __importDefault(PlayNext_1)["default"];
  }
});
var PlayPrevious_1 = require("./PlayPrevious");
Object.defineProperty(exports, "PlayPrevious", {
  enumerable: true,
  get: function get() {
    return __importDefault(PlayPrevious_1)["default"];
  }
});
var PlayObject_1 = require("./PlayObject");
Object.defineProperty(exports, "PlayObject", {
  enumerable: true,
  get: function get() {
    return __importDefault(PlayObject_1)["default"];
  }
});
var Play_1 = require("./Play");
Object.defineProperty(exports, "Play", {
  enumerable: true,
  get: function get() {
    return __importDefault(Play_1)["default"];
  }
});
var Screen4K_1 = require("./Screen4K");
Object.defineProperty(exports, "Screen4K", {
  enumerable: true,
  get: function get() {
    return __importDefault(Screen4K_1)["default"];
  }
});
var ScreenControl_1 = require("./ScreenControl");
Object.defineProperty(exports, "ScreenControl", {
  enumerable: true,
  get: function get() {
    return __importDefault(ScreenControl_1)["default"];
  }
});
var ScreenHD_1 = require("./ScreenHD");
Object.defineProperty(exports, "ScreenHD", {
  enumerable: true,
  get: function get() {
    return __importDefault(ScreenHD_1)["default"];
  }
});
var ScreenSettings_1 = require("./ScreenSettings");
Object.defineProperty(exports, "ScreenSettings", {
  enumerable: true,
  get: function get() {
    return __importDefault(ScreenSettings_1)["default"];
  }
});
var ScreenSubscription_1 = require("./ScreenSubscription");
Object.defineProperty(exports, "ScreenSubscription", {
  enumerable: true,
  get: function get() {
    return __importDefault(ScreenSubscription_1)["default"];
  }
});
var ScreenTV_1 = require("./ScreenTV");
Object.defineProperty(exports, "ScreenTV", {
  enumerable: true,
  get: function get() {
    return __importDefault(ScreenTV_1)["default"];
  }
});
var Speed1_1 = require("./Speed1\u0445");
Object.defineProperty(exports, "Speed1\u0445", {
  enumerable: true,
  get: function get() {
    return __importDefault(Speed1_1)["default"];
  }
});
var Speed2_1 = require("./Speed2\u0445");
Object.defineProperty(exports, "Speed2\u0445", {
  enumerable: true,
  get: function get() {
    return __importDefault(Speed2_1)["default"];
  }
});
var Speed4_1 = require("./Speed4\u0445");
Object.defineProperty(exports, "Speed4\u0445", {
  enumerable: true,
  get: function get() {
    return __importDefault(Speed4_1)["default"];
  }
});
var Speed6_1 = require("./Speed6\u0445");
Object.defineProperty(exports, "Speed6\u0445", {
  enumerable: true,
  get: function get() {
    return __importDefault(Speed6_1)["default"];
  }
});
var Speed8_1 = require("./Speed8\u0445");
Object.defineProperty(exports, "Speed8\u0445", {
  enumerable: true,
  get: function get() {
    return __importDefault(Speed8_1)["default"];
  }
});
var SpeedPlayback_1 = require("./SpeedPlayback");
Object.defineProperty(exports, "SpeedPlayback", {
  enumerable: true,
  get: function get() {
    return __importDefault(SpeedPlayback_1)["default"];
  }
});
var SubtitlesFill_1 = require("./SubtitlesFill");
Object.defineProperty(exports, "SubtitlesFill", {
  enumerable: true,
  get: function get() {
    return __importDefault(SubtitlesFill_1)["default"];
  }
});
var Subtitles_1 = require("./Subtitles");
Object.defineProperty(exports, "Subtitles", {
  enumerable: true,
  get: function get() {
    return __importDefault(Subtitles_1)["default"];
  }
});
var Translation_1 = require("./Translation");
Object.defineProperty(exports, "Translation", {
  enumerable: true,
  get: function get() {
    return __importDefault(Translation_1)["default"];
  }
});
var Voice_1 = require("./Voice");
Object.defineProperty(exports, "Voice", {
  enumerable: true,
  get: function get() {
    return __importDefault(Voice_1)["default"];
  }
});
var VolumeDownFill_1 = require("./VolumeDownFill");
Object.defineProperty(exports, "VolumeDownFill", {
  enumerable: true,
  get: function get() {
    return __importDefault(VolumeDownFill_1)["default"];
  }
});
var VolumeDown_1 = require("./VolumeDown");
Object.defineProperty(exports, "VolumeDown", {
  enumerable: true,
  get: function get() {
    return __importDefault(VolumeDown_1)["default"];
  }
});
var VolumeOffFill_1 = require("./VolumeOffFill");
Object.defineProperty(exports, "VolumeOffFill", {
  enumerable: true,
  get: function get() {
    return __importDefault(VolumeOffFill_1)["default"];
  }
});
var VolumeOff_1 = require("./VolumeOff");
Object.defineProperty(exports, "VolumeOff", {
  enumerable: true,
  get: function get() {
    return __importDefault(VolumeOff_1)["default"];
  }
});
var VolumeUpFill_1 = require("./VolumeUpFill");
Object.defineProperty(exports, "VolumeUpFill", {
  enumerable: true,
  get: function get() {
    return __importDefault(VolumeUpFill_1)["default"];
  }
});
var VolumeUp_1 = require("./VolumeUp");
Object.defineProperty(exports, "VolumeUp", {
  enumerable: true,
  get: function get() {
    return __importDefault(VolumeUp_1)["default"];
  }
});
var ZoomIn_1 = require("./ZoomIn");
Object.defineProperty(exports, "ZoomIn", {
  enumerable: true,
  get: function get() {
    return __importDefault(ZoomIn_1)["default"];
  }
});
var ZoomOut_1 = require("./ZoomOut");
Object.defineProperty(exports, "ZoomOut", {
  enumerable: true,
  get: function get() {
    return __importDefault(ZoomOut_1)["default"];
  }
});