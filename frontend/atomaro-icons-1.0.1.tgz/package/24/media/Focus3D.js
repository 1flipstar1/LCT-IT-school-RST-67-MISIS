'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Focus3D = function Focus3D(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M19 4.5H16V3H19C20.1046 3 21 3.89543 21 5V8H19.5V5C19.5 4.72386 19.2761 4.5 19 4.5ZM8 3V4.5H5C4.72386 4.5 4.5 4.72386 4.5 5V8H3V5C3 3.89543 3.89543 3 5 3H8ZM3 16H4.5V19C4.5 19.2761 4.72386 19.5 5 19.5H8V21H5C3.89543 21 3 20.1046 3 19V16ZM16 21V19.5H19C19.2761 19.5 19.5 19.2761 19.5 19V16H21V19C21 20.1046 20.1046 21 19 21H16ZM12.2833 7.09149L12.0002 6.97607L11.7171 7.09149L7.46688 8.8241L7 9.01443V9.51861V14.4958V15.0029L7.47054 15.1918L11.7205 16.8983L12 17.0105L12.2794 16.8983L16.5298 15.1918L17.0003 15.0029V14.4958V9.51861V9.01443L16.5335 8.8241L12.2833 7.09149ZM8.5 11.2143V13.9887L11.25 15.093V12.3482L8.5 11.2143ZM15.5003 13.9887L12.75 15.093V12.3484L15.5003 11.2143V13.9887ZM14.9747 9.80851L12.0002 8.59592L9.02565 9.80851L12.0002 11.0351L14.9747 9.80851Z',
    })
  );
};
Focus3D.displayName = 'Focus3D';
exports['default'] = Focus3D;
