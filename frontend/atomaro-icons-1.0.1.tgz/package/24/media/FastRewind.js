'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var FastRewind = function FastRewind(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M11.8763 7.11206L5.37845 11.2698C4.87385 11.5926 4.87385 12.4074 5.37845 12.7302L11.8763 16.8879C12.377 17.2083 13 16.8035 13 16.1577L13 13.7678L17.8763 16.8879C18.377 17.2083 19 16.8035 19 16.1577L19 7.84229C19 7.19652 18.377 6.79166 17.8763 7.11206L13 10.2322L13 7.84229C13 7.19651 12.377 6.79166 11.8763 7.11206Z',
    })
  );
};
FastRewind.displayName = 'FastRewind';
exports['default'] = FastRewind;
