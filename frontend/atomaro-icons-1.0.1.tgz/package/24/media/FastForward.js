'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var FastForward = function FastForward(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M12.1237 7.11206L18.6216 11.2698C19.1261 11.5926 19.1262 12.4074 18.6216 12.7302L12.1237 16.8879C11.623 17.2083 11 16.8035 11 16.1577V13.7678L6.12374 16.8879C5.62302 17.2083 5 16.8035 5 16.1577V7.84229C5 7.19652 5.62302 6.79166 6.12374 7.11206L11 10.2322V7.84229C11 7.19652 11.623 6.79166 12.1237 7.11206Z',
    })
  );
};
FastForward.displayName = 'FastForward';
exports['default'] = FastForward;
