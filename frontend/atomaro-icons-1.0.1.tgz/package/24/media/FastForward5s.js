'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var FastForward5s = function FastForward5s(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M12.2195 2.03014L14.4393 4.25H11.992H11.9688V4.25005C7.01256 4.2669 3 8.28986 3 13.25C3 18.2206 7.02944 22.25 12 22.25C16.9706 22.25 21 18.2206 21 13.25C21 10.8554 20.0648 8.67924 18.5398 7.0668L17.4786 8.12796C18.7324 9.46852 19.5 11.2696 19.5 13.25C19.5 17.3921 16.1421 20.75 12 20.75C7.85786 20.75 4.5 17.3921 4.5 13.25C4.5 9.11228 7.8507 5.75716 11.9867 5.75001V5.75H14.4345L12.2195 7.965L13.2802 9.02566L16.7779 5.52791C17.0708 5.23502 17.0708 4.76015 16.7779 4.46725L13.2801 0.969482L12.2195 2.03014ZM9.98897 10.1018H14.0875V11.3998H10.9993L10.8888 12.4289C11.2627 12.1991 11.752 12.0998 12.1605 12.0998C12.9004 12.0998 13.4839 12.3199 13.8826 12.7174C14.2812 13.1148 14.4835 13.678 14.4835 14.3418C14.4835 15.6866 13.4731 16.7278 11.9715 16.7278C11.1741 16.7278 10.5938 16.5016 10.2121 16.1427C9.83037 15.7837 9.65747 15.3014 9.65747 14.8098C9.65747 14.7796 9.65989 14.723 9.6633 14.6696C9.66656 14.6184 9.67134 14.5595 9.67741 14.5292L9.69438 14.4444L11.0805 14.5179L11.0621 14.6282C11.0538 14.6779 11.0455 14.7623 11.0455 14.8188C11.0455 15.0303 11.1342 15.2015 11.2911 15.3223C11.4504 15.445 11.6858 15.5198 11.9805 15.5198C12.3147 15.5198 12.5911 15.4144 12.7837 15.2208C12.9762 15.0273 13.0955 14.7352 13.0955 14.3418C13.0955 13.9857 12.9815 13.7068 12.7908 13.5172C12.6 13.3274 12.3233 13.2178 11.9805 13.2178C11.5694 13.2178 11.1364 13.4116 10.83 13.7436L10.7892 13.7878L9.72328 13.5083L9.98897 10.1018Z',
    })
  );
};
FastForward5s.displayName = 'FastForward5s';
exports['default'] = FastForward5s;
