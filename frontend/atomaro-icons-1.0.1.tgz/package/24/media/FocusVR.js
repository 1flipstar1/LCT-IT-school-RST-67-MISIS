'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var FocusVR = function FocusVR(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M19 4.5H16V3H19C20.1046 3 21 3.89543 21 5V8H19.5V5C19.5 4.72386 19.2761 4.5 19 4.5ZM8 3V4.5H5C4.72386 4.5 4.5 4.72386 4.5 5V8H3V5C3 3.89543 3.89543 3 5 3H8ZM3 16H4.5V19C4.5 19.2761 4.72386 19.5 5 19.5H8V21H5C3.89543 21 3 20.1046 3 19V16ZM16 21V19.5H19C19.2761 19.5 19.5 19.2761 19.5 19V16H21V19C21 20.1046 20.1046 21 19 21H16ZM13.2468 8.9873H12.4968V9.7373V14.9999H13.9968V13.5354H15.2133L16.0186 14.999H17.7306L16.783 13.2766C17.508 12.8965 18.0025 12.1367 18.0025 11.2614C18.0025 10.0054 16.9844 8.9873 15.7285 8.9873H13.2468ZM15.7285 12.0354H13.9968V10.4873H15.7285C16.156 10.4873 16.5025 10.8339 16.5025 11.2614C16.5025 11.6889 16.156 12.0354 15.7285 12.0354ZM7.89595 15H9.51913L12.0002 9H10.377L8.70756 13.0373L7.03821 9H5.41504L7.89595 15Z',
    })
  );
};
FocusVR.displayName = 'FocusVR';
exports['default'] = FocusVR;
