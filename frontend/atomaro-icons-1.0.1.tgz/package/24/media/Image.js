'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Image = function Image(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M18 4.5H6C5.17157 4.5 4.5 5.17157 4.5 6V11.5145L6.99032 9.20761C7.26497 8.95319 7.68517 8.94027 7.97493 9.17734L13.0201 13.3052L14.55 12.1578C14.8301 11.9477 15.2183 11.9594 15.4852 12.1859L19.5 15.5922V6C19.5 5.17157 18.8284 4.5 18 4.5ZM19.5 17.5594L14.9712 13.7169L13.45 14.8578C13.1739 15.0649 12.7922 15.0568 12.5251 14.8383L7.53055 10.7519L4.50968 13.5502L4.5 13.5398V18C4.5 18.8284 5.17157 19.5 6 19.5H18C18.8284 19.5 19.5 18.8284 19.5 18V17.5594ZM6 3C4.34315 3 3 4.34315 3 6V18C3 19.6569 4.34315 21 6 21H18C19.6569 21 21 19.6569 21 18V6C21 4.34315 19.6569 3 18 3H6ZM14 8.5C14 7.67157 14.6716 7 15.5 7C16.3284 7 17 7.67157 17 8.5C17 9.32843 16.3284 10 15.5 10C14.6716 10 14 9.32843 14 8.5Z',
    })
  );
};
Image.displayName = 'Image';
exports['default'] = Image;
