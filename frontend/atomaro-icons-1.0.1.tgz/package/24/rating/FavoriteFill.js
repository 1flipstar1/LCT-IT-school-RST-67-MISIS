'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var FavoriteFill = function FavoriteFill(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      d: 'M5 5C5 3.89543 5.89543 3 7 3H17C18.1046 3 19 3.89543 19 5V20.0057C19 20.7569 18.2028 21.2399 17.537 20.8921L12 18L6.46297 20.8921C5.79719 21.2399 5 20.7569 5 20.0057V5Z',
    })
  );
};
FavoriteFill.displayName = 'FavoriteFill';
exports['default'] = FavoriteFill;
