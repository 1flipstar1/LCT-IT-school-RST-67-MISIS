'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var FaceSmillingColor = function FaceSmillingColor(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      d: 'M22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12Z',
      fill: '#F29100',
    }),
    ',',
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M10.009 10.5031C10.009 11.3333 9.33543 12.0063 8.5045 12.0063C7.67358 12.0063 6.99999 11.3333 6.99999 10.5031C6.99999 9.67298 7.67358 9 8.5045 9C9.33543 9 10.009 9.67298 10.009 10.5031ZM8.10287 14.25C8.49783 14.9341 9.0659 15.5022 9.74999 15.8971C10.4341 16.2921 11.2101 16.5 12 16.5C12.7899 16.5 13.5659 16.2921 14.25 15.8971C14.9341 15.5022 15.5021 14.9341 15.8971 14.25L17.1961 15C16.6695 15.9121 15.9121 16.6695 15 17.1962C14.0879 17.7228 13.0532 18 12 18C10.9468 18 9.9121 17.7228 8.99999 17.1962C8.08787 16.6695 7.33044 15.9121 6.80383 15L8.10287 14.25ZM15.5045 12.0063C16.3354 12.0063 17.009 11.3333 17.009 10.5031C17.009 9.67298 16.3354 9 15.5045 9C14.6736 9 14 9.67298 14 10.5031C14 11.3333 14.6736 12.0063 15.5045 12.0063Z',
    })
  );
};
FaceSmillingColor.displayName = 'FaceSmillingColor';
exports['default'] = FaceSmillingColor;
