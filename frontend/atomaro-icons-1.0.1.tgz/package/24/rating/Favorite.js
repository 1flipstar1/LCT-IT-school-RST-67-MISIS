'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Favorite = function Favorite(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M12 16.3077L12.6945 16.6704L17.5 19.1805V5C17.5 4.72386 17.2761 4.5 17 4.5H7C6.72386 4.5 6.5 4.72386 6.5 5V19.1805L11.3055 16.6704L12 16.3077ZM12 18L17.537 20.8921C18.2028 21.2399 19 20.7569 19 20.0057V5C19 3.89543 18.1046 3 17 3H7C5.89543 3 5 3.89543 5 5V20.0057C5 20.7569 5.79719 21.2399 6.46297 20.8921L12 18Z',
    })
  );
};
Favorite.displayName = 'Favorite';
exports['default'] = Favorite;
