'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var HeartBroken = function HeartBroken(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M3 8.97831C3 6.24655 5.16494 4 7.87453 4C9.28971 4 10.5168 4.74855 11.3676 5.76904C11.6045 6.0533 11.8168 6.36357 11.9997 6.69262C12.1825 6.36365 12.3946 6.05344 12.6314 5.76922C13.4816 4.74863 14.7083 4 16.1236 4C18.8332 4 20.9981 6.24655 20.9981 8.97831C20.9981 11.4006 19.4893 13.5485 17.7652 15.3159C16.4435 16.6709 14.8908 17.902 13.5947 18.9297L13.5946 18.9298C13.1916 19.2493 12.8134 19.5492 12.4747 19.827C12.1981 20.0538 11.8 20.0538 11.5234 19.827C11.1847 19.5491 10.8064 19.2493 10.4034 18.9297L10.4034 18.9297L10.4034 18.9297C9.10725 17.902 7.55459 16.6709 6.23286 15.3159C4.50876 13.5485 3 11.4006 3 8.97831ZM12.8454 8.64423L13.4421 10.2271L13.5666 10.5574L13.3932 10.8628L12.3285 12.7376L13.7236 14.6303L14.007 15.0148L13.782 15.4331L12.4388 17.9311C12.5313 17.8577 12.6247 17.7836 12.7189 17.7089L12.719 17.7089C14.0029 16.6905 15.4437 15.5477 16.6915 14.2685C18.3554 12.5628 19.4981 10.7843 19.4981 8.97831C19.4981 7.03961 17.9698 5.5 16.1236 5.5C15.2609 5.5 14.4258 5.95875 13.7838 6.72936C13.3278 7.2767 12.9983 7.94958 12.8454 8.64423ZM10.9795 17.471L12.2368 15.1327L10.8344 13.2302L10.5438 12.8359L10.7843 12.4123L11.9161 10.4193L11.1179 8.30155L10.8972 7.84629C10.7245 7.44311 10.4934 7.06304 10.2154 6.72954C9.5729 5.95883 8.73726 5.5 7.87453 5.5C6.02829 5.5 4.5 7.03961 4.5 8.97831C4.5 10.7843 5.64272 12.5628 7.30662 14.2685C8.45817 15.4491 9.7741 16.5134 10.9795 17.471Z',
    })
  );
};
HeartBroken.displayName = 'HeartBroken';
exports['default'] = HeartBroken;
