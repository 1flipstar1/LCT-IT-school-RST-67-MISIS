'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var HeartFill = function HeartFill(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      d: 'M3 8.97831C3 6.24655 5.16494 4 7.87453 4C9.28971 4 10.5168 4.74855 11.3676 5.76904C11.6045 6.0533 11.8168 6.36357 11.9997 6.69262C12.1825 6.36365 12.3946 6.05344 12.6314 5.76922C13.4816 4.74863 14.7083 4 16.1236 4C18.8332 4 20.9981 6.24655 20.9981 8.97831C20.9981 11.4006 19.4893 13.5485 17.7652 15.3159C16.4435 16.6709 14.8908 17.902 13.5947 18.9297L13.5946 18.9298C13.1916 19.2493 12.8134 19.5492 12.4747 19.827C12.1981 20.0538 11.8 20.0538 11.5234 19.827C11.1847 19.5491 10.8064 19.2493 10.4034 18.9297L10.4034 18.9297C9.10727 17.902 7.55461 16.6709 6.23286 15.3159C4.50876 13.5485 3 11.4006 3 8.97831Z',
    })
  );
};
HeartFill.displayName = 'HeartFill';
exports['default'] = HeartFill;
