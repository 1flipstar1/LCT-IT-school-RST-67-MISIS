'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var FaceGrin = function FaceGrin(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M20.5 12C20.5 16.6944 16.6944 20.5 12 20.5C7.30558 20.5 3.5 16.6944 3.5 12C3.5 7.30558 7.30558 3.5 12 3.5C16.6944 3.5 20.5 7.30558 20.5 12ZM22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12ZM15.5 13L17 13C17 13.5226 16.9198 14.0265 16.7711 14.5C16.134 16.5286 14.2388 18 12 18C9.76118 18 7.86603 16.5286 7.2289 14.5C7.08018 14.0265 7 13.5226 7 13H8.5H15.5ZM12 16.5C10.6038 16.5 9.39855 15.6825 8.83682 14.5H15.1632C14.6015 15.6825 13.3962 16.5 12 16.5ZM10.2446 10.453L7.23292 11.453L6.76024 10.0294L9.77195 9.02942L10.2446 10.453ZM13.7602 10.453L16.7719 11.453L17.2446 10.0294L14.2329 9.02942L13.7602 10.453Z',
    })
  );
};
FaceGrin.displayName = 'FaceGrin';
exports['default'] = FaceGrin;
