'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Dislike = function Dislike(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M13.4962 20.8783V17H14.9962L17.9987 17C19.7899 17 21.1819 15.4405 20.9794 13.6608L20.4986 9.43472C20.2111 6.90832 18.0733 5 15.5306 5L8.4985 5L8.49807 5H6.99807H5C3.89543 5 3 5.89543 3 7V15C3 16.1046 3.89543 17 5 17H6.99807H7.32243L9.4367 21.7423C9.77776 22.5072 10.537 23 11.3745 23C12.5463 23 13.4962 22.0501 13.4962 20.8783ZM15.5306 6.5L8.4985 6.5L8.4985 15.9542L10.8067 21.1315C10.9067 21.3556 11.1291 21.5 11.3745 21.5C11.7179 21.5 11.9962 21.2217 11.9962 20.8783V17C11.9962 16.1716 12.6678 15.5 13.4962 15.5L17.9987 15.5C18.8943 15.5 19.5903 14.7203 19.4891 13.8304L19.0082 9.60431C18.807 7.83582 17.3105 6.5 15.5306 6.5ZM5 15.5H6.99807V6.5H5C4.72386 6.5 4.5 6.72385 4.5 7V15C4.5 15.2761 4.72386 15.5 5 15.5Z',
    })
  );
};
Dislike.displayName = 'Dislike';
exports['default'] = Dislike;
