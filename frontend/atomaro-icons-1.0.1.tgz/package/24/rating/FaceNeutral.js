'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var FaceNeutral = function FaceNeutral(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M20.5 12C20.5 16.6944 16.6944 20.5 12 20.5C7.30558 20.5 3.5 16.6944 3.5 12C3.5 7.30558 7.30558 3.5 12 3.5C16.6944 3.5 20.5 7.30558 20.5 12ZM22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12ZM16 16.25V14.75H8V16.25H16ZM10.009 10.5031C10.009 11.3333 9.33544 12.0063 8.50452 12.0063C7.6736 12.0063 7 11.3333 7 10.5031C7 9.67298 7.6736 9 8.50452 9C9.33544 9 10.009 9.67298 10.009 10.5031ZM15.5045 12.0063C16.3354 12.0063 17.009 11.3333 17.009 10.5031C17.009 9.67298 16.3354 9 15.5045 9C14.6736 9 14 9.67298 14 10.5031C14 11.3333 14.6736 12.0063 15.5045 12.0063Z',
    })
  );
};
FaceNeutral.displayName = 'FaceNeutral';
exports['default'] = FaceNeutral;
