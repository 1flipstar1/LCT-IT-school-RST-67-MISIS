'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var FaceSmilling = function FaceSmilling(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M20.5 12C20.5 16.6944 16.6944 20.5 12 20.5C7.30558 20.5 3.5 16.6944 3.5 12C3.5 7.30558 7.30558 3.5 12 3.5C16.6944 3.5 20.5 7.30558 20.5 12ZM22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12ZM9.75 15.8971C9.06591 15.5022 8.49784 14.9341 8.10289 14.25L6.80385 15C7.33046 15.9121 8.08788 16.6695 9 17.1962C9.91212 17.7228 10.9468 18 12 18C13.0532 18 14.0879 17.7228 15 17.1962C15.9121 16.6695 16.6695 15.9121 17.1962 15L15.8971 14.25C15.5022 14.9341 14.9341 15.5022 14.25 15.8971C13.5659 16.2921 12.7899 16.5 12 16.5C11.2101 16.5 10.4341 16.2921 9.75 15.8971ZM10.009 10.5031C10.009 11.3332 9.33544 12.0062 8.50452 12.0062C7.6736 12.0062 7 11.3332 7 10.5031C7 9.67292 7.6736 8.99994 8.50452 8.99994C9.33544 8.99994 10.009 9.67292 10.009 10.5031ZM15.5045 12.0062C16.3354 12.0062 17.009 11.3332 17.009 10.5031C17.009 9.67292 16.3354 8.99994 15.5045 8.99994C14.6736 8.99994 14 9.67292 14 10.5031C14 11.3332 14.6736 12.0062 15.5045 12.0062Z',
    })
  );
};
FaceSmilling.displayName = 'FaceSmilling';
exports['default'] = FaceSmilling;
