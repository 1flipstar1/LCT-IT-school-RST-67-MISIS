'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var CodeBinary = function CodeBinary(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M17.8416 2.99963L16.3871 4.47301L17.4545 5.52683L18.1452 4.82716V9.51101H16.4208V11.011H20.9208V9.51101H19.6452V2.99992L19.6445 2.99963H17.8416ZM2.50034 4.47297L3.95462 2.99988H5.75853V9.51097H7.03406V11.011H2.53406V9.51097H4.25853V4.82712L3.56779 5.52679L2.50034 4.47297ZM13 5.74988V8.24988C13 8.94023 12.4404 9.49988 11.75 9.49988C11.0597 9.49988 10.5 8.94023 10.5 8.24988V5.74988C10.5 5.05952 11.0597 4.49988 11.75 4.49988C12.4404 4.49988 13 5.05952 13 5.74988ZM9.00001 5.74988C9.00001 4.23109 10.2312 2.99988 11.75 2.99988C13.2688 2.99988 14.5 4.23109 14.5 5.74988V8.24988C14.5 9.76866 13.2688 10.9999 11.75 10.9999C10.2312 10.9999 9.00001 9.76866 9.00001 8.24988V5.74988ZM19.4207 15.7499V18.2499C19.4207 18.9402 18.8611 19.4999 18.1707 19.4999C17.4804 19.4999 16.9207 18.9402 16.9207 18.2499V15.7499C16.9207 15.0595 17.4804 14.4999 18.1707 14.4999C18.8611 14.4999 19.4207 15.0595 19.4207 15.7499ZM15.4207 15.7499C15.4207 14.2311 16.652 12.9999 18.1707 12.9999C19.6895 12.9999 20.9207 14.2311 20.9207 15.7499V18.2499C20.9207 19.7687 19.6895 20.9999 18.1707 20.9999C16.652 20.9999 15.4207 19.7687 15.4207 18.2499V15.7499ZM3.95719 12.9896L2.49887 14.4744L3.56901 15.5255L4.25841 14.8236V19.5008H2.53394V21.0008H7.03394V19.5008H5.75841V12.9897L5.75829 12.9896H3.95719ZM9.46498 14.4744L10.9233 12.9896H12.7244L12.7245 12.9897V19.5008H14V21.0008H9.50005V19.5008H11.2245V14.8236L10.5351 15.5255L9.46498 14.4744Z',
    })
  );
};
CodeBinary.displayName = 'CodeBinary';
exports['default'] = CodeBinary;
