'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var GridGant = function GridGant(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M4.5 6V8.01562L19.5 8.01562V6C19.5 5.17157 18.8284 4.5 18 4.5L6 4.5C5.17157 4.5 4.5 5.17157 4.5 6ZM4.5 18L4.5 9.51562L19.5 9.51562V18C19.5 18.8284 18.8284 19.5 18 19.5H6C5.17157 19.5 4.5 18.8284 4.5 18ZM3 18C3 19.6569 4.34315 21 6 21H18C19.6569 21 21 19.6569 21 18V6C21 4.34315 19.6569 3 18 3H6C4.34315 3 3 4.34315 3 6V18ZM6 13.5084H14V12.0084H6V13.5084ZM10 17.0118H8V15.5118H10V17.0118ZM12 17.0118L18 17.0118L18 15.5118L12 15.5118V17.0118Z',
    })
  );
};
GridGant.displayName = 'GridGant';
exports['default'] = GridGant;
