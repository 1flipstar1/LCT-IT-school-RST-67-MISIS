'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var EyedropperFill = function EyedropperFill(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M19.9591 11.1248L18.8436 10.0093L10.4699 18.3829C10.0948 18.758 9.58614 18.9687 9.0557 18.9687H5.51953C5.24339 18.9687 5.01953 18.7449 5.01953 18.4687V14.9326C5.01953 14.4021 5.23024 13.8934 5.60532 13.5184L13.9789 5.14478L12.8693 4.03521L13.9299 2.97453L15.0395 4.08412L16.3862 2.73748C17.3625 1.76117 18.9454 1.76117 19.9217 2.73748L21.2508 4.06655C22.2271 5.04286 22.2271 6.62577 21.2508 7.60208L19.9042 8.94865L21.0197 10.0641L19.9591 11.1248ZM6.51953 17.4687H9.0557C9.18831 17.4687 9.31549 17.4161 9.40926 17.3223L17.7829 8.94867L15.0396 6.20542L6.66598 14.579C6.57221 14.6728 6.51953 14.8 6.51953 14.9326V17.4687Z',
    }),
    ',',
    react_1['default'].createElement('path', {
      d: 'M4 21C4 21.5523 3.55228 22 3 22C2.44772 22 2 21.5523 2 21C2 20.4477 2.44772 20 3 20C3.55228 20 4 20.4477 4 21Z',
    })
  );
};
EyedropperFill.displayName = 'EyedropperFill';
exports['default'] = EyedropperFill;
