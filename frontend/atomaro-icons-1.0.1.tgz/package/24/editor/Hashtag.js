'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Hashtag = function Hashtag(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M8.28127 15.1648L7.61325 19H9.13583L9.80385 15.1648H13.0938L12.4258 19H13.9484L14.6164 15.1648H19V13.6648H14.8776L15.418 10.5625H19V9.0625H15.6793L16.3869 5H14.8643L14.1567 9.0625H10.8667L11.5744 5H10.0518L9.34417 9.0625H5V10.5625H9.0829L8.54254 13.6648H5V15.1648H8.28127ZM10.0651 13.6648H13.3551L13.8954 10.5625H10.6055L10.0651 13.6648Z',
    })
  );
};
Hashtag.displayName = 'Hashtag';
exports['default'] = Hashtag;
