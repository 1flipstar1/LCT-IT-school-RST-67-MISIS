'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var DragVerticalDots = function DragVerticalDots(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M10 17C9.44772 17 9 17.4477 9 18C9 18.5523 9.44772 19 10 19C10.5523 19 11 18.5523 11 18C11 17.4477 10.5523 17 10 17ZM13 18C13 17.4477 13.4477 17 14 17C14.5523 17 15 17.4477 15 18C15 18.5523 14.5523 19 14 19C13.4477 19 13 18.5523 13 18ZM14 13C13.4477 13 13 13.4477 13 14C13 14.5523 13.4477 15 14 15C14.5523 15 15 14.5523 15 14C15 13.4477 14.5523 13 14 13ZM14 9C13.4477 9 13 9.44771 13 10C13 10.5523 13.4477 11 14 11C14.5523 11 15 10.5523 15 10C15 9.44772 14.5523 9 14 9ZM9 14C9 13.4477 9.44772 13 10 13C10.5523 13 11 13.4477 11 14C11 14.5523 10.5523 15 10 15C9.44772 15 9 14.5523 9 14ZM10 9C9.44772 9 9 9.44771 9 10C9 10.5523 9.44772 11 10 11C10.5523 11 11 10.5523 11 10C11 9.44772 10.5523 9 10 9ZM13 6C13 5.44771 13.4477 5 14 5C14.5523 5 15 5.44772 15 6C15 6.55228 14.5523 7 14 7C13.4477 7 13 6.55228 13 6ZM10 5C9.44772 5 9 5.44771 9 6C9 6.55228 9.44772 7 10 7C10.5523 7 11 6.55229 11 6C11 5.44772 10.5523 5 10 5Z',
    })
  );
};
DragVerticalDots.displayName = 'DragVerticalDots';
exports['default'] = DragVerticalDots;
