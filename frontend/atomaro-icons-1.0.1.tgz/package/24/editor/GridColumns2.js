'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var GridColumns2 = function GridColumns2(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M18 4.5H6C5.17157 4.5 4.5 5.17157 4.5 6V7.75H19.5V6C19.5 5.17157 18.8284 4.5 18 4.5ZM4.5 18V9.25H11.25V19.5H6C5.17157 19.5 4.5 18.8284 4.5 18ZM12.75 19.5H18C18.8284 19.5 19.5 18.8284 19.5 18V9.25H12.75V19.5ZM21 18V9.25V7.75V6C21 4.34315 19.6569 3 18 3H6C4.34315 3 3 4.34315 3 6V18C3 19.6569 4.34315 21 6 21H18C19.6569 21 21 19.6569 21 18Z',
    })
  );
};
GridColumns2.displayName = 'GridColumns2';
exports['default'] = GridColumns2;
