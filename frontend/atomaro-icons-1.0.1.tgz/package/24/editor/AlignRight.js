'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var AlignRight = function AlignRight(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M20 5H4V6.55556H20V5ZM10 9.22222H20V10.7778H10V9.22222Z',
    }),
    ',',
    react_1['default'].createElement('path', {
      d: 'M20 17.4444H10V19H20V17.4444Z',
    }),
    ',',
    react_1['default'].createElement('path', {
      d: 'M20 13.5H4V15.0556H20V13.5Z',
    })
  );
};
AlignRight.displayName = 'AlignRight';
exports['default'] = AlignRight;
