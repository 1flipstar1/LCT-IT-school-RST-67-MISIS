'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Array = function Array(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M1.00098 5.99976C1.00098 4.89519 1.89641 3.99976 3.00098 3.99976H4.99976V5.49976H3.00098C2.72483 5.49976 2.50098 5.72361 2.50098 5.99976V18.0005C2.50098 18.2766 2.72483 18.5005 3.00098 18.5005H4.99976V20.0005H3.00098C1.89641 20.0005 1.00098 19.105 1.00098 18.0005V5.99976ZM22.9978 5.99976C22.9978 4.89519 22.1024 3.99976 20.9978 3.99976H18.9998V5.49976H20.9978C21.2739 5.49976 21.4978 5.72361 21.4978 5.99976V18.0005C21.4978 18.2766 21.2739 18.5005 20.9978 18.5005H18.9998V20.0005H20.9978C22.1024 20.0005 22.9978 19.105 22.9978 18.0005V5.99976ZM12 13.25C12.6904 13.25 13.25 12.6904 13.25 12C13.25 11.3096 12.6904 10.75 12 10.75C11.3096 10.75 10.75 11.3096 10.75 12C10.75 12.6904 11.3096 13.25 12 13.25ZM7.5 13.25C8.19036 13.25 8.75 12.6904 8.75 12C8.75 11.3097 8.19036 10.75 7.5 10.75C6.80964 10.75 6.25 11.3097 6.25 12C6.25 12.6904 6.80964 13.25 7.5 13.25ZM17.7502 12C17.7502 12.6904 17.1905 13.25 16.5002 13.25C15.8098 13.25 15.2502 12.6904 15.2502 12C15.2502 11.3096 15.8098 10.75 16.5002 10.75C17.1905 10.75 17.7502 11.3096 17.7502 12Z',
    })
  );
};
Array.displayName = 'Array';
exports['default'] = Array;
