'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var GridTablet = function GridTablet(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M18 4.5H6C5.17157 4.5 4.5 5.17157 4.5 6V7.75H19.5V6C19.5 5.17157 18.8284 4.5 18 4.5ZM4.5 13.5039V9.25H8.53508V13.5039H4.5ZM4.5 15.0039V18C4.5 18.8284 5.17157 19.5 6 19.5H8.53508V15.0039H4.5ZM10.0351 15.0039V19.5H13.9966V15.0039H10.0351ZM15.4966 15.0039V19.5H18C18.8284 19.5 19.5 18.8284 19.5 18V15.0039H15.4966ZM19.5 13.5039H15.4966V9.25H19.5V13.5039ZM21 13.5039V15.0039V18C21 19.6569 19.6569 21 18 21H6C4.34315 21 3 19.6569 3 18V6C3 4.34315 4.34315 3 6 3H18C19.6569 3 21 4.34315 21 6V7.75V9.25V13.5039ZM13.9966 13.5039H10.0351V9.25H13.9966V13.5039Z',
    })
  );
};
GridTablet.displayName = 'GridTablet';
exports['default'] = GridTablet;
