'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Edit = function Edit(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M18.2407 5.86993L17.2857 4.82794C16.9165 4.42513 16.2924 4.3932 15.884 4.75624L14.3213 6.14562L16.6194 8.68268L18.1714 7.28979C18.5854 6.91818 18.6166 6.28008 18.2407 5.86993ZM5.5 13.9881L13.2002 7.1423L15.5031 9.68459L7.90674 16.5024H5.5V13.9881ZM19.3465 4.85645L18.3915 3.81446C17.4686 2.80744 15.9083 2.72762 14.8874 3.63521L4.33557 13.0163C4.12212 13.206 4 13.478 4 13.7636V17.0024C4 17.5547 4.44772 18.0024 5 18.0024H8.09822C8.34478 18.0024 8.58266 17.9113 8.76616 17.7466L19.1733 8.40612C20.2084 7.47709 20.2863 5.88184 19.3465 4.85645ZM20 19.4998H4V20.9998H20V19.4998Z',
    })
  );
};
Edit.displayName = 'Edit';
exports['default'] = Edit;
