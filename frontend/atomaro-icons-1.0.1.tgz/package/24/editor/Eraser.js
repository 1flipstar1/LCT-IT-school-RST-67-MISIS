'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Eraser = function Eraser(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M14.5 3.62129L9.09099 9.0303L13.9706 13.9099L19.3788 8.50012L14.5 3.62129ZM4.12132 14L8.03033 10.091L12.91 14.9707L11.3788 16.5023L6.62159 16.5002L4.12132 14ZM20.793 7.79296L15.2071 2.20708C14.8166 1.81655 14.1834 1.81655 13.7929 2.20708L2.70711 13.2929C2.31658 13.6834 2.31658 14.3166 2.70711 14.7071L5.70729 17.7073C5.89472 17.8947 6.1489 18 6.41396 18.0002L11.5855 18.0024C11.8509 18.0025 12.1054 17.8971 12.2931 17.7094L20.7931 9.20708C21.1835 8.81654 21.1835 8.18345 20.793 7.79296ZM21 19.5H6V21H21V19.5Z',
    })
  );
};
Eraser.displayName = 'Eraser';
exports['default'] = Eraser;
