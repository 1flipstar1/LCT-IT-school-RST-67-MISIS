'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var CompareAdded = function CompareAdded(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      d: 'M4 6.25H20V7.75H4V6.25Z',
    }),
    ',',
    react_1['default'].createElement('path', {
      d: 'M15 11.25H4V12.75H15V11.25Z',
    }),
    ',',
    react_1['default'].createElement('path', {
      d: 'M11 16.25L4 16.25V17.75L11 17.75V16.25Z',
    }),
    ',',
    react_1['default'].createElement('path', {
      d: 'M18.5304 19.0304L22.5304 15.0304L21.4697 13.9697L18 17.4394L16.5301 15.9696L15.4695 17.0303L17.4697 19.0304C17.7626 19.3233 18.2375 19.3233 18.5304 19.0304Z',
    })
  );
};
CompareAdded.displayName = 'CompareAdded';
exports['default'] = CompareAdded;
