'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var ColumnDelete = function ColumnDelete(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M16.0001 17.0607L19.9697 21.0303L21.0304 19.9697L4.03039 2.96967L2.96973 4.03033L8.00006 9.06066V20.25C8.00006 20.6642 8.33584 21 8.75006 21H15.2501C15.6643 21 16.0001 20.6642 16.0001 20.25V17.0607ZM14.5001 15.5607V19.5H9.50006L9.50006 10.5607L14.5001 15.5607ZM16.0001 3.75V12.9393L14.5001 11.4393V4.5L9.50006 4.5V6.43928L8.00006 4.93928V3.75C8.00006 3.33578 8.33584 3 8.75006 3H15.2501C15.6643 3 16.0001 3.33578 16.0001 3.75Z',
    })
  );
};
ColumnDelete.displayName = 'ColumnDelete';
exports['default'] = ColumnDelete;
