'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Crop = function Crop(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M5.50049 6.9994V15.4989C5.50049 17.1557 6.84364 18.4989 8.50049 18.4989H17.0005V22H18.5005V18.4989H21.9991V16.9989H8.50049C7.67206 16.9989 7.00049 16.3273 7.00049 15.4989V2H5.50049V5.4994H2.00009V6.9994H5.50049ZM18.5005 15V8.4994C18.5005 6.84255 17.1573 5.4994 15.5005 5.4994H9V6.9994H15.5005C16.3289 6.9994 17.0005 7.67098 17.0005 8.4994V15H18.5005Z',
    })
  );
};
Crop.displayName = 'Crop';
exports['default'] = Crop;
