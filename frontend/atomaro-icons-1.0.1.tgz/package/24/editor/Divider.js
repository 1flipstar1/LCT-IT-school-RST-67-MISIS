'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Divider = function Divider(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M18 4.5H6C5.72386 4.5 5.5 4.72386 5.5 5V7C5.5 7.27614 5.72386 7.5 6 7.5H18C18.2761 7.5 18.5 7.27614 18.5 7V5C18.5 4.72386 18.2761 4.5 18 4.5ZM6 3C4.89543 3 4 3.89543 4 5V7C4 8.10457 4.89543 9 6 9H18C19.1046 9 20 8.10457 20 7V5C20 3.89543 19.1046 3 18 3H6ZM18 16.5H6C5.72386 16.5 5.5 16.7239 5.5 17V19C5.5 19.2761 5.72386 19.5 6 19.5H18C18.2761 19.5 18.5 19.2761 18.5 19V17C18.5 16.7239 18.2761 16.5 18 16.5ZM6 15C4.89543 15 4 15.8954 4 17V19C4 20.1046 4.89543 21 6 21H18C19.1046 21 20 20.1046 20 19V17C20 15.8954 19.1046 15 18 15H6ZM22 11.25H2V12.75H22V11.25Z',
    })
  );
};
Divider.displayName = 'Divider';
exports['default'] = Divider;
