'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var GridPanelRight = function GridPanelRight(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M16.25 4.5L18 4.5C18.8284 4.5 19.5 5.17158 19.5 6L19.5 18C19.5 18.8284 18.8284 19.5 18 19.5H16.25L16.25 4.5ZM14.75 4.5L6 4.5C5.17158 4.5 4.5 5.17157 4.5 6L4.5 18C4.5 18.8284 5.17157 19.5 6 19.5L14.75 19.5L14.75 4.5ZM14.75 21H6C4.34315 21 3 19.6569 3 18L3 6C3 4.34315 4.34315 3 6 3L18 3C19.6569 3 21 4.34315 21 6L21 18C21 19.6569 19.6569 21 18 21L16.25 21H14.75Z',
    })
  );
};
GridPanelRight.displayName = 'GridPanelRight';
exports['default'] = GridPanelRight;
