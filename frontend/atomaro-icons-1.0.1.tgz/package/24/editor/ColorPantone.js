'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var ColorPantone = function ColorPantone(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M6 4.5H9C9.82843 4.5 10.5 5.17157 10.5 6V16.5C10.5 18.1569 9.15685 19.5 7.5 19.5C5.84315 19.5 4.5 18.1569 4.5 16.5V6C4.5 5.17157 5.17157 4.5 6 4.5ZM7.49991 21H7.5H17.9999C19.6568 21 20.9999 19.6569 20.9999 18V15C20.9999 13.4545 19.8313 12.182 18.3295 12.0179C19.3173 10.8392 19.2572 9.08013 18.1492 7.97211L16.0279 5.85079C14.9199 4.74277 13.1608 4.68266 11.9821 5.67045C11.818 4.16865 10.5455 3 9 3H6C4.34315 3 3 4.34315 3 6V16.5C3 17.6525 3.43328 18.7039 4.14584 19.5H4.14575C4.96973 20.4206 6.16716 21 7.49991 21ZM17.9999 13.5H16.8639L11 19.364V19.3287C10.9528 19.387 10.9042 19.4441 10.8542 19.5H12.9999H17.9999C18.8283 19.5 19.4999 18.8284 19.4999 18V15C19.4999 14.1716 18.8283 13.5 17.9999 13.5ZM12 16.2426L17.0885 11.1541C17.6743 10.5683 17.6743 9.61855 17.0885 9.03277L14.9672 6.91145C14.3814 6.32566 13.4317 6.32566 12.8459 6.91145L12 7.75734V16.2426ZM7.5 17.5C8.05228 17.5 8.5 17.0523 8.5 16.5C8.5 15.9477 8.05228 15.5 7.5 15.5C6.94772 15.5 6.5 15.9477 6.5 16.5C6.5 17.0523 6.94772 17.5 7.5 17.5Z',
    })
  );
};
ColorPantone.displayName = 'ColorPantone';
exports['default'] = ColorPantone;
