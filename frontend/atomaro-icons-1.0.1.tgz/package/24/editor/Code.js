'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Code = function Code(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M13.0159 5.02109L9.54237 18.6213L10.9957 18.9925L14.4692 5.39227L13.0159 5.02109ZM20.9396 12.0001L16.9697 8.03033L18.0303 6.96965L22.5306 11.4698C22.6713 11.6104 22.7503 11.8012 22.7503 12.0001C22.7503 12.1991 22.6713 12.3898 22.5306 12.5305L18.0303 17.0303L16.9697 15.9696L20.9396 12.0001ZM1.47012 11.4698L5.96963 6.96969L7.03037 8.03028L3.06109 12.0001L7.03035 15.9697L5.96965 17.0303L1.47014 12.5304C1.17728 12.2375 1.17727 11.7627 1.47012 11.4698Z',
    })
  );
};
Code.displayName = 'Code';
exports['default'] = Code;
