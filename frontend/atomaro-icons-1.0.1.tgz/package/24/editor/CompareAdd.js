'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var CompareAdd = function CompareAdd(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      d: 'M3.99951 6.25H19.9995V7.75H3.99951V6.25Z',
    }),
    ',',
    react_1['default'].createElement('path', {
      d: 'M14.9995 11.25H3.99951V12.75H14.9995V11.25Z',
    }),
    ',',
    react_1['default'].createElement('path', {
      d: 'M10.9995 16.25L3.99951 16.25V17.75L10.9995 17.75V16.25Z',
    }),
    ',',
    react_1['default'].createElement('path', {
      d: 'M19.7499 20L19.75 17.75L22 17.7499L22 16.2499L19.75 16.25L19.7501 14L18.2501 14L18.25 16.25L16 16.2501L16 17.75L18.25 17.75L18.2499 20L19.7499 20Z',
    })
  );
};
CompareAdd.displayName = 'CompareAdd';
exports['default'] = CompareAdd;
