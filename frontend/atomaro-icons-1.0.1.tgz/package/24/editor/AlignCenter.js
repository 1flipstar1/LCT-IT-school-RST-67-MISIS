'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var AlignCenter = function AlignCenter(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M20 5H4V6.55556H20V5ZM7 9.22222H17V10.7778H7V9.22222Z',
    }),
    ',',
    react_1['default'].createElement('path', {
      d: 'M17 17.4444H7V19H17V17.4444Z',
    }),
    ',',
    react_1['default'].createElement('path', {
      d: 'M20 13.4444H4V15H20V13.4444Z',
    })
  );
};
AlignCenter.displayName = 'AlignCenter';
exports['default'] = AlignCenter;
