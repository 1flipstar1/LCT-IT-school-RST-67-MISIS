'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Diamond = function Diamond(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M5.71893 5.5L3.05066 9.5063H6.99575L8.06169 5.5H5.71893ZM8.46079 4H5.18346C5.0162 4 4.86002 4.08363 4.76731 4.22284L1.08386 9.75339C0.956343 9.94484 0.975909 10.1986 1.13126 10.3682L11.6327 21.8355C11.8309 22.0519 12.172 22.0519 12.3702 21.8355L22.8716 10.3682C23.027 10.1986 23.0465 9.94484 22.919 9.75339L19.2356 4.22284C19.1429 4.08363 18.9867 4 18.8194 4H15.5465H8.46079ZM14.3937 5.5H9.61388L8.54793 9.5063H15.4608L14.3937 5.5ZM17.0131 9.5063L15.946 5.5H18.284L20.9522 9.5063H17.0131ZM15.3589 11.0063H8.64419L12.003 18.1891L15.3589 11.0063ZM6.98829 11.0063H3.74953L10.3677 18.2332L6.98829 11.0063ZM13.6411 18.2266L17.0145 11.0063H20.2534L13.6411 18.2266Z',
    })
  );
};
Diamond.displayName = 'Diamond';
exports['default'] = Diamond;
