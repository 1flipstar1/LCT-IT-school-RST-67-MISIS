'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Invoice = function Invoice(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M20 4.5L22 4.5V3H2V4.5L4.01562 4.5V20.25C4.01562 20.515 4.15549 20.7603 4.38355 20.8954C4.61161 21.0304 4.89398 21.035 5.12634 20.9075L7.45343 19.631L9.2302 20.8658C9.47875 21.0386 9.80679 21.045 10.0619 20.8821L12.0071 19.6398L13.9531 20.8821C14.2081 21.045 14.536 21.0386 14.7846 20.8659L16.5621 19.6309L18.8893 20.9075C19.1216 21.035 19.404 21.0304 19.6321 20.8954C19.8601 20.7603 20 20.515 20 20.25V4.5ZM18.5 4.5L5.51562 4.5V18.9831L7.13928 18.0924C7.38881 17.9555 7.69432 17.9717 7.92803 18.1341L9.67582 19.3489L11.6034 18.1179C11.8495 17.9607 12.1645 17.9607 12.4106 18.1178L14.339 19.3489L16.0877 18.134C16.3214 17.9717 16.6269 17.9556 16.8763 18.0924L18.5 18.9831V4.5ZM8 9.5H16V8H8V9.5ZM12 13.5H8V12H12V13.5Z',
    })
  );
};
Invoice.displayName = 'Invoice';
exports['default'] = Invoice;
