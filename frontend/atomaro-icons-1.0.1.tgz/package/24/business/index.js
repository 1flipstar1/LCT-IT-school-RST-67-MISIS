"use strict";

var __importDefault = this && this.__importDefault || function (mod) {
  return mod && mod.__esModule ? mod : {
    "default": mod
  };
};
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ZeroRuble = exports.Wallet = exports.WalletOld = exports.VIP = exports.Union = exports.Tie = exports.Stickers = exports.StatisticsLine = exports.StatisticsCurve = exports.StatisticsColumn = exports.StatisticsCircular = exports.StatisticsBoard = exports.Split = exports.Shuffle = exports.ShoppingBasket = exports.Ruble = exports.Reuse = exports.Promocode = exports.Present = exports.Postcard = exports.Portfolio = exports.Percentage = exports.PaymentCard = exports.PaymentCardToCard = exports.PaymentCardRuble = exports.PaymentCardPercent = exports.Motion = exports.Merge = exports.Invoice = exports.HandHeart = exports.HandCoins = exports.Group = exports.Euro = exports.Dollar = exports.Diamond = exports.DeliveryEnvelope = exports.DeliveryCourier = exports.DeliveryBox = exports.CoworkingSitting = exports.Coupon = exports.Cart = exports.CartOn = exports.Calculator = exports.BoardText = void 0;
var BoardText_1 = require("./BoardText");
Object.defineProperty(exports, "BoardText", {
  enumerable: true,
  get: function get() {
    return __importDefault(BoardText_1)["default"];
  }
});
var Calculator_1 = require("./Calculator");
Object.defineProperty(exports, "Calculator", {
  enumerable: true,
  get: function get() {
    return __importDefault(Calculator_1)["default"];
  }
});
var CartOn_1 = require("./CartOn");
Object.defineProperty(exports, "CartOn", {
  enumerable: true,
  get: function get() {
    return __importDefault(CartOn_1)["default"];
  }
});
var Cart_1 = require("./Cart");
Object.defineProperty(exports, "Cart", {
  enumerable: true,
  get: function get() {
    return __importDefault(Cart_1)["default"];
  }
});
var Coupon_1 = require("./Coupon");
Object.defineProperty(exports, "Coupon", {
  enumerable: true,
  get: function get() {
    return __importDefault(Coupon_1)["default"];
  }
});
var CoworkingSitting_1 = require("./CoworkingSitting");
Object.defineProperty(exports, "CoworkingSitting", {
  enumerable: true,
  get: function get() {
    return __importDefault(CoworkingSitting_1)["default"];
  }
});
var DeliveryBox_1 = require("./DeliveryBox");
Object.defineProperty(exports, "DeliveryBox", {
  enumerable: true,
  get: function get() {
    return __importDefault(DeliveryBox_1)["default"];
  }
});
var DeliveryCourier_1 = require("./DeliveryCourier");
Object.defineProperty(exports, "DeliveryCourier", {
  enumerable: true,
  get: function get() {
    return __importDefault(DeliveryCourier_1)["default"];
  }
});
var DeliveryEnvelope_1 = require("./DeliveryEnvelope");
Object.defineProperty(exports, "DeliveryEnvelope", {
  enumerable: true,
  get: function get() {
    return __importDefault(DeliveryEnvelope_1)["default"];
  }
});
var Diamond_1 = require("./Diamond");
Object.defineProperty(exports, "Diamond", {
  enumerable: true,
  get: function get() {
    return __importDefault(Diamond_1)["default"];
  }
});
var Dollar_1 = require("./Dollar");
Object.defineProperty(exports, "Dollar", {
  enumerable: true,
  get: function get() {
    return __importDefault(Dollar_1)["default"];
  }
});
var Euro_1 = require("./Euro");
Object.defineProperty(exports, "Euro", {
  enumerable: true,
  get: function get() {
    return __importDefault(Euro_1)["default"];
  }
});
var Group_1 = require("./Group");
Object.defineProperty(exports, "Group", {
  enumerable: true,
  get: function get() {
    return __importDefault(Group_1)["default"];
  }
});
var HandCoins_1 = require("./HandCoins");
Object.defineProperty(exports, "HandCoins", {
  enumerable: true,
  get: function get() {
    return __importDefault(HandCoins_1)["default"];
  }
});
var HandHeart_1 = require("./HandHeart");
Object.defineProperty(exports, "HandHeart", {
  enumerable: true,
  get: function get() {
    return __importDefault(HandHeart_1)["default"];
  }
});
var Invoice_1 = require("./Invoice");
Object.defineProperty(exports, "Invoice", {
  enumerable: true,
  get: function get() {
    return __importDefault(Invoice_1)["default"];
  }
});
var Merge_1 = require("./Merge");
Object.defineProperty(exports, "Merge", {
  enumerable: true,
  get: function get() {
    return __importDefault(Merge_1)["default"];
  }
});
var Motion_1 = require("./Motion");
Object.defineProperty(exports, "Motion", {
  enumerable: true,
  get: function get() {
    return __importDefault(Motion_1)["default"];
  }
});
var PaymentCardPercent_1 = require("./PaymentCardPercent");
Object.defineProperty(exports, "PaymentCardPercent", {
  enumerable: true,
  get: function get() {
    return __importDefault(PaymentCardPercent_1)["default"];
  }
});
var PaymentCardRuble_1 = require("./PaymentCardRuble");
Object.defineProperty(exports, "PaymentCardRuble", {
  enumerable: true,
  get: function get() {
    return __importDefault(PaymentCardRuble_1)["default"];
  }
});
var PaymentCardToCard_1 = require("./PaymentCardToCard");
Object.defineProperty(exports, "PaymentCardToCard", {
  enumerable: true,
  get: function get() {
    return __importDefault(PaymentCardToCard_1)["default"];
  }
});
var PaymentCard_1 = require("./PaymentCard");
Object.defineProperty(exports, "PaymentCard", {
  enumerable: true,
  get: function get() {
    return __importDefault(PaymentCard_1)["default"];
  }
});
var Percentage_1 = require("./Percentage");
Object.defineProperty(exports, "Percentage", {
  enumerable: true,
  get: function get() {
    return __importDefault(Percentage_1)["default"];
  }
});
var Portfolio_1 = require("./Portfolio");
Object.defineProperty(exports, "Portfolio", {
  enumerable: true,
  get: function get() {
    return __importDefault(Portfolio_1)["default"];
  }
});
var Postcard_1 = require("./Postcard");
Object.defineProperty(exports, "Postcard", {
  enumerable: true,
  get: function get() {
    return __importDefault(Postcard_1)["default"];
  }
});
var Present_1 = require("./Present");
Object.defineProperty(exports, "Present", {
  enumerable: true,
  get: function get() {
    return __importDefault(Present_1)["default"];
  }
});
var Promocode_1 = require("./Promocode");
Object.defineProperty(exports, "Promocode", {
  enumerable: true,
  get: function get() {
    return __importDefault(Promocode_1)["default"];
  }
});
var Reuse_1 = require("./Reuse");
Object.defineProperty(exports, "Reuse", {
  enumerable: true,
  get: function get() {
    return __importDefault(Reuse_1)["default"];
  }
});
var Ruble_1 = require("./Ruble");
Object.defineProperty(exports, "Ruble", {
  enumerable: true,
  get: function get() {
    return __importDefault(Ruble_1)["default"];
  }
});
var ShoppingBasket_1 = require("./ShoppingBasket");
Object.defineProperty(exports, "ShoppingBasket", {
  enumerable: true,
  get: function get() {
    return __importDefault(ShoppingBasket_1)["default"];
  }
});
var Shuffle_1 = require("./Shuffle");
Object.defineProperty(exports, "Shuffle", {
  enumerable: true,
  get: function get() {
    return __importDefault(Shuffle_1)["default"];
  }
});
var Split_1 = require("./Split");
Object.defineProperty(exports, "Split", {
  enumerable: true,
  get: function get() {
    return __importDefault(Split_1)["default"];
  }
});
var StatisticsBoard_1 = require("./StatisticsBoard");
Object.defineProperty(exports, "StatisticsBoard", {
  enumerable: true,
  get: function get() {
    return __importDefault(StatisticsBoard_1)["default"];
  }
});
var StatisticsCircular_1 = require("./StatisticsCircular");
Object.defineProperty(exports, "StatisticsCircular", {
  enumerable: true,
  get: function get() {
    return __importDefault(StatisticsCircular_1)["default"];
  }
});
var StatisticsColumn_1 = require("./StatisticsColumn");
Object.defineProperty(exports, "StatisticsColumn", {
  enumerable: true,
  get: function get() {
    return __importDefault(StatisticsColumn_1)["default"];
  }
});
var StatisticsCurve_1 = require("./StatisticsCurve");
Object.defineProperty(exports, "StatisticsCurve", {
  enumerable: true,
  get: function get() {
    return __importDefault(StatisticsCurve_1)["default"];
  }
});
var StatisticsLine_1 = require("./StatisticsLine");
Object.defineProperty(exports, "StatisticsLine", {
  enumerable: true,
  get: function get() {
    return __importDefault(StatisticsLine_1)["default"];
  }
});
var Stickers_1 = require("./Stickers");
Object.defineProperty(exports, "Stickers", {
  enumerable: true,
  get: function get() {
    return __importDefault(Stickers_1)["default"];
  }
});
var Tie_1 = require("./Tie");
Object.defineProperty(exports, "Tie", {
  enumerable: true,
  get: function get() {
    return __importDefault(Tie_1)["default"];
  }
});
var Union_1 = require("./Union");
Object.defineProperty(exports, "Union", {
  enumerable: true,
  get: function get() {
    return __importDefault(Union_1)["default"];
  }
});
var VIP_1 = require("./VIP");
Object.defineProperty(exports, "VIP", {
  enumerable: true,
  get: function get() {
    return __importDefault(VIP_1)["default"];
  }
});
var WalletOld_1 = require("./WalletOld");
Object.defineProperty(exports, "WalletOld", {
  enumerable: true,
  get: function get() {
    return __importDefault(WalletOld_1)["default"];
  }
});
var Wallet_1 = require("./Wallet");
Object.defineProperty(exports, "Wallet", {
  enumerable: true,
  get: function get() {
    return __importDefault(Wallet_1)["default"];
  }
});
var ZeroRuble_1 = require("./ZeroRuble");
Object.defineProperty(exports, "ZeroRuble", {
  enumerable: true,
  get: function get() {
    return __importDefault(ZeroRuble_1)["default"];
  }
});