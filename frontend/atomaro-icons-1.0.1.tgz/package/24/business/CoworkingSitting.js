'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var CoworkingSitting = function CoworkingSitting(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M6.50195 6.5C7.05424 6.5 7.50195 6.05228 7.50195 5.5C7.50195 4.94772 7.05424 4.5 6.50195 4.5C5.94967 4.5 5.50195 4.94772 5.50195 5.5C5.50195 6.05228 5.94967 6.5 6.50195 6.5ZM6.50195 8C7.88267 8 9.00195 6.88071 9.00195 5.5C9.00195 4.11929 7.88267 3 6.50195 3C5.12124 3 4.00195 4.11929 4.00195 5.5C4.00195 6.88071 5.12124 8 6.50195 8ZM12.5 20.5V16.0156C12.5 15.7395 12.2761 15.5156 12 15.5156H9.71652C8.49237 15.5156 7.5 14.5233 7.5 13.2991V11.5C7.5 10.9477 7.05228 10.5 6.5 10.5C5.94772 10.5 5.5 10.9477 5.5 11.5V14.6654C5.5 15.3654 6.03966 15.9394 6.72562 15.9939H9.21181C10.0211 15.9939 10.7249 16.5489 10.9136 17.3359L10.9799 17.6124C11.0189 17.7155 11.0514 17.8221 11.0769 17.9319L11.6741 20.5H12.5ZM4 12H3.02344L3.9865 15.7971C4.09372 16.2198 4.3167 16.5889 4.61638 16.8739L3.45756 22H4.99541L6.01523 17.4888C6.0656 17.4922 6.11636 17.4939 6.16744 17.4939H6.67639C6.72814 17.4967 6.78026 17.4981 6.83271 17.4981H8.6419C9.03663 17.4981 9.38715 17.7291 9.54852 18.076L10.2756 21.1085L10.303 21.2265C10.3067 21.2423 10.3107 21.2579 10.3151 21.2733L10.4893 22H11.2771H12.0319H13C13.5523 22 14 21.5523 14 21V16.0156C14 14.9111 13.1046 14.0156 12 14.0156H9.71652C9.3208 14.0156 9 13.6948 9 13.2991V11.5C9 10.1193 7.88071 9 6.5 9C5.11929 9 4 10.1193 4 11.5V12ZM17.54 11.02H18.2622C19.7046 11.02 20.7744 12.3581 20.4571 13.7651L18.9955 20.2451C18.7641 21.2712 17.8525 22 16.8006 22H16V20.5H16.8006C17.1513 20.5 17.4551 20.2571 17.5323 19.915L18.9938 13.435C19.0996 12.966 18.743 12.52 18.2622 12.52H13V11.02H15.9901L17.5554 4.99881L19.0071 5.37619L17.54 11.02Z',
    })
  );
};
CoworkingSitting.displayName = 'CoworkingSitting';
exports['default'] = CoworkingSitting;
