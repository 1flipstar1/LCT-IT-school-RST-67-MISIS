'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var DeliveryBox = function DeliveryBox(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M3.5 5.5V8.50704H20.5V5.5H3.5ZM2.25 4C2.11193 4 2 4.11193 2 4.25V9.75704C2 9.89511 2.11193 10.007 2.25 10.007H3V18.0186C3 19.1231 3.89543 20.0186 5 20.0186H19C20.1046 20.0186 21 19.1231 21 18.0186V10.007H21.75C21.8881 10.007 22 9.89511 22 9.75704V4.25C22 4.11193 21.8881 4 21.75 4H2.25ZM4.5 18.0186V10.007H19.5V18.0186C19.5 18.2947 19.2761 18.5186 19 18.5186H5C4.72386 18.5186 4.5 18.2947 4.5 18.0186ZM10 11C9.44772 11 9 11.4477 9 12C9 12.5523 9.44772 13 10 13H14C14.5523 13 15 12.5523 15 12C15 11.4477 14.5523 11 14 11H10Z',
    })
  );
};
DeliveryBox.displayName = 'DeliveryBox';
exports['default'] = DeliveryBox;
