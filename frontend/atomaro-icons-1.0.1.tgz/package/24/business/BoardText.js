'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var BoardText = function BoardText(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M12.75 2L12.75 4H21C21.5523 4 22 4.44772 22 5V15C22 16.6569 20.6569 18 19 18H14.7253L15.4434 20.6005L13.9975 20.9997L13.1692 18H10.8236L9.99526 20.9997L8.54938 20.6004L9.26746 18H5C3.34315 18 2 16.6569 2 15V5C2 4.44772 2.44772 4 3 4H11.25L11.25 2H12.75ZM3.5 15V5.5H20.5V15C20.5 15.8284 19.8284 16.5 19 16.5H5C4.17157 16.5 3.5 15.8284 3.5 15ZM12 11.5H8V13H12V11.5ZM8 8.5V10H16V8.5H8Z',
    })
  );
};
BoardText.displayName = 'BoardText';
exports['default'] = BoardText;
