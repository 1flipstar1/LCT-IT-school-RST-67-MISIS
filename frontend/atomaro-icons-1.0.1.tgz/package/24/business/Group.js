'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Group = function Group(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M19.2139 7.99991L12.7581 3.80372C12.2923 3.50099 11.7062 3.501 11.2405 3.80375L4.78568 7.99968L11.2405 12.1958C11.7062 12.4986 12.2923 12.4986 12.7581 12.1959L19.2139 7.99991ZM13.5168 2.48605C12.5853 1.8806 11.4131 1.88063 10.4817 2.48611L3.35122 7.12124C2.73335 7.52289 2.73335 8.47641 3.35121 8.87807L10.4817 13.5134C11.4131 14.1189 12.5853 14.119 13.5168 13.5136L20.6484 8.87838C21.2664 8.47676 21.2664 7.52313 20.6484 7.12148L13.5168 2.48605ZM12.094 16.451L20.2601 11.5374L20.9979 12.8594L12.8318 17.773C12.303 18.0912 11.6511 18.0934 11.1202 17.7789L3.00666 12.9724L3.73591 11.6453L11.8495 16.4518C11.9253 16.4968 12.0184 16.4964 12.094 16.451ZM20.2363 15.3661L12.0842 20.427C12.0086 20.4739 11.9146 20.4751 11.8379 20.4301L3.73091 15.6758L3.00766 17.0066L11.1147 21.761C11.6516 22.0758 12.3097 22.0674 12.839 21.7388L20.991 16.678L20.2363 15.3661Z',
    })
  );
};
Group.displayName = 'Group';
exports['default'] = Group;
