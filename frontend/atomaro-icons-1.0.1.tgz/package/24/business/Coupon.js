'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Coupon = function Coupon(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M4 6.5H14.75V8.5H16.25V6.5H20C20.2761 6.5 20.5 6.72386 20.5 7V8.64494C19.0543 9.07521 18 10.4145 18 12C18 13.5855 19.0543 14.9248 20.5 15.3551V17C20.5 17.2761 20.2761 17.5 20 17.5H16.25V15.5H14.75V17.5H4C3.72386 17.5 3.5 17.2761 3.5 17V15.3551C4.94574 14.9248 6 13.5855 6 12C6 10.4145 4.94574 9.07521 3.5 8.64494V7C3.5 6.72386 3.72386 6.5 4 6.5ZM22 9V8.75V7C22 5.89543 21.1046 5 20 5H4C2.89543 5 2 5.89543 2 7V8.75V9V9.75C2 9.88807 2.11193 10 2.25 10H2.5C3.60457 10 4.5 10.8954 4.5 12C4.5 13.1046 3.60457 14 2.5 14H2.25C2.11193 14 2 14.1119 2 14.25V15V15.25V17C2 18.1046 2.89543 19 4 19H20C21.1046 19 22 18.1046 22 17V15.25V15V14.25C22 14.1119 21.8881 14 21.75 14H21.5C20.3954 14 19.5 13.1046 19.5 12C19.5 10.8954 20.3954 10 21.5 10H21.75C21.8881 10 22 9.88807 22 9.75V9ZM14.75 14H16.25V10H14.75V14Z',
    })
  );
};
Coupon.displayName = 'Coupon';
exports['default'] = Coupon;
