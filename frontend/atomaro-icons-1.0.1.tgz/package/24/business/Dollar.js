'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Dollar = function Dollar(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      d: 'M10.9988 21H12.4988V19.24C15.1588 18.98 16.8988 17.26 16.8988 15.08C16.8988 12.92 15.3187 11.72 12.4988 11.12V6.28C13.7987 6.56 14.7987 7.48 15.2987 8.92L16.6188 8.14C15.9988 6.32 14.4987 5.08 12.4988 4.8V3H10.9988V4.74C8.55875 4.92 6.87875 6.36 6.87875 8.38C6.87875 10.6 8.59875 11.8 10.9988 12.32V17.74C9.17875 17.46 8.11875 16.16 7.71875 14.16L6.21875 14.94C6.67875 17.16 8.29875 18.94 10.9988 19.22V21ZM10.9988 10.78C9.45875 10.32 8.47875 9.6 8.47875 8.4C8.47875 7.14 9.51875 6.34 10.9988 6.2V10.78ZM12.4988 17.76V12.68C14.2787 13.14 15.2188 13.86 15.2188 15.2C15.2188 16.42 14.2388 17.54 12.4988 17.76Z',
    })
  );
};
Dollar.displayName = 'Dollar';
exports['default'] = Dollar;
