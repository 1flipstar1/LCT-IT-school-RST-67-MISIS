'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Cart = function Cart(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M6.35968 6.96333L5.48272 18.89C5.41879 19.7594 6.10692 20.5 6.97868 20.5H17.0211C17.8929 20.5 18.581 19.7594 18.5171 18.89L17.6403 6.96334C17.6211 6.70213 17.4035 6.5 17.1416 6.5H15.9955L15.9956 8.99994L14.4956 9L14.4955 6.5H9.50016L9.50006 9L8.00006 8.99994L8.00016 6.5H6.85833C6.59641 6.5 6.37889 6.70212 6.35968 6.96333ZM8.00023 5H6.85833C5.81066 5 4.94054 5.80849 4.86372 6.85334L3.98676 18.78C3.8589 20.5188 5.23516 22 6.97868 22H17.0211C18.7646 22 20.1409 20.5188 20.0131 18.78L19.1362 6.85336C19.0594 5.8085 18.1893 5 17.1416 5H15.9954L15.9954 4.74988C15.9953 3.23115 14.7641 2 13.2454 2H10.7502C9.2315 2 8.0003 3.23115 8.00024 4.74989L8.00023 5ZM9.50023 5L9.50024 4.74995C9.50027 4.05961 10.0599 3.5 10.7502 3.5H13.2454C13.9357 3.5 14.4954 4.05961 14.4954 4.74995L14.4954 5H9.50023Z',
    })
  );
};
Cart.displayName = 'Cart';
exports['default'] = Cart;
