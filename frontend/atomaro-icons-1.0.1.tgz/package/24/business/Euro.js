'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Euro = function Euro(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      d: 'M12.46 19.4038C15.32 19.4038 17.14 17.8038 17.96 15.1838L16.54 14.6638C15.8601 16.7038 14.64 17.9038 12.48 17.9038C10.26 17.9038 8.72005 16.4238 8.12005 14.2438H13.4L13.96 13.0038H7.88005C7.86005 12.7238 7.86005 12.4238 7.86005 12.1238C7.86005 11.8238 7.86005 11.5438 7.90005 11.2438H13.4L13.96 10.0038H8.12005C8.76005 7.82375 10.34 6.34375 12.52 6.34375C14.52 6.34375 15.92 7.28375 16.54 9.28375L18 8.66375C17.3 6.38375 15.5 4.84375 12.56 4.84375C9.56005 4.84375 7.20005 6.94375 6.44005 10.0038H5.36005L4.80005 11.2438H6.24005C6.20005 11.5438 6.18005 11.8238 6.18005 12.1238C6.18005 12.4238 6.20005 12.7238 6.22005 13.0038H5.36005L4.80005 14.2438H6.44005C7.12005 17.3238 9.36005 19.4038 12.46 19.4038Z',
    })
  );
};
Euro.displayName = 'Euro';
exports['default'] = Euro;
