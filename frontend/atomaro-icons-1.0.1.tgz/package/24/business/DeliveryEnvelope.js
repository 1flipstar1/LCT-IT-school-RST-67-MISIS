'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var DeliveryEnvelope = function DeliveryEnvelope(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M7 7.5C6.17157 7.5 5.5 6.82843 5.5 6V4.5H18.5V6C18.5 6.82843 17.8284 7.5 17 7.5H14.3202L13.9629 6.16647C13.9266 6.03097 13.7873 5.95055 13.6518 5.98686L9.31287 7.14948C9.17737 7.18578 9.09696 7.32506 9.13327 7.46056L9.14384 7.5H7ZM9.54576 9H7C6.45357 9 5.94126 8.85391 5.5 8.59865V18C5.5 18.8284 6.17157 19.5 7 19.5H17C17.8284 19.5 18.5 18.8284 18.5 18V8.59865C18.0587 8.85391 17.5464 9 17 9H14.7221L14.8667 9.53948C14.903 9.67498 14.8226 9.81426 14.6871 9.85056L10.3481 11.0132C10.2126 11.0495 10.0734 10.9691 10.0371 10.8336L9.54576 9ZM20 18V6V4C20 3.44772 19.5523 3 19 3H5C4.48223 3 4.05637 3.3935 4.00516 3.89776C4.00175 3.93137 4 3.96548 4 4V6V18C4 19.6569 5.34315 21 7 21H17C18.6569 21 20 19.6569 20 18ZM10 16.4995H7V17.9995H10V16.4995ZM11 16.4995H13V17.9995H11V16.4995ZM10.9046 8.27588L12.8365 7.75824L13.0953 8.72416L11.1635 9.2418L10.9046 8.27588Z',
    })
  );
};
DeliveryEnvelope.displayName = 'DeliveryEnvelope';
exports['default'] = DeliveryEnvelope;
