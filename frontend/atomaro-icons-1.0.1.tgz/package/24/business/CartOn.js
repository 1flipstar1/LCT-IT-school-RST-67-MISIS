'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var CartOn = function CartOn(props) {
  var _a = props.fill,
    fill = _a === void 0 ? '#0E1117' : _a,
    _b = props.secondaryColor,
    secondaryColor = _b === void 0 ? props.secondaryColor || '#D91528' : _b;
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props, {
      fill: fill,
    }),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M6.35968 6.96333L5.48272 18.89C5.41879 19.7594 6.10692 20.5 6.97868 20.5H17.0211C17.8929 20.5 18.581 19.7594 18.5171 18.89L17.6403 6.96334C17.6211 6.70213 17.4035 6.5 17.1416 6.5H9.50016L9.50006 9L8.00006 8.99994L8.00016 6.5H6.85833C6.59641 6.5 6.37889 6.70212 6.35968 6.96333ZM8.00023 5H6.85833C5.81066 5 4.94054 5.80849 4.86372 6.85334L3.98676 18.78C3.8589 20.5188 5.23516 22 6.97868 22H17.0211C18.7646 22 20.1409 20.5188 20.0131 18.78L19.1362 6.85336C19.0594 5.8085 18.1893 5 17.1416 5H15.9955L15.9955 4.74977C15.9953 3.23108 14.7642 2 13.2455 2H10.7502C9.2315 2 8.0003 3.23115 8.00024 4.74989L8.00023 5ZM9.50023 5L9.50024 4.74995C9.50027 4.05961 10.0599 3.5 10.7502 3.5H13.2455C13.9358 3.5 14.4954 4.05958 14.4955 4.7499L14.4955 5H9.50023Z',
    }),
    ',',
    react_1['default'].createElement('path', {
      d: 'M22 13C22 15.2091 20.2091 17 18 17C15.7909 17 14 15.2091 14 13C14 10.7909 15.7909 9 18 9C20.2091 9 22 10.7909 22 13Z',
      fill: secondaryColor,
    })
  );
};
CartOn.displayName = 'CartOn';
exports['default'] = CartOn;
