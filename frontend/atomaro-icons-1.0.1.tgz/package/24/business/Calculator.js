'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('../../Icon'));
var Calculator = function Calculator(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M4.5 6L4.5 18C4.5 18.8284 5.17157 19.5 6 19.5H18C18.8284 19.5 19.5 18.8284 19.5 18V6C19.5 5.17157 18.8284 4.5 18 4.5L6 4.5C5.17157 4.5 4.5 5.17157 4.5 6ZM3 18C3 19.6569 4.34315 21 6 21H18C19.6569 21 21 19.6569 21 18V6C21 4.34315 19.6569 3 18 3H6C4.34315 3 3 4.34315 3 6V18ZM7.75 9.25V11H9.25V9.25H11V7.75H9.25V6H7.75V7.75H6V9.25H7.75ZM17.9986 14.0601L16.5363 15.5155L17.9984 16.9707L16.9353 18.0289L15.4731 16.5736L14.0105 18.0294L12.947 16.9702L14.4093 15.5148L12.9472 14.0596L14.0103 13.0014L15.4725 14.4567L16.9351 13.0009L17.9986 14.0601ZM6 14.75H11V13.25H6V14.75ZM6 17.75H11V16.25H6V17.75ZM13 9.25H18V7.75H13V9.25Z',
    })
  );
};
Calculator.displayName = 'Calculator';
exports['default'] = Calculator;
