"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.DEFAULT_ICON_SIZE = void 0;
exports.DEFAULT_ICON_SIZE = 24;