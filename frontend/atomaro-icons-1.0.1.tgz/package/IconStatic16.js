'use strict';
var PropTypes = require('prop-types');

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __rest =
  (this && this.__rest) ||
  function (s, e) {
    var t = {};
    for (var p in s)
      if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === 'function')
      for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
          t[p[i]] = s[p[i]];
      }
    return t;
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var styles_1 = require('./styles');
var IconStatic16 = function IconStatic16(props) {
  var children = props.children,
    restProps = __rest(props, ['children']);
  return react_1['default'].createElement(
    styles_1.StyledSVG,
    __assign(
      {
        width: '16',
        height: '16',
        viewBox: '0 0 16 16',
        'aria-hidden': 'true',
        xmlns: 'http://www.w3.org/2000/svg',
      },
      restProps
    ),
    children
  );
};

IconStatic16.propTypes = {
  children: PropTypes.node,
};

IconStatic16.displayName = 'IconStatic16';
exports['default'] = IconStatic16;
