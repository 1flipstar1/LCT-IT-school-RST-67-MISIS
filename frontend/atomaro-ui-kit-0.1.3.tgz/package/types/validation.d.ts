export interface ValidationRule {
    error?: string;
    validate: (inputValue: string) => boolean;
}
