import { THEMES, BREAKPOINTS } from '../constants/components';
import { IThemeSpacing } from './spacing';
import { ShapesType, TypographyVariantsType, CheckboxSizesType } from './base';
export type CalcColorWithAlphaType = (alpha?: number) => string;
export interface IBaseColors {
    primary1: CalcColorWithAlphaType;
    primary2: CalcColorWithAlphaType;
    secondary1: CalcColorWithAlphaType;
    secondary2: CalcColorWithAlphaType;
}
export interface ISystemColors {
    success: CalcColorWithAlphaType;
    warning: CalcColorWithAlphaType;
    error: CalcColorWithAlphaType;
    info: CalcColorWithAlphaType;
}
export interface ITransparentColors {
    [100]: string;
    [75]: string;
    [50]: string;
    [25]: string;
    [10]: string;
    [5]: string;
    [3]: string;
}
export interface IShadows {
    bottomS: string;
    bottomM: string;
    bottomL: string;
    bottomXL: string;
    topS: string;
    topM: string;
    topL: string;
    topXL: string;
    control: string;
}
export interface IGreyScaleColors {
    black: string;
    white: string;
    [95]: string;
    [90]: string;
    [80]: string;
    [60]: string;
    [40]: string;
    [20]: string;
    [10]: string;
    [5]: string;
}
export interface IInlineNotifications {
    info: CalcColorWithAlphaType;
    warning: CalcColorWithAlphaType;
    error: CalcColorWithAlphaType;
    success: CalcColorWithAlphaType;
}
export interface IStepper {
    transparent: {
        default: string;
    };
}
export interface INumberStepper {
    textColor: string;
}
export interface IInput {
    error: string;
    checkmark: string;
}
export interface ITabs {
    disabled: {
        accentColor: string;
    };
}
export interface IChip {
    background: string;
}
export interface ITag {
    background: string;
}
export interface ISelect {
    dropdown: string;
}
export interface IDropdownMenu {
    background: string;
    backgroundGradient: string;
}
export interface IMultiselect {
    error: string;
}
interface ITooltip {
    backgroundColor: string;
}
export interface ITransitions {
    easeInOut: string;
    cubicBezier: string;
}
export interface IThemeStaticFonts {
    accentXS: string;
    accentS: string;
    accentM: string;
    accentL: string;
    bodyL: string;
    bodyM: string;
    caption: string;
    description: string;
    mega: string;
    h1: string;
    h2: string;
    h3: string;
    h4: string;
}
export interface IThemeAdaptiveFonts {
    [BREAKPOINTS.mobile_small]: IThemeStaticFonts;
    [BREAKPOINTS.mobile_large]: IThemeStaticFonts;
    [BREAKPOINTS.desktop_small]: IThemeStaticFonts;
}
export interface IThemeFonts {
    static: IThemeStaticFonts;
    adaptive: IThemeAdaptiveFonts;
}
export type ThemeNamesType = keyof typeof THEMES;
export interface ITheme {
    fonts: IThemeFonts;
    inlineNotifications: IInlineNotifications;
    stepper: IStepper;
    numberStepper: INumberStepper;
    input: IInput;
    tabs: ITabs;
    chip: IChip;
    tag: ITag;
    dropdownMenu: IDropdownMenu;
    multiselect: IMultiselect;
    greyScale: IGreyScaleColors;
    baseColors: IBaseColors;
    shadows: IShadows;
    spacing: IThemeSpacing;
    systemColors: ISystemColors;
    tooltip: ITooltip;
    toastNotifications: string;
    transparent: ITransparentColors;
    transitions: ITransitions;
    select: ISelect;
    shape: ShapesType;
    components: IThemeComponents;
}
export interface ITableSizeParams {
    cellHorizontalPadding: number;
    cellVerticalPadding: number;
    cellTypographyVariant: TypographyVariantsType;
    headTypographyVariant: TypographyVariantsType;
    checkboxSize: CheckboxSizesType;
    iconSize: number;
    offsetSize: number;
}
export interface ITableSizes {
    [key: string]: ITableSizeParams;
}
export interface ITreeSizeParams {
    verticalPadding: number;
    horizontalPadding: number;
    innerPadding: number;
    typographyVariant: TypographyVariantsType;
    checkboxSize: CheckboxSizesType;
    iconSize: number;
}
export interface ITreeSizes {
    [key: string]: ITreeSizeParams;
}
export interface IThemeComponents {
    table: {
        size: ITableSizes;
    };
    tree: {
        size: ITreeSizes;
    };
}
export interface IThemeComponentsParial {
    table?: {
        size?: {
            [key: string]: Partial<ITableSizeParams>;
        };
    };
    tree?: {
        size?: {
            [key: string]: Partial<ITreeSizeParams>;
        };
    };
}
export interface ICustomTheme {
    baseColors?: {
        primary1?: string;
        primary2?: string;
        secondary1?: string;
        secondary2?: string;
    };
    greyScale?: Partial<IGreyScaleColors>;
    shape?: ShapesType;
    components?: IThemeComponentsParial;
}
export {};
