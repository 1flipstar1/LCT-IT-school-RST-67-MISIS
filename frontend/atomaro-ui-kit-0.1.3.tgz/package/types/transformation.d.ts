export interface TransformationRule {
    transform: (inputValue?: string) => string;
    onBlurTransform?: (inputValue: string) => string;
}
