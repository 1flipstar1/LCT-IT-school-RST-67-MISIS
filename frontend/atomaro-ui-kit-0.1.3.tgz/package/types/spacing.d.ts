import { SPACING_VERTICAL_KEYS_LIST, SPACING_FULL_KEYS_LIST } from '../constants/spacing';
import { BREAKPOINTS } from '../constants/components';
export type SpacingFullKeysType = keyof typeof SPACING_FULL_KEYS_LIST;
export type SpacingVerticalKeysType = keyof typeof SPACING_VERTICAL_KEYS_LIST;
export interface IThemeSpacingFUll {
    [BREAKPOINTS.mobile_small]: Record<SpacingFullKeysType, number>;
    [BREAKPOINTS.mobile_large]: Record<SpacingFullKeysType, number>;
    [BREAKPOINTS.tablet_vertical_large]: Record<SpacingFullKeysType, number>;
}
export interface IThemeSpacingVertical {
    [BREAKPOINTS.mobile_small]: Record<SpacingVerticalKeysType, number>;
    [BREAKPOINTS.mobile_large]: Record<SpacingVerticalKeysType, number>;
    [BREAKPOINTS.desktop_small]: Record<SpacingVerticalKeysType, number>;
}
export interface IThemeSpacing {
    spacingFull: IThemeSpacingFUll;
    spacingVertical: IThemeSpacingVertical;
}
