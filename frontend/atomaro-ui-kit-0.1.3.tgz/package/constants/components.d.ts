export declare enum SIZES {
    s = "s",
    m = "m",
    l = "l",
    xl = "xl"
}
export declare enum COLORSCHEME {
    accent = "accent",
    neutral = "neutral"
}
export declare enum SHAPES {
    geometric = "geometric",
    rounded = "rounded",
    circular = "circular"
}
export declare enum VARIANT {
    primary = "primary",
    secondary = "secondary",
    outline = "outline",
    ghost = "ghost"
}
export declare enum SYSTEM_COLORS {
    info = "info",
    warning = "warning",
    error = "error",
    success = "success"
}
export declare enum THEMES {
    light = "light",
    dark = "dark"
}
export declare enum TEXT_HORIZONTAL_POSITIONS {
    left = "left",
    right = "right"
}
export declare enum BASE_COLORS {
    primary1 = "primary1",
    primary2 = "primary2",
    secondary1 = "secondary1",
    secondary2 = "secondary2"
}
export declare enum BREAKPOINTS {
    mobile_small = 320,
    mobile_large = 375,
    tablet_vertical_small = 640,
    tablet_vertical_large = 768,
    tablet_horizontal = 1024,
    desktop_small = 1280,
    desktop_middle = 1512,
    desktop_large = 1920
}
export declare enum BUTTON_TYPES {
    button = "button",
    reset = "reset",
    submit = "submit"
}
export declare enum BUTTON_VIEWS {
    primary = "primary",
    secondary = "secondary",
    outline = "outline",
    ghost = "ghost"
}
export declare enum VIEWS {
    primary = "primary",
    secondary = "secondary",
    tertiary = "tertiary"
}
export declare enum ICON_POSITIONS {
    left = "left",
    right = "right"
}
export declare enum TYPOGRAPHY_VARIANTS {
    mega = "mega",
    h1 = "h1",
    h2 = "h2",
    h3 = "h3",
    h4 = "h4",
    bodyL = "bodyL",
    bodyM = "bodyM",
    caption = "caption",
    description = "description",
    accentXS = "accentXS",
    accentS = "accentS",
    accentM = "accentM",
    accentL = "accentL"
}
export declare enum TYPOGRAPHY_COLORS {
    info = "info",
    warning = "warning",
    error = "error",
    success = "success",
    main = "main",
    description = "description",
    caption = "caption",
    disabled = "disabled",
    primary1 = "primary1",
    primary2 = "primary2",
    secondary1 = "secondary1",
    secondary2 = "secondary2"
}
export declare enum TRANSPARENT_COLORS {
    primary1 = "primary1",
    primary2 = "primary2",
    secondary1 = "secondary1",
    secondary2 = "secondary2",
    info = "info",
    warning = "warning",
    error = "error",
    success = "success"
}
export declare enum CHECKBOX_SIZES {
    small = "small",
    medium = "medium"
}
export declare enum CHECKBOX_VIEW {
    default = "default",
    accent = "accent"
}
export declare enum INPUT_SIZES {
    xsmall = "xsmall",
    small = "small",
    medium = "medium"
}
export declare enum TREE_SIZES {
    small = "small",
    medium = "medium"
}
export declare enum TABLE_SIZES {
    medium = "medium",
    small = "small"
}
export declare enum FOLD_DIRECTION {
    down = "down",
    up = "up",
    topLeft = "topLeft",
    topRight = "topRight",
    bottomLeft = "bottomLeft",
    bottomRight = "bottomRight",
    auto = "auto"
}
