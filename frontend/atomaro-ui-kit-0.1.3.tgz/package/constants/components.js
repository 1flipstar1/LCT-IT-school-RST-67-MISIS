"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.FOLD_DIRECTION = exports.TABLE_SIZES = exports.TREE_SIZES = exports.INPUT_SIZES = exports.CHECKBOX_VIEW = exports.CHECKBOX_SIZES = exports.TRANSPARENT_COLORS = exports.TYPOGRAPHY_COLORS = exports.TYPOGRAPHY_VARIANTS = exports.ICON_POSITIONS = exports.VIEWS = exports.BUTTON_VIEWS = exports.BUTTON_TYPES = exports.BREAKPOINTS = exports.BASE_COLORS = exports.TEXT_HORIZONTAL_POSITIONS = exports.THEMES = exports.SYSTEM_COLORS = exports.VARIANT = exports.SHAPES = exports.COLORSCHEME = exports.SIZES = void 0;
var SIZES;
(function (SIZES) {
  SIZES["s"] = "s";
  SIZES["m"] = "m";
  SIZES["l"] = "l";
  SIZES["xl"] = "xl";
})(SIZES = exports.SIZES || (exports.SIZES = {}));
var COLORSCHEME;
(function (COLORSCHEME) {
  COLORSCHEME["accent"] = "accent";
  COLORSCHEME["neutral"] = "neutral";
})(COLORSCHEME = exports.COLORSCHEME || (exports.COLORSCHEME = {}));
var SHAPES;
(function (SHAPES) {
  SHAPES["geometric"] = "geometric";
  SHAPES["rounded"] = "rounded";
  SHAPES["circular"] = "circular";
})(SHAPES = exports.SHAPES || (exports.SHAPES = {}));
var VARIANT;
(function (VARIANT) {
  VARIANT["primary"] = "primary";
  VARIANT["secondary"] = "secondary";
  VARIANT["outline"] = "outline";
  VARIANT["ghost"] = "ghost";
})(VARIANT = exports.VARIANT || (exports.VARIANT = {}));
var SYSTEM_COLORS;
(function (SYSTEM_COLORS) {
  SYSTEM_COLORS["info"] = "info";
  SYSTEM_COLORS["warning"] = "warning";
  SYSTEM_COLORS["error"] = "error";
  SYSTEM_COLORS["success"] = "success";
})(SYSTEM_COLORS = exports.SYSTEM_COLORS || (exports.SYSTEM_COLORS = {}));
var THEMES;
(function (THEMES) {
  THEMES["light"] = "light";
  THEMES["dark"] = "dark";
})(THEMES = exports.THEMES || (exports.THEMES = {}));
var TEXT_HORIZONTAL_POSITIONS;
(function (TEXT_HORIZONTAL_POSITIONS) {
  TEXT_HORIZONTAL_POSITIONS["left"] = "left";
  TEXT_HORIZONTAL_POSITIONS["right"] = "right";
})(TEXT_HORIZONTAL_POSITIONS = exports.TEXT_HORIZONTAL_POSITIONS || (exports.TEXT_HORIZONTAL_POSITIONS = {}));
var BASE_COLORS;
(function (BASE_COLORS) {
  BASE_COLORS["primary1"] = "primary1";
  BASE_COLORS["primary2"] = "primary2";
  BASE_COLORS["secondary1"] = "secondary1";
  BASE_COLORS["secondary2"] = "secondary2";
})(BASE_COLORS = exports.BASE_COLORS || (exports.BASE_COLORS = {}));
var BREAKPOINTS;
(function (BREAKPOINTS) {
  BREAKPOINTS[BREAKPOINTS["mobile_small"] = 320] = "mobile_small";
  BREAKPOINTS[BREAKPOINTS["mobile_large"] = 375] = "mobile_large";
  BREAKPOINTS[BREAKPOINTS["tablet_vertical_small"] = 640] = "tablet_vertical_small";
  BREAKPOINTS[BREAKPOINTS["tablet_vertical_large"] = 768] = "tablet_vertical_large";
  BREAKPOINTS[BREAKPOINTS["tablet_horizontal"] = 1024] = "tablet_horizontal";
  BREAKPOINTS[BREAKPOINTS["desktop_small"] = 1280] = "desktop_small";
  BREAKPOINTS[BREAKPOINTS["desktop_middle"] = 1512] = "desktop_middle";
  BREAKPOINTS[BREAKPOINTS["desktop_large"] = 1920] = "desktop_large";
})(BREAKPOINTS = exports.BREAKPOINTS || (exports.BREAKPOINTS = {}));
var BUTTON_TYPES;
(function (BUTTON_TYPES) {
  BUTTON_TYPES["button"] = "button";
  BUTTON_TYPES["reset"] = "reset";
  BUTTON_TYPES["submit"] = "submit";
})(BUTTON_TYPES = exports.BUTTON_TYPES || (exports.BUTTON_TYPES = {}));
var BUTTON_VIEWS;
(function (BUTTON_VIEWS) {
  BUTTON_VIEWS["primary"] = "primary";
  BUTTON_VIEWS["secondary"] = "secondary";
  BUTTON_VIEWS["outline"] = "outline";
  BUTTON_VIEWS["ghost"] = "ghost";
})(BUTTON_VIEWS = exports.BUTTON_VIEWS || (exports.BUTTON_VIEWS = {}));
var VIEWS;
(function (VIEWS) {
  VIEWS["primary"] = "primary";
  VIEWS["secondary"] = "secondary";
  VIEWS["tertiary"] = "tertiary";
})(VIEWS = exports.VIEWS || (exports.VIEWS = {}));
var ICON_POSITIONS;
(function (ICON_POSITIONS) {
  ICON_POSITIONS["left"] = "left";
  ICON_POSITIONS["right"] = "right";
})(ICON_POSITIONS = exports.ICON_POSITIONS || (exports.ICON_POSITIONS = {}));
var TYPOGRAPHY_VARIANTS;
(function (TYPOGRAPHY_VARIANTS) {
  TYPOGRAPHY_VARIANTS["mega"] = "mega";
  TYPOGRAPHY_VARIANTS["h1"] = "h1";
  TYPOGRAPHY_VARIANTS["h2"] = "h2";
  TYPOGRAPHY_VARIANTS["h3"] = "h3";
  TYPOGRAPHY_VARIANTS["h4"] = "h4";
  TYPOGRAPHY_VARIANTS["bodyL"] = "bodyL";
  TYPOGRAPHY_VARIANTS["bodyM"] = "bodyM";
  TYPOGRAPHY_VARIANTS["caption"] = "caption";
  TYPOGRAPHY_VARIANTS["description"] = "description";
  TYPOGRAPHY_VARIANTS["accentXS"] = "accentXS";
  TYPOGRAPHY_VARIANTS["accentS"] = "accentS";
  TYPOGRAPHY_VARIANTS["accentM"] = "accentM";
  TYPOGRAPHY_VARIANTS["accentL"] = "accentL";
})(TYPOGRAPHY_VARIANTS = exports.TYPOGRAPHY_VARIANTS || (exports.TYPOGRAPHY_VARIANTS = {}));
var TYPOGRAPHY_COLORS;
(function (TYPOGRAPHY_COLORS) {
  TYPOGRAPHY_COLORS["info"] = "info";
  TYPOGRAPHY_COLORS["warning"] = "warning";
  TYPOGRAPHY_COLORS["error"] = "error";
  TYPOGRAPHY_COLORS["success"] = "success";
  TYPOGRAPHY_COLORS["main"] = "main";
  TYPOGRAPHY_COLORS["description"] = "description";
  TYPOGRAPHY_COLORS["caption"] = "caption";
  TYPOGRAPHY_COLORS["disabled"] = "disabled";
  TYPOGRAPHY_COLORS["primary1"] = "primary1";
  TYPOGRAPHY_COLORS["primary2"] = "primary2";
  TYPOGRAPHY_COLORS["secondary1"] = "secondary1";
  TYPOGRAPHY_COLORS["secondary2"] = "secondary2";
})(TYPOGRAPHY_COLORS = exports.TYPOGRAPHY_COLORS || (exports.TYPOGRAPHY_COLORS = {}));
var TRANSPARENT_COLORS;
(function (TRANSPARENT_COLORS) {
  TRANSPARENT_COLORS["primary1"] = "primary1";
  TRANSPARENT_COLORS["primary2"] = "primary2";
  TRANSPARENT_COLORS["secondary1"] = "secondary1";
  TRANSPARENT_COLORS["secondary2"] = "secondary2";
  TRANSPARENT_COLORS["info"] = "info";
  TRANSPARENT_COLORS["warning"] = "warning";
  TRANSPARENT_COLORS["error"] = "error";
  TRANSPARENT_COLORS["success"] = "success";
})(TRANSPARENT_COLORS = exports.TRANSPARENT_COLORS || (exports.TRANSPARENT_COLORS = {}));
var CHECKBOX_SIZES;
(function (CHECKBOX_SIZES) {
  CHECKBOX_SIZES["small"] = "small";
  CHECKBOX_SIZES["medium"] = "medium";
})(CHECKBOX_SIZES = exports.CHECKBOX_SIZES || (exports.CHECKBOX_SIZES = {}));
var CHECKBOX_VIEW;
(function (CHECKBOX_VIEW) {
  CHECKBOX_VIEW["default"] = "default";
  CHECKBOX_VIEW["accent"] = "accent";
})(CHECKBOX_VIEW = exports.CHECKBOX_VIEW || (exports.CHECKBOX_VIEW = {}));
var INPUT_SIZES;
(function (INPUT_SIZES) {
  INPUT_SIZES["xsmall"] = "xsmall";
  INPUT_SIZES["small"] = "small";
  INPUT_SIZES["medium"] = "medium";
})(INPUT_SIZES = exports.INPUT_SIZES || (exports.INPUT_SIZES = {}));
var TREE_SIZES;
(function (TREE_SIZES) {
  TREE_SIZES["small"] = "small";
  TREE_SIZES["medium"] = "medium";
})(TREE_SIZES = exports.TREE_SIZES || (exports.TREE_SIZES = {}));
var TABLE_SIZES;
(function (TABLE_SIZES) {
  TABLE_SIZES["medium"] = "medium";
  TABLE_SIZES["small"] = "small";
})(TABLE_SIZES = exports.TABLE_SIZES || (exports.TABLE_SIZES = {}));
var FOLD_DIRECTION;
(function (FOLD_DIRECTION) {
  FOLD_DIRECTION["down"] = "down";
  FOLD_DIRECTION["up"] = "up";
  FOLD_DIRECTION["topLeft"] = "topLeft";
  FOLD_DIRECTION["topRight"] = "topRight";
  FOLD_DIRECTION["bottomLeft"] = "bottomLeft";
  FOLD_DIRECTION["bottomRight"] = "bottomRight";
  FOLD_DIRECTION["auto"] = "auto";
})(FOLD_DIRECTION = exports.FOLD_DIRECTION || (exports.FOLD_DIRECTION = {}));