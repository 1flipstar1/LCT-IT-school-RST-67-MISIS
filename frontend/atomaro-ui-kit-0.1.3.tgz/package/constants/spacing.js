'use strict';

var _a, _b, _c, _d, _e, _f, _g, _h;
Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.themeSpacing =
  exports.ADAPTIVE_SPACING_VERTICAL =
  exports.ADAPTIVE_SPACING_FULL =
  exports.SPACING_VERTICAL_KEYS_LIST =
  exports.SPACING_FULL_KEYS_LIST =
    void 0;
var components_1 = require('./components');
var spacing_1 = require('../utils/spacing');
var SPACING_FULL_KEYS_LIST;
(function (SPACING_FULL_KEYS_LIST) {
  SPACING_FULL_KEYS_LIST['s'] = 's';
  SPACING_FULL_KEYS_LIST['m'] = 'm';
  SPACING_FULL_KEYS_LIST['l'] = 'l';
  SPACING_FULL_KEYS_LIST['xl'] = 'xl';
})(
  (SPACING_FULL_KEYS_LIST = exports.SPACING_FULL_KEYS_LIST || (exports.SPACING_FULL_KEYS_LIST = {}))
);
var SPACING_VERTICAL_KEYS_LIST;
(function (SPACING_VERTICAL_KEYS_LIST) {
  SPACING_VERTICAL_KEYS_LIST['xs'] = 'xs';
  SPACING_VERTICAL_KEYS_LIST['s'] = 's';
  SPACING_VERTICAL_KEYS_LIST['m'] = 'm';
  SPACING_VERTICAL_KEYS_LIST['l'] = 'l';
  SPACING_VERTICAL_KEYS_LIST['xl'] = 'xl';
  SPACING_VERTICAL_KEYS_LIST['xxl'] = 'xxl';
  SPACING_VERTICAL_KEYS_LIST['xxxl'] = 'xxxl';
})(
  (SPACING_VERTICAL_KEYS_LIST =
    exports.SPACING_VERTICAL_KEYS_LIST || (exports.SPACING_VERTICAL_KEYS_LIST = {}))
);
exports.ADAPTIVE_SPACING_FULL =
  ((_a = {}),
  (_a[components_1.BREAKPOINTS.mobile_small] =
    ((_b = {}),
    (_b[SPACING_FULL_KEYS_LIST.s] = (0, spacing_1.getSpacing)(2)),
    (_b[SPACING_FULL_KEYS_LIST.m] = (0, spacing_1.getSpacing)(3)),
    (_b[SPACING_FULL_KEYS_LIST.l] = (0, spacing_1.getSpacing)(5)),
    (_b[SPACING_FULL_KEYS_LIST.xl] = (0, spacing_1.getSpacing)(5)),
    _b)),
  (_a[components_1.BREAKPOINTS.mobile_large] =
    ((_c = {}),
    (_c[SPACING_FULL_KEYS_LIST.s] = (0, spacing_1.getSpacing)(3)),
    (_c[SPACING_FULL_KEYS_LIST.m] = (0, spacing_1.getSpacing)(4)),
    (_c[SPACING_FULL_KEYS_LIST.l] = (0, spacing_1.getSpacing)(6)),
    (_c[SPACING_FULL_KEYS_LIST.xl] = (0, spacing_1.getSpacing)(10)),
    _c)),
  (_a[components_1.BREAKPOINTS.tablet_vertical_large] =
    ((_d = {}),
    (_d[SPACING_FULL_KEYS_LIST.s] = (0, spacing_1.getSpacing)(3)),
    (_d[SPACING_FULL_KEYS_LIST.m] = (0, spacing_1.getSpacing)(4)),
    (_d[SPACING_FULL_KEYS_LIST.l] = (0, spacing_1.getSpacing)(8)),
    (_d[SPACING_FULL_KEYS_LIST.xl] = (0, spacing_1.getSpacing)(16)),
    _d)),
  _a);
exports.ADAPTIVE_SPACING_VERTICAL =
  ((_e = {}),
  (_e[components_1.BREAKPOINTS.mobile_small] =
    ((_f = {}),
    (_f[SPACING_VERTICAL_KEYS_LIST.xs] = (0, spacing_1.getSpacing)(1)),
    (_f[SPACING_VERTICAL_KEYS_LIST.s] = (0, spacing_1.getSpacing)(2)),
    (_f[SPACING_VERTICAL_KEYS_LIST.m] = (0, spacing_1.getSpacing)(3)),
    (_f[SPACING_VERTICAL_KEYS_LIST.l] = (0, spacing_1.getSpacing)(5)),
    (_f[SPACING_VERTICAL_KEYS_LIST.xl] = (0, spacing_1.getSpacing)(6)),
    (_f[SPACING_VERTICAL_KEYS_LIST.xxl] = (0, spacing_1.getSpacing)(8)),
    (_f[SPACING_VERTICAL_KEYS_LIST.xxxl] = (0, spacing_1.getSpacing)(10)),
    _f)),
  (_e[components_1.BREAKPOINTS.mobile_large] =
    ((_g = {}),
    (_g[SPACING_VERTICAL_KEYS_LIST.xs] = (0, spacing_1.getSpacing)(2)),
    (_g[SPACING_VERTICAL_KEYS_LIST.s] = (0, spacing_1.getSpacing)(3)),
    (_g[SPACING_VERTICAL_KEYS_LIST.m] = (0, spacing_1.getSpacing)(4)),
    (_g[SPACING_VERTICAL_KEYS_LIST.l] = (0, spacing_1.getSpacing)(6)),
    (_g[SPACING_VERTICAL_KEYS_LIST.xl] = (0, spacing_1.getSpacing)(8)),
    (_g[SPACING_VERTICAL_KEYS_LIST.xxl] = (0, spacing_1.getSpacing)(10)),
    (_g[SPACING_VERTICAL_KEYS_LIST.xxxl] = (0, spacing_1.getSpacing)(13)),
    _g)),
  (_e[components_1.BREAKPOINTS.desktop_small] =
    ((_h = {}),
    (_h[SPACING_VERTICAL_KEYS_LIST.xs] = (0, spacing_1.getSpacing)(2)),
    (_h[SPACING_VERTICAL_KEYS_LIST.s] = (0, spacing_1.getSpacing)(4)),
    (_h[SPACING_VERTICAL_KEYS_LIST.m] = (0, spacing_1.getSpacing)(5)),
    (_h[SPACING_VERTICAL_KEYS_LIST.l] = (0, spacing_1.getSpacing)(8)),
    (_h[SPACING_VERTICAL_KEYS_LIST.xl] = (0, spacing_1.getSpacing)(10)),
    (_h[SPACING_VERTICAL_KEYS_LIST.xxl] = (0, spacing_1.getSpacing)(12)),
    (_h[SPACING_VERTICAL_KEYS_LIST.xxxl] = (0, spacing_1.getSpacing)(14)),
    _h)),
  _e);
exports.themeSpacing = {
  spacingFull: exports.ADAPTIVE_SPACING_FULL,
  spacingVertical: exports.ADAPTIVE_SPACING_VERTICAL,
};
