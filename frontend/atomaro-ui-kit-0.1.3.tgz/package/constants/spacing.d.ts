export declare enum SPACING_FULL_KEYS_LIST {
    s = "s",
    m = "m",
    l = "l",
    xl = "xl"
}
export declare enum SPACING_VERTICAL_KEYS_LIST {
    xs = "xs",
    s = "s",
    m = "m",
    l = "l",
    xl = "xl",
    xxl = "xxl",
    xxxl = "xxxl"
}
export declare const ADAPTIVE_SPACING_FULL: {
    320: {
        s: number;
        m: number;
        l: number;
        xl: number;
    };
    375: {
        s: number;
        m: number;
        l: number;
        xl: number;
    };
    768: {
        s: number;
        m: number;
        l: number;
        xl: number;
    };
};
export declare const ADAPTIVE_SPACING_VERTICAL: {
    320: {
        xs: number;
        s: number;
        m: number;
        l: number;
        xl: number;
        xxl: number;
        xxxl: number;
    };
    375: {
        xs: number;
        s: number;
        m: number;
        l: number;
        xl: number;
        xxl: number;
        xxxl: number;
    };
    1280: {
        xs: number;
        s: number;
        m: number;
        l: number;
        xl: number;
        xxl: number;
        xxxl: number;
    };
};
export declare const themeSpacing: {
    spacingFull: {
        320: {
            s: number;
            m: number;
            l: number;
            xl: number;
        };
        375: {
            s: number;
            m: number;
            l: number;
            xl: number;
        };
        768: {
            s: number;
            m: number;
            l: number;
            xl: number;
        };
    };
    spacingVertical: {
        320: {
            xs: number;
            s: number;
            m: number;
            l: number;
            xl: number;
            xxl: number;
            xxxl: number;
        };
        375: {
            xs: number;
            s: number;
            m: number;
            l: number;
            xl: number;
            xxl: number;
            xxxl: number;
        };
        1280: {
            xs: number;
            s: number;
            m: number;
            l: number;
            xl: number;
            xxl: number;
            xxxl: number;
        };
    };
};
