import { ChangeEvent, MouseEvent, CompositionEvent } from 'react';
import { TransformationRule } from '../types/transformation';
export declare const setCaretPosition: (input: any, pos: number, endPos?: number) => void;
export declare const getCaretPosition: (input: HTMLInputElement) => number;
export declare const correctCaretPosition: (input: HTMLInputElement) => void;
export declare const defaultTrasformationRule: TransformationRule;
export declare function resolveOnChange<E extends HTMLInputElement | HTMLTextAreaElement>(target: E, e: ChangeEvent<E> | MouseEvent<HTMLElement, MouseEvent> | CompositionEvent<HTMLElement>, onChange: undefined | ((event: ChangeEvent<E>) => void)): void;
