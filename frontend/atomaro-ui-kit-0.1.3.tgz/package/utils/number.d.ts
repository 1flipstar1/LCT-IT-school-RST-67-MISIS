export declare const clamp: (value: number, min?: number, max?: number) => number;
export declare const withinTheInterval: (value: number, min?: number, max?: number) => boolean;
