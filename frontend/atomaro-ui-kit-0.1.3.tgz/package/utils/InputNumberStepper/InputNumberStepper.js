'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.addSizeInputIncrement =
  exports.checkNumStepperValLength =
  exports.displayValToNumberVal =
  exports.getDisplayValue =
    void 0;
var constants_1 = require('../../components/InputNumberStepper/constants');
var getDisplayValue = function getDisplayValue(value) {
  var res = String(value);
  if (res.length > 3) {
    var transformArr = res
      .split('')
      .reverse()
      .reduce(function (acc, num, index) {
        acc.push(num);
        if ((index + 1) % 3 === 0) {
          acc.push(' ');
        }
        return acc;
      }, []);
    res = transformArr.reverse().join('').trim();
  }
  return res;
};
exports.getDisplayValue = getDisplayValue;
var displayValToNumberVal = function displayValToNumberVal(value) {
  return Number(value.split(' ').join(''));
};
exports.displayValToNumberVal = displayValToNumberVal;
var checkNumStepperValLength = function checkNumStepperValLength(current) {
  return current.length <= constants_1.NUMBER_STEPPER_VAL_MAX_LENGTH;
};
exports.checkNumStepperValLength = checkNumStepperValLength;
var addSizeInputIncrement = function addSizeInputIncrement(str) {
  var counter = 0;
  var tmpArr = str.split('');
  tmpArr.forEach(function (elem) {
    if (elem === ' ') {
      counter += 1;
    }
  });
  return counter;
};
exports.addSizeInputIncrement = addSizeInputIncrement;
