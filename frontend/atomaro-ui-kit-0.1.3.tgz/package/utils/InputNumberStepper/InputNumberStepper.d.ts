export declare const getDisplayValue: (value: number) => string;
export declare const displayValToNumberVal: (value: string) => number;
export declare const checkNumStepperValLength: (current: string) => boolean;
export declare const addSizeInputIncrement: (str: string) => number;
