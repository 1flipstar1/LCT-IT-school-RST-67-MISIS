export declare const getSpacing: (num: number, line?: number) => number;
