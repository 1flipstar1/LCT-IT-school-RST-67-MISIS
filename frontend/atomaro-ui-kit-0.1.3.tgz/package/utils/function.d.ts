export declare const noop: () => void;
export declare const preventDefaultFn: (event: any) => void;
