'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.isDisabledCompatibleChildren = void 0;
var react_1 = require('react');
var isDisabledCompatibleChildren = function isDisabledCompatibleChildren(element, parent) {
  var _a;
  if (!(0, react_1.isValidElement)(element)) {
    return false;
  }
  var elementType = element.type;
  if (
    (elementType.displayName === 'Button' ||
      elementType.displayName === 'IconButton' ||
      element.type === 'button') &&
    element.props.disabled
  ) {
    return true;
  }
  if (
    parent &&
    ((_a = parent.current) === null || _a === void 0 ? void 0 : _a.children[0]) &&
    parent.current.children[0].nodeName === 'BUTTON'
  ) {
    if (parent.current.children[0].hasAttribute('disabled') === true) {
      return true;
    }
  }
  return false;
};
exports.isDisabledCompatibleChildren = isDisabledCompatibleChildren;
