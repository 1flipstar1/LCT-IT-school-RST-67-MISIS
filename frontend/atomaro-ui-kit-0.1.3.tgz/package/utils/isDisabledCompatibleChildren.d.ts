import React, { ReactNode } from 'react';
export declare const isDisabledCompatibleChildren: (element: ReactNode, parent?: React.RefObject<HTMLElement | HTMLButtonElement>) => boolean;
