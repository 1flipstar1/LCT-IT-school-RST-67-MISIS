'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.getSpacing = void 0;
var BASELINE = 4;
var getSpacing = function getSpacing(num, line) {
  if (line === void 0) {
    line = BASELINE;
  }
  return num * line;
};
exports.getSpacing = getSpacing;
