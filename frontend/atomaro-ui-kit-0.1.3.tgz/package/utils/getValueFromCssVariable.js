'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.getValueFromCssVariable = void 0;
var getValueFromCssVariable = function getValueFromCssVariable(variable) {
  var value = getComputedStyle(document.documentElement, null).getPropertyValue(variable);
  if (!value) {
    throw new Error('No css variable found for '.concat(variable));
  }
  return value;
};
exports.getValueFromCssVariable = getValueFromCssVariable;
