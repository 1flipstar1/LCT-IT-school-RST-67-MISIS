export declare const getValueFromCssVariable: (variable: string) => string;
