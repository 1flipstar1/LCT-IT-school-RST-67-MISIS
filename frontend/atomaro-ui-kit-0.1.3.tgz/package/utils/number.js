'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.withinTheInterval = exports.clamp = void 0;
var clamp = function clamp(value, min, max) {
  if (typeof min === 'number' && typeof max === 'number') {
    return Math.min(Math.max(value, min), max);
  }
  return value;
};
exports.clamp = clamp;
var withinTheInterval = function withinTheInterval(value, min, max) {
  if (typeof max === 'number' && !min) {
    return value <= max;
  }
  if (typeof min === 'number' && !max) {
    return value >= min;
  }
  if (typeof min === 'number' && typeof max === 'number') {
    return value >= min && value <= max;
  }
  return true;
};
exports.withinTheInterval = withinTheInterval;
