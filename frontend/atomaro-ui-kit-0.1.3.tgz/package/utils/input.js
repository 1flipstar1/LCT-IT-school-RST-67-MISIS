'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.resolveOnChange =
  exports.defaultTrasformationRule =
  exports.correctCaretPosition =
  exports.getCaretPosition =
  exports.setCaretPosition =
    void 0;
var setCaretPosition = function setCaretPosition(input, pos, endPos) {
  var end = endPos || pos;
  if (input.setSelectionRange) {
    input.focus();
    input.setSelectionRange(pos, end);
  }
};
exports.setCaretPosition = setCaretPosition;
var getCaretPosition = function getCaretPosition(input) {
  input.focus();
  if (input.selectionStart) {
    return input.selectionStart;
  }
  return 0;
};
exports.getCaretPosition = getCaretPosition;
var correctCaretPosition = function correctCaretPosition(input) {
  var currentCaretPosition = (0, exports.getCaretPosition)(input);
  var prevVal = input.value;
  setTimeout(function () {
    if (prevVal.length < input.value.length) {
      currentCaretPosition += 1;
    }
    if (prevVal.length > input.value.length) {
      currentCaretPosition -= 1;
    }
    (0, exports.setCaretPosition)(input, currentCaretPosition);
  }, 0);
};
exports.correctCaretPosition = correctCaretPosition;
exports.defaultTrasformationRule = {
  transform: function transform(inputValue) {
    if (inputValue === void 0) {
      inputValue = '';
    }
    return inputValue;
  },
};
function resolveOnChange(
  target,
  e,
  onChange
  // targetValue?: string,
) {
  if (!onChange) {
    return;
  }
  var event = e;
  if (e.type === 'click') {
    // click clear icon
    event = Object.create(e);
    var currentTarget = target.cloneNode(true);
    event.target = currentTarget;
    event.currentTarget = currentTarget;
    currentTarget.value = '';
    onChange(event);
    return;
  }
  // Trigger by composition event, this means we need force change the input value
  // if (targetValue !== undefined) {
  //   event = Object.create(e);
  //   event.target = target;
  //   event.currentTarget = target;
  //   target.value = targetValue;
  //   onChange(event as ChangeEvent<E>);
  //   return;
  // }
  onChange(event);
}
exports.resolveOnChange = resolveOnChange;
