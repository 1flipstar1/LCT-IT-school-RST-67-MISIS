'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.preventDefaultFn = exports.noop = void 0;
var noop = function noop() {};
exports.noop = noop;
var preventDefaultFn = function preventDefaultFn(event) {
  event.preventDefault();
};
exports.preventDefaultFn = preventDefaultFn;
