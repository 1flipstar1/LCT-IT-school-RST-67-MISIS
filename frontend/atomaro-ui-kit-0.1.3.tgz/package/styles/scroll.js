"use strict";

exports.__esModule = true;
exports.scrollStyles = void 0;
var _styledComponents = require("styled-components");
var _templateObject;
function _taggedTemplateLiteralLoose(strings, raw) { if (!raw) { raw = strings.slice(0); } strings.raw = raw; return strings; }
var scrollStyles = exports.scrollStyles = (0, _styledComponents.css)(_templateObject || (_templateObject = _taggedTemplateLiteralLoose(["\n  ::-webkit-scrollbar {\n    width: 6px;\n  }\n\n  ::-webkit-scrollbar-track {\n    background: ", ";\n    background-clip: content-box;\n    border: 1px solid transparent;\n    border-radius: 2px;\n  }\n\n  ::-webkit-scrollbar-thumb {\n    background: ", ";\n    background-clip: content-box;\n    border: 1px solid transparent;\n    border-radius: 2px;\n\n    &:hover {\n      border: 0;\n    }\n  }\n"])), function (_ref) {
  var theme = _ref.theme;
  return theme.transparent[10];
}, function (_ref2) {
  var theme = _ref2.theme;
  return theme.greyScale[40];
});