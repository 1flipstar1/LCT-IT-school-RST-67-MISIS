import { css } from 'styled-components';

export const scrollStyles = css`
  ::-webkit-scrollbar {
    width: 6px;
  }

  ::-webkit-scrollbar-track {
    background: ${({ theme }) => theme.transparent[10]};
    background-clip: content-box;
    border: 1px solid transparent;
    border-radius: 2px;
  }

  ::-webkit-scrollbar-thumb {
    background: ${({ theme }) => theme.greyScale[40]};
    background-clip: content-box;
    border: 1px solid transparent;
    border-radius: 2px;

    &:hover {
      border: 0;
    }
  }
`;
