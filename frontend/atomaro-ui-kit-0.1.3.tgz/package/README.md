## О библиотеке

UI-kit с React компонентами дизайн-системы Атомаро Про. [Атомаро](https://atomaro.design/?utm_source=npmjs_ui_kit&utm_medium=referral&utm_campaign=home_url) — это сервис и конструктор для создания дизайн-систем для любой задачи.

## Установка

Добавьте ДС Атомаро в свой проект.

```bash
  npm i @atomaro/ui-kit
```

### **Использование**

Импортируйте **стили с токенами** и необходимые компоненты в свой UI

Дефолтная светлая (**@atomaro/ui-kit/theme/default-light.css**) и тёмная тема (**@atomaro/ui-kit/theme/default-dark.css**) находятся в одном пакете с компонентами

Использование компонентов:

```jsx
import '@atomaro/ui-kit/theme/default-light.css'
import { Button } from '@atomaro/ui-kit';
```

```jsx
<Button label='Кнопка'/>
```

### **Ресурсы**

- [Telegram канал с новостями и анонсами](https://t.me/atomaro_ds)
- [Telegram чат поддержки](https://t.me/atomaro_ds_chat)

### **Контакты**

С любым вопросом о дизайн-системе или предложением по улучшению вы можете обратиться к команде Atomaro по адресу [hello@atomaro.design](mailto:hello@atomaro.design)
