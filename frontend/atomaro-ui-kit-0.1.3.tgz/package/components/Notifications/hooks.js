'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.useNotificationsButtons =
  exports.useNotificationsStack =
  exports.useNotificationsHeight =
  exports.useNotifications =
    void 0;
var react_1 = require('react');
var NotificationsStackContext_1 = require('../wrappers/ToastNotificationsProvider/NotificationsStackContext');
var useNotifications = function useNotifications(_a) {
  var onClose = _a.onClose,
    onOpen = _a.onOpen;
  var _b = (0, react_1.useState)(false),
    open = _b[0],
    setOpen = _b[1];
  var handleOpenNotification = (0, react_1.useCallback)(
    function () {
      setOpen(true);
      onOpen();
    },
    [onOpen]
  );
  var handleCloseNotification = (0, react_1.useCallback)(
    function () {
      setOpen(false);
      onClose();
    },
    [onClose]
  );
  (0, react_1.useEffect)(handleOpenNotification, [handleOpenNotification]);
  return {
    isOpen: open,
    handleCloseNotification: handleCloseNotification,
  };
};
exports.useNotifications = useNotifications;
var useNotificationsHeight = function useNotificationsHeight(wrapper, isShouldHaveHeight) {
  var createCollapse = (0, react_1.useCallback)(
    function () {
      if (wrapper) {
        // eslint-disable-next-line no-param-reassign
        wrapper.style.height = isShouldHaveHeight ? ''.concat(wrapper.scrollHeight, 'px') : '0px';
      }
    },
    [isShouldHaveHeight, wrapper]
  );
  (0, react_1.useEffect)(createCollapse, [createCollapse]);
  (0, react_1.useEffect)(
    function () {
      window.addEventListener('resize', createCollapse);
      return function () {
        window.removeEventListener('resize', createCollapse);
      };
    },
    [createCollapse]
  );
};
exports.useNotificationsHeight = useNotificationsHeight;
var useNotificationsStack = function useNotificationsStack() {
  return (0, react_1.useContext)(NotificationsStackContext_1.NotificationsStackContext);
};
exports.useNotificationsStack = useNotificationsStack;
var useNotificationsButtons = function useNotificationsButtons() {
  var _a = (0, react_1.useState)(0),
    buttonsHeight = _a[0],
    setButtonsHeight = _a[1];
  var buttonsRef = (0, react_1.useCallback)(function (node) {
    if (node) {
      var cs = getComputedStyle(node);
      var paddingY = parseFloat(cs.paddingTop) + parseFloat(cs.paddingBottom);
      var borderY = parseFloat(cs.borderTopWidth) + parseFloat(cs.borderBottomWidth);
      // Высота кнопок без отступов
      var elementHeight = node.offsetHeight - paddingY - borderY;
      if (!Number.isNaN(elementHeight)) {
        setButtonsHeight(elementHeight);
      }
    }
  }, []);
  return {
    buttonsHeight: buttonsHeight,
    buttonsRef: buttonsRef,
  };
};
exports.useNotificationsButtons = useNotificationsButtons;
