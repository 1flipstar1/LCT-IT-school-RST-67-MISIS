export declare const ICON_SIZE = 24;
export declare const INLINE_NOTIFICATION_TIMEOUT = 300;
export declare const DEFAULT_ID = "1";
export declare enum NOTIFICATION_VARIANTS {
    primary = "primary"
}
export declare enum NOTIFICATION_SIZES {
    m = "m"
}
export declare enum NOTIFICATION_COLORSCHEMES {
    info = "info",
    warning = "warning",
    error = "error",
    success = "success"
}
export declare enum NOTIFICATION_POSITION {
    topLeft = "topLeft",
    topRight = "topRight",
    topCenter = "topCenter",
    bottomLeft = "bottomLeft",
    bottomRight = "bottomRight",
    bottomCenter = "bottomCenter"
}
export type NotificationColorSchemeType = keyof typeof NOTIFICATION_COLORSCHEMES;
export type NotificationVariantType = keyof typeof NOTIFICATION_VARIANTS;
export type NotificationSizeType = keyof typeof NOTIFICATION_SIZES;
export declare const NOTIFICATION_COLORSCHEME_DEFAULT = NOTIFICATION_COLORSCHEMES.info;
export declare const NOTIFICATION_VARIANT_DEFAULT = NOTIFICATION_VARIANTS.primary;
export declare const NOTIFICATION_SIZE_DEFAULT = NOTIFICATION_SIZES.m;
