export declare const useNotifications: ({ onClose, onOpen, }: {
    onClose: () => void;
    onOpen: () => void;
}) => {
    isOpen: boolean;
    handleCloseNotification: () => void;
};
export declare const useNotificationsHeight: (wrapper: HTMLElement | null, isShouldHaveHeight: boolean) => void;
export declare const useNotificationsStack: () => {
    addCustomNotification: (props: import("./CustomToastNotification/types").ICustomToastNotification) => void;
    addNotification: (props: import("./ToastNotification/types").IToastNotification) => void;
    closeNotification: (id: string) => void;
};
export declare const useNotificationsButtons: () => {
    buttonsHeight: number;
    buttonsRef: (node: any) => void;
};
