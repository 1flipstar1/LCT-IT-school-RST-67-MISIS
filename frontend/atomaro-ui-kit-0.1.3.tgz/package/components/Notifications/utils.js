'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.createActionButtons = void 0;
var createActionButtons = function createActionButtons(actionButtons) {
  if (actionButtons === void 0) {
    actionButtons = [];
  }
  return actionButtons.slice(0, 2).map(function (button, index) {
    return {
      button: button,
      id: index + 3,
    };
  });
};
exports.createActionButtons = createActionButtons;
