import React from 'react';
import { NOTIFICATION_POSITION, NotificationColorSchemeType, NotificationSizeType, NotificationVariantType } from './constants';
import { IFunctionButtonProps } from '../Button/FunctionButton/types';
export interface INotification extends React.HTMLAttributes<HTMLDivElement> {
    /** Задает основной цвет для уведомления
     *  @default info */
    colorScheme?: NotificationColorSchemeType;
    /** Задает вариант уведомления
     *  @default primary */
    variant?: NotificationVariantType;
    /** Задает размер уведомления
     *  @default m */
    size?: NotificationSizeType;
    /** Задает заголовок уведомления */
    title?: string;
    /** Задает подзаголовок уведомления */
    subtitle?: string;
    /** Callback функция, вызываемая при появлении уведомления
     * @returns {undefined}
     */
    onOpen?: () => void;
    /** Callback функция, вызываемая при закрытии уведомления
     * @returns {undefined}
     */
    onClose?: () => void;
    /** Задаёт отображение кнопки "Закрыть"
     *  @default true */
    closeButton?: boolean;
    /** Задаёт отображение иконки"
     *  @default true */
    icon?: boolean;
    /** Задает id для компонента */
    id?: string;
}
export interface INotificationButton extends Omit<IFunctionButtonProps, 'onClick'> {
    action: (id?: string) => void;
}
export type NotificationPositionType = keyof typeof NOTIFICATION_POSITION;
