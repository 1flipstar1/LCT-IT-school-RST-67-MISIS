import { ReactNode } from 'react';
import { NotificationPositionType, INotification } from '../types';
export interface ICustomToastNotification extends Pick<INotification, 'className' | 'style' | 'variant' | 'size' | 'onOpen' | 'onClose' | 'id'> {
    /** Задает контент */
    children?: (onClose: () => void) => ReactNode;
    /** Задает расположение уведомления */
    position?: NotificationPositionType;
    /** Задает время в милисекундах, через которое уведомление скроется */
    timeout?: number;
}
export interface ICustomToastNotificationWithIsCustom extends ICustomToastNotification {
    isCustom?: boolean;
}
