'use strict';
var PropTypes = require('prop-types');

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __createBinding =
  (this && this.__createBinding) ||
  (Object.create
    ? function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ('get' in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = {
            enumerable: true,
            get: function get() {
              return m[k];
            },
          };
        }
        Object.defineProperty(o, k2, desc);
      }
    : function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
      });
var __setModuleDefault =
  (this && this.__setModuleDefault) ||
  (Object.create
    ? function (o, v) {
        Object.defineProperty(o, 'default', {
          enumerable: true,
          value: v,
        });
      }
    : function (o, v) {
        o['default'] = v;
      });
var __importStar =
  (this && this.__importStar) ||
  function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null)
      for (var k in mod)
        if (k !== 'default' && Object.prototype.hasOwnProperty.call(mod, k))
          __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
  };
var __rest =
  (this && this.__rest) ||
  function (s, e) {
    var t = {};
    for (var p in s)
      if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === 'function')
      for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
          t[p[i]] = s[p[i]];
      }
    return t;
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importStar(require('react'));
var clsx_1 = __importDefault(require('clsx'));
require('../../../styles/components/notifications/customToastNotification.scss');
require('../../../styles/components/notifications/toastNotification.scss');
var constants_1 = require('../constants');
var hooks_1 = require('../hooks');
var CustomToastNotification = function CustomToastNotification(props) {
  var _a = props.variant,
    variant = _a === void 0 ? constants_1.NOTIFICATION_VARIANT_DEFAULT : _a,
    _b = props.size,
    size = _b === void 0 ? constants_1.NOTIFICATION_SIZE_DEFAULT : _b,
    _c = props.id,
    id = _c === void 0 ? constants_1.DEFAULT_ID : _c,
    timeout = props.timeout,
    _d = props.onOpen,
    onOpen = _d === void 0 ? function () {} : _d,
    _e = props.className,
    classes = _e === void 0 ? '' : _e,
    _f = props.position,
    position = _f === void 0 ? constants_1.NOTIFICATION_POSITION.topRight : _f,
    children = props.children,
    restProps = __rest(props, [
      'variant',
      'size',
      'id',
      'timeout',
      'onOpen',
      'className',
      'position',
      'children',
    ]);
  var timeoutRef = (0, react_1.useRef)();
  var notificationWrapper = (0, react_1.useRef)(null);
  var isOpen = (0, hooks_1.useNotifications)({
    onOpen: onOpen,
    onClose: function onClose() {},
  }).isOpen;
  (0, hooks_1.useNotificationsHeight)(notificationWrapper.current, isOpen);
  var closeNotification = (0, hooks_1.useNotificationsStack)().closeNotification;
  var handleCloseToastNotification = (0, react_1.useCallback)(
    function () {
      closeNotification(id);
    },
    [closeNotification, id]
  );
  (0, react_1.useEffect)(
    function () {
      if (timeout) {
        timeoutRef.current = setTimeout(handleCloseToastNotification, timeout);
      }
      return function () {
        return clearTimeout(timeoutRef.current);
      };
    },
    [timeout, id, closeNotification, handleCloseToastNotification]
  );
  var rootClassName = (0, clsx_1['default'])(
    'custom-toast-notification',
    'custom-toast-notification--size-'.concat(constants_1.NOTIFICATION_SIZES[size]),
    'custom-toast-notification--'.concat(constants_1.NOTIFICATION_VARIANTS[variant]),
    'custom-toast-notification--'.concat(constants_1.NOTIFICATION_POSITION[position]),
    ''.concat(classes)
  );
  return react_1['default'].createElement(
    'div',
    __assign(
      {
        className: rootClassName,
        ref: notificationWrapper,
      },
      restProps
    ),
    react_1['default'].createElement(
      'div',
      {
        className: 'custom-toast-notification__wrapper',
      },
      (children && children(handleCloseToastNotification)) ||
        react_1['default'].createElement(
          'div',
          {
            className: 'custom-toast-notification__content',
          },
          '\u0417\u0434\u0435\u0441\u044C \u043C\u043E\u0436\u0435\u0442 \u0431\u044B\u0442\u044C \u043B\u044E\u0431\u043E\u0439 \u043A\u043E\u043D\u0442\u0435\u043D\u0442'
        )
    )
  );
};

CustomToastNotification.propTypes = {
  /**
   * Задает контент
   */
  children: PropTypes.func,
  className: PropTypes.string,
  /**
   * Задает id для компонента
   */
  id: PropTypes.string,
  /**
   * Callback функция, вызываемая при появлении уведомления
   * @returns {undefined}
   */
  onOpen: PropTypes.func,
  /**
   * Задает расположение уведомления
   */
  position: PropTypes.oneOf([
    'bottomCenter',
    'bottomLeft',
    'bottomRight',
    'topCenter',
    'topLeft',
    'topRight',
  ]),
  /**
   * Задает размер уведомления
   *  @default m
   */
  size: PropTypes.oneOf(['m']),
  /**
   * Задает время в милисекундах, через которое уведомление скроется
   */
  timeout: PropTypes.number,
  /**
   * Задает вариант уведомления
   *  @default primary
   */
  variant: PropTypes.oneOf(['primary']),
};

exports['default'] = CustomToastNotification;
