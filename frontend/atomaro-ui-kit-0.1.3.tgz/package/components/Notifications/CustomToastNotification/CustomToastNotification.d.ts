import { FC } from 'react';
import '../../../styles/components/notifications/customToastNotification.scss';
import '../../../styles/components/notifications/toastNotification.scss';
import { ICustomToastNotification } from './types';
declare const CustomToastNotification: FC<ICustomToastNotification>;
export default CustomToastNotification;
