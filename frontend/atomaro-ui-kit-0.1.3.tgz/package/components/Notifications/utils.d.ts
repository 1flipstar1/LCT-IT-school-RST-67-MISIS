import { ReactElement } from 'react';
export declare const createActionButtons: (actionButtons?: ReactElement[]) => {
    button: ReactElement<any, string | import("react").JSXElementConstructor<any>>;
    id: number;
}[];
