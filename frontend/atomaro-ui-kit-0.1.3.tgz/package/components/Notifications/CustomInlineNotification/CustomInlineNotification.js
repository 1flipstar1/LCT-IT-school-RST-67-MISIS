'use strict';
var PropTypes = require('prop-types');

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __rest =
  (this && this.__rest) ||
  function (s, e) {
    var t = {};
    for (var p in s)
      if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === 'function')
      for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
          t[p[i]] = s[p[i]];
      }
    return t;
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var react_transition_group_1 = require('react-transition-group');
var clsx_1 = __importDefault(require('clsx'));
require('../../../styles/components/notifications/customInlineNotification.scss');
var constants_1 = require('../constants');
var CustomInlineNotification = function CustomInlineNotification(props) {
  var _a = props.variant,
    variant = _a === void 0 ? constants_1.NOTIFICATION_VARIANT_DEFAULT : _a,
    _b = props.size,
    size = _b === void 0 ? constants_1.NOTIFICATION_SIZE_DEFAULT : _b,
    _c = props.isOpened,
    isOpened = _c === void 0 ? true : _c,
    _d = props.className,
    classes = _d === void 0 ? '' : _d,
    children = props.children,
    restProps = __rest(props, ['variant', 'size', 'isOpened', 'className', 'children']);
  var rootClassName = (0, clsx_1['default'])(
    'custom-inline-notification',
    'custom-inline-notification--size-'.concat(constants_1.NOTIFICATION_SIZES[size]),
    'custom-inline-notification--'.concat(constants_1.NOTIFICATION_VARIANTS[variant]),
    ''.concat(classes)
  );
  return react_1['default'].createElement(
    react_transition_group_1.CSSTransition,
    {
      in: isOpened,
      classNames: 'custom-inline-notifications',
      timeout: constants_1.INLINE_NOTIFICATION_TIMEOUT,
      mountOnEnter: true,
      unmountOnExit: true,
    },
    react_1['default'].createElement(
      'div',
      __assign(
        {
          className: rootClassName,
        },
        restProps
      ),
      (children && children) || 'Здесь может быть любой контент'
    )
  );
};

CustomInlineNotification.propTypes = {
  /**
   * Задает контент
   */
  children: PropTypes.node,
  className: PropTypes.string,
  /**
   * Управление состоянием
   */
  isOpened: PropTypes.bool.isRequired,
  /**
   * Задает размер уведомления
   *  @default m
   */
  size: PropTypes.oneOf(['m']),
  /**
   * Задает вариант уведомления
   *  @default primary
   */
  variant: PropTypes.oneOf(['primary']),
};

exports['default'] = CustomInlineNotification;
