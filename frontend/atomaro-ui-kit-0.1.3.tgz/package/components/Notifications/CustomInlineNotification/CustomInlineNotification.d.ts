import { FC } from 'react';
import '../../../styles/components/notifications/customInlineNotification.scss';
import { ICustomInlineNotification } from './types';
declare const CustomInlineNotification: FC<ICustomInlineNotification>;
export default CustomInlineNotification;
