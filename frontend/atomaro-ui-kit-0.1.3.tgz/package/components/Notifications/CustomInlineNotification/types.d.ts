import { ReactNode } from 'react';
import { INotification } from '../types';
export interface ICustomInlineNotification extends Pick<INotification, 'className' | 'style' | 'variant' | 'size' | 'id'> {
    /** Управление состоянием */
    isOpened: boolean;
    /** Задает контент */
    children?: ReactNode;
}
