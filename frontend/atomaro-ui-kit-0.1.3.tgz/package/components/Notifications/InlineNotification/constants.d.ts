/// <reference types="react" />
export declare const INLINE_ICON_COMPONENT: {
    error: {
        (props: import("@atomaro/icons/types").IIconProps): import("react").JSX.Element;
        displayName: string;
    };
    info: {
        (props: import("@atomaro/icons/types").IIconProps): import("react").JSX.Element;
        displayName: string;
    };
    success: {
        (props: import("@atomaro/icons/types").IIconProps): import("react").JSX.Element;
        displayName: string;
    };
    warning: {
        (props: import("@atomaro/icons/types").IIconProps): import("react").JSX.Element;
        displayName: string;
    };
};
