'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __createBinding =
  (this && this.__createBinding) ||
  (Object.create
    ? function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ('get' in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = {
            enumerable: true,
            get: function get() {
              return m[k];
            },
          };
        }
        Object.defineProperty(o, k2, desc);
      }
    : function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
      });
var __setModuleDefault =
  (this && this.__setModuleDefault) ||
  (Object.create
    ? function (o, v) {
        Object.defineProperty(o, 'default', {
          enumerable: true,
          value: v,
        });
      }
    : function (o, v) {
        o['default'] = v;
      });
var __importStar =
  (this && this.__importStar) ||
  function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null)
      for (var k in mod)
        if (k !== 'default' && Object.prototype.hasOwnProperty.call(mod, k))
          __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
  };
var __rest =
  (this && this.__rest) ||
  function (s, e) {
    var t = {};
    for (var p in s)
      if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === 'function')
      for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
          t[p[i]] = s[p[i]];
      }
    return t;
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importStar(require('react'));
var react_transition_group_1 = require('react-transition-group');
var clsx_1 = __importDefault(require('clsx'));
require('../../../styles/components/notifications/inlineNotification.scss');
var constants_1 = require('../constants');
var constants_2 = require('./constants');
var hooks_1 = require('../hooks');
var utils_1 = require('../utils');
var CloseButton_1 = __importDefault(require('../../Button/CloseButton/CloseButton'));
var FunctionButton_1 = __importDefault(require('../../Button/FunctionButton/FunctionButton'));
var InlineNotification = function InlineNotification(props) {
  var _a = props.colorScheme,
    colorScheme = _a === void 0 ? constants_1.NOTIFICATION_COLORSCHEME_DEFAULT : _a,
    _b = props.variant,
    variant = _b === void 0 ? constants_1.NOTIFICATION_VARIANT_DEFAULT : _b,
    _c = props.size,
    size = _c === void 0 ? constants_1.NOTIFICATION_SIZE_DEFAULT : _c,
    title = props.title,
    subtitle = props.subtitle,
    _d = props.actionButtons,
    actionButtons = _d === void 0 ? [] : _d,
    _e = props.onOpen,
    onOpen = _e === void 0 ? function () {} : _e,
    _f = props.onClose,
    onClose = _f === void 0 ? function () {} : _f,
    closeButton = props.closeButton,
    _g = props.id,
    id = _g === void 0 ? constants_1.DEFAULT_ID : _g,
    _h = props.icon,
    icon = _h === void 0 ? false : _h,
    _j = props.className,
    classes = _j === void 0 ? '' : _j,
    restProps = __rest(props, [
      'colorScheme',
      'variant',
      'size',
      'title',
      'subtitle',
      'actionButtons',
      'onOpen',
      'onClose',
      'closeButton',
      'id',
      'icon',
      'className',
    ]);
  var Icon = constants_2.INLINE_ICON_COMPONENT[colorScheme];
  var _k = (0, hooks_1.useNotifications)({
      onOpen: onOpen,
      onClose: onClose,
    }),
    handleCloseNotification = _k.handleCloseNotification,
    isOpen = _k.isOpen;
  var buttonsRef = (0, hooks_1.useNotificationsButtons)().buttonsRef;
  var buttons = (0, utils_1.createActionButtons)(
    actionButtons.map(function (_a) {
      var action = _a.action,
        buttonProps = __rest(_a, ['action']);
      return react_1['default'].createElement(
        FunctionButton_1['default'],
        __assign({}, buttonProps, {
          onClick: function onClick() {
            return action(id);
          },
        })
      );
    })
  );
  var notificationIcon =
    Icon &&
    react_1['default'].createElement(
      'div',
      {
        className: 'inline-notification__icon',
      },
      react_1['default'].createElement(Icon, {
        fill: 'unset',
        size: constants_1.ICON_SIZE,
      })
    );
  var notificationTitle =
    title &&
    react_1['default'].createElement(
      'h2',
      {
        className: 'inline-notification__title',
      },
      title
    );
  var notificationSubtitle =
    subtitle &&
    react_1['default'].createElement(
      'p',
      {
        className: 'inline-notification__subtitle',
      },
      subtitle
    );
  var notificationButtons =
    buttons.length > 0 &&
    react_1['default'].createElement(
      'div',
      {
        className: 'inline-notification__actions',
        ref: buttonsRef,
      },
      buttons.map(function (elem) {
        return react_1['default'].createElement(
          react_1.Fragment,
          {
            key: elem.id,
          },
          elem.button
        );
      })
    );
  var notificationCloseButton =
    closeButton &&
    react_1['default'].createElement(
      'div',
      {
        className: 'inline-notification__close',
      },
      react_1['default'].createElement(CloseButton_1['default'], {
        onClick: handleCloseNotification,
        size: 's',
      })
    );
  var rootClassName = (0, clsx_1['default'])(
    'inline-notification',
    'inline-notification--size-'.concat(constants_1.NOTIFICATION_SIZES[size]),
    'inline-notification--'.concat(constants_1.NOTIFICATION_VARIANTS[variant]),
    'inline-notification--'.concat(constants_1.NOTIFICATION_COLORSCHEMES[colorScheme]),
    ''.concat(classes)
  );
  return react_1['default'].createElement(
    react_transition_group_1.CSSTransition,
    {
      in: isOpen,
      classNames: 'inline-notifications',
      timeout: constants_1.INLINE_NOTIFICATION_TIMEOUT,
      mountOnEnter: true,
      unmountOnExit: true,
    },
    react_1['default'].createElement(
      'div',
      __assign(
        {
          className: rootClassName,
        },
        restProps
      ),
      icon && notificationIcon,
      react_1['default'].createElement(
        'div',
        {
          className: 'inline-notification__content',
        },
        react_1['default'].createElement(
          'div',
          {
            className: 'inline-notification__inner',
          },
          notificationTitle,
          notificationSubtitle,
          notificationButtons
        ),
        notificationCloseButton
      )
    )
  );
};
exports['default'] = InlineNotification;
