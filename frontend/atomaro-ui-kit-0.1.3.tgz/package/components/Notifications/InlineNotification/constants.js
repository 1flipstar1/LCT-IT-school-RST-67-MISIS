'use strict';

var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
var _a;
Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.INLINE_ICON_COMPONENT = void 0;
/* eslint-disable import/no-extraneous-dependencies */
var ErrorColor_1 = __importDefault(require('@atomaro/icons/24/alert/ErrorColor'));
var InformationColor_1 = __importDefault(require('@atomaro/icons/24/alert/InformationColor'));
var OkColor_1 = __importDefault(require('@atomaro/icons/24/alert/OkColor'));
var AttentionColor_1 = __importDefault(require('@atomaro/icons/24/alert/AttentionColor'));
var constants_1 = require('../constants');
exports.INLINE_ICON_COMPONENT =
  ((_a = {}),
  (_a[constants_1.NOTIFICATION_COLORSCHEMES.error] = ErrorColor_1['default']),
  (_a[constants_1.NOTIFICATION_COLORSCHEMES.info] = InformationColor_1['default']),
  (_a[constants_1.NOTIFICATION_COLORSCHEMES.success] = OkColor_1['default']),
  (_a[constants_1.NOTIFICATION_COLORSCHEMES.warning] = AttentionColor_1['default']),
  _a);
