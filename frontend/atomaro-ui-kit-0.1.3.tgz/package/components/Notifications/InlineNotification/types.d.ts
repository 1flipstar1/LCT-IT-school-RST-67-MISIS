import { ReactNode } from 'react';
import { INotification, INotificationButton } from '../types';
export interface IInlineNotification extends INotification {
    /** Задает кнопки уведомления
     * @param {string} text - Текст кнопки
     * @param {(id: string) => void} action - Callback функция, вызываемая при клике
     */
    actionButtons?: INotificationButton[];
    children?: ReactNode;
}
