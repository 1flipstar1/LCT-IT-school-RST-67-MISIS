import React from 'react';
import '../../../styles/components/notifications/inlineNotification.scss';
import { IInlineNotification } from './types';
declare const InlineNotification: (props: IInlineNotification) => React.JSX.Element;
export default InlineNotification;
