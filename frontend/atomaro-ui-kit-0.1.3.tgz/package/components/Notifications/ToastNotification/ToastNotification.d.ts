import React from 'react';
import '../../../styles/components/notifications/toastNotification.scss';
import { IToastNotification } from './types';
declare const ToastNotification: React.FC<IToastNotification>;
export default ToastNotification;
