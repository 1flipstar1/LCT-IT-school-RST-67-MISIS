'use strict';
var PropTypes = require('prop-types');

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __createBinding =
  (this && this.__createBinding) ||
  (Object.create
    ? function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ('get' in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = {
            enumerable: true,
            get: function get() {
              return m[k];
            },
          };
        }
        Object.defineProperty(o, k2, desc);
      }
    : function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
      });
var __setModuleDefault =
  (this && this.__setModuleDefault) ||
  (Object.create
    ? function (o, v) {
        Object.defineProperty(o, 'default', {
          enumerable: true,
          value: v,
        });
      }
    : function (o, v) {
        o['default'] = v;
      });
var __importStar =
  (this && this.__importStar) ||
  function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null)
      for (var k in mod)
        if (k !== 'default' && Object.prototype.hasOwnProperty.call(mod, k))
          __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
  };
var __rest =
  (this && this.__rest) ||
  function (s, e) {
    var t = {};
    for (var p in s)
      if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === 'function')
      for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
          t[p[i]] = s[p[i]];
      }
    return t;
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importStar(require('react'));
var clsx_1 = __importDefault(require('clsx'));
require('../../../styles/components/notifications/toastNotification.scss');
var constants_1 = require('./constants');
var constants_2 = require('../constants');
var hooks_1 = require('../hooks');
var utils_1 = require('../utils');
var CloseButton_1 = __importDefault(require('../../Button/CloseButton/CloseButton'));
var FunctionButton_1 = __importDefault(require('../../Button/FunctionButton/FunctionButton'));
var ToastNotification = function ToastNotification(props) {
  var _a = props.colorScheme,
    colorScheme = _a === void 0 ? constants_2.NOTIFICATION_COLORSCHEME_DEFAULT : _a,
    _b = props.variant,
    variant = _b === void 0 ? constants_2.NOTIFICATION_VARIANT_DEFAULT : _b,
    _c = props.size,
    size = _c === void 0 ? constants_2.NOTIFICATION_SIZE_DEFAULT : _c,
    title = props.title,
    subtitle = props.subtitle,
    _d = props.id,
    id = _d === void 0 ? constants_2.DEFAULT_ID : _d,
    timeout = props.timeout,
    _e = props.actionButtons,
    actionButtons = _e === void 0 ? [] : _e,
    _f = props.onOpen,
    onOpen = _f === void 0 ? function () {} : _f,
    _g = props.onClose,
    onClose = _g === void 0 ? function () {} : _g,
    closeButton = props.closeButton,
    _h = props.position,
    position = _h === void 0 ? constants_2.NOTIFICATION_POSITION.topRight : _h,
    _j = props.icon,
    icon = _j === void 0 ? false : _j,
    _k = props.className,
    classes = _k === void 0 ? '' : _k,
    restProps = __rest(props, [
      'colorScheme',
      'variant',
      'size',
      'title',
      'subtitle',
      'id',
      'timeout',
      'actionButtons',
      'onOpen',
      'onClose',
      'closeButton',
      'position',
      'icon',
      'className',
    ]);
  var Icon = constants_1.TOAST_ICON_COMPONENT[colorScheme];
  var timeoutRef = (0, react_1.useRef)();
  var notificationWrapper = (0, react_1.useRef)(null);
  var isOpen = (0, hooks_1.useNotifications)({
    onOpen: onOpen,
    onClose: onClose,
  }).isOpen;
  (0, hooks_1.useNotificationsHeight)(notificationWrapper.current, isOpen);
  var closeNotification = (0, hooks_1.useNotificationsStack)().closeNotification;
  var buttonsRef = (0, hooks_1.useNotificationsButtons)().buttonsRef;
  var handleCloseToastNotification = (0, react_1.useCallback)(
    function () {
      onClose();
      closeNotification(id);
    },
    [onClose, closeNotification, id]
  );
  (0, react_1.useEffect)(
    function () {
      if (timeout) {
        timeoutRef.current = setTimeout(handleCloseToastNotification, timeout);
      }
      return function () {
        return clearTimeout(timeoutRef.current);
      };
    },
    [onClose, timeout, id, closeNotification, handleCloseToastNotification]
  );
  var buttons = (0, utils_1.createActionButtons)(
    actionButtons.map(function (_a) {
      var action = _a.action,
        buttonProps = __rest(_a, ['action']);
      return react_1['default'].createElement(
        FunctionButton_1['default'],
        __assign({}, buttonProps, {
          onClick: function onClick() {
            return action(id);
          },
        })
      );
    })
  );
  var notificationIcon =
    Icon &&
    react_1['default'].createElement(
      'div',
      {
        className: 'toast-notification__icon',
      },
      react_1['default'].createElement(Icon, {
        fill: 'unset',
        size: constants_2.ICON_SIZE,
      })
    );
  var notificationTitle =
    title &&
    react_1['default'].createElement(
      'h4',
      {
        className: 'toast-notification__title',
      },
      title
    );
  var notificationSubtitle =
    subtitle &&
    react_1['default'].createElement(
      'p',
      {
        className: 'toast-notification__subtitle',
      },
      subtitle
    );
  var notificationCloseButton =
    closeButton &&
    react_1['default'].createElement(
      'div',
      {
        className: 'toast-notification__close',
      },
      react_1['default'].createElement(CloseButton_1['default'], {
        onClick: handleCloseToastNotification,
        size: 's',
      })
    );
  var notificationButtons =
    buttons.length > 0 &&
    react_1['default'].createElement(
      'div',
      {
        className: 'toast-notification__actions',
        ref: buttonsRef,
      },
      buttons.map(function (elem) {
        return react_1['default'].createElement(
          react_1.Fragment,
          {
            key: elem.id,
          },
          elem.button
        );
      })
    );
  var rootClassName = (0, clsx_1['default'])(
    'toast-notification',
    'toast-notification--size-'.concat(constants_2.NOTIFICATION_SIZES[size]),
    'toast-notification--'.concat(constants_2.NOTIFICATION_VARIANTS[variant]),
    'toast-notification--'.concat(constants_2.NOTIFICATION_COLORSCHEMES[colorScheme]),
    'toast-notification--'.concat(constants_2.NOTIFICATION_POSITION[position]),
    ''.concat(classes)
  );
  return react_1['default'].createElement(
    'div',
    __assign(
      {
        className: rootClassName,
        ref: notificationWrapper,
      },
      restProps
    ),
    react_1['default'].createElement(
      'div',
      {
        className: 'toast-notification__wrapper',
      },
      icon && notificationIcon,
      react_1['default'].createElement(
        'div',
        {
          className: 'toast-notification__content',
        },
        react_1['default'].createElement(
          'div',
          {
            className: 'toast-notification__inner',
          },
          notificationTitle,
          notificationSubtitle,
          notificationButtons
        ),
        notificationCloseButton
      )
    )
  );
};

ToastNotification.propTypes = {
  /**
   * Задает кнопки уведомления
   * @param {string} text - Текст кнопки
   * @param {(id: string) => void} action - Callback функция, вызываемая при клике
   */
  actionButtons: PropTypes.arrayOf(PropTypes.object),
  className: PropTypes.string,
  /**
   * Задаёт отображение кнопки "Закрыть"
   *  @default true
   */
  closeButton: PropTypes.bool,
  /**
   * Задает основной цвет для уведомления
   *  @default info
   */
  colorScheme: PropTypes.oneOf(['error', 'info', 'success', 'warning']),
  /**
   * Задаёт отображение иконки"
   *  @default true
   */
  icon: PropTypes.bool,
  /**
   * Задает id для компонента
   */
  id: PropTypes.string,
  /**
   * Callback функция, вызываемая при закрытии уведомления
   * @returns {undefined}
   */
  onClose: PropTypes.func,
  /**
   * Callback функция, вызываемая при появлении уведомления
   * @returns {undefined}
   */
  onOpen: PropTypes.func,
  /**
   * Задает расположение уведомления
   */
  position: PropTypes.oneOf([
    'bottomCenter',
    'bottomLeft',
    'bottomRight',
    'topCenter',
    'topLeft',
    'topRight',
  ]),
  /**
   * Задает размер уведомления
   *  @default m
   */
  size: PropTypes.oneOf(['m']),
  /**
   * Задает подзаголовок уведомления
   */
  subtitle: PropTypes.string,
  /**
   * Задает время в милисекундах, через которое уведомление скроется
   */
  timeout: PropTypes.number,
  /**
   * Задает заголовок уведомления
   */
  title: PropTypes.string,
  /**
   * Задает вариант уведомления
   *  @default primary
   */
  variant: PropTypes.oneOf(['primary']),
};

exports['default'] = ToastNotification;
