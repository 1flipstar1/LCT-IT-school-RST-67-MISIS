import { NotificationPositionType, INotification, INotificationButton } from '../types';
export interface IToastNotification extends INotification {
    /** Задает время в милисекундах, через которое уведомление скроется */
    timeout?: number;
    /** Задает кнопки уведомления
     * @param {string} text - Текст кнопки
     * @param {(id: string) => void} action - Callback функция, вызываемая при клике
     */
    actionButtons?: INotificationButton[];
    /** Задает расположение уведомления */
    position?: NotificationPositionType;
}
export interface IToastNotificationWithIsCustom extends IToastNotification {
    isCustom?: boolean;
}
