import React from 'react';
import '../../styles/components/modal.scss';
import { IModalProps } from './types';
declare const Modal: React.FC<IModalProps>;
export default Modal;
