export declare enum SCROLL_BEHAVIOR_MAP {
    inside = "inside",
    outside = "outside"
}
export declare const DEFAULT_MARGIN_TOP = 56;
