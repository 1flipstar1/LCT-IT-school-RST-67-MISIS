"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.DEFAULT_MARGIN_TOP = exports.SCROLL_BEHAVIOR_MAP = void 0;
var SCROLL_BEHAVIOR_MAP;
(function (SCROLL_BEHAVIOR_MAP) {
  SCROLL_BEHAVIOR_MAP["inside"] = "inside";
  SCROLL_BEHAVIOR_MAP["outside"] = "outside";
})(SCROLL_BEHAVIOR_MAP = exports.SCROLL_BEHAVIOR_MAP || (exports.SCROLL_BEHAVIOR_MAP = {}));
exports.DEFAULT_MARGIN_TOP = 56;