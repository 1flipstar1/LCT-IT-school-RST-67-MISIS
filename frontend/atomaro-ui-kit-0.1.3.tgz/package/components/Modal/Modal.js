'use strict';
var PropTypes = require('prop-types');

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __createBinding =
  (this && this.__createBinding) ||
  (Object.create
    ? function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ('get' in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = {
            enumerable: true,
            get: function get() {
              return m[k];
            },
          };
        }
        Object.defineProperty(o, k2, desc);
      }
    : function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
      });
var __setModuleDefault =
  (this && this.__setModuleDefault) ||
  (Object.create
    ? function (o, v) {
        Object.defineProperty(o, 'default', {
          enumerable: true,
          value: v,
        });
      }
    : function (o, v) {
        o['default'] = v;
      });
var __importStar =
  (this && this.__importStar) ||
  function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null)
      for (var k in mod)
        if (k !== 'default' && Object.prototype.hasOwnProperty.call(mod, k))
          __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importStar(require('react'));
var react_dom_1 = require('react-dom');
var react_transition_group_1 = require('react-transition-group');
var clsx_1 = __importDefault(require('clsx'));
var constants_1 = require('../Overlay/constants');
var Overlay_1 = __importDefault(require('../Overlay/Overlay'));
require('../../styles/components/modal.scss');
var function_1 = require('../../utils/function');
var constants_2 = require('./constants');
var Modal = function Modal(_a) {
  var isOpen = _a.isOpen,
    children = _a.children,
    maxWidth = _a.maxWidth,
    maxHeight = _a.maxHeight,
    _b = _a.useInPortal,
    portal = _b === void 0 ? false : _b,
    _c = _a.unmount,
    unmount = _c === void 0 ? false : _c,
    centered = _a.centered,
    _d = _a.overlayVariant,
    overlayVariant = _d === void 0 ? constants_1.OVERLAY_VARIANTS.primary : _d,
    _e = _a.showOverlay,
    showOverlay = _e === void 0 ? true : _e,
    _f = _a.scrollBehaviour,
    scroll = _f === void 0 ? constants_2.SCROLL_BEHAVIOR_MAP.inside : _f,
    style = _a.style,
    _g = _a.marginTop,
    marginTop = _g === void 0 ? constants_2.DEFAULT_MARGIN_TOP : _g,
    onClickOverlay = _a.onClickOverlay,
    _h = _a.onEsc,
    onEsc = _h === void 0 ? function_1.noop : _h;
  var modalRef = (0, react_1.useRef)(null);
  var scrollBehaviour = scroll === constants_2.SCROLL_BEHAVIOR_MAP.inside;
  var _j = (0, react_1.useState)(null),
    overlayHeight = _j[0],
    setOverlayHeight = _j[1];
  (0, react_1.useEffect)(
    function () {
      if (modalRef.current) {
        setOverlayHeight(modalRef.current.offsetHeight + marginTop * 2);
      }
      window.addEventListener('keydown', onEsc);
      return function () {
        window.removeEventListener('keydown', onEsc);
      };
      // eslint-disable-next-line react-hooks/exhaustive-deps
    },
    [isOpen]
  );
  var rootClassName = (0, clsx_1['default'])(
    'modal',
    centered && 'modal--centered',
    scrollBehaviour && 'modal--scroll-behaviour'
  );
  var rootStyles = __assign(
    __assign(
      __assign(
        {},
        !centered
          ? {
              '--modal-margin-top': ''.concat(marginTop, 'px'),
            }
          : {}
      ),
      {
        '--modal-max-width': maxWidth || 'auto',
        '--modal-max-height': maxHeight || 'auto',
      }
    ),
    style
  );
  var modal = react_1['default'].createElement(
    'div',
    {
      className: rootClassName,
      ref: modalRef,
      style: rootStyles,
    },
    children
  );
  return react_1['default'].createElement(
    react_transition_group_1.CSSTransition,
    {
      in: isOpen,
      nodeRef: modalRef,
      timeout: 300,
      classNames: 'modal',
      mountOnEnter: true,
      unmountOnExit: unmount,
    },
    react_1['default'].createElement(
      'div',
      {
        className: (0, clsx_1['default'])('modal__wrapper', !isOpen && 'modal__wrapper--hidden'),
      },
      react_1['default'].createElement(Overlay_1['default'], {
        style: {
          minHeight: '100%',
          height: ''.concat(overlayHeight, 'px'),
        },
        variant: overlayVariant,
        isOpened: showOverlay && isOpen,
        onClick: onClickOverlay,
        useInPortal: portal,
      }),
      portal ? (0, react_dom_1.createPortal)(modal, document.body) : modal
    )
  );
};

Modal.propTypes = {
  /**
   * Выравнивает модальное окно вертикально по центру
   */
  centered: PropTypes.bool,
  children: PropTypes.node,
  /**
   * State модального окна
   */
  isOpen: PropTypes.bool,
  /**
   * Величина отступа сверху от модалки, если параметр centered не указан
   *  @default 64
   */
  marginTop: PropTypes.number,
  /**
   * Задает максимальную высоту модального окна (например, '100px' - значение в пикселях, а '100%' - в процентах)
   */
  maxHeight: PropTypes.string,
  /**
   * Задает максимальную ширину модального окна (например, '100px' - значение в пикселях, а '100%' - в процентах)
   */
  maxWidth: PropTypes.string,
  /**
   * Callback функция, вызываемая при клике на Overlay
   */
  onClickOverlay: PropTypes.func,
  /**
   * Callback функция, вызываемая при нажатии на Escape
   */
  onEsc: PropTypes.func,
  /**
   * Определяет как отображается Overlay
   *  @default primary
   */
  overlayVariant: PropTypes.oneOf(['primary', 'secondary']),
  /**
   * Задаёт использование внутреннего или внешнего скролла для модального окна
   * (outside не работает вместе c centered)
   *  @default inside
   */
  scrollBehaviour: PropTypes.oneOf(['inside', 'outside']),
  /**
   * Задает отображение overlay при открытой панеле
   */
  showOverlay: PropTypes.bool,
  /**
   * Задает дополнительные стили для компонента
   */
  style: PropTypes.object,
  /**
   * Параметр, отвечающий за то, удалять ли модальное окно из DOM дерева или нет
   */
  unmount: PropTypes.bool,
  /**
   * Задаёт вариант использования с React Portal
   * @default false
   */
  useInPortal: PropTypes.bool,
};

exports['default'] = Modal;
