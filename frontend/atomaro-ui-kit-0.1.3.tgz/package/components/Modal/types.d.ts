import React, { CSSProperties, ReactNode } from 'react';
import { OverlayVariantType } from '../Overlay/constants';
import { SCROLL_BEHAVIOR_MAP } from './constants';
export interface IModalProps {
    /** State модального окна */
    isOpen?: boolean;
    /** Задает максимальную ширину модального окна (например, '100px' - значение в пикселях, а '100%' - в процентах) */
    maxWidth?: string;
    /** Задает максимальную высоту модального окна (например, '100px' - значение в пикселях, а '100%' - в процентах) */
    maxHeight?: string;
    /** Выравнивает модальное окно вертикально по центру */
    centered?: boolean;
    /** Величина отступа сверху от модалки, если параметр centered не указан
     *  @default 64 */
    marginTop?: number;
    /** Задаёт использование внутреннего или внешнего скролла для модального окна
     * (outside не работает вместе c centered)
     *  @default inside */
    scrollBehaviour?: SCROLL_BEHAVIOR_MAP;
    /** Ref элемента, клик по которому, запускает модальное окно. Необходимо для расчета координат элемента */
    buttonRef?: React.RefObject<any>;
    /** Задает дополнительные стили для компонента */
    style?: CSSProperties;
    /** Задает отображение overlay при открытой панеле */
    showOverlay?: boolean;
    /** Определяет как отображается Overlay
     *  @default primary */
    overlayVariant?: OverlayVariantType;
    /** Параметр, отвечающий за то, удалять ли модальное окно из DOM дерева или нет */
    unmount?: boolean;
    /** Задаёт вариант использования с React Portal
     * @default false */
    useInPortal?: boolean;
    children?: ReactNode;
    /** Задаёт класс компоненту */
    className?: string;
    /** Callback функция, вызываемая при клике на Overlay */
    onClickOverlay?: () => void;
    /** Callback функция, вызываемая при нажатии на Escape */
    onEsc?: (any: any) => void;
}
