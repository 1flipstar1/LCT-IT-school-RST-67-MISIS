import { ReactNode } from 'react';
export interface MonthContextProviderProps {
    months: string[];
    children: ReactNode;
    date: Date;
    isRange?: boolean;
    activeDate?: Date;
    secondDate?: Date;
}
