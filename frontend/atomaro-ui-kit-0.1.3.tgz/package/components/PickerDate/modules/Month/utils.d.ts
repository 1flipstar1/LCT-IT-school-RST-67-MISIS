import { DATE_STATUS } from '../../constants';
export declare const getStatusMonth: (date: Date, month: Date, focusedMonths: string[], activeDate?: Date, secondDate?: Date) => DATE_STATUS.default | DATE_STATUS.focused | DATE_STATUS.focusedFirst | DATE_STATUS.focusedLast;
