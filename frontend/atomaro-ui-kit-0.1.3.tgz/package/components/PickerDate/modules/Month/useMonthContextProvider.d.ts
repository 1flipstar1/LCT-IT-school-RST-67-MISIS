import { CalendarItemType } from '../../types';
import { MonthContextProviderProps } from './types';
export declare const useMonthContextProvider: (props: MonthContextProviderProps) => {
    months: CalendarItemType[];
    handleMouseEnter: (value: Date) => void;
    handleMouseLeave: () => void;
};
