'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.MonthsContext = void 0;
var react_1 = require('react');
exports.MonthsContext = (0, react_1.createContext)({});
