import { FC } from 'react';
import { MonthContextProviderProps } from './types';
export declare const MonthContextProvider: FC<MonthContextProviderProps>;
