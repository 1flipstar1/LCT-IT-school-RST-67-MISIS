/// <reference types="react" />
import { CalendarItemType } from '../../types';
type MonthsContextType = {
    cols: number;
    months: CalendarItemType[];
    handleMouseEnter: (value: Date) => void;
    handleMouseLeave: () => void;
};
export declare const MonthsContext: import("react").Context<MonthsContextType>;
export {};
