'use strict';
var PropTypes = require('prop-types');

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.MonthContextProvider = void 0;
var react_1 = __importDefault(require('react'));
var MonthContext_1 = require('./MonthContext');
var useMonthContextProvider_1 = require('./useMonthContextProvider');
var MonthContextProvider = function MonthContextProvider(props) {
  var children = props.children;
  var _a = (0, useMonthContextProvider_1.useMonthContextProvider)(__assign({}, props)),
    months = _a.months,
    handleMouseEnter = _a.handleMouseEnter,
    handleMouseLeave = _a.handleMouseLeave;
  return react_1['default'].createElement(
    MonthContext_1.MonthsContext.Provider,
    {
      value: {
        cols: 3,
        months: months,
        handleMouseEnter: handleMouseEnter,
        handleMouseLeave: handleMouseLeave,
      },
    },
    children
  );
};

MonthContextProvider.propTypes = {
  children: PropTypes.node,
};

exports.MonthContextProvider = MonthContextProvider;
