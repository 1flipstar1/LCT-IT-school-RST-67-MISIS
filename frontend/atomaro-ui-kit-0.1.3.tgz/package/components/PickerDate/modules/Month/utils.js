'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.getStatusMonth = void 0;
var constants_1 = require('../../constants');
var getStatusMonth = function getStatusMonth(date, month, focusedMonths, activeDate, secondDate) {
  var compatariveActiveDate = activeDate
    ? new Date(
        activeDate === null || activeDate === void 0 ? void 0 : activeDate.getFullYear(),
        activeDate.getMonth(),
        1
      )
    : undefined;
  var compatariveSecondDate = secondDate
    ? new Date(secondDate.getFullYear(), secondDate.getMonth(), 1)
    : undefined;
  if (activeDate && !secondDate) {
    if (compatariveActiveDate.toDateString() === month.toDateString())
      return constants_1.DATE_STATUS.focusedFirst;
    if (focusedMonths && focusedMonths.length && focusedMonths.includes(month.toDateString())) {
      if (month.toDateString() === focusedMonths[focusedMonths.length - 1]) {
        return constants_1.DATE_STATUS.focusedLast;
      }
      return constants_1.DATE_STATUS.focused;
    }
  }
  if (activeDate && secondDate) {
    if (compatariveActiveDate.toDateString() === month.toDateString())
      return constants_1.DATE_STATUS.focusedFirst;
    if (compatariveSecondDate.toDateString() === month.toDateString())
      return constants_1.DATE_STATUS.focusedLast;
    if (month > compatariveActiveDate && month < compatariveSecondDate)
      return constants_1.DATE_STATUS.focused;
  }
  return constants_1.DATE_STATUS['default'];
};
exports.getStatusMonth = getStatusMonth;
