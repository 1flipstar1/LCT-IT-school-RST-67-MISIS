'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.useMonthContextProvider = void 0;
var react_1 = require('react');
var utils_1 = require('./utils');
var useMonthContextProvider = function useMonthContextProvider(props) {
  var monthsNames = props.months,
    date = props.date,
    activeDate = props.activeDate,
    secondDate = props.secondDate,
    isRange = props.isRange;
  var getNextMonth = function getNextMonth(m) {
    if (m.getMonth() + 1 === 12) {
      return new Date(m.getFullYear() + 1, 0, 1);
    }
    return new Date(m.getFullYear(), m.getMonth() + 1, 1);
  };
  var getFocusedMonthsArray = function getFocusedMonthsArray(start, end) {
    var months = [];
    if (start && end) {
      for (var m = start; m <= end; m = getNextMonth(m)) {
        months.push(m.toDateString());
      }
    }
    return months;
  };
  var _a = (0, react_1.useState)(getFocusedMonthsArray(activeDate, secondDate)),
    focusedMonths = _a[0],
    setFocusedMonths = _a[1];
  var months = (0, react_1.useMemo)(
    function () {
      var year = date.getFullYear();
      return monthsNames.map(function (month, idx) {
        var tmpMonth = new Date(year, idx, 1);
        return {
          date: tmpMonth,
          title: month,
          empty: false,
          gradient: undefined,
          status: (0, utils_1.getStatusMonth)(
            date,
            tmpMonth,
            focusedMonths,
            activeDate,
            secondDate
          ),
        };
      });
    },
    [monthsNames, date, activeDate, secondDate, focusedMonths]
  );
  var handleMouseEnter = function handleMouseEnter(value) {
    if (isRange) {
      if (activeDate && !secondDate && value > activeDate) {
        setFocusedMonths(getFocusedMonthsArray(activeDate, value));
      }
    }
  };
  var handleMouseLeave = function handleMouseLeave() {
    setFocusedMonths([]);
  };
  return {
    months: months,
    handleMouseEnter: handleMouseEnter,
    handleMouseLeave: handleMouseLeave,
  };
};
exports.useMonthContextProvider = useMonthContextProvider;
