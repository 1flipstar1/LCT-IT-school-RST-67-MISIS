'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.TimesContext = void 0;
var react_1 = require('react');
exports.TimesContext = (0, react_1.createContext)({});
