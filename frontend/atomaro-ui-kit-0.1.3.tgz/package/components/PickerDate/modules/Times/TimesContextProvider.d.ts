import React, { ReactNode } from 'react';
interface TimesContextProviderProps {
    children: ReactNode;
    interval: number;
    format: string;
    date: Date;
    activeDate?: Date;
    secondDate?: Date;
    enabledDates?: Date[];
    disabledDates?: Date[];
    minDate?: Date;
    maxDate?: Date;
    isRange: boolean;
    renderFormat: string;
}
export declare const TimesContextProvider: (props: TimesContextProviderProps) => React.JSX.Element;
export {};
