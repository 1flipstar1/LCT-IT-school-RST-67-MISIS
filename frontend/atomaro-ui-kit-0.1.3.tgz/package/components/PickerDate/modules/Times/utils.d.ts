import { CalendarItemType } from '../../types';
export declare const getTimesArray: (date: Date, interval: number, focusedTimes: string[], format: string, renderFormat: string, minCurrTime?: Date, maxCurrTime?: Date, activeDate?: Date, secondDate?: Date, enabledDates?: Date[], disabledDates?: Date[]) => CalendarItemType[];
export declare const getFocusedTimesArray: (interval?: number, start?: Date, end?: Date, format?: string, curr?: Date) => string[];
