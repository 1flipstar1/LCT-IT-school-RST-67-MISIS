/// <reference types="react" />
import { CalendarItemType } from '../../types';
type TimesContextType = {
    cols: number;
    times: CalendarItemType[];
    handleMouseEnter: (value: Date) => void;
    handleMouseLeave: () => void;
};
export declare const TimesContext: import("react").Context<TimesContextType>;
export {};
