'use strict';

var __createBinding =
  (this && this.__createBinding) ||
  (Object.create
    ? function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ('get' in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = {
            enumerable: true,
            get: function get() {
              return m[k];
            },
          };
        }
        Object.defineProperty(o, k2, desc);
      }
    : function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
      });
var __setModuleDefault =
  (this && this.__setModuleDefault) ||
  (Object.create
    ? function (o, v) {
        Object.defineProperty(o, 'default', {
          enumerable: true,
          value: v,
        });
      }
    : function (o, v) {
        o['default'] = v;
      });
var __importStar =
  (this && this.__importStar) ||
  function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null)
      for (var k in mod)
        if (k !== 'default' && Object.prototype.hasOwnProperty.call(mod, k))
          __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.TimesContextProvider = void 0;
var react_1 = __importStar(require('react'));
var TimesContext_1 = require('./TimesContext');
var utils_1 = require('./utils');
var TimesContextProvider = function TimesContextProvider(props) {
  var children = props.children,
    inputInterval = props.interval,
    format = props.format,
    date = props.date,
    activeDate = props.activeDate,
    secondDate = props.secondDate,
    enabledDates = props.enabledDates,
    disabledDates = props.disabledDates,
    minDate = props.minDate,
    maxDate = props.maxDate,
    isRange = props.isRange,
    renderFormat = props.renderFormat;
  var checkInterval = function checkInterval(interval) {
    if (interval === 0) {
      return 15;
    }
    return interval;
  };
  var _a = (0, react_1.useState)(checkInterval(inputInterval)),
    interval = _a[0],
    setInterval = _a[1];
  (0, react_1.useEffect)(
    function () {
      setInterval(checkInterval(inputInterval));
    },
    [inputInterval, setInterval]
  );
  var _b = (0, react_1.useState)(
      (0, utils_1.getFocusedTimesArray)(interval, activeDate, secondDate, format, date)
    ),
    focusedTimes = _b[0],
    setFocusedTimes = _b[1];
  (0, react_1.useEffect)(
    function () {
      setFocusedTimes(
        (0, utils_1.getFocusedTimesArray)(interval, activeDate, secondDate, format, date)
      );
    },
    [interval, activeDate, secondDate, format, date]
  );
  var times = (0, react_1.useMemo)(
    function () {
      return (0, utils_1.getTimesArray)(
        date,
        interval,
        focusedTimes,
        format,
        renderFormat,
        minDate,
        maxDate,
        activeDate,
        secondDate,
        enabledDates,
        disabledDates
      );
    },
    [
      date,
      interval,
      focusedTimes,
      format,
      minDate,
      maxDate,
      activeDate,
      secondDate,
      renderFormat,
      enabledDates,
      disabledDates,
    ]
  );
  var handleMouseEnter = function handleMouseEnter(value) {
    if (isRange && activeDate && !secondDate) {
      if (value > activeDate) {
        setFocusedTimes(
          (0, utils_1.getFocusedTimesArray)(interval, activeDate, value, format, date)
        );
      }
    }
  };
  var handleMouseLeave = function handleMouseLeave() {
    setFocusedTimes(
      (0, utils_1.getFocusedTimesArray)(interval, activeDate, secondDate, format, date)
    );
  };
  return react_1['default'].createElement(
    TimesContext_1.TimesContext.Provider,
    {
      value: {
        cols: 3,
        times: times,
        handleMouseEnter: handleMouseEnter,
        handleMouseLeave: handleMouseLeave,
      },
    },
    children
  );
};
exports.TimesContextProvider = TimesContextProvider;
