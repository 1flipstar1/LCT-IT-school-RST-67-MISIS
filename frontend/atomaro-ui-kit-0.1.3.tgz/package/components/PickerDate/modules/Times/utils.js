'use strict';

var __spreadArray =
  (this && this.__spreadArray) ||
  function (to, from, pack) {
    if (pack || arguments.length === 2)
      for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
          if (!ar) ar = Array.prototype.slice.call(from, 0, i);
          ar[i] = from[i];
        }
      }
    return to.concat(ar || Array.prototype.slice.call(from));
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.getFocusedTimesArray = exports.getTimesArray = void 0;
var dayjs_1 = __importDefault(require('dayjs'));
var isSameOrBefore_1 = __importDefault(require('dayjs/plugin/isSameOrBefore'));
var isSameOrAfter_1 = __importDefault(require('dayjs/plugin/isSameOrAfter'));
var constants_1 = require('../../constants');
dayjs_1['default'].extend(isSameOrBefore_1['default']);
dayjs_1['default'].extend(isSameOrAfter_1['default']);
var checkDisabledDate = function checkDisabledDate(time, min, max, enabledDates, disabledDates) {
  var timeString = time.format('YYYY.MM.DD HH:mm').toString();
  if (enabledDates) {
    var enabledDatesStrings =
      enabledDates === null || enabledDates === void 0
        ? void 0
        : enabledDates.map(function (i) {
            return (0, dayjs_1['default'])(i).format('YYYY.MM.DD HH:mm').toString();
          });
    if (
      enabledDatesStrings === null || enabledDatesStrings === void 0
        ? void 0
        : enabledDatesStrings.includes(timeString)
    )
      return false;
  }
  if (disabledDates) {
    var disabledDatesStrings =
      disabledDates === null || disabledDates === void 0
        ? void 0
        : disabledDates.map(function (i) {
            return (0, dayjs_1['default'])(i).format('YYYY.MM.DD HH:mm').toString();
          });
    if (disabledDatesStrings.includes(timeString)) return true;
  }
  var minTimeMinutes = (0, dayjs_1['default'])(min).minute();
  var minTimeHours = (0, dayjs_1['default'])(min).hour();
  var start = (0, dayjs_1['default'])(min).hour(minTimeHours).minute(minTimeMinutes);
  var maxTimeMinutes = (0, dayjs_1['default'])(max).minute();
  var maxTimeHours = (0, dayjs_1['default'])(max).hour();
  var end = (0, dayjs_1['default'])(max).hour(maxTimeHours).minute(maxTimeMinutes);
  if (min && max) {
    if (start.isBefore(end)) {
      if (time.isBefore(start)) {
        return true;
      }
      if (time.isAfter(end)) {
        return true;
      }
    }
    if (start.isAfter(end)) {
      if (time.isBefore(end)) {
        return true;
      }
      if (time.isAfter(start)) {
        return true;
      }
    }
    return false;
  }
  if (min || max) {
    if (min && time.isBefore(start)) {
      return true;
    }
    if (max && time.isAfter(end)) {
      return true;
    }
  }
  return false;
};
var getTimeStatus = function getTimeStatus(
  time,
  focusedTimes,
  format,
  minTime,
  maxTime,
  activeDate,
  secondDate,
  enabledDates,
  disabledDates
) {
  if (format === void 0) {
    format = constants_1.DEFAULT_FULL_TIME_FORMAT;
  }
  var timeString = time.format(format);
  if (checkDisabledDate(time, minTime, maxTime, enabledDates, disabledDates)) {
    return constants_1.DATE_STATUS.disabled;
  }
  if (focusedTimes.includes(timeString)) {
    if (timeString === focusedTimes[0]) {
      return constants_1.DATE_STATUS.focusedFirst;
    }
    if (timeString === focusedTimes[focusedTimes.length - 1]) {
      return constants_1.DATE_STATUS.focusedLast;
    }
    return constants_1.DATE_STATUS.focused;
  }
  if (!focusedTimes.length) {
    if (activeDate && (0, dayjs_1['default'])(activeDate).format(format) === timeString) {
      return constants_1.DATE_STATUS.focusedFirst;
    }
    if (secondDate && (0, dayjs_1['default'])(secondDate).format(format) === timeString) {
      return constants_1.DATE_STATUS.focusedLast;
    }
  }
  return constants_1.DATE_STATUS['default'];
};
var getTimesArray = function getTimesArray(
  date,
  interval,
  focusedTimes,
  format,
  renderFormat,
  minCurrTime,
  maxCurrTime,
  activeDate,
  secondDate,
  enabledDates,
  disabledDates
) {
  if (date === void 0) {
    date = new Date();
  }
  if (interval === void 0) {
    interval = constants_1.DEFAULT_MINUTES_INTERVAL;
  }
  if (format === void 0) {
    format = constants_1.DEFAULT_FULL_TIME_FORMAT;
  }
  var minTime = (0, dayjs_1['default'])(date).hour(0).minute(0).second(0);
  var maxTime = (0, dayjs_1['default'])(date).hour(23).minute(59).second(59);
  var times = [];
  for (var i = minTime; i.isSameOrBefore(maxTime); i = i.add(interval, 'minute')) {
    times.push({
      date: new Date(i.format()),
      title: i.format(renderFormat),
      status: getTimeStatus(
        i,
        focusedTimes,
        format,
        minCurrTime,
        maxCurrTime,
        activeDate,
        secondDate,
        enabledDates,
        disabledDates
      ),
    });
  }
  return times;
};
exports.getTimesArray = getTimesArray;
var getFocusedTimesArray = function getFocusedTimesArray(interval, start, end, format, curr) {
  if (interval === void 0) {
    interval = constants_1.DEFAULT_MINUTES_INTERVAL;
  }
  if (format === void 0) {
    format = constants_1.DEFAULT_FULL_TIME_FORMAT;
  }
  var times = [];
  if (start && end && curr) {
    var startMinutes = start.getMinutes();
    var startHours = start.getHours();
    var startDay = start.getDate();
    var startMonth = start.getMonth();
    var startYear = start.getFullYear();
    var startFullDate = new Date(startYear, startMonth, startDay, startHours, startMinutes);
    var endMinutes = end.getMinutes();
    var endHours = end.getHours();
    var endDay = end.getDate();
    var endMonth = end.getMonth();
    var endYear = end.getFullYear();
    var endFullDate = new Date(endYear, endMonth, endDay, endHours, endMinutes);
    var currDay = curr.getDate();
    var currMonth = curr.getMonth();
    var currYear = curr.getFullYear();
    var createTimes = function createTimes(s, e) {
      var innerTimes = [];
      for (var i = (0, dayjs_1['default'])(s); i.isSameOrBefore(e); i = i.add(interval, 'minute')) {
        innerTimes.push(i.format(format));
      }
      return innerTimes;
    };
    var compareCurrDay = new Date(currYear, currMonth, currDay, 0, 0);
    var compareStartDay = new Date(startYear, startMonth, startDay, 0, 0);
    var compareEndDay = new Date(endYear, endMonth, endDay, 0, 0);
    if (compareStartDay.toDateString() === compareEndDay.toDateString()) {
      times = createTimes(startFullDate, endFullDate);
    }
    if (compareStartDay < compareEndDay) {
      if (compareCurrDay.toDateString() === compareEndDay.toDateString()) {
        times = __spreadArray(
          [startFullDate.toDateString()],
          createTimes(compareCurrDay, endFullDate),
          true
        );
      }
      if (compareCurrDay.getDate() < compareEndDay.getDate()) {
        if (compareCurrDay.getDate() !== compareStartDay.getDate()) {
          times = createTimes(new Date(currYear, currMonth, currDay, 0, interval), compareCurrDay);
        }
        if (compareCurrDay.getDate() === compareStartDay.getDate()) {
          times = __spreadArray(
            __spreadArray(
              [],
              createTimes(startFullDate, new Date(currYear, currMonth, currDay, 23, 45)),
              true
            ),
            [endFullDate.toDateString()],
            false
          );
        }
      }
    }
  }
  return times;
};
exports.getFocusedTimesArray = getFocusedTimesArray;
