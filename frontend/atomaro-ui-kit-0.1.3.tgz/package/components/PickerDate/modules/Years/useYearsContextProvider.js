'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.useYearsContextProvider = void 0;
var react_1 = require('react');
var utils_1 = require('./utils');
var useYearsContextProvider = function useYearsContextProvider(props) {
  var inputMinYear = props.minYear,
    inputMaxYear = props.maxYear,
    date = props.date,
    activeDate = props.activeDate,
    secondDate = props.secondDate,
    isRange = props.isRange;
  var _a = (0, react_1.useState)(inputMinYear),
    minYear = _a[0],
    setMinYear = _a[1];
  var _b = (0, react_1.useState)(inputMaxYear),
    maxYear = _b[0],
    setMaxYear = _b[1];
  (0, react_1.useEffect)(
    function () {
      if (inputMinYear > inputMaxYear) {
        setMaxYear(inputMinYear);
        setMinYear(inputMaxYear);
      }
      if (inputMinYear === inputMaxYear) {
        setMaxYear(inputMaxYear + 1);
        setMinYear(inputMinYear);
      }
      if (inputMinYear < inputMaxYear) {
        setMaxYear(inputMaxYear);
        setMinYear(inputMinYear);
      }
    },
    [inputMinYear, inputMaxYear]
  );
  var _c = (0, react_1.useState)((0, utils_1.getFocusedYearsArray)(activeDate, secondDate)),
    focusedYears = _c[0],
    setFocusedYears = _c[1];
  var years = (0, react_1.useMemo)(
    function () {
      var y = [];
      for (var i = minYear; i <= maxYear; i += 1) {
        y.push({
          date: new Date(i, 0, 1),
          title: String(i),
          empty: undefined,
          gradient: undefined,
          status: (0, utils_1.getStatusYears)(date, i, activeDate, secondDate, focusedYears),
        });
      }
      return y;
    },
    [minYear, maxYear, date, activeDate, secondDate, focusedYears]
  );
  var handleMouseEnter = function handleMouseEnter(value) {
    if (isRange) {
      if (activeDate && !secondDate && value > activeDate) {
        setFocusedYears((0, utils_1.getFocusedYearsArray)(activeDate, value));
      }
    }
  };
  var handleMouseLeave = function handleMouseLeave() {
    setFocusedYears([]);
  };
  return {
    years: years,
    handleMouseEnter: handleMouseEnter,
    handleMouseLeave: handleMouseLeave,
  };
};
exports.useYearsContextProvider = useYearsContextProvider;
