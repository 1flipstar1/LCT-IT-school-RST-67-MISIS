import { CalendarItemType } from '../../types';
import { YearsContextProviderProps } from './types';
export declare const useYearsContextProvider: (props: YearsContextProviderProps) => {
    years: CalendarItemType[];
    handleMouseEnter: (value: Date) => void;
    handleMouseLeave: () => void;
};
