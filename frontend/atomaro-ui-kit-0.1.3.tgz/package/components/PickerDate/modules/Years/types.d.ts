import { ReactNode } from 'react';
export interface YearsContextProviderProps {
    children: ReactNode;
    minYear: number;
    maxYear: number;
    date: Date;
    activeDate?: Date;
    secondDate?: Date;
    isRange?: boolean;
}
