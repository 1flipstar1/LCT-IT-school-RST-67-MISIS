import { FC } from 'react';
import { YearsContextProviderProps } from './types';
export declare const YearsContextProvider: FC<YearsContextProviderProps>;
