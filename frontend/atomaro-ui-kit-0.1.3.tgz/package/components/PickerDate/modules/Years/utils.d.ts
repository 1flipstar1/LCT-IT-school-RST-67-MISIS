import { DATE_STATUS } from '../../constants';
export declare const getStatusYears: (date: Date, year: number, activeDate?: Date, secondDate?: Date, focusedYears?: number[]) => DATE_STATUS.default | DATE_STATUS.focused | DATE_STATUS.focusedFirst | DATE_STATUS.focusedLast;
export declare const getNextYear: (year: Date) => Date;
export declare const getFocusedYearsArray: (start?: Date, end?: Date) => number[];
