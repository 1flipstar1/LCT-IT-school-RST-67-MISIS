'use strict';
var PropTypes = require('prop-types');

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.YearsContextProvider = void 0;
var react_1 = __importDefault(require('react'));
var YearsContext_1 = require('./YearsContext');
var useYearsContextProvider_1 = require('./useYearsContextProvider');
var YearsContextProvider = function YearsContextProvider(props) {
  var children = props.children;
  var _a = (0, useYearsContextProvider_1.useYearsContextProvider)(__assign({}, props)),
    years = _a.years,
    handleMouseEnter = _a.handleMouseEnter,
    handleMouseLeave = _a.handleMouseLeave;
  return react_1['default'].createElement(
    YearsContext_1.YearsContext.Provider,
    {
      value: {
        cols: 3,
        years: years,
        handleMouseEnter: handleMouseEnter,
        handleMouseLeave: handleMouseLeave,
      },
    },
    children
  );
};

YearsContextProvider.propTypes = {
  children: PropTypes.node,
};

exports.YearsContextProvider = YearsContextProvider;
