'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.getFocusedYearsArray = exports.getNextYear = exports.getStatusYears = void 0;
var constants_1 = require('../../constants');
var getStatusYears = function getStatusYears(date, year, activeDate, secondDate, focusedYears) {
  if (activeDate && !secondDate) {
    if (activeDate.getFullYear() === year) {
      return constants_1.DATE_STATUS.focusedFirst;
    }
    if (focusedYears && focusedYears.includes(year)) {
      if (year === focusedYears[focusedYears.length - 1]) {
        return constants_1.DATE_STATUS.focusedLast;
      }
      return constants_1.DATE_STATUS.focused;
    }
  }
  if (activeDate && secondDate) {
    if (activeDate.getFullYear() === year) return constants_1.DATE_STATUS.focusedFirst;
    if (secondDate.getFullYear() === year) return constants_1.DATE_STATUS.focusedLast;
    if (year > activeDate.getFullYear() && year < secondDate.getFullYear())
      return constants_1.DATE_STATUS.focused;
  }
  return constants_1.DATE_STATUS['default'];
};
exports.getStatusYears = getStatusYears;
var getNextYear = function getNextYear(year) {
  return new Date(year.getFullYear() + 1, year.getMonth(), year.getDate());
};
exports.getNextYear = getNextYear;
var getFocusedYearsArray = function getFocusedYearsArray(start, end) {
  var years = [];
  if (start && end) {
    for (var s = start; s.getFullYear() <= end.getFullYear(); s = (0, exports.getNextYear)(s)) {
      years.push(s.getFullYear());
    }
  }
  return years;
};
exports.getFocusedYearsArray = getFocusedYearsArray;
