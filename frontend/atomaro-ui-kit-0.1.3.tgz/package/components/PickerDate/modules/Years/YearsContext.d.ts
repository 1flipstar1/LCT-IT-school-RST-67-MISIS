/// <reference types="react" />
import { CalendarItemType } from '../../types';
type YearsContextType = {
    cols: number;
    years: CalendarItemType[];
    handleMouseEnter: (value: Date) => void;
    handleMouseLeave: () => void;
};
export declare const YearsContext: import("react").Context<YearsContextType>;
export {};
