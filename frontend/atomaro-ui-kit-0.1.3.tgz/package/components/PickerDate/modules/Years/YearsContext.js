'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.YearsContext = void 0;
var react_1 = require('react');
exports.YearsContext = (0, react_1.createContext)({});
