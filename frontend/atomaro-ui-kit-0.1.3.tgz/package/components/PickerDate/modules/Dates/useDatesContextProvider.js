'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.useDatesContextProvider = void 0;
var react_1 = require('react');
var utils_1 = require('./utils');
var useDatesContextProvider = function useDatesContextProvider(props) {
  var date = props.date,
    activeDate = props.activeDate,
    secondDate = props.secondDate,
    _a = props.disabledDates,
    disabledDates = _a === void 0 ? [] : _a,
    _b = props.enabledDates,
    enabledDates = _b === void 0 ? [] : _b,
    minDate = props.minDate,
    maxDate = props.maxDate,
    isRange = props.isRange,
    isOnlyEnabled = props.isOnlyEnabled;
  var _c = (0, react_1.useState)((0, utils_1.getFocusedDatesArray)(activeDate, secondDate, date)),
    focusedDates = _c[0],
    setFocusedDates = _c[1];
  (0, react_1.useEffect)(
    function () {
      setFocusedDates((0, utils_1.getFocusedDatesArray)(activeDate, secondDate, date));
    },
    [activeDate, secondDate, date]
  );
  var dates = (0, react_1.useMemo)(
    function () {
      return (0, utils_1.getDates)(date, {
        firstDayIndex: 1,
        minDate: minDate,
        maxDate: maxDate,
        focusedDates: focusedDates,
        disabledDates: disabledDates,
        enabledDates: enabledDates,
        isOnlyEnabled: isOnlyEnabled,
      });
    },
    [date, minDate, maxDate, focusedDates, disabledDates, enabledDates, isOnlyEnabled]
  );
  var handleMouseEnter = function handleMouseEnter(value) {
    if (isRange && activeDate && !secondDate && date) {
      if (value > activeDate) {
        setFocusedDates((0, utils_1.getFocusedDatesArray)(activeDate, value, date));
      }
    }
  };
  var handleMouseLeave = function handleMouseLeave() {
    setFocusedDates((0, utils_1.getFocusedDatesArray)(activeDate, secondDate, date));
  };
  return {
    dates: dates,
    handleMouseEnter: handleMouseEnter,
    handleMouseLeave: handleMouseLeave,
  };
};
exports.useDatesContextProvider = useDatesContextProvider;
