import { CalendarItemType } from '../../types';
import { DatesContextProviderProps } from './types';
export declare const useDatesContextProvider: (props: DatesContextProviderProps) => {
    dates: CalendarItemType[];
    handleMouseEnter: (value: Date) => void;
    handleMouseLeave: () => void;
};
