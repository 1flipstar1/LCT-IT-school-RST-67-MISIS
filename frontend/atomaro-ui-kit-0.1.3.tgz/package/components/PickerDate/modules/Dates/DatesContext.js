'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.DatesContext = void 0;
var react_1 = require('react');
exports.DatesContext = (0, react_1.createContext)({});
