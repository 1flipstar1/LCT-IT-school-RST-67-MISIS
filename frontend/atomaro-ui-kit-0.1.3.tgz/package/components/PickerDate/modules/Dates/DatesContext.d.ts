/// <reference types="react" />
import { CalendarItemType } from '../../types';
type DatesContextType = {
    cols: number;
    dates: CalendarItemType[];
    handleMouseEnter: (value: Date) => void;
    handleMouseLeave: () => void;
};
export declare const DatesContext: import("react").Context<DatesContextType>;
export {};
