'use strict';
var PropTypes = require('prop-types');

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.DatesContextProvider = void 0;
var react_1 = __importDefault(require('react'));
var DatesContext_1 = require('./DatesContext');
var useDatesContextProvider_1 = require('./useDatesContextProvider');
var DatesContextProvider = function DatesContextProvider(props) {
  var children = props.children;
  var _a = (0, useDatesContextProvider_1.useDatesContextProvider)(__assign({}, props)),
    dates = _a.dates,
    handleMouseEnter = _a.handleMouseEnter,
    handleMouseLeave = _a.handleMouseLeave;
  return react_1['default'].createElement(
    DatesContext_1.DatesContext.Provider,
    {
      value: {
        cols: 7,
        dates: dates,
        handleMouseEnter: handleMouseEnter,
        handleMouseLeave: handleMouseLeave,
      },
    },
    children
  );
};

DatesContextProvider.propTypes = {
  children: PropTypes.node,
};

exports.DatesContextProvider = DatesContextProvider;
