import { CalendarDateParamsType } from './types';
import { CalendarItemType } from '../../types';
export declare const getFocusedDatesArray: (start?: Date, end?: Date, currDate?: Date) => string[];
export declare const getRangeGradient: (items: CalendarItemType[]) => CalendarItemType[];
export declare const getDatesArray: (from: Date, to: Date, params: CalendarDateParamsType) => CalendarItemType[];
export declare const getDates: (date: Date, params: CalendarDateParamsType) => CalendarItemType[];
