import { CSSProperties, ReactNode } from 'react';
import { ShapesType, BaseColorsType } from '../../../../types/base';
import { ITheme } from '../../../../types/theme';
import { DATE_STATUS, RANGE_GRADIENT } from '../../constants';
export interface ICalendarDates {
    shape?: ShapesType;
    color?: BaseColorsType;
    date: Date;
    activeDate?: Date;
    secondDate?: Date;
    isRange?: boolean;
    firstDayIndex?: number;
    daysOfWeek?: string[];
    minDate?: Date;
    maxDate?: Date;
    disabledDates?: Date[];
    onSelect?: (activeDate: Date, secondDate?: Date) => void;
    className?: string;
    style?: CSSProperties;
    renderDate?: (date: Date) => ReactNode;
}
export type CalendarDateType = {
    date: Date;
    empty?: boolean;
    gradient?: RANGE_GRADIENT;
    status: DATE_STATUS;
};
export type StyledCalendarDatesItemType = {
    status: DATE_STATUS;
    shape: ShapesType;
    theme: ITheme;
    color: string;
    isCurrent?: boolean;
};
export type CalendarDateParamsType = {
    empty?: boolean;
    firstDayIndex: number;
    minDate?: Date;
    maxDate?: Date;
    focusedDates: string[];
    disabledDates: Date[];
    enabledDates: Date[];
    isOnlyEnabled?: boolean;
};
export interface DatesContextProviderProps {
    children: ReactNode;
    date: Date;
    activeDate?: Date;
    secondDate?: Date;
    disabledDates?: Date[];
    enabledDates?: Date[];
    minDate?: Date;
    maxDate?: Date;
    isRange?: boolean;
    isOnlyEnabled?: boolean;
}
