import { FC } from 'react';
import { DatesContextProviderProps } from './types';
export declare const DatesContextProvider: FC<DatesContextProviderProps>;
