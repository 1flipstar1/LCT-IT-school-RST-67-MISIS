'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __spreadArray =
  (this && this.__spreadArray) ||
  function (to, from, pack) {
    if (pack || arguments.length === 2)
      for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
          if (!ar) ar = Array.prototype.slice.call(from, 0, i);
          ar[i] = from[i];
        }
      }
    return to.concat(ar || Array.prototype.slice.call(from));
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.getDates =
  exports.getDatesArray =
  exports.getRangeGradient =
  exports.getFocusedDatesArray =
    void 0;
var dayjs_1 = __importDefault(require('dayjs'));
var isBetween_1 = __importDefault(require('dayjs/plugin/isBetween'));
var constants_1 = require('../../constants');
var utils_1 = require('../../utils');
dayjs_1['default'].extend(isBetween_1['default']);
var getDaysInMonth = function getDaysInMonth(year, month) {
  return new Date(year, month + 1, 0).getDate();
};
var getFocusedDatesArray = function getFocusedDatesArray(start, end, currDate) {
  var dates = [];
  if (start && end && currDate) {
    var startDay = start.getDate();
    var startMonth = start.getMonth();
    var startYear = start.getFullYear();
    var startFullDate = new Date(startYear, startMonth, startDay);
    var endDay = end.getDate();
    var endMonth = end.getMonth();
    var endYear = end.getFullYear();
    var endFullDate = new Date(endYear, endMonth, endDay);
    var currDateMonth = currDate.getMonth();
    var currDateYear = currDate.getFullYear();
    var currDateDaysInMonth = (0, dayjs_1['default'])(currDate).daysInMonth();
    var createDates = function createDates(s, e) {
      var innerDates = [];
      for (var d = s; d <= e; d = (0, utils_1.getNextDay)(d)) {
        innerDates.push(new Date(d).toDateString());
      }
      return innerDates;
    };
    if (startYear === endYear) {
      if (startMonth === endMonth) {
        dates = createDates(startFullDate, endFullDate);
      }
      if (startMonth < endMonth) {
        if (startMonth < currDateMonth) {
          dates = __spreadArray(
            [startFullDate.toDateString()],
            createDates(
              new Date(currDateYear, currDateMonth, 1),
              new Date(endYear, endMonth, endDay)
            ),
            true
          );
        }
        if (startMonth === currDateMonth && startYear === currDateYear) {
          dates = __spreadArray(
            __spreadArray(
              [],
              createDates(
                startFullDate,
                new Date(currDateYear, currDateMonth, currDateDaysInMonth)
              ),
              true
            ),
            [endFullDate.toDateString()],
            false
          );
        }
      }
    }
    if (startYear < endYear) {
      var compareDateStart = new Date(startYear, startMonth, 1);
      var compareDateCurr = new Date(currDateYear, currDateMonth, 1);
      if (compareDateCurr > compareDateStart) {
        dates = __spreadArray(
          [startFullDate.toDateString()],
          createDates(new Date(currDateYear, currDateMonth, 1), endFullDate),
          true
        );
      }
      if (compareDateCurr.toDateString() === compareDateStart.toDateString()) {
        dates = __spreadArray(
          __spreadArray(
            [],
            createDates(startFullDate, new Date(currDateYear, currDateMonth, currDateDaysInMonth)),
            true
          ),
          [endFullDate.toDateString()],
          false
        );
      }
    }
  }
  if (start && !end) {
    dates.push(start.toDateString());
  }
  return dates;
};
exports.getFocusedDatesArray = getFocusedDatesArray;
var checkDisabledDate = function checkDisabledDate(date, params) {
  var disabledDates = params.disabledDates,
    enabledDates = params.enabledDates,
    minDate = params.minDate,
    maxDate = params.maxDate,
    isOnlyEnabled = params.isOnlyEnabled;
  var disabledDatesToSting = disabledDates.map(function (i) {
    return i.toDateString();
  });
  var enabledDatesToString = enabledDates.map(function (i) {
    return i.toDateString();
  });
  if (enabledDatesToString.includes(date.toDateString())) {
    return false;
  }
  if (isOnlyEnabled) {
    return true;
  }
  if (disabledDatesToSting.includes(date.toDateString())) {
    return true;
  }
  if (minDate && maxDate) {
    if (
      date.toDateString() === minDate.toDateString() ||
      date.toDateString() === maxDate.toDateString()
    ) {
      return false;
    }
    return !(0, dayjs_1['default'])(date).isBetween(minDate, maxDate);
  }
  if (minDate) {
    return (0, dayjs_1['default'])(date).isBefore(minDate, 'day');
  }
  if (maxDate) {
    return (0, dayjs_1['default'])(date).isAfter(maxDate, 'day');
  }
  return false;
};
var getDateStatus = function getDateStatus(date, params) {
  var focusedDates = params.focusedDates;
  var dateString = date.toDateString();
  if (checkDisabledDate(date, params)) {
    return constants_1.DATE_STATUS.disabled;
  }
  if (focusedDates.length > 1 && focusedDates.includes(dateString)) {
    if (dateString === focusedDates[0]) {
      return constants_1.DATE_STATUS.focusedFirst;
    }
    if (dateString === focusedDates[focusedDates.length - 1]) {
      return constants_1.DATE_STATUS.focusedLast;
    }
    return constants_1.DATE_STATUS.focused;
  }
  if (focusedDates.length === 1 && focusedDates.includes(dateString)) {
    return constants_1.DATE_STATUS.focusedFirst;
  }
  return constants_1.DATE_STATUS['default'];
};
var getRangeGradient = function getRangeGradient(items) {
  var tmpItems = items.map(function (item, idx, arr) {
    if (idx < arr.length - 2) {
      if (item.empty && arr[idx + 1].status === constants_1.DATE_STATUS.focused) {
        return __assign(__assign({}, item), {
          gradient: constants_1.RANGE_GRADIENT.before,
        });
      }
    }
    return item;
  });
  if (
    tmpItems[tmpItems.length - 1].status === constants_1.DATE_STATUS.focused &&
    tmpItems.length !== 35
  ) {
    tmpItems = __spreadArray(
      __spreadArray([], tmpItems, true),
      [
        {
          date: (0, utils_1.getNextDay)(tmpItems[tmpItems.length - 1].date),
          title: String((0, utils_1.getNextDay)(tmpItems[tmpItems.length - 1].date).getDate()),
          empty: true,
          gradient: constants_1.RANGE_GRADIENT.after,
          status: constants_1.DATE_STATUS['default'],
        },
      ],
      false
    );
  }
  return tmpItems;
};
exports.getRangeGradient = getRangeGradient;
var getDatesArray = function getDatesArray(from, to, params) {
  var dates = [];
  for (var d = from; d <= to; d = (0, utils_1.getNextDay)(d)) {
    var date = new Date(d);
    dates.push({
      date: date,
      title: date.getDate().toString(),
      empty: params.empty,
      status: getDateStatus(date, params),
    });
  }
  return dates;
};
exports.getDatesArray = getDatesArray;
var getDates = function getDates(date, params) {
  var month = date.getMonth();
  var year = date.getFullYear();
  var dates = (0, exports.getDatesArray)(
    new Date(year, month, 1),
    new Date(year, month, getDaysInMonth(year, month)),
    params
  );
  var prevMonthDates = [];
  var firstDayInMonth = new Date(year, month, 1).getDay();
  var prevMonthDateTo = getDaysInMonth(year, month - 1);
  if (firstDayInMonth !== params.firstDayIndex) {
    var prevDatesLength = (firstDayInMonth === 0 ? 7 : firstDayInMonth) - params.firstDayIndex - 1;
    prevMonthDates = (0, exports.getDatesArray)(
      new Date(year, month - 1, prevMonthDateTo - prevDatesLength),
      new Date(year, month - 1, prevMonthDateTo),
      __assign(__assign({}, params), {
        empty: true,
      })
    ).map(function (d) {
      return __assign(__assign({}, d), {
        status: constants_1.DATE_STATUS['default'],
      });
    });
  }
  return (0, exports.getRangeGradient)(
    __spreadArray(__spreadArray([], prevMonthDates, true), dates, true)
  );
};
exports.getDates = getDates;
