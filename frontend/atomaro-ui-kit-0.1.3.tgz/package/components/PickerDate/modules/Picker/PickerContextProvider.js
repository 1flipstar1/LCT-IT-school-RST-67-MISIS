'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __createBinding =
  (this && this.__createBinding) ||
  (Object.create
    ? function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ('get' in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = {
            enumerable: true,
            get: function get() {
              return m[k];
            },
          };
        }
        Object.defineProperty(o, k2, desc);
      }
    : function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
      });
var __setModuleDefault =
  (this && this.__setModuleDefault) ||
  (Object.create
    ? function (o, v) {
        Object.defineProperty(o, 'default', {
          enumerable: true,
          value: v,
        });
      }
    : function (o, v) {
        o['default'] = v;
      });
var __importStar =
  (this && this.__importStar) ||
  function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null)
      for (var k in mod)
        if (k !== 'default' && Object.prototype.hasOwnProperty.call(mod, k))
          __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.PickerContextProvider = void 0;
var react_1 = __importStar(require('react'));
var PickerContext_1 = require('./PickerContext');
var PickerContextProvider = function PickerContextProvider(props) {
  var userStyle = props.style,
    data = props.data,
    methods = props.methods,
    modules = props.modules,
    children = props.children;
  var className = userStyle.className,
    style = userStyle.style,
    dayClassName = userStyle.dayClassName,
    dayStyle = userStyle.dayStyle;
  var variant = data.variant,
    view = data.view,
    date = data.date,
    activeDate = data.activeDate,
    secondDate = data.secondDate,
    today = data.today,
    size = data.size,
    nameOfMonths = data.nameOfMonths,
    daysOfWeek = data.daysOfWeek,
    calendarMode = data.calendarMode,
    isRange = data.isRange;
  var setDate = methods.setDate,
    dateClickHandler = methods.dateClickHandler,
    changeView = methods.changeView,
    renderDate = methods.renderDate;
  var calendar = (0, react_1.useMemo)(
    function () {
      var CurrModule = modules[view].module;
      return react_1['default'].createElement(
        CurrModule,
        __assign({}, modules[view].args),
        children
      );
    },
    [view, modules, children]
  );
  return react_1['default'].createElement(
    PickerContext_1.PickerContext.Provider,
    {
      value: {
        className: className,
        style: style,
        dayClassName: dayClassName,
        dayStyle: dayStyle,
        view: view,
        nameOfMonths: nameOfMonths,
        daysOfWeek: daysOfWeek,
        date: date,
        setDate: setDate,
        today: today,
        dateClickHandler: dateClickHandler,
        changeView: changeView,
        variant: variant,
        size: size,
        activeDate: activeDate,
        secondDate: secondDate,
        renderDate: renderDate,
        calendarMode: calendarMode,
        isRange: isRange,
      },
    },
    calendar
  );
};
exports.PickerContextProvider = PickerContextProvider;
