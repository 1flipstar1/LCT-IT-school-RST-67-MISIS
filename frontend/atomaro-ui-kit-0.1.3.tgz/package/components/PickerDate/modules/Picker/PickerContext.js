'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.PickerContext = void 0;
var react_1 = require('react');
exports.PickerContext = (0, react_1.createContext)({});
