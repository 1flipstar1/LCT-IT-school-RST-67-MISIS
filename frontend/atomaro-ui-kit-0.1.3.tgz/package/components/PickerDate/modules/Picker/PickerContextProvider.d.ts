import React from 'react';
import { PickerContextProviderProps } from './types';
export declare const PickerContextProvider: (props: PickerContextProviderProps) => React.JSX.Element;
