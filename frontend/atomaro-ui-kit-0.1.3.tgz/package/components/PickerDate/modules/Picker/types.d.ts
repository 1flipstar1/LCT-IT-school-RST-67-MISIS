import { ReactNode, FC, CSSProperties } from 'react';
import { CALENDAR_VIEW, CALENDAR_MODE, PickerDateVariants, PickerDateSizes } from '../../constants';
interface IModul {
    module: FC<any>;
    args: any;
}
interface IModules {
    [key: CALENDAR_VIEW | string]: IModul;
}
export interface PickerContextProviderProps {
    style: {
        className?: string;
        style?: CSSProperties;
        dayClassName?: string;
        dayStyle?: CSSProperties;
    };
    data: {
        variant: PickerDateVariants | string;
        size: PickerDateSizes | string;
        nameOfMonths: string[];
        daysOfWeek: string[];
        view: CALENDAR_VIEW;
        isRange: boolean;
        date: Date;
        activeDate?: Date;
        secondDate?: Date;
        today: Date;
        calendarMode: CALENDAR_MODE;
        ref?: any;
    };
    methods: {
        changeView: (view: CALENDAR_VIEW) => void;
        dateClickHandler: (date: Date) => void;
        setDate: Function;
        renderDate?: (date: Date) => ReactNode;
    };
    modules: IModules;
    children: ReactNode;
}
export {};
