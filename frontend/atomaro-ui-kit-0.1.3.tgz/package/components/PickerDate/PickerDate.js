'use strict';
var PropTypes = require('prop-types');

var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var constants_1 = require('./constants');
var MonthContextProvider_1 = require('./modules/Month/MonthContextProvider');
var PickerContextProvider_1 = require('./modules/Picker/PickerContextProvider');
var DatesContextProvider_1 = require('./modules/Dates/DatesContextProvider');
var YearsContextProvider_1 = require('./modules/Years/YearsContextProvider');
var TimesContextProvider_1 = require('./modules/Times/TimesContextProvider');
var Calendar_1 = require('./components/Calendar/Calendar');
var usePickerDate_1 = require('./usePickerDate');
var components_1 = require('../../constants/components');
var PickerDate = react_1['default'].forwardRef(function PickerDate(props, ref) {
  var _a;
  var activeDate = props.activeDate,
    secondDate = props.secondDate,
    _b = props.daysOfWeek,
    daysOfWeek = _b === void 0 ? constants_1.DAYS_OF_WEEK : _b,
    _c = props.isRange,
    isRange = _c === void 0 ? false : _c,
    _d = props.isOnlyEnabled,
    isOnlyEnabled = _d === void 0 ? false : _d,
    _e = props.showTime,
    showTime = _e === void 0 ? false : _e,
    _f = props.timeProps,
    timeProps =
      _f === void 0
        ? {
            isRange: false,
            interval: 15,
            format: constants_1.DEFAULT_TIME_FORMAT,
          }
        : _f,
    _g = props.variant,
    variant = _g === void 0 ? components_1.VARIANT.primary : _g,
    _h = props.size,
    size = _h === void 0 ? components_1.SIZES.m : _h,
    _j = props.months,
    months = _j === void 0 ? constants_1.MONTHS : _j,
    _k = props.minYear,
    minYear = _k === void 0 ? 1980 : _k,
    _l = props.maxYear,
    maxYear = _l === void 0 ? 2040 : _l,
    _m = props.minDate,
    minDate = _m === void 0 ? undefined : _m,
    _o = props.maxDate,
    maxDate = _o === void 0 ? undefined : _o,
    _p = props.calendarMode,
    calendarMode = _p === void 0 ? constants_1.CALENDAR_MODE.YEARS_WITH_MONTH_DAYS : _p,
    _q = props.disabledDates,
    disabledDates = _q === void 0 ? [] : _q,
    _r = props.enabledDates,
    enabledDates = _r === void 0 ? [] : _r,
    onSelect = props.onSelect,
    onChangeMonth = props.onChangeMonth,
    onChangeYear = props.onChangeYear,
    className = props.className,
    style = props.style,
    dayClassName = props.dayClassName,
    dayStyle = props.dayStyle,
    renderDate = props.renderDate;
  var _s = (0, usePickerDate_1.usePickerDate)({
      activeDate: activeDate,
      secondDate: secondDate,
      isRange: isRange,
      onSelect: onSelect,
      showTime: showTime,
      timeProps: timeProps,
      onChangeMonth: onChangeMonth,
      onChangeYear: onChangeYear,
      calendarMode: calendarMode,
    }),
    today = _s.today,
    date = _s.date,
    setDate = _s.setDate,
    activeValue = _s.activeValue,
    secondValue = _s.secondValue,
    view = _s.view,
    dateClickHandler = _s.dateClickHandler,
    changeView = _s.changeView;
  return react_1['default'].createElement(
    PickerContextProvider_1.PickerContextProvider,
    {
      style: {
        className: className,
        style: style,
        dayClassName: dayClassName,
        dayStyle: dayStyle,
      },
      data: {
        nameOfMonths: months,
        daysOfWeek: daysOfWeek,
        variant: variant,
        size: size,
        view: view,
        date: date,
        activeDate: activeValue,
        secondDate: secondValue,
        today: today,
        calendarMode: calendarMode,
        isRange: isRange,
        ref: ref,
      },
      methods: {
        dateClickHandler: dateClickHandler,
        setDate: setDate,
        changeView: changeView,
        renderDate: renderDate,
      },
      modules:
        ((_a = {}),
        (_a[constants_1.CALENDAR_VIEW.day] = {
          module: DatesContextProvider_1.DatesContextProvider,
          args: {
            date: date,
            activeDate: activeValue,
            secondDate: secondValue,
            daysOfWeek: daysOfWeek,
            isRange: isRange,
            minDate: minDate,
            maxDate: maxDate,
            disabledDates: disabledDates,
            enabledDates: enabledDates,
            isOnlyEnabled: isOnlyEnabled,
          },
        }),
        (_a[constants_1.CALENDAR_VIEW.year] = {
          module: YearsContextProvider_1.YearsContextProvider,
          args: {
            minYear: minYear,
            maxYear: maxYear,
            date: date,
            activeDate: activeValue,
            secondDate: secondValue,
            isRange: isRange,
          },
        }),
        (_a[constants_1.CALENDAR_VIEW.month] = {
          module: MonthContextProvider_1.MonthContextProvider,
          args: {
            months: months,
            date: date,
            activeDate: activeValue,
            secondDate: secondValue,
            isRange: isRange,
          },
        }),
        (_a[constants_1.CALENDAR_VIEW.time] = {
          module: TimesContextProvider_1.TimesContextProvider,
          args: {
            interval: timeProps.interval,
            format: constants_1.DEFAULT_FULL_TIME_FORMAT,
            date: date,
            activeDate: activeValue,
            secondDate: secondValue,
            isRange: isRange,
            renderFormat: timeProps.format,
            minDate: minDate,
            maxDate: maxDate,
            disabledDates: disabledDates,
            enabledDates: enabledDates,
            isOnlyEnabled: isOnlyEnabled,
          },
        }),
        _a),
    },
    react_1['default'].createElement(Calendar_1.Calendar, null)
  );
});

PickerDate.propTypes = {
  /**
   * Значение активной даты по умолчанию
   */
  activeDate: PropTypes.instanceOf(Date),
  /**
   * Конфигурация календаря – определяет какие календари отображать
   * @default CALENDAR_MODE.YEARS_WITH_MONTH_DAYS_TIMES
   */
  calendarMode: PropTypes.oneOf([
    'DAYS_ONLY',
    'DAYS_WITH_TIMES',
    'MONTHS_ONLY',
    'MONTHS_WITH_DAYS_TIMES',
    'MONTHS_WITH_DAYS',
    'TIMES_ONLY',
    'YEARS_ONLY',
    'YEARS_WITH_MONTH_DAYS_TIMES',
    'YEARS_WITH_MONTH_DAYS',
    'YEARS_WITH_MONTH',
  ]),
  /**
   * Задает дополнительные классы
   */
  className: PropTypes.string,
  /**
   * Задает дополнительные классы
   */
  dayClassName: PropTypes.string,
  /**
   * Задает названия дней недели
   *  @default ['пн', 'вт', 'ср', 'чт', 'пт', 'сб', 'вс']
   */
  daysOfWeek: PropTypes.arrayOf(PropTypes.string),
  /**
   * Задает дополнительные стили для компонента
   */
  dayStyle: PropTypes.object,
  /**
   * Задает дизейбленые даты, которые нельзя выбрать
   */
  disabledDates: PropTypes.arrayOf(PropTypes.instanceOf(Date)),
  /**
   * Задает доступные даты с самым большим приоритетом
   */
  enabledDates: PropTypes.arrayOf(PropTypes.instanceOf(Date)),
  /**
   * Принудительно делает доступными даты только из массива enabledDates
   *  @default false
   */
  isOnlyEnabled: PropTypes.bool,
  /**
   * Дает возможность выбрать период из двух дат
   *  @default false
   */
  isRange: PropTypes.bool,
  /**
   * Задает максимальную дату для выбора
   */
  maxDate: PropTypes.instanceOf(Date),
  /**
   * Задает максимальный отображаемый год в календаре, по умолчанию текущий + 10
   * @default 2031
   */
  maxYear: PropTypes.number,
  /**
   * Задает минимальную дату для выбора
   */
  minDate: PropTypes.instanceOf(Date),
  /**
   * Задает минимальный отображаемый год в календаре
   * @default 1980
   */
  minYear: PropTypes.number,
  /**
   * Задает названия месяцев
   *  @default [
   * 'Январь',
   * 'Февраль',
   * 'Март',
   * 'Апрель',
   * 'Май',
   * 'Июнь',
   * 'Июль',
   * 'Август',
   * 'Сентябрь',
   * 'Октябрь',
   * 'Ноябрь',
   * 'Декабрь',
   * ]
   */
  months: PropTypes.arrayOf(PropTypes.string),
  /**
   * Callback, вызываемый при изменении месяца
   * @param month - выбранный месяц
   */
  onChangeMonth: PropTypes.func,
  /**
   * Callback, вызываемый при изменении года
   * @param year - выбранный год
   */
  onChangeYear: PropTypes.func,
  /**
   * Callback функция, вызываемая при изменении значения
   * @param activeDate - выбранная дата
   * @param secondDate - вторая выбранная дата
   */
  onSelect: PropTypes.func,
  /**
   * Функция, которая дает возможность кастомного вывода даты
   * @param date - дата
   */
  renderDate: PropTypes.func,
  /**
   * Значение второй даты по умолчанию (когда isRange = true)
   */
  secondDate: PropTypes.instanceOf(Date),
  /**
   * Добавляет возможность выбора времени PickerTime
   * @default false
   */
  showTime: PropTypes.bool,
  /**
   * Задает размер
   *  @default m
   */
  size: PropTypes.string,
  /**
   * Задает дополнительные стили для компонента
   */
  style: PropTypes.object,
  /**
   * Задает параметры для выбора времени
   * @param isRange - Дает возможность выбрать период из двух дат
   * @param interval - Задает интвервал выбора времени в минутах
   * @param format - Формат вывода времени
   */
  timeProps: PropTypes.shape({
    /**
     * Формат вывода времени
     * @default "HH:mm"
     */
    format: PropTypes.string,
    /**
     * Задает интервал выбора времени в минутах
     * @default 15
     */
    interval: PropTypes.number,
    /**
     * Дает возможность выбрать период
     *  @default false
     */
    isRange: PropTypes.bool,
  }),
  /**
   * Задает внешний вид
   *  @default primary
   */
  variant: PropTypes.string,
};

exports['default'] = PickerDate;
