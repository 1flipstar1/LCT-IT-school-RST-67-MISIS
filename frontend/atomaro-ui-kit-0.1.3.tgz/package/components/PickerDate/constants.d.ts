import { SIZES, VARIANT } from '../../constants/components';
export declare const DEFAULT_DATE_FORMAT = "DD.MM.YYYY";
export declare const DAYS_OF_WEEK: string[];
export declare const MONTHS: string[];
export declare enum CALENDAR_VIEW {
    day = "day",
    month = "month",
    year = "year",
    time = "time"
}
export declare enum CALENDAR_MODE {
    YEARS_ONLY = "YEARS_ONLY",
    YEARS_WITH_MONTH = "YEARS_WITH_MONTH",
    YEARS_WITH_MONTH_DAYS = "YEARS_WITH_MONTH_DAYS",
    YEARS_WITH_MONTH_DAYS_TIMES = "YEARS_WITH_MONTH_DAYS_TIMES",
    MONTHS_ONLY = "MONTHS_ONLY",
    MONTHS_WITH_DAYS = "MONTHS_WITH_DAYS",
    MONTHS_WITH_DAYS_TIMES = "MONTHS_WITH_DAYS_TIMES",
    DAYS_ONLY = "DAYS_ONLY",
    DAYS_WITH_TIMES = "DAYS_WITH_TIMES",
    TIMES_ONLY = "TIMES_ONLY"
}
export declare enum DATE_STATUS {
    default = "default",
    disabled = "disabled",
    focused = "focused",
    focusedFirst = "focusedFirst",
    focusedLast = "focusedLast"
}
export declare enum RANGE_GRADIENT {
    before = "before",
    after = "after"
}
export type PickerDateSizes = Exclude<SIZES, 'l' | 's' | 'xl'>;
export type PickerDateVariants = Exclude<VARIANT, 'secondary' | 'outline' | 'ghost'>;
export declare const DEFAULT_TIME_FORMAT = "HH:mm";
export declare const DEFAULT_FULL_TIME_FORMAT = "DD.MM.YYYY HH:mm";
export declare const DEFAULT_MINUTES_INTERVAL = 15;
export declare const MIN_YEAR = 1980;
export declare const MAX_YEAR: number;
