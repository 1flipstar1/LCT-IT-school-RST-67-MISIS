import React from 'react';
import { PickerDateProps } from './types';
declare const PickerDate: React.ForwardRefExoticComponent<PickerDateProps & React.RefAttributes<HTMLInputElement>>;
export default PickerDate;
