'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.usePickerDate = void 0;
/* eslint-disable react-hooks/exhaustive-deps */
var react_1 = require('react');
var constants_1 = require('./constants');
var utils_1 = require('./utils');
var usePickerDate = function usePickerDate(props) {
  var activeDate = props.activeDate,
    secondDate = props.secondDate,
    isRange = props.isRange,
    onSelect = props.onSelect,
    showTime = props.showTime,
    timeProps = props.timeProps,
    onChangeMonth = props.onChangeMonth,
    onChangeYear = props.onChangeYear,
    calendarMode = props.calendarMode;
  var _a = (0, react_1.useState)((0, utils_1.getView)(calendarMode, showTime)),
    view = _a[0],
    setView = _a[1];
  (0, react_1.useEffect)(
    function () {
      setView((0, utils_1.getView)(calendarMode, showTime));
    },
    [calendarMode, showTime, setView]
  );
  var today = (0, react_1.useMemo)(
    function () {
      var tmpToday = new Date();
      switch (view) {
        case constants_1.CALENDAR_VIEW.day:
          return tmpToday;
        case constants_1.CALENDAR_VIEW.month:
          return new Date(tmpToday.getFullYear(), tmpToday.getMonth(), 1);
        case constants_1.CALENDAR_VIEW.year:
          return new Date(tmpToday.getFullYear(), 0, 1);
        case constants_1.CALENDAR_VIEW.time:
          return new Date(
            tmpToday.getFullYear(),
            tmpToday.getMonth(),
            tmpToday.getDate(),
            tmpToday.getHours(),
            (timeProps === null || timeProps === void 0 ? void 0 : timeProps.interval)
              ? (0, utils_1.getMinutesFromInterval)(
                  timeProps === null || timeProps === void 0 ? void 0 : timeProps.interval,
                  tmpToday.getMinutes()
                )
              : 0
          );
        default:
          return tmpToday;
      }
    },
    [view, timeProps === null || timeProps === void 0 ? void 0 : timeProps.interval]
  );
  var _b = (0, react_1.useState)(activeDate || today),
    date = _b[0],
    setDate = _b[1];
  var _c = (0, react_1.useState)(activeDate),
    activeValue = _c[0],
    setActiveValue = _c[1];
  var _d = (0, react_1.useState)(secondDate),
    secondValue = _d[0],
    setSecondValue = _d[1];
  (0, react_1.useEffect)(
    function () {
      setActiveValue(activeDate);
      if (isRange) {
        setSecondValue(secondDate);
      } else {
        setSecondValue(undefined);
      }
    },
    [activeDate, secondDate, isRange]
  );
  var clickModeArgs = (0, react_1.useMemo)(
    function () {
      return {
        activeValue: activeValue,
        secondValue: secondValue,
        secondDate: secondDate,
        view: view,
        isRange: isRange,
        showTime: showTime,
        timeProps: timeProps,
        setDate: setDate,
        setView: setView,
        setActiveValue: setActiveValue,
        setSecondValue: setSecondValue,
        onChangeMonth: onChangeMonth,
        onChangeYear: onChangeYear,
        onSelect: onSelect,
      };
    },
    [
      activeValue,
      secondValue,
      secondDate,
      view,
      isRange,
      showTime,
      timeProps,
      setDate,
      setView,
      setActiveValue,
      setSecondValue,
      onChangeMonth,
      onChangeYear,
      onSelect,
    ]
  );
  var dateClickHandler = function dateClickHandler(currDate) {
    if (showTime) {
      (0, utils_1.YMDTClickMode)(currDate, clickModeArgs);
      return;
    }
    switch (calendarMode) {
      case constants_1.CALENDAR_MODE.YEARS_WITH_MONTH_DAYS_TIMES:
        (0, utils_1.YMDTClickMode)(currDate, clickModeArgs);
        return;
      case constants_1.CALENDAR_MODE.YEARS_WITH_MONTH_DAYS:
        (0, utils_1.YMDClickMode)(currDate, clickModeArgs);
        return;
      case constants_1.CALENDAR_MODE.YEARS_WITH_MONTH:
        (0, utils_1.YMClickMode)(currDate, clickModeArgs);
        return;
      case constants_1.CALENDAR_MODE.YEARS_ONLY:
        (0, utils_1.YClickMode)(currDate, clickModeArgs);
        return;
      case constants_1.CALENDAR_MODE.MONTHS_ONLY:
        (0, utils_1.MClickMode)(currDate, clickModeArgs);
        return;
      case constants_1.CALENDAR_MODE.MONTHS_WITH_DAYS:
        (0, utils_1.MDClickMode)(currDate, clickModeArgs);
        return;
      case constants_1.CALENDAR_MODE.MONTHS_WITH_DAYS_TIMES:
        (0, utils_1.MDTClickMode)(currDate, clickModeArgs);
        return;
      case constants_1.CALENDAR_MODE.DAYS_ONLY:
        (0, utils_1.DClickMode)(currDate, clickModeArgs);
        return;
      case constants_1.CALENDAR_MODE.DAYS_WITH_TIMES:
        (0, utils_1.DTClickMode)(currDate, clickModeArgs);
        return;
      case constants_1.CALENDAR_MODE.TIMES_ONLY:
        (0, utils_1.TClickMode)(currDate, clickModeArgs);
        return;
      default:
        (0, utils_1.YMDClickMode)(currDate, clickModeArgs);
    }
  };
  var changeView = function changeView(viewItem) {
    setView(viewItem);
  };
  return {
    today: today,
    date: date,
    setDate: setDate,
    activeValue: activeValue,
    setActiveValue: setActiveValue,
    secondValue: secondValue,
    setSecondValue: setSecondValue,
    view: view,
    setView: setView,
    dateClickHandler: dateClickHandler,
    changeView: changeView,
  };
};
exports.usePickerDate = usePickerDate;
