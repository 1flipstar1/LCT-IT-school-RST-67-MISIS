'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.getPrevYear =
  exports.getNextYear =
  exports.getNextMonth =
  exports.getPrevMonth =
  exports.getPrevDay =
  exports.getNextDay =
    void 0;
var getNextDay = function getNextDay(date) {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate() + 1);
};
exports.getNextDay = getNextDay;
var getPrevDay = function getPrevDay(date) {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate() - 1);
};
exports.getPrevDay = getPrevDay;
var getPrevMonth = function getPrevMonth(date) {
  var currentMonth = date.getMonth();
  var currentYear = date.getFullYear();
  var month = currentMonth === 0 ? 11 : currentMonth - 1;
  var year = currentMonth === 0 ? currentYear - 1 : currentYear;
  return new Date(year, month, 1);
};
exports.getPrevMonth = getPrevMonth;
var getNextMonth = function getNextMonth(date) {
  var currentMonth = date.getMonth();
  var currentYear = date.getFullYear();
  var month = currentMonth === 11 ? 0 : currentMonth + 1;
  var year = currentMonth === 11 ? currentYear + 1 : currentYear;
  return new Date(year, month, 1);
};
exports.getNextMonth = getNextMonth;
var getNextYear = function getNextYear(date) {
  return new Date(date.getFullYear() + 1, 0, 1);
};
exports.getNextYear = getNextYear;
var getPrevYear = function getPrevYear(date) {
  return new Date(date.getFullYear() - 1, 0, 1);
};
exports.getPrevYear = getPrevYear;
