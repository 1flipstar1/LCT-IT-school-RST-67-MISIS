import { FC } from 'react';
import '../../../../styles/components/pickerDate/calendar.scss';
export declare const Calendar: FC;
