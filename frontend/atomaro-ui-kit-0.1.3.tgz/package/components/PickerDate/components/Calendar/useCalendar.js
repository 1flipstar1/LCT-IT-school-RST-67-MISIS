'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.useCalendar = void 0;
var react_1 = require('react');
var DatesContext_1 = require('../../modules/Dates/DatesContext');
var YearsContext_1 = require('../../modules/Years/YearsContext');
var MonthContext_1 = require('../../modules/Month/MonthContext');
var TimesContext_1 = require('../../modules/Times/TimesContext');
var PickerContext_1 = require('../../modules/Picker/PickerContext');
var constants_1 = require('../../constants');
var useCalendar = function useCalendar() {
  var _a = (0, react_1.useContext)(DatesContext_1.DatesContext),
    colsDates = _a.cols,
    dates = _a.dates,
    datesMouseEnter = _a.handleMouseEnter,
    datesMouseLeave = _a.handleMouseLeave;
  var _b = (0, react_1.useContext)(TimesContext_1.TimesContext),
    colsTimes = _b.cols,
    times = _b.times,
    timeMouseEnter = _b.handleMouseEnter,
    timeMouseLeave = _b.handleMouseLeave;
  var _c = (0, react_1.useContext)(YearsContext_1.YearsContext),
    colsYears = _c.cols,
    years = _c.years,
    yearsMouseEnter = _c.handleMouseEnter,
    yearsMouseLeave = _c.handleMouseLeave;
  var _d = (0, react_1.useContext)(MonthContext_1.MonthsContext),
    colsMonths = _d.cols,
    months = _d.months,
    monthMouseEnter = _d.handleMouseEnter,
    monthMouseLeave = _d.handleMouseLeave;
  var _e = (0, react_1.useContext)(PickerContext_1.PickerContext),
    className = _e.className,
    style = _e.style,
    dayClassName = _e.dayClassName,
    dayStyle = _e.dayStyle,
    nameOfMonths = _e.nameOfMonths,
    daysOfWeek = _e.daysOfWeek,
    view = _e.view,
    date = _e.date,
    activeDate = _e.activeDate,
    secondDate = _e.secondDate,
    setDate = _e.setDate,
    today = _e.today,
    dateClickHandler = _e.dateClickHandler,
    changeView = _e.changeView,
    renderDate = _e.renderDate,
    variant = _e.variant,
    size = _e.size,
    calendarMode = _e.calendarMode,
    isRange = _e.isRange;
  var handleMouseEnter = (0, react_1.useCallback)(
    function (d) {
      if (view === constants_1.CALENDAR_VIEW.day) datesMouseEnter(d);
      if (view === constants_1.CALENDAR_VIEW.time) timeMouseEnter(d);
      if (view === constants_1.CALENDAR_VIEW.year) yearsMouseEnter(d);
      if (view === constants_1.CALENDAR_VIEW.month) monthMouseEnter(d);
    },
    [datesMouseEnter, timeMouseEnter, yearsMouseEnter, monthMouseEnter, view]
  );
  var handleMouseLeave = (0, react_1.useCallback)(
    function () {
      if (view === constants_1.CALENDAR_VIEW.day) datesMouseLeave();
      if (view === constants_1.CALENDAR_VIEW.time) timeMouseLeave();
      if (view === constants_1.CALENDAR_VIEW.year) yearsMouseLeave();
      if (view === constants_1.CALENDAR_VIEW.month) monthMouseLeave();
    },
    [datesMouseLeave, timeMouseLeave, yearsMouseLeave, monthMouseLeave, view]
  );
  var cols = (0, react_1.useMemo)(
    function () {
      if (view === constants_1.CALENDAR_VIEW.day) {
        return colsDates;
      }
      if (view === constants_1.CALENDAR_VIEW.month) {
        return colsMonths;
      }
      if (view === constants_1.CALENDAR_VIEW.year) {
        return colsYears;
      }
      if (view === constants_1.CALENDAR_VIEW.time) {
        return colsTimes;
      }
      return colsYears;
    },
    [colsDates, colsYears, colsMonths, colsTimes, view]
  );
  var items = (0, react_1.useMemo)(
    function () {
      if (view === constants_1.CALENDAR_VIEW.day) {
        return dates;
      }
      if (view === constants_1.CALENDAR_VIEW.month) {
        return months;
      }
      if (view === constants_1.CALENDAR_VIEW.year) {
        return years;
      }
      if (view === constants_1.CALENDAR_VIEW.time) {
        return times;
      }
      return dates;
    },
    [dates, months, years, times, view]
  );
  var firstItemRref = (0, react_1.useRef)(null);
  var lastItemRref = (0, react_1.useRef)(null);
  var calendarRef = (0, react_1.useRef)(null);
  var getItemRef = function getItemRef(
    status,
    firstRef,
    lastRef,
    isSecondDate,
    isActiveDate,
    dateItem,
    todayItem,
    calendarView
  ) {
    if (!isSecondDate && !isActiveDate) {
      if (calendarView === constants_1.CALENDAR_VIEW.day) {
        if (todayItem.toDateString() === dateItem.toDateString()) {
          return firstRef;
        }
      }
      if (todayItem.toLocaleString() === dateItem.toLocaleString()) {
        return firstRef;
      }
    } else {
      switch (status) {
        case constants_1.DATE_STATUS.focusedFirst:
          return firstRef;
        case constants_1.DATE_STATUS.focusedLast:
          return lastRef;
        default:
          return null;
      }
    }
    return null;
  };
  (0, react_1.useEffect)(
    function () {
      var _a, _b, _c, _d, _e, _f, _g, _h;
      if (calendarRef) {
        if (
          (((_a = firstItemRref.current) === null || _a === void 0 ? void 0 : _a.offsetTop) &&
            ((_b = lastItemRref.current) === null || _b === void 0 ? void 0 : _b.offsetTop)) ||
          (((_c = firstItemRref.current) === null || _c === void 0 ? void 0 : _c.offsetTop) &&
            !((_d = lastItemRref.current) === null || _d === void 0 ? void 0 : _d.offsetTop))
        ) {
          (_e = calendarRef.current) === null || _e === void 0
            ? void 0
            : _e.scrollBy(0, firstItemRref.current.offsetTop);
        }
        if (
          !((_f = firstItemRref.current) === null || _f === void 0 ? void 0 : _f.offsetTop) &&
          ((_g = lastItemRref.current) === null || _g === void 0 ? void 0 : _g.offsetTop)
        ) {
          (_h = calendarRef.current) === null || _h === void 0
            ? void 0
            : _h.scrollBy(0, lastItemRref.current.offsetTop);
        }
      }
    },
    [firstItemRref, lastItemRref, calendarRef]
  );
  var isSecondDate = !!secondDate;
  var isActiveDate = !!activeDate;
  return {
    className: className,
    style: style,
    dayClassName: dayClassName,
    dayStyle: dayStyle,
    nameOfMonths: nameOfMonths,
    daysOfWeek: daysOfWeek,
    view: view,
    cols: cols,
    items: items,
    firstItemRref: firstItemRref,
    lastItemRref: lastItemRref,
    calendarRef: calendarRef,
    isSecondDate: isSecondDate,
    isActiveDate: isActiveDate,
    isRange: isRange,
    date: date,
    setDate: setDate,
    today: today,
    variant: variant,
    size: size,
    calendarMode: calendarMode,
    getItemRef: getItemRef,
    handleMouseEnter: handleMouseEnter,
    handleMouseLeave: handleMouseLeave,
    dateClickHandler: dateClickHandler,
    changeView: changeView,
    renderDate: renderDate,
  };
};
exports.useCalendar = useCalendar;
