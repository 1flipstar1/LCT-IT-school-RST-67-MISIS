export declare const getNextDay: (date: Date) => Date;
export declare const getPrevDay: (date: Date) => Date;
export declare const getPrevMonth: (date: Date) => Date;
export declare const getNextMonth: (date: Date) => Date;
export declare const getNextYear: (date: Date) => Date;
export declare const getPrevYear: (date: Date) => Date;
