'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __createBinding =
  (this && this.__createBinding) ||
  (Object.create
    ? function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ('get' in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = {
            enumerable: true,
            get: function get() {
              return m[k];
            },
          };
        }
        Object.defineProperty(o, k2, desc);
      }
    : function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
      });
var __setModuleDefault =
  (this && this.__setModuleDefault) ||
  (Object.create
    ? function (o, v) {
        Object.defineProperty(o, 'default', {
          enumerable: true,
          value: v,
        });
      }
    : function (o, v) {
        o['default'] = v;
      });
var __importStar =
  (this && this.__importStar) ||
  function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null)
      for (var k in mod)
        if (k !== 'default' && Object.prototype.hasOwnProperty.call(mod, k))
          __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.Calendar = void 0;
/* eslint-disable jsx-a11y/no-static-element-interactions */
/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable react/no-array-index-key */
var react_1 = __importStar(require('react'));
var dayjs_1 = __importDefault(require('dayjs'));
var clsx_1 = __importDefault(require('clsx'));
require('../../../../styles/components/pickerDate/calendar.scss');
var constants_1 = require('../../constants');
var utils_1 = require('./utils');
var YearsWithMonthDaysHeader_1 = require('../Header/components/YearsWithMonthDaysHeader');
var YearsWithMonthHeader_1 = require('../Header/components/YearsWithMonthHeader');
var MonthWithDaysHeader_1 = require('../Header/components/MonthWithDaysHeader');
var useCalendar_1 = require('./useCalendar');
var Calendar = function Calendar() {
  var _a = (0, useCalendar_1.useCalendar)(),
    className = _a.className,
    style = _a.style,
    dayClassName = _a.dayClassName,
    dayStyle = _a.dayStyle,
    nameOfMonths = _a.nameOfMonths,
    daysOfWeek = _a.daysOfWeek,
    view = _a.view,
    // cols,
    items = _a.items,
    firstItemRref = _a.firstItemRref,
    lastItemRref = _a.lastItemRref,
    calendarRef = _a.calendarRef,
    isSecondDate = _a.isSecondDate,
    isActiveDate = _a.isActiveDate,
    isRange = _a.isRange,
    date = _a.date,
    setDate = _a.setDate,
    today = _a.today,
    variant = _a.variant,
    size = _a.size,
    calendarMode = _a.calendarMode,
    getItemRef = _a.getItemRef,
    handleMouseEnter = _a.handleMouseEnter,
    handleMouseLeave = _a.handleMouseLeave,
    dateClickHandler = _a.dateClickHandler,
    _changeView = _a.changeView,
    renderDate = _a.renderDate;
  var isFocusedExist = items.some(function (el) {
    return (
      el.status === constants_1.DATE_STATUS.focused ||
      el.status === constants_1.DATE_STATUS.focusedLast
    );
  });
  var Header = (0, react_1.useMemo)(
    function () {
      switch (calendarMode) {
        case constants_1.CALENDAR_MODE.YEARS_ONLY:
        case constants_1.CALENDAR_MODE.MONTHS_ONLY:
        case constants_1.CALENDAR_MODE.DAYS_ONLY:
        case constants_1.CALENDAR_MODE.DAYS_WITH_TIMES:
        case constants_1.CALENDAR_MODE.TIMES_ONLY:
          return null;
        case constants_1.CALENDAR_MODE.YEARS_WITH_MONTH:
          return react_1['default'].createElement(YearsWithMonthHeader_1.YearsWithMonthHeader, {
            variant: variant,
            size: size,
            year: String(date.getFullYear()),
            view: view,
            getNextYear: function getNextYear() {
              return setDate((0, utils_1.getNextYear)(date));
            },
            getPrevYear: function getPrevYear() {
              return setDate((0, utils_1.getPrevYear)(date));
            },
            changeView: function changeView(v) {
              return _changeView(v);
            },
          });
        case constants_1.CALENDAR_MODE.MONTHS_WITH_DAYS:
        case constants_1.CALENDAR_MODE.MONTHS_WITH_DAYS_TIMES:
          return react_1['default'].createElement(MonthWithDaysHeader_1.MonthWithDaysHeader, {
            variant: variant,
            size: size,
            fullDate: (0, dayjs_1['default'])(date).format(constants_1.DEFAULT_DATE_FORMAT),
            month: nameOfMonths[date.getMonth()],
            view: view,
            getNextMonth: function getNextMonth() {
              return setDate((0, utils_1.getNextMonth)(date));
            },
            getPrevMonth: function getPrevMonth() {
              return setDate((0, utils_1.getPrevMonth)(date));
            },
            changeView: function changeView(v) {
              return _changeView(v);
            },
          });
        default:
          return react_1['default'].createElement(
            YearsWithMonthDaysHeader_1.YearsWithMonthDaysHeader,
            {
              variant: variant,
              size: size,
              fullDate: (0, dayjs_1['default'])(date).format(constants_1.DEFAULT_DATE_FORMAT),
              month: nameOfMonths[date.getMonth()],
              year: String(date.getFullYear()),
              view: view,
              getNextMonth: function getNextMonth() {
                return setDate((0, utils_1.getNextMonth)(date));
              },
              getPrevMonth: function getPrevMonth() {
                return setDate((0, utils_1.getPrevMonth)(date));
              },
              getPrevDay: function getPrevDay() {
                return setDate((0, utils_1.getPrevDay)(date));
              },
              getNextDay: function getNextDay() {
                return setDate((0, utils_1.getNextDay)(date));
              },
              changeView: function changeView(v) {
                return _changeView(v);
              },
            }
          );
      }
    },
    [calendarMode, variant, size, date, view, nameOfMonths, setDate, _changeView]
  );
  var rootClassName = (0, clsx_1['default'])(
    'calendar',
    'calendar--size-'.concat(size),
    'calendar--'.concat(variant),
    'calendar--'.concat(view),
    'calendar--'.concat(calendarMode.toLowerCase()),
    isSecondDate && 'calendar--second-date',
    isRange && 'calendar--range',
    isFocusedExist && 'calendar--focused-exist',
    isActiveDate && 'calendar--active-date',
    className && ''.concat(className)
  );
  var calendarItemClassName = function calendarItemClassName(status, empty, isToday, gradient) {
    return (0, clsx_1['default'])(
      'calendar__item',
      'calendar__item--'.concat(status),
      empty && 'calendar__item--empty',
      isToday && 'calendar__item--today',
      gradient && 'calendar__item--gradient-'.concat(gradient)
    );
  };
  return react_1['default'].createElement(
    'div',
    {
      className: rootClassName,
      style: __assign({}, style),
    },
    Header,
    react_1['default'].createElement(
      'div',
      {
        className: 'calendar__calendar',
        ref: calendarRef,
      },
      view === constants_1.CALENDAR_VIEW.day &&
        daysOfWeek.map(function (day, idx) {
          return react_1['default'].createElement(
            'div',
            {
              className: 'calendar__day',
              key: idx,
            },
            day
          );
        }),
      items.map(function (elem, idx) {
        return react_1['default'].createElement(
          'div',
          {
            className: calendarItemClassName(
              elem.status,
              !!elem.empty,
              view === constants_1.CALENDAR_VIEW.day
                ? today.toDateString() === elem.date.toDateString()
                : today.toLocaleString() === elem.date.toLocaleString(),
              elem.gradient
            ),
            ref: getItemRef(
              elem.status,
              firstItemRref,
              lastItemRref,
              isSecondDate,
              isActiveDate,
              elem.date,
              today,
              view
            ),
            key: idx,
          },
          react_1['default'].createElement(
            'div',
            {
              className: 'calendar__inner '.concat(dayClassName || ''),
              style: __assign({}, dayStyle),
              onClick: function onClick(e) {
                e.stopPropagation();
                if (elem.status !== constants_1.DATE_STATUS.disabled && !elem.empty) {
                  dateClickHandler(new Date(elem.date));
                }
                return null;
              },
              onMouseEnter: function onMouseEnter(e) {
                e.stopPropagation();
                if (!elem.empty) {
                  handleMouseEnter(elem.date);
                }
              },
              onMouseLeave: function onMouseLeave(e) {
                e.stopPropagation();
                handleMouseLeave();
              },
            },
            react_1['default'].createElement(
              'span',
              null,
              renderDate ? renderDate(elem.date, view) : elem.title
            )
          )
        );
      })
    )
  );
};
exports.Calendar = Calendar;
