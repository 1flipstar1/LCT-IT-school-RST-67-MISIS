'use strict';
var PropTypes = require('prop-types');

var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.YearsWithMonthHeader = void 0;
/* eslint-disable import/no-extraneous-dependencies */
var react_1 = __importDefault(require('react'));
var clsx_1 = __importDefault(require('clsx'));
var ChevronLeft_1 = __importDefault(require('@atomaro/icons/24/navigation/ChevronLeft'));
var ChevronRight_1 = __importDefault(require('@atomaro/icons/24/navigation/ChevronRight'));
var constants_1 = require('../../../constants');
require('../../../../../styles/components/pickerDate/header.scss');
var YearsWithMonthHeader = function YearsWithMonthHeader(_a) {
  var year = _a.year,
    view = _a.view,
    getNextYear = _a.getNextYear,
    getPrevYear = _a.getPrevYear,
    changeView = _a.changeView,
    size = _a.size,
    variant = _a.variant;
  var isActiveYear = view === constants_1.CALENDAR_VIEW.year;
  var rootClassName = (0, clsx_1['default'])(
    'calendar-header',
    'calendar-header--'.concat(view),
    'calendar-header--'.concat(variant),
    'calendar-header--size-'.concat(size),
    isActiveYear && 'calendar-header--active-year'
  );
  return react_1['default'].createElement(
    'div',
    {
      className: rootClassName,
    },
    view === constants_1.CALENDAR_VIEW.month &&
      react_1['default'].createElement(
        'div',
        {
          className: 'calendar-header__button',
          onClick: function onClick(e) {
            e.stopPropagation();
            getPrevYear();
          },
        },
        react_1['default'].createElement(ChevronLeft_1['default'], null)
      ),
    react_1['default'].createElement(
      'div',
      {
        className: 'calendar-header__container',
      },
      react_1['default'].createElement(
        'div',
        {
          className: 'calendar-header__item calendar-header__item--year',
          onClick: function onClick(e) {
            e.stopPropagation();
            changeView(constants_1.CALENDAR_VIEW.year);
          },
        },
        year
      )
    ),
    view === constants_1.CALENDAR_VIEW.month &&
      react_1['default'].createElement(
        'div',
        {
          className: 'calendar-header__button',
          onClick: function onClick(e) {
            e.stopPropagation();
            getNextYear();
          },
        },
        react_1['default'].createElement(ChevronRight_1['default'], null)
      )
  );
};

YearsWithMonthHeader.propTypes = {
  changeView: PropTypes.func.isRequired,
  getNextYear: PropTypes.func.isRequired,
  getPrevYear: PropTypes.func.isRequired,
  size: PropTypes.string.isRequired,
  variant: PropTypes.string.isRequired,
  view: PropTypes.oneOf(['day', 'month', 'time', 'year']).isRequired,
  year: PropTypes.string.isRequired,
};

exports.YearsWithMonthHeader = YearsWithMonthHeader;
