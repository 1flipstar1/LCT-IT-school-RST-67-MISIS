import { FC } from 'react';
import '../../../../../styles/components/pickerDate/header.scss';
import { YearsWithMonthHeaderProps } from '../types';
export declare const YearsWithMonthHeader: FC<YearsWithMonthHeaderProps>;
