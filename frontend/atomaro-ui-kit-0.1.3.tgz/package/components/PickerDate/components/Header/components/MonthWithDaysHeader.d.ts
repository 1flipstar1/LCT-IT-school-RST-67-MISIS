import { FC } from 'react';
import '../../../../../styles/components/pickerDate/header.scss';
import { MonthWithDaysHeaderProps } from '../types';
export declare const MonthWithDaysHeader: FC<MonthWithDaysHeaderProps>;
