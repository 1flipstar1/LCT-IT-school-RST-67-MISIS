'use strict';
var PropTypes = require('prop-types');

var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.MonthWithDaysHeader = void 0;
/* eslint-disable import/no-extraneous-dependencies */
var react_1 = __importDefault(require('react'));
var clsx_1 = __importDefault(require('clsx'));
var constants_1 = require('../../../constants');
var ChevronLeft_1 = __importDefault(require('@atomaro/icons/24/navigation/ChevronLeft'));
var ChevronRight_1 = __importDefault(require('@atomaro/icons/24/navigation/ChevronRight'));
require('../../../../../styles/components/pickerDate/header.scss');
var MonthWithDaysHeader = function MonthWithDaysHeader(_a) {
  var fullDate = _a.fullDate,
    month = _a.month,
    view = _a.view,
    getPrevMonth = _a.getPrevMonth,
    getNextMonth = _a.getNextMonth,
    changeView = _a.changeView,
    variant = _a.variant,
    size = _a.size;
  var isActiveMonth = view === constants_1.CALENDAR_VIEW.month;
  var isActiveYear = view === constants_1.CALENDAR_VIEW.year;
  var rootClassName = (0, clsx_1['default'])(
    'calendar-header',
    'calendar-header--'.concat(view),
    'calendar-header--'.concat(variant),
    'calendar-header--size-'.concat(size),
    isActiveMonth && 'calendar-header--active-month',
    isActiveYear && 'calendar-header--active-year'
  );
  return react_1['default'].createElement(
    'div',
    {
      className: rootClassName,
    },
    view === constants_1.CALENDAR_VIEW.day || view === constants_1.CALENDAR_VIEW.time
      ? react_1['default'].createElement(
          'div',
          {
            className: 'calendar-header__button',
            onClick: function onClick(e) {
              e.stopPropagation();
              getPrevMonth();
            },
          },
          react_1['default'].createElement(ChevronLeft_1['default'], null)
        )
      : null,
    react_1['default'].createElement(
      'div',
      {
        className: 'calendar-header__container',
      },
      view === constants_1.CALENDAR_VIEW.time
        ? react_1['default'].createElement(
            'div',
            {
              className: 'calendar-header__item calendar-header__item--fullDate',
            },
            fullDate
          )
        : react_1['default'].createElement(
            'div',
            {
              className: 'calendar-header__item calendar-header__item--month',
              onClick: function onClick(e) {
                e.stopPropagation();
                changeView(constants_1.CALENDAR_VIEW.month);
              },
            },
            month
          )
    ),
    view === constants_1.CALENDAR_VIEW.day || view === constants_1.CALENDAR_VIEW.time
      ? react_1['default'].createElement(
          'div',
          {
            className: 'calendar-header__button',
            onClick: function onClick(e) {
              e.stopPropagation();
              getNextMonth();
            },
          },
          react_1['default'].createElement(ChevronRight_1['default'], null)
        )
      : null
  );
};

MonthWithDaysHeader.propTypes = {
  changeView: PropTypes.func.isRequired,
  fullDate: PropTypes.string.isRequired,
  getNextMonth: PropTypes.func.isRequired,
  getPrevMonth: PropTypes.func.isRequired,
  month: PropTypes.string.isRequired,
  size: PropTypes.string.isRequired,
  variant: PropTypes.string.isRequired,
  view: PropTypes.oneOf(['day', 'month', 'time', 'year']).isRequired,
};

exports.MonthWithDaysHeader = MonthWithDaysHeader;
