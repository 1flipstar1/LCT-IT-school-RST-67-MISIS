import { FC } from 'react';
import '../../../../../styles/components/pickerDate/header.scss';
import { YearsWithMonthDaysHeaderProps } from '../types';
export declare const YearsWithMonthDaysHeader: FC<YearsWithMonthDaysHeaderProps>;
