import { CALENDAR_VIEW, PickerDateSizes, PickerDateVariants } from '../../constants';
interface IHeader {
    fullDate: string;
    month: string;
    year: string;
    view: CALENDAR_VIEW;
    variant: PickerDateVariants | string;
    size: PickerDateSizes | string;
    getNextYear: () => void;
    getPrevYear: () => void;
    getPrevMonth: () => void;
    getNextMonth: () => void;
    getPrevDay: () => void;
    getNextDay: () => void;
    changeView: (view: CALENDAR_VIEW) => void;
}
export type YearsWithMonthDaysHeaderProps = Omit<IHeader, 'getNextYear' | 'getPrevYear'>;
export type YearsWithMonthHeaderProps = Omit<IHeader, 'fullDate' | 'month' | 'getPrevMonth' | 'getNextMonth' | 'getPrevDay' | 'getNextDay'>;
export type MonthWithDaysHeaderProps = Omit<IHeader, 'year' | 'getNextYear' | 'getPrevYear' | 'getPrevDay' | 'getNextDay'>;
export {};
