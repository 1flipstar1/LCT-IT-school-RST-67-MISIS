'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.MAX_YEAR =
  exports.MIN_YEAR =
  exports.DEFAULT_MINUTES_INTERVAL =
  exports.DEFAULT_FULL_TIME_FORMAT =
  exports.DEFAULT_TIME_FORMAT =
  exports.RANGE_GRADIENT =
  exports.DATE_STATUS =
  exports.CALENDAR_MODE =
  exports.CALENDAR_VIEW =
  exports.MONTHS =
  exports.DAYS_OF_WEEK =
  exports.DEFAULT_DATE_FORMAT =
    void 0;
exports.DEFAULT_DATE_FORMAT = 'DD.MM.YYYY';
exports.DAYS_OF_WEEK = ['пн', 'вт', 'ср', 'чт', 'пт', 'сб', 'вс'];
exports.MONTHS = [
  'Январь',
  'Февраль',
  'Март',
  'Апрель',
  'Май',
  'Июнь',
  'Июль',
  'Август',
  'Сентябрь',
  'Октябрь',
  'Ноябрь',
  'Декабрь',
];
var CALENDAR_VIEW;
(function (CALENDAR_VIEW) {
  CALENDAR_VIEW['day'] = 'day';
  CALENDAR_VIEW['month'] = 'month';
  CALENDAR_VIEW['year'] = 'year';
  CALENDAR_VIEW['time'] = 'time';
})((CALENDAR_VIEW = exports.CALENDAR_VIEW || (exports.CALENDAR_VIEW = {})));
var CALENDAR_MODE;
(function (CALENDAR_MODE) {
  CALENDAR_MODE['YEARS_ONLY'] = 'YEARS_ONLY';
  CALENDAR_MODE['YEARS_WITH_MONTH'] = 'YEARS_WITH_MONTH';
  CALENDAR_MODE['YEARS_WITH_MONTH_DAYS'] = 'YEARS_WITH_MONTH_DAYS';
  CALENDAR_MODE['YEARS_WITH_MONTH_DAYS_TIMES'] = 'YEARS_WITH_MONTH_DAYS_TIMES';
  CALENDAR_MODE['MONTHS_ONLY'] = 'MONTHS_ONLY';
  CALENDAR_MODE['MONTHS_WITH_DAYS'] = 'MONTHS_WITH_DAYS';
  CALENDAR_MODE['MONTHS_WITH_DAYS_TIMES'] = 'MONTHS_WITH_DAYS_TIMES';
  CALENDAR_MODE['DAYS_ONLY'] = 'DAYS_ONLY';
  CALENDAR_MODE['DAYS_WITH_TIMES'] = 'DAYS_WITH_TIMES';
  CALENDAR_MODE['TIMES_ONLY'] = 'TIMES_ONLY';
})((CALENDAR_MODE = exports.CALENDAR_MODE || (exports.CALENDAR_MODE = {})));
var DATE_STATUS;
(function (DATE_STATUS) {
  DATE_STATUS['default'] = 'default';
  DATE_STATUS['disabled'] = 'disabled';
  DATE_STATUS['focused'] = 'focused';
  DATE_STATUS['focusedFirst'] = 'focusedFirst';
  DATE_STATUS['focusedLast'] = 'focusedLast';
})((DATE_STATUS = exports.DATE_STATUS || (exports.DATE_STATUS = {})));
var RANGE_GRADIENT;
(function (RANGE_GRADIENT) {
  RANGE_GRADIENT['before'] = 'before';
  RANGE_GRADIENT['after'] = 'after';
})((RANGE_GRADIENT = exports.RANGE_GRADIENT || (exports.RANGE_GRADIENT = {})));
exports.DEFAULT_TIME_FORMAT = 'HH:mm';
exports.DEFAULT_FULL_TIME_FORMAT = 'DD.MM.YYYY HH:mm';
exports.DEFAULT_MINUTES_INTERVAL = 15;
exports.MIN_YEAR = 1980;
exports.MAX_YEAR = new Date().getFullYear() + 10;
