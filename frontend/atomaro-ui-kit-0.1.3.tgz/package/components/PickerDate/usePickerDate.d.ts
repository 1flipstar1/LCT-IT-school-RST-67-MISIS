/// <reference types="react" />
import { PickerDateProps } from './types';
import { CALENDAR_VIEW } from './constants';
export declare const usePickerDate: (props: PickerDateProps) => {
    today: Date;
    date: Date;
    setDate: import("react").Dispatch<import("react").SetStateAction<Date>>;
    activeValue: Date;
    setActiveValue: import("react").Dispatch<import("react").SetStateAction<Date>>;
    secondValue: Date;
    setSecondValue: import("react").Dispatch<import("react").SetStateAction<Date>>;
    view: CALENDAR_VIEW;
    setView: import("react").Dispatch<import("react").SetStateAction<CALENDAR_VIEW>>;
    dateClickHandler: (currDate: Date) => void;
    changeView: (viewItem: CALENDAR_VIEW) => void;
};
