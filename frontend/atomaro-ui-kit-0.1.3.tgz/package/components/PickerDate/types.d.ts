import { CSSProperties, ReactNode } from 'react';
import { RANGE_GRADIENT, DATE_STATUS, CALENDAR_MODE, CALENDAR_VIEW, PickerDateVariants, PickerDateSizes } from './constants';
export interface ITimeProps {
    /** Дает возможность выбрать период
     *  @default false */
    isRange?: boolean;
    /** Задает интервал выбора времени в минутах
     * @default 15
     */
    interval?: number;
    /** Формат вывода времени
     * @default "HH:mm"
     */
    format?: string;
}
export interface PickerDateProps {
    /** Задает внешний вид
     *  @default primary */
    variant?: PickerDateVariants | string;
    /** Задает размер
     *  @default m */
    size?: PickerDateSizes | string;
    /** Значение активной даты по умолчанию */
    activeDate?: Date;
    /** Значение второй даты по умолчанию (когда isRange = true) */
    secondDate?: Date;
    /** Дает возможность выбрать период из двух дат
     *  @default false */
    isRange?: boolean;
    /** Принудительно делает доступными даты только из массива enabledDates
     *  @default false */
    isOnlyEnabled?: boolean;
    /** Задает индекс первого дня недели
     * @default 1 */
    firstDayIndex?: number;
    /** Задает названия дней недели
     *  @default ['пн', 'вт', 'ср', 'чт', 'пт', 'сб', 'вс'] */
    daysOfWeek?: string[];
    /** Задает названия месяцев
       *  @default [
        'Январь',
        'Февраль',
        'Март',
        'Апрель',
        'Май',
        'Июнь',
        'Июль',
        'Август',
        'Сентябрь',
        'Октябрь',
        'Ноябрь',
        'Декабрь',
      ] */
    months?: string[];
    /** Задает минимальный отображаемый год в календаре
     * @default 1980 */
    minYear?: number;
    /** Задает максимальный отображаемый год в календаре, по умолчанию текущий + 10
     * @default 2031 */
    maxYear?: number;
    /** Задает минимальную дату для выбора */
    minDate?: Date;
    /** Задает максимальную дату для выбора */
    maxDate?: Date;
    /** Задает дизейбленые даты, которые нельзя выбрать */
    disabledDates?: Date[];
    /** Задает доступные даты с самым большим приоритетом */
    enabledDates?: Date[];
    /** Конфигурация календаря – определяет какие календари отображать
     * @default CALENDAR_MODE.YEARS_WITH_MONTH_DAYS_TIMES */
    calendarMode?: CALENDAR_MODE;
    /** Добавляет возможность выбора времени PickerTime
     * @default false
     */
    showTime?: boolean;
    /** Задает параметры для выбора времени
     * @param isRange - Дает возможность выбрать период из двух дат
     * @param interval - Задает интвервал выбора времени в минутах
     * @param format - Формат вывода времени
     */
    timeProps?: ITimeProps;
    /** Callback функция, вызываемая при изменении значения
     * @param activeDate - выбранная дата
     * @param secondDate - вторая выбранная дата
     */
    onSelect?: (activeDate: Date, secondDate?: Date) => void;
    /** Callback, вызываемый при изменении месяца
     * @param month - выбранный месяц
     */
    onChangeMonth?: (month: number) => void;
    /** Callback, вызываемый при изменении года
     * @param year - выбранный год
     */
    onChangeYear?: (year: number) => void;
    /** Задает дополнительные классы */
    className?: string;
    /** Задает дополнительные стили для компонента */
    style?: CSSProperties;
    /** Задает дополнительные классы */
    dayClassName?: string;
    /** Задает дополнительные стили для компонента */
    dayStyle?: CSSProperties;
    /** Функция, которая дает возможность кастомного вывода даты
     * @param date - дата
     */
    renderDate?: (date: Date, view?: CALENDAR_VIEW) => ReactNode;
}
export type CalendarItemType = {
    date: Date;
    title: string;
    empty?: boolean;
    gradient?: RANGE_GRADIENT;
    status: DATE_STATUS;
};
export interface ClickModeConfig {
    activeValue?: Date;
    secondValue?: Date;
    secondDate?: Date;
    view: CALENDAR_VIEW;
    isRange?: boolean;
    showTime?: boolean;
    timeProps?: ITimeProps;
    setDate: Function;
    setView: Function;
    setActiveValue: Function;
    setSecondValue: Function;
    onChangeMonth?: ((month: number) => void) | undefined;
    onChangeYear?: ((year: number) => void) | undefined;
    onSelect?: (activeDate: Date, secondDate?: Date) => void;
}
