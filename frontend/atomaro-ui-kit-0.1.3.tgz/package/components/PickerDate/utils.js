'use strict';

var __spreadArray =
  (this && this.__spreadArray) ||
  function (to, from, pack) {
    if (pack || arguments.length === 2)
      for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
          if (!ar) ar = Array.prototype.slice.call(from, 0, i);
          ar[i] = from[i];
        }
      }
    return to.concat(ar || Array.prototype.slice.call(from));
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.getMinutesFromInterval =
  exports.TClickMode =
  exports.DClickMode =
  exports.DTClickMode =
  exports.MClickMode =
  exports.MDClickMode =
  exports.MDTClickMode =
  exports.YClickMode =
  exports.YMClickMode =
  exports.YMDClickMode =
  exports.YMDTClickMode =
  exports.getView =
  exports.getPrevDay =
  exports.getNextDay =
    void 0;
/* eslint-disable no-plusplus */
var constants_1 = require('./constants');
var getNextDay = function getNextDay(date) {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate() + 1);
};
exports.getNextDay = getNextDay;
var getPrevDay = function getPrevDay(date) {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate() - 1);
};
exports.getPrevDay = getPrevDay;
// Определяет какой календарь показывть при первом рендере
var getView = function getView(calendarMode, showTime) {
  if (calendarMode === constants_1.CALENDAR_MODE.YEARS_ONLY) {
    return constants_1.CALENDAR_VIEW.year;
  }
  if (
    calendarMode === constants_1.CALENDAR_MODE.YEARS_WITH_MONTH ||
    calendarMode === constants_1.CALENDAR_MODE.MONTHS_ONLY
  ) {
    return constants_1.CALENDAR_VIEW.month;
  }
  if (
    calendarMode === constants_1.CALENDAR_MODE.YEARS_WITH_MONTH_DAYS ||
    calendarMode === constants_1.CALENDAR_MODE.YEARS_WITH_MONTH_DAYS_TIMES ||
    calendarMode === constants_1.CALENDAR_MODE.MONTHS_WITH_DAYS ||
    calendarMode === constants_1.CALENDAR_MODE.MONTHS_WITH_DAYS_TIMES ||
    calendarMode === constants_1.CALENDAR_MODE.DAYS_ONLY ||
    calendarMode === constants_1.CALENDAR_MODE.DAYS_WITH_TIMES ||
    showTime === true
  ) {
    return constants_1.CALENDAR_VIEW.day;
  }
  if (calendarMode === constants_1.CALENDAR_MODE.TIMES_ONLY) {
    return constants_1.CALENDAR_VIEW.time;
  }
  return constants_1.CALENDAR_VIEW.day;
};
exports.getView = getView;
// клики в разных режимах календарей
var YMDTClickMode = function YMDTClickMode(currDate, config) {
  var activeValue = config.activeValue,
    secondValue = config.secondValue,
    secondDate = config.secondDate,
    view = config.view,
    isRange = config.isRange,
    timeProps = config.timeProps,
    setDate = config.setDate,
    setView = config.setView,
    setActiveValue = config.setActiveValue,
    setSecondValue = config.setSecondValue,
    onChangeMonth = config.onChangeMonth,
    onChangeYear = config.onChangeYear,
    onSelect = config.onSelect;
  var year = currDate.getFullYear();
  var month = currDate.getMonth();
  switch (view) {
    case constants_1.CALENDAR_VIEW.day:
      setDate(currDate);
      setView(constants_1.CALENDAR_VIEW.time);
      break;
    case constants_1.CALENDAR_VIEW.month:
      setDate(new Date(year, month, 1));
      setView(constants_1.CALENDAR_VIEW.day);
      if (onChangeMonth) {
        onChangeMonth(month);
      }
      break;
    case constants_1.CALENDAR_VIEW.year:
      setDate(currDate);
      if (activeValue && secondValue) {
        if (
          currDate.getFullYear() ===
          (secondDate === null || secondDate === void 0 ? void 0 : secondDate.getFullYear())
        ) {
          setDate(secondDate);
        } else if (
          currDate.getFullYear() ===
          (activeValue === null || activeValue === void 0 ? void 0 : activeValue.getFullYear())
        ) {
          setDate(activeValue);
        } else {
          setDate(currDate);
        }
      }
      if (activeValue && !secondValue) {
        if (year === activeValue.getFullYear()) {
          setDate(activeValue);
        } else {
          setDate(new Date(year, 0, 1));
        }
      }
      setView(constants_1.CALENDAR_VIEW.day);
      if (onChangeYear) {
        onChangeYear(year);
      }
      break;
    case constants_1.CALENDAR_VIEW.time:
      if (isRange) {
        if ((activeValue && secondValue) || (!activeValue && !secondValue)) {
          setActiveValue(currDate);
          setSecondValue(undefined);
          if (!(timeProps === null || timeProps === void 0 ? void 0 : timeProps.isRange)) {
            setView(constants_1.CALENDAR_VIEW.day);
          }
          if (onSelect) onSelect(currDate, undefined);
          return;
        }
        if (activeValue && !secondValue && activeValue < currDate) {
          setSecondValue(currDate);
          setView(constants_1.CALENDAR_VIEW.day);
          if (onSelect) onSelect(activeValue, currDate);
          return;
        }
      }
      setActiveValue(currDate);
      setView(constants_1.CALENDAR_VIEW.day);
      if (onSelect) onSelect(currDate, undefined);
      break;
    default:
      if (isRange) {
        if ((activeValue && secondValue) || (!activeValue && !secondValue)) {
          setActiveValue(currDate);
          setSecondValue(undefined);
          return;
        }
        if (activeValue && !secondValue && activeValue < currDate) {
          setSecondValue(currDate);
          return;
        }
      }
      setActiveValue(currDate);
  }
};
exports.YMDTClickMode = YMDTClickMode;
var YMDClickMode = function YMDClickMode(currDate, config) {
  var activeValue = config.activeValue,
    secondValue = config.secondValue,
    view = config.view,
    isRange = config.isRange,
    timeProps = config.timeProps,
    setDate = config.setDate,
    setView = config.setView,
    setActiveValue = config.setActiveValue,
    setSecondValue = config.setSecondValue,
    onChangeMonth = config.onChangeMonth,
    onChangeYear = config.onChangeYear,
    onSelect = config.onSelect;
  var year = currDate.getFullYear();
  var month = currDate.getMonth();
  switch (view) {
    case constants_1.CALENDAR_VIEW.day:
      if (isRange) {
        if ((activeValue && secondValue) || (!activeValue && !secondValue)) {
          setActiveValue(currDate);
          setSecondValue(undefined);
          if (onSelect) onSelect(currDate, undefined);
          return;
        }
        if (activeValue && !secondValue && activeValue < currDate) {
          setSecondValue(currDate);
          if (onSelect) onSelect(activeValue, currDate);
          return;
        }
      }
      setActiveValue(currDate);
      if (onSelect) onSelect(currDate, undefined);
      break;
    case constants_1.CALENDAR_VIEW.month:
      setDate(new Date(year, month, 1));
      setView(constants_1.CALENDAR_VIEW.day);
      if (onChangeMonth) {
        onChangeMonth(month);
      }
      break;
    case constants_1.CALENDAR_VIEW.year:
      setDate(currDate);
      if (onChangeYear) {
        onChangeYear(year);
      }
      if (activeValue && secondValue) {
        if (currDate.getFullYear() === secondValue.getFullYear()) {
          setDate(secondValue);
        } else if (currDate.getFullYear() === activeValue.getFullYear()) {
          setDate(activeValue);
        } else {
          setDate(currDate);
        }
      }
      if (activeValue && !secondValue) {
        if (year === activeValue.getFullYear()) {
          setDate(activeValue);
        } else {
          setDate(new Date(year, 0, 1));
        }
      }
      setView(constants_1.CALENDAR_VIEW.day);
      break;
    case constants_1.CALENDAR_VIEW.time:
      if (isRange) {
        if ((activeValue && secondValue) || (!activeValue && !secondValue)) {
          setActiveValue(currDate);
          setSecondValue(undefined);
          if (!(timeProps === null || timeProps === void 0 ? void 0 : timeProps.isRange)) {
            setView(constants_1.CALENDAR_VIEW.day);
          }
          return;
        }
        if (activeValue && !secondValue && activeValue < currDate) {
          setSecondValue(currDate);
          setView(constants_1.CALENDAR_VIEW.day);
          return;
        }
      }
      setActiveValue(currDate);
      setView(constants_1.CALENDAR_VIEW.day);
      break;
    default:
      if (isRange) {
        if ((activeValue && secondValue) || (!activeValue && !secondValue)) {
          setActiveValue(currDate);
          setSecondValue(undefined);
          return;
        }
        if (activeValue && !secondValue && activeValue < currDate) {
          setSecondValue(currDate);
          return;
        }
      }
      setActiveValue(currDate);
  }
};
exports.YMDClickMode = YMDClickMode;
var YMClickMode = function YMClickMode(currDate, config) {
  var activeValue = config.activeValue,
    secondValue = config.secondValue,
    secondDate = config.secondDate,
    view = config.view,
    isRange = config.isRange,
    setDate = config.setDate,
    setView = config.setView,
    setActiveValue = config.setActiveValue,
    setSecondValue = config.setSecondValue,
    onChangeMonth = config.onChangeMonth,
    onChangeYear = config.onChangeYear,
    onSelect = config.onSelect;
  var year = currDate.getFullYear();
  var month = currDate.getMonth();
  var addingDate = new Date(year, month, 1);
  switch (view) {
    case constants_1.CALENDAR_VIEW.month:
      setDate(addingDate);
      if (onChangeMonth) {
        onChangeMonth(month);
      }
      if (isRange) {
        if (activeValue && secondValue) {
          setActiveValue(addingDate);
          setSecondValue(undefined);
          setView(constants_1.CALENDAR_VIEW.year);
          if (onSelect) onSelect(addingDate, undefined);
          return;
        }
        if (activeValue && !secondValue && activeValue < addingDate) {
          setSecondValue(addingDate);
          setView(constants_1.CALENDAR_VIEW.month);
          if (onSelect) onSelect(activeValue, addingDate);
          return;
        }
        if (!activeValue && !secondValue) {
          setActiveValue(addingDate);
          setView(constants_1.CALENDAR_VIEW.year);
          if (onSelect) onSelect(addingDate, undefined);
          return;
        }
      }
      setActiveValue(addingDate);
      if (onSelect) onSelect(addingDate, undefined);
      break;
    case constants_1.CALENDAR_VIEW.year:
      setDate(currDate);
      if (activeValue && secondValue) {
        if (
          currDate.getFullYear() ===
          (secondDate === null || secondDate === void 0 ? void 0 : secondDate.getFullYear())
        ) {
          setDate(secondDate);
        } else if (currDate.getFullYear() === activeValue.getFullYear()) {
          setDate(activeValue);
        } else {
          setDate(currDate);
        }
      }
      if (activeValue && !secondValue) {
        if (year === activeValue.getFullYear()) {
          setDate(activeValue);
        } else {
          setDate(new Date(year, 0, 1));
        }
      }
      setView(constants_1.CALENDAR_VIEW.month);
      if (onChangeYear) {
        onChangeYear(year);
      }
      break;
    default:
      if (isRange) {
        if ((activeValue && secondValue) || (!activeValue && !secondValue)) {
          setActiveValue(currDate);
          setSecondValue(undefined);
          return;
        }
        if (activeValue && !secondValue) {
          setSecondValue(currDate);
          return;
        }
      }
      setActiveValue(currDate);
  }
};
exports.YMClickMode = YMClickMode;
var YClickMode = function YClickMode(currDate, config) {
  var activeValue = config.activeValue,
    secondValue = config.secondValue,
    isRange = config.isRange,
    setActiveValue = config.setActiveValue,
    setSecondValue = config.setSecondValue,
    onChangeYear = config.onChangeYear,
    onSelect = config.onSelect;
  var year = currDate.getFullYear();
  if (onChangeYear) {
    onChangeYear(year);
  }
  if (isRange) {
    if ((activeValue && secondValue) || (!activeValue && !secondValue)) {
      setActiveValue(currDate);
      setSecondValue(undefined);
      if (onSelect) onSelect(currDate, undefined);
      return;
    }
    if (activeValue && !secondValue) {
      if (currDate > activeValue) {
        setSecondValue(currDate);
        if (onSelect) onSelect(activeValue, currDate);
        return;
      }
      setActiveValue(currDate);
      setSecondValue(undefined);
      if (onSelect) onSelect(currDate, undefined);
      return;
    }
  }
  setActiveValue(currDate);
  if (onSelect) onSelect(currDate, undefined);
};
exports.YClickMode = YClickMode;
var MDTClickMode = function MDTClickMode(currDate, config) {
  var activeValue = config.activeValue,
    secondValue = config.secondValue,
    view = config.view,
    isRange = config.isRange,
    timeProps = config.timeProps,
    setDate = config.setDate,
    setView = config.setView,
    setActiveValue = config.setActiveValue,
    setSecondValue = config.setSecondValue,
    onChangeMonth = config.onChangeMonth,
    onSelect = config.onSelect;
  var year = currDate.getFullYear();
  var month = currDate.getMonth();
  switch (view) {
    case constants_1.CALENDAR_VIEW.day:
      setDate(currDate);
      setView(constants_1.CALENDAR_VIEW.time);
      break;
    case constants_1.CALENDAR_VIEW.month:
      setDate(new Date(year, month, 1));
      setView(constants_1.CALENDAR_VIEW.day);
      if (onChangeMonth) {
        onChangeMonth(month);
      }
      break;
    case constants_1.CALENDAR_VIEW.time:
      if (isRange) {
        if ((activeValue && secondValue) || (!activeValue && !secondValue)) {
          setActiveValue(currDate);
          setSecondValue(undefined);
          if (!(timeProps === null || timeProps === void 0 ? void 0 : timeProps.isRange)) {
            setView(constants_1.CALENDAR_VIEW.day);
          }
          if (onSelect) onSelect(currDate, undefined);
          return;
        }
        if (activeValue && !secondValue && activeValue < currDate) {
          setSecondValue(currDate);
          setView(constants_1.CALENDAR_VIEW.day);
          if (onSelect) onSelect(activeValue, currDate);
          return;
        }
      }
      setActiveValue(currDate);
      setView(constants_1.CALENDAR_VIEW.day);
      if (onSelect) onSelect(currDate, undefined);
      break;
    default:
      if (isRange) {
        if ((activeValue && secondValue) || (!activeValue && !secondValue)) {
          setActiveValue(currDate);
          setSecondValue(undefined);
          return;
        }
        if (activeValue && !secondValue && activeValue < currDate) {
          setSecondValue(currDate);
          return;
        }
      }
      setActiveValue(currDate);
  }
};
exports.MDTClickMode = MDTClickMode;
var MDClickMode = function MDClickMode(currDate, config) {
  var activeValue = config.activeValue,
    secondValue = config.secondValue,
    view = config.view,
    isRange = config.isRange,
    setDate = config.setDate,
    setView = config.setView,
    setActiveValue = config.setActiveValue,
    setSecondValue = config.setSecondValue,
    onChangeMonth = config.onChangeMonth,
    onSelect = config.onSelect;
  var year = currDate.getFullYear();
  var month = currDate.getMonth();
  switch (view) {
    case constants_1.CALENDAR_VIEW.day:
      if (isRange) {
        if ((activeValue && secondValue) || (!activeValue && !secondValue)) {
          setActiveValue(currDate);
          setSecondValue(undefined);
          if (onSelect) onSelect(currDate, undefined);
          return;
        }
        if (activeValue && !secondValue && activeValue < currDate) {
          setSecondValue(currDate);
          if (onSelect) onSelect(activeValue, currDate);
          return;
        }
      }
      setActiveValue(currDate);
      if (onSelect) onSelect(currDate, undefined);
      break;
    case constants_1.CALENDAR_VIEW.month:
      setDate(new Date(year, month, 1));
      setView(constants_1.CALENDAR_VIEW.day);
      if (onChangeMonth) {
        onChangeMonth(month);
      }
      break;
    default:
      if (isRange) {
        if ((activeValue && secondValue) || (!activeValue && !secondValue)) {
          setActiveValue(currDate);
          setSecondValue(undefined);
          return;
        }
        if (activeValue && !secondValue && activeValue < currDate) {
          setSecondValue(currDate);
          return;
        }
      }
      setActiveValue(currDate);
  }
};
exports.MDClickMode = MDClickMode;
var MClickMode = function MClickMode(currDate, config) {
  var activeValue = config.activeValue,
    secondValue = config.secondValue,
    isRange = config.isRange,
    setActiveValue = config.setActiveValue,
    setSecondValue = config.setSecondValue,
    onChangeMonth = config.onChangeMonth,
    onSelect = config.onSelect;
  var month = currDate.getMonth();
  if (onChangeMonth) {
    onChangeMonth(month);
  }
  if (isRange) {
    if ((activeValue && secondValue) || (!activeValue && !secondValue)) {
      setActiveValue(currDate);
      setSecondValue(undefined);
      if (onSelect) onSelect(currDate, undefined);
      return;
    }
    if (activeValue && !secondValue && activeValue < currDate) {
      setSecondValue(currDate);
      if (onSelect) onSelect(activeValue, currDate);
      return;
    }
  }
  setActiveValue(currDate);
  if (onSelect) onSelect(currDate, undefined);
};
exports.MClickMode = MClickMode;
var DTClickMode = function DTClickMode(currDate, config) {
  var activeValue = config.activeValue,
    secondValue = config.secondValue,
    view = config.view,
    isRange = config.isRange,
    timeProps = config.timeProps,
    setDate = config.setDate,
    setView = config.setView,
    setActiveValue = config.setActiveValue,
    setSecondValue = config.setSecondValue,
    onSelect = config.onSelect;
  switch (view) {
    case constants_1.CALENDAR_VIEW.day:
      setDate(currDate);
      setView(constants_1.CALENDAR_VIEW.time);
      break;
    case constants_1.CALENDAR_VIEW.time:
      if (isRange) {
        if ((activeValue && secondValue) || (!activeValue && !secondValue)) {
          setActiveValue(currDate);
          setSecondValue(undefined);
          if (!(timeProps === null || timeProps === void 0 ? void 0 : timeProps.isRange)) {
            setView(constants_1.CALENDAR_VIEW.day);
          }
          if (onSelect) onSelect(currDate, undefined);
          return;
        }
        if (activeValue && !secondValue && activeValue < currDate) {
          setSecondValue(currDate);
          setView(constants_1.CALENDAR_VIEW.day);
          if (onSelect) onSelect(activeValue, currDate);
          return;
        }
      }
      setActiveValue(currDate);
      setView(constants_1.CALENDAR_VIEW.day);
      if (onSelect) onSelect(currDate, undefined);
      break;
    default:
      if (isRange) {
        if ((activeValue && secondValue) || (!activeValue && !secondValue)) {
          setActiveValue(currDate);
          setSecondValue(undefined);
          return;
        }
        if (activeValue && !secondValue && activeValue < currDate) {
          setSecondValue(currDate);
          return;
        }
      }
      setActiveValue(currDate);
  }
};
exports.DTClickMode = DTClickMode;
var DClickMode = function DClickMode(currDate, config) {
  var activeValue = config.activeValue,
    secondValue = config.secondValue,
    isRange = config.isRange,
    setActiveValue = config.setActiveValue,
    setSecondValue = config.setSecondValue,
    onSelect = config.onSelect;
  if (isRange) {
    if ((activeValue && secondValue) || (!activeValue && !secondValue)) {
      setActiveValue(currDate);
      setSecondValue(undefined);
      if (onSelect) onSelect(currDate, undefined);
      return;
    }
    if (activeValue && !secondValue && activeValue < currDate) {
      setSecondValue(currDate);
      if (onSelect) onSelect(activeValue, currDate);
      return;
    }
  }
  setActiveValue(currDate);
  if (onSelect) onSelect(currDate, undefined);
};
exports.DClickMode = DClickMode;
var TClickMode = function TClickMode(currDate, config) {
  var activeValue = config.activeValue,
    secondValue = config.secondValue,
    isRange = config.isRange,
    setActiveValue = config.setActiveValue,
    setSecondValue = config.setSecondValue,
    onSelect = config.onSelect;
  if (isRange) {
    if ((activeValue && secondValue) || (!activeValue && !secondValue)) {
      setActiveValue(currDate);
      setSecondValue(undefined);
      if (onSelect) onSelect(currDate, undefined);
      return;
    }
    if (activeValue && !secondValue && activeValue < currDate) {
      setSecondValue(currDate);
      if (onSelect) onSelect(activeValue, currDate);
      return;
    }
  }
  setActiveValue(currDate);
  if (onSelect) onSelect(currDate, undefined);
};
exports.TClickMode = TClickMode;
var getMinutesFromInterval = function getMinutesFromInterval(interval, minutes) {
  var intervalsArray = [];
  if (interval < 60) {
    var increment = 60 / interval;
    var _loop_1 = function _loop_1(i) {
      intervalsArray.push(
        __spreadArray([], Array(interval), true).map(function (_, idx) {
          return interval * i + idx;
        })
      );
    };
    for (var i = 0; i < increment; i++) {
      _loop_1(i);
    }
    if (intervalsArray.length) {
      for (var _int = 0; _int < intervalsArray.length; _int++) {
        if (intervalsArray[_int].includes(minutes)) {
          return intervalsArray[_int][0];
        }
      }
    }
  }
  return minutes;
};
exports.getMinutesFromInterval = getMinutesFromInterval;
