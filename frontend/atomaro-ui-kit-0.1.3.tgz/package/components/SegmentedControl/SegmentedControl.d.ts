import { FC } from 'react';
import '../../styles/components/segmentedControl.scss';
import { ISegmentedControl } from './types';
declare const SegmentedControl: FC<ISegmentedControl>;
export default SegmentedControl;
