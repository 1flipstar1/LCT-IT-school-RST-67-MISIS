import React from 'react';
import { SegmentedControlSizesType, SegmentedControlVariantsType } from './constants';
export interface ISegmentedControl extends Omit<React.HTMLAttributes<HTMLDivElement>, 'onChange'> {
    /** Задаёт вид компонента
     *  @default primary */
    variant?: SegmentedControlVariantsType;
    /** Задает размер компонента
     *  @default m */
    size?: SegmentedControlSizesType;
    /** Задает индекс активного сегмента */
    value?: string;
    /** Задает параметр disabled для всей группы */
    disabledAll?: boolean;
    /** Задает id для элемента */
    id?: string;
    /** Callback функция, вызываемая при изменении значения */
    onChange?: (index: string) => void;
    children: React.ReactElement[];
}
export interface ISegmentedControlContext {
    variant?: SegmentedControlVariantsType;
    size?: SegmentedControlSizesType;
    activeIndex?: string;
    disabledAll?: boolean;
    handleChange?: (index: string) => void;
    segmentedControlRef?: React.MutableRefObject<HTMLDivElement>;
}
