export declare enum SEGMENTED_CONTROL_SIZES {
    l = "l",
    m = "m",
    s = "s"
}
export declare enum SEGMENTED_CONTROL_VARIANTS {
    primary = "primary",
    secondary = "secondary"
}
export type SegmentedControlSizesType = keyof typeof SEGMENTED_CONTROL_SIZES;
export type SegmentedControlVariantsType = keyof typeof SEGMENTED_CONTROL_VARIANTS;
export declare const DEFAULT_SIZE = SEGMENTED_CONTROL_SIZES.m;
export declare const DEFAULT_VARIANT = SEGMENTED_CONTROL_VARIANTS.primary;
