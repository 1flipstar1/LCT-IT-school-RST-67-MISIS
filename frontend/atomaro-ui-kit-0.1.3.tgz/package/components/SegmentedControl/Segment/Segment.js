'use strict';
var PropTypes = require('prop-types');

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __createBinding =
  (this && this.__createBinding) ||
  (Object.create
    ? function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ('get' in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = {
            enumerable: true,
            get: function get() {
              return m[k];
            },
          };
        }
        Object.defineProperty(o, k2, desc);
      }
    : function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
      });
var __setModuleDefault =
  (this && this.__setModuleDefault) ||
  (Object.create
    ? function (o, v) {
        Object.defineProperty(o, 'default', {
          enumerable: true,
          value: v,
        });
      }
    : function (o, v) {
        o['default'] = v;
      });
var __importStar =
  (this && this.__importStar) ||
  function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null)
      for (var k in mod)
        if (k !== 'default' && Object.prototype.hasOwnProperty.call(mod, k))
          __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
  };
var __rest =
  (this && this.__rest) ||
  function (s, e) {
    var t = {};
    for (var p in s)
      if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === 'function')
      for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
          t[p[i]] = s[p[i]];
      }
    return t;
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importStar(require('react'));
var clsx_1 = __importDefault(require('clsx'));
require('../../../styles/components/segment.scss');
var context_1 = require('../context');
var noop_1 = require('../../../utils/noop');
var constants_1 = require('../constants');
var Segment = function Segment(props) {
  var index = props.index,
    label = props.label,
    icon = props.icon,
    _a = props.variant,
    variantProp = _a === void 0 ? constants_1.DEFAULT_VARIANT : _a,
    _b = props.size,
    sizeProp = _b === void 0 ? constants_1.DEFAULT_SIZE : _b,
    _c = props.onClick,
    onClick = _c === void 0 ? noop_1.noop : _c,
    _d = props.disabled,
    disabledProp = _d === void 0 ? false : _d,
    _e = props.className,
    className = _e === void 0 ? '' : _e,
    restProps = __rest(props, [
      'index',
      'label',
      'icon',
      'variant',
      'size',
      'onClick',
      'disabled',
      'className',
    ]);
  var _f = (0, react_1.useContext)(context_1.SegmentedControlContext),
    _g = _f.variant,
    variant = _g === void 0 ? variantProp : _g,
    _h = _f.size,
    size = _h === void 0 ? sizeProp : _h,
    activeIndex = _f.activeIndex,
    disabledAll = _f.disabledAll,
    handleChange = _f.handleChange;
  var itemRef = (0, react_1.useRef)();
  var isSelected = activeIndex === index;
  var isDisabled = disabledAll || disabledProp;
  var onClickHandler = function onClickHandler(event) {
    if (!isDisabled && !!handleChange) {
      handleChange(index);
    }
    onClick(event);
  };
  var rootClassName = (0, clsx_1['default'])(
    'segment',
    'segment--'.concat(constants_1.SEGMENTED_CONTROL_VARIANTS[variant]),
    'segment--size-'.concat(constants_1.SEGMENTED_CONTROL_SIZES[size]),
    className
  );
  return react_1['default'].createElement(
    'button',
    __assign(
      {
        className: rootClassName,
        type: 'button',
        disabled: isDisabled,
        'aria-pressed': isSelected,
        ref: itemRef,
        onClick: onClickHandler,
      },
      restProps
    ),
    icon && icon,
    react_1['default'].createElement(
      'span',
      {
        className: 'segment__label',
      },
      label
    )
  );
};

Segment.propTypes = {
  className: PropTypes.string,
  /**
   * Устанавливает атрибут disabled для сегмента
   */
  disabled: PropTypes.bool,
  /**
   * Задаёт иконку для сегмента
   */
  icon: PropTypes.node,
  /**
   * Индекс текущего сегмента
   */
  index: PropTypes.string.isRequired,
  /**
   * Задаёт текст внутри сегмента
   */
  label: PropTypes.node,
  onClick: PropTypes.func,
  /**
   * Задаёт размер компонента
   *  @default m
   */
  size: PropTypes.oneOf(['l', 'm', 's']),
  /**
   * Задаёт вид сегмента
   *  @default primary
   */
  variant: PropTypes.oneOf(['primary', 'secondary']),
};

Segment.displayName = 'Segment';
exports['default'] = Segment;
