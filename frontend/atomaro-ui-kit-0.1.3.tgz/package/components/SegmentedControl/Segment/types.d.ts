import React from 'react';
import { SegmentedControlSizesType, SegmentedControlVariantsType } from '../constants';
export interface ISegment extends Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, 'children'> {
    /** Индекс текущего сегмента */
    index: string;
    /** Задаёт вид сегмента
     *  @default primary */
    variant?: SegmentedControlVariantsType;
    /** Задаёт текст внутри сегмента */
    label?: React.ReactNode;
    /** Задаёт размер компонента
     *  @default m */
    size?: SegmentedControlSizesType;
    /** Задаёт иконку для сегмента */
    icon?: React.ReactNode;
    /** Устанавливает атрибут disabled для сегмента */
    disabled?: boolean;
}
