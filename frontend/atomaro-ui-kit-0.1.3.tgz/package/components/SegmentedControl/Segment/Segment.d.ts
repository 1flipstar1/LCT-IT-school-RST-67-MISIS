import { FC } from 'react';
import '../../../styles/components/segment.scss';
import { ISegment } from './types';
declare const Segment: FC<ISegment>;
export default Segment;
