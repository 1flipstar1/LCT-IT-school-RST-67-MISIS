import React from 'react';
import { ISegmentedControlContext } from './types';
export declare const SegmentedControlContext: React.Context<ISegmentedControlContext>;
declare const SegmentedControlContextProvider: React.Provider<ISegmentedControlContext>;
export default SegmentedControlContextProvider;
