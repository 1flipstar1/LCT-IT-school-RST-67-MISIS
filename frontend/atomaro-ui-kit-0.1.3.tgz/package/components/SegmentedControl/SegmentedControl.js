'use strict';
var PropTypes = require('prop-types');

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __createBinding =
  (this && this.__createBinding) ||
  (Object.create
    ? function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ('get' in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = {
            enumerable: true,
            get: function get() {
              return m[k];
            },
          };
        }
        Object.defineProperty(o, k2, desc);
      }
    : function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
      });
var __setModuleDefault =
  (this && this.__setModuleDefault) ||
  (Object.create
    ? function (o, v) {
        Object.defineProperty(o, 'default', {
          enumerable: true,
          value: v,
        });
      }
    : function (o, v) {
        o['default'] = v;
      });
var __importStar =
  (this && this.__importStar) ||
  function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null)
      for (var k in mod)
        if (k !== 'default' && Object.prototype.hasOwnProperty.call(mod, k))
          __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
  };
var __rest =
  (this && this.__rest) ||
  function (s, e) {
    var t = {};
    for (var p in s)
      if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === 'function')
      for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
          t[p[i]] = s[p[i]];
      }
    return t;
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importStar(require('react'));
var clsx_1 = __importDefault(require('clsx'));
require('../../styles/components/segmentedControl.scss');
var constants_1 = require('./constants');
var context_1 = __importDefault(require('./context'));
var noop_1 = require('../../utils/noop');
var SegmentedControl = function SegmentedControl(props) {
  var _a = props.variant,
    variant = _a === void 0 ? constants_1.DEFAULT_VARIANT : _a,
    _b = props.size,
    size = _b === void 0 ? constants_1.DEFAULT_SIZE : _b,
    _c = props.disabledAll,
    disabledAll = _c === void 0 ? false : _c,
    value = props.value,
    _d = props.className,
    className = _d === void 0 ? '' : _d,
    _e = props.onChange,
    onChange = _e === void 0 ? noop_1.noop : _e,
    children = props.children,
    restProps = __rest(props, [
      'variant',
      'size',
      'disabledAll',
      'value',
      'className',
      'onChange',
      'children',
    ]);
  var ref = (0, react_1.useRef)();
  var _f = (0, react_1.useState)(value),
    activeIndex = _f[0],
    setActiveIndex = _f[1];
  var handleChange = function handleChange(index) {
    if (index !== activeIndex) {
      setActiveIndex(index);
      onChange(index);
    }
  };
  (0, react_1.useEffect)(
    function () {
      if (value && value !== activeIndex) {
        setActiveIndex(value);
      }
      // eslint-disable-next-line react-hooks/exhaustive-deps
    },
    [value]
  );
  var rootClassName = (0, clsx_1['default'])(
    'segmentedcontrol',
    'segmentedcontrol--'.concat(constants_1.SEGMENTED_CONTROL_VARIANTS[variant]),
    'segmentedcontrol--size-'.concat(constants_1.SEGMENTED_CONTROL_SIZES[size]),
    className
  );
  return react_1['default'].createElement(
    context_1['default'],
    {
      value: {
        variant: variant,
        size: size,
        disabledAll: disabledAll,
        activeIndex: activeIndex,
        handleChange: handleChange,
        segmentedControlRef: ref,
      },
    },
    react_1['default'].createElement(
      'div',
      __assign(
        {
          className: rootClassName,
          role: 'radiogroup',
        },
        restProps
      ),
      children
    )
  );
};

SegmentedControl.propTypes = {
  children: PropTypes.arrayOf(PropTypes.element).isRequired,
  className: PropTypes.string,
  /**
   * Задает параметр disabled для всей группы
   */
  disabledAll: PropTypes.bool,
  /**
   * Callback функция, вызываемая при изменении значения
   */
  onChange: PropTypes.func,
  /**
   * Задает размер компонента
   *  @default m
   */
  size: PropTypes.oneOf(['l', 'm', 's']),
  /**
   * Задает индекс активного сегмента
   */
  value: PropTypes.string,
  /**
   * Задаёт вид компонента
   *  @default primary
   */
  variant: PropTypes.oneOf(['primary', 'secondary']),
};

SegmentedControl.displayName = 'SegmentedControl';
exports['default'] = SegmentedControl;
