'use strict';

var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.SegmentedControlContext = void 0;
var react_1 = __importDefault(require('react'));
exports.SegmentedControlContext = react_1['default'].createContext({});
var SegmentedControlContextProvider = exports.SegmentedControlContext.Provider;
exports['default'] = SegmentedControlContextProvider;
