import { PLACEMENTS } from '../../hooks/usePopper/constants';
export declare enum TRIGGERS {
    click = "click",
    hover = "hover"
}
export declare enum TOOLTIP_SIZES {
    s = "s",
    m = "m"
}
export declare enum TOOLTIP_VARIANTS {
    primary = "primary"
}
export declare const ADDITIONAL_OFFSET = 4;
export declare const DEFAULT_TRIGGER = TRIGGERS.click;
export declare const DEFAULT_SIZE = TOOLTIP_SIZES.m;
export declare const DEFAULT_VARIANT = TOOLTIP_VARIANTS.primary;
export declare const DEFAULT_PLACEMENT = PLACEMENTS.auto;
