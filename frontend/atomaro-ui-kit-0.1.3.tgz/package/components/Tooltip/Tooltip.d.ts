import React from 'react';
import '../../styles/components/tooltip.scss';
import { ITooltipProps } from './types';
declare const Tooltip: React.FC<ITooltipProps>;
export default Tooltip;
