'use strict';
var PropTypes = require('prop-types');

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __createBinding =
  (this && this.__createBinding) ||
  (Object.create
    ? function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ('get' in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = {
            enumerable: true,
            get: function get() {
              return m[k];
            },
          };
        }
        Object.defineProperty(o, k2, desc);
      }
    : function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
      });
var __setModuleDefault =
  (this && this.__setModuleDefault) ||
  (Object.create
    ? function (o, v) {
        Object.defineProperty(o, 'default', {
          enumerable: true,
          value: v,
        });
      }
    : function (o, v) {
        o['default'] = v;
      });
var __importStar =
  (this && this.__importStar) ||
  function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null)
      for (var k in mod)
        if (k !== 'default' && Object.prototype.hasOwnProperty.call(mod, k))
          __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
  };
var __rest =
  (this && this.__rest) ||
  function (s, e) {
    var t = {};
    for (var p in s)
      if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === 'function')
      for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
          t[p[i]] = s[p[i]];
      }
    return t;
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importStar(require('react'));
var react_dom_1 = require('react-dom');
var clsx_1 = __importDefault(require('clsx'));
require('../../styles/components/tooltip.scss');
var constants_1 = require('./constants');
var CloseButton_1 = __importDefault(require('../Button/CloseButton/CloseButton'));
var constants_2 = require('../Button/CloseButton/constants');
var useOutsideClick_1 = __importDefault(require('../../hooks/useOutsideClick'));
var usePopper_1 = require('../../hooks/usePopper/usePopper');
var getValueFromCssVariable_1 = require('../../utils/getValueFromCssVariable');
var isDisabledCompatibleChildren_1 = require('../../utils/isDisabledCompatibleChildren');
var hystersisOpen = false;
var hystersisTimer = null;
var Tooltip = function Tooltip(props) {
  var title = props.title,
    subtitle = props.subtitle,
    _a = props.variant,
    variant = _a === void 0 ? constants_1.DEFAULT_VARIANT : _a,
    _b = props.size,
    size = _b === void 0 ? constants_1.DEFAULT_SIZE : _b,
    _c = props.closeButton,
    closeButton = _c === void 0 ? true : _c,
    _d = props.trigger,
    trigger = _d === void 0 ? constants_1.DEFAULT_TRIGGER : _d,
    _e = props.placement,
    placement = _e === void 0 ? constants_1.DEFAULT_PLACEMENT : _e,
    _f = props.pointer,
    pointer = _f === void 0 ? true : _f,
    _g = props.useInPortal,
    useInPortal = _g === void 0 ? true : _g,
    _h = props.enterDelay,
    enterDelay = _h === void 0 ? 150 : _h,
    _j = props.enterNextDelay,
    enterNextDelay = _j === void 0 ? 0 : _j,
    _k = props.leaveDelay,
    leaveDelay = _k === void 0 ? 200 : _k,
    onOpen = props.onOpen,
    onClose = props.onClose,
    offset = props.offset,
    offsetCounterAxis = props.offsetCounterAxis,
    arrowPadding = props.arrowPadding,
    className = props.className,
    children = props.children,
    pointerIsCentered = props.pointerIsCentered,
    usePopperProps = props.usePopperProps,
    restProps = __rest(props, [
      'title',
      'subtitle',
      'variant',
      'size',
      'closeButton',
      'trigger',
      'placement',
      'pointer',
      'useInPortal',
      'enterDelay',
      'enterNextDelay',
      'leaveDelay',
      'onOpen',
      'onClose',
      'offset',
      'offsetCounterAxis',
      'arrowPadding',
      'className',
      'children',
      'pointerIsCentered',
      'usePopperProps',
    ]);
  var tooltipRef = (0, react_1.useRef)();
  var tooltipTriggerRef = (0, react_1.useRef)();
  var ignoreNonTouchEvents = react_1['default'].useRef(false);
  var closeTimer = react_1['default'].useRef();
  var enterTimer = react_1['default'].useRef();
  var leaveTimer = react_1['default'].useRef();
  var touchTimer = react_1['default'].useRef();
  var _l = (0, react_1.useState)(false),
    open = _l[0],
    setOpen = _l[1];
  var _m = (0, react_1.useState)(true),
    isCloseButtonVisible = _m[0],
    setCloseButtonVisibility = _m[1];
  var _o = (0, react_1.useState)(false),
    disabled = _o[0],
    setDisabled = _o[1];
  var pointerOffsetVar = (0, getValueFromCssVariable_1.getValueFromCssVariable)(
    '--tooltip-'.concat(size, '-pointer-offset')
  );
  var formattedPointerOffset = parseFloat(pointerOffsetVar);
  var pointerHeigth = (0, getValueFromCssVariable_1.getValueFromCssVariable)(
    '--tooltip-'.concat(size, '-pointer-height')
  );
  var formattedPointerHeigth = parseFloat(pointerHeigth);
  var _p = (0, usePopper_1.usePopper)(
      __assign(
        {
          enabled: true,
          placement: placement,
          popper: tooltipRef === null || tooltipRef === void 0 ? void 0 : tooltipRef.current,
          trigger:
            tooltipTriggerRef === null || tooltipTriggerRef === void 0
              ? void 0
              : tooltipTriggerRef.current,
          eventListeners: open,
          arrowPadding:
            arrowPadding !== null && arrowPadding !== void 0
              ? arrowPadding
              : formattedPointerOffset,
          offset:
            offset !== null && offset !== void 0
              ? offset
              : formattedPointerHeigth + constants_1.ADDITIONAL_OFFSET,
          offsetCounterAxis: offsetCounterAxis,
          pointerIsCentered: pointerIsCentered,
        },
        usePopperProps
      )
    ),
    getArrowInnerProps = _p.getArrowInnerProps,
    getArrowProps = _p.getArrowProps;
  var prevUserSelect = react_1['default'].useRef();
  var stopTouchInteraction = react_1['default'].useCallback(function () {
    if (prevUserSelect.current !== undefined) {
      document.body.style.WebkitUserSelect = prevUserSelect.current;
      prevUserSelect.current = undefined;
    }
    clearTimeout(touchTimer.current);
  }, []);
  react_1['default'].useEffect(
    function () {
      return function () {
        clearTimeout(closeTimer.current);
        clearTimeout(enterTimer.current);
        clearTimeout(leaveTimer.current);
        stopTouchInteraction();
      };
    },
    [stopTouchInteraction]
  );
  var handleOpen = function handleOpen(event) {
    if (disabled) {
      return;
    }
    if (hystersisTimer) {
      clearTimeout(hystersisTimer);
    }
    hystersisOpen = true;
    setOpen(true);
    if (onOpen && !open) {
      onOpen(event);
    }
  };
  var handleClose = function handleClose(event) {
    if (hystersisTimer) {
      clearTimeout(hystersisTimer);
    }
    hystersisTimer = setTimeout(function () {
      hystersisOpen = false;
    }, 800 + leaveDelay);
    setOpen(false);
    if (onClose && open) {
      onClose(event);
    }
    clearTimeout(closeTimer.current);
    closeTimer.current = setTimeout(function () {
      ignoreNonTouchEvents.current = false;
    }, 150);
  };
  var handleEnter = function handleEnter(event) {
    if (ignoreNonTouchEvents.current && event.type !== 'touchstart') {
      return;
    }
    clearTimeout(enterTimer.current);
    clearTimeout(leaveTimer.current);
    if (enterDelay || (hystersisOpen && enterNextDelay)) {
      enterTimer.current = setTimeout(
        function () {
          handleOpen(event);
        },
        hystersisOpen ? enterNextDelay : enterDelay
      );
    } else {
      handleOpen(event);
    }
  };
  var handleLeave = function handleLeave(event) {
    clearTimeout(enterTimer.current);
    clearTimeout(leaveTimer.current);
    leaveTimer.current = setTimeout(function () {
      handleClose(event);
    }, leaveDelay);
  };
  (0, useOutsideClick_1['default'])(tooltipRef, function (target) {
    if (trigger === constants_1.TRIGGERS.click && !tooltipTriggerRef.current.contains(target)) {
      setOpen(false);
    }
  });
  (0, react_1.useEffect)(
    function () {
      setDisabled(!title && !subtitle);
    },
    [subtitle, title]
  );
  (0, react_1.useEffect)(function () {
    window.addEventListener('scroll', handleClose);
    window.addEventListener('resize', handleClose);
    return function () {
      window.removeEventListener('scroll', handleClose);
      window.removeEventListener('resize', handleClose);
    };
  });
  (0, react_1.useEffect)(
    function () {
      setCloseButtonVisibility(closeButton && trigger === constants_1.TRIGGERS.click);
    },
    [closeButton, trigger]
  );
  var hasDisabledChildren = (0, isDisabledCompatibleChildren_1.isDisabledCompatibleChildren)(
    children,
    tooltipTriggerRef
  );
  var rootClassName = (0, clsx_1['default'])(
    'tooltip__root',
    hasDisabledChildren ? 'tooltip__root--disabled-children' : null
  );
  var tooltipClassName = (0, clsx_1['default'])(
    'tooltip',
    'tooltip--'.concat(constants_1.TOOLTIP_VARIANTS[variant]),
    'tooltip--size-'.concat(constants_1.TOOLTIP_SIZES[size]),
    className
  );
  var renderCloseButton =
    isCloseButtonVisible &&
    react_1['default'].createElement(CloseButton_1['default'], {
      onClick: function onClick() {
        return setOpen(false);
      },
      size: size === 'm' ? constants_2.CLOSE_BUTTON_SIZES.s : constants_2.CLOSE_BUTTON_SIZES['2xs'],
    });
  var renderTitle =
    title &&
    react_1['default'].createElement(
      'div',
      {
        className: 'tooltip__title',
      },
      title
    );
  var renderSubtitle =
    subtitle &&
    react_1['default'].createElement(
      'div',
      {
        className: 'tooltip__subtitle',
      },
      subtitle
    );
  var renderArrow =
    pointer &&
    react_1['default'].createElement(
      'div',
      __assign(
        {
          className: 'tooltip__pointer_wrapper',
        },
        getArrowProps()
      ),
      react_1['default'].createElement(
        'div',
        __assign(
          {
            className: 'tooltip__pointer',
          },
          getArrowInnerProps()
        )
      )
    );
  var renderTooltip = react_1['default'].createElement(
    'div',
    __assign(
      {
        ref: tooltipRef,
        role: 'tooltip',
        className: tooltipClassName,
        'data-show': open,
      },
      restProps
    ),
    react_1['default'].createElement(
      'div',
      {
        className: 'tooltip__content_wrapper',
      },
      renderTitle,
      renderSubtitle
    ),
    renderCloseButton,
    renderArrow
  );
  return react_1['default'].createElement(
    'div',
    {
      className: rootClassName,
    },
    react_1['default'].createElement(
      'div',
      {
        'aria-hidden': true,
        ref: tooltipTriggerRef,
        className: 'tooltip__trigger',
        onClick: function onClick(e) {
          return trigger === constants_1.TRIGGERS.click && handleOpen(e);
        },
        onMouseEnter: function onMouseEnter(e) {
          return trigger === constants_1.TRIGGERS.hover && handleEnter(e);
        },
        onMouseLeave: function onMouseLeave(e) {
          return trigger === constants_1.TRIGGERS.hover && handleLeave(e);
        },
      },
      children
    ),
    useInPortal ? (0, react_dom_1.createPortal)(renderTooltip, document.body) : renderTooltip
  );
};

Tooltip.propTypes = {
  /**
   * Задаёт отступ для поинтера (стрелки) от края тултипа (не применяется при placement up, down, right, left)
   *  @default 0
   */
  arrowPadding: PropTypes.number,
  /**
   * Задаёт элемент, от которого будет позиционироваться тултип
   */
  children: PropTypes.node,
  className: PropTypes.string,
  /**
   * Задает отображение кнопки "Закрыть"
   *  @default true
   */
  closeButton: PropTypes.bool,
  /**
   * Задаёт задержку перед появлением тултипа при наведении
   * @default 150
   */
  enterDelay: PropTypes.number,
  /**
   * Задаёт задержку перед появлением тултипа при повторном наведении
   * @default 0
   */
  enterNextDelay: PropTypes.number,
  /**
   * Задаёт задержку на исчезновение тултипа
   * @default 200
   */
  leaveDelay: PropTypes.number,
  /**
   * Задаёт смещение тултипа относительно родительского компонента по основной оси
   */
  offset: PropTypes.number,
  /**
   * Задаёт смещение тултипа относительно родительского компонента по поперченой оси (не применяется при placement up, down, right, left)
   */
  offsetCounterAxis: PropTypes.number,
  /**
   * Callback-функция, вызываемая при закрытии тултипа
   */
  onClose: PropTypes.func,
  /**
   * Callback-функция, вызываемая при появлении тултипа
   */
  onOpen: PropTypes.func,
  /**
   * Задает расположение для отображения
   *  @default auto
   */
  placement: PropTypes.oneOf([
    'auto',
    'bottom',
    'bottomLeft',
    'bottomRight',
    'left',
    'leftBottom',
    'leftTop',
    'right',
    'rightBottom',
    'rightTop',
    'top',
    'topLeft',
    'topRight',
  ]),
  /**
   * Включает отображение поинтера (стрелки)
   *  @default true
   */
  pointer: PropTypes.bool,
  /**
   * Центририровать pointer на родительский компонент
   *  @default "false"
   */
  pointerIsCentered: PropTypes.bool,
  /**
   * Задаёт размер элемента
   *  @default m
   */
  size: PropTypes.oneOf(['m', 's']),
  /**
   * Задает основной текст
   */
  subtitle: PropTypes.node,
  /**
   * Задает заголовок
   */
  title: PropTypes.string,
  /**
   * Задает событие триггер для отображения
   *  @default click
   */
  trigger: PropTypes.oneOf(['click', 'hover']),
  /**
   * Задаёт вариант использования с React Portal
   * @default true
   */
  useInPortal: PropTypes.bool,
  /**
   * Задаёт параметры для poppper.js
   */
  usePopperProps: PropTypes.shape({
    /**
     * Задаёт отступ для поинтера (стрелки) от края поппера (не применяется при placement up, down, right, left)
     *  @default 0
     */
    arrowPadding: PropTypes.number,
    /**
     * Задаёт область для preventOverflow
     *  @default 'clippingParents'
     */
    boundary: PropTypes.oneOfType([
      PropTypes.oneOf(['clippingParents', 'scrollParent']),
      function (props, propName) {
        if (props[propName] == null) {
          return new Error("Prop '" + propName + "' is required but wasn't specified");
        } else if (typeof props[propName] !== 'object' || props[propName].nodeType !== 1) {
          return new Error("Expected prop '" + propName + "' to be of type Element");
        }
      },
    ]),
    /**
     * Включает popper.js для позиционирования
     *  @default "true"
     */
    enabled: PropTypes.bool,
    /**
     * При включении, тултип будет обновлять позицию при scroll, resize
     *  @default "false"
     */
    eventListeners: PropTypes.bool,
    /**
     * При включении, тултип будет менять своё положение на противоположное при нехватке места для отображения
     *  @default "true"
     */
    flip: PropTypes.bool,
    /**
     * Задаёт модификаторы Popper.js
     */
    modifiers: PropTypes.arrayOf(
      PropTypes.shape({
        data: PropTypes.object,
        effect: PropTypes.func,
        enabled: PropTypes.bool,
        fn: PropTypes.func,
        name: PropTypes.string,
        options: PropTypes.object,
        phase: PropTypes.oneOf([
          'afterMain',
          'afterRead',
          'afterWrite',
          'beforeMain',
          'beforeRead',
          'beforeWrite',
          'main',
          'read',
          'write',
        ]),
        requires: PropTypes.arrayOf(PropTypes.string),
        requiresIfExists: PropTypes.arrayOf(PropTypes.string),
      })
    ),
    /**
     * Задаёт смещение поппера относительно родительского компонента по основной оси
     *  @default 11
     */
    offset: PropTypes.number,
    /**
     * Задаёт смещение поппера относительно родительского компонента по поперченой оси (не применяется при placement up, down, right, left)
     *  @default 0
     */
    offsetCounterAxis: PropTypes.number,
    /**
     * Задает расположение
     *  @default "auto"
     */
    placement: PropTypes.oneOf([
      'auto',
      'bottom',
      'bottomLeft',
      'bottomRight',
      'left',
      'leftBottom',
      'leftTop',
      'right',
      'rightBottom',
      'rightTop',
      'top',
      'topLeft',
      'topRight',
    ]),
    /**
     * Центририровать pointer на родительский компонент
     *  @default "false"
     */
    pointerIsCentered: PropTypes.bool,
    popper: function (props, propName) {
      if (props[propName] == null) {
        return null;
      } else if (typeof props[propName] !== 'object' || props[propName].nodeType !== 1) {
        return new Error("Expected prop '" + propName + "' to be of type Element");
      }
    },
    /**
     * При включении, тултип будет смещаться, чтобы оставаться в зоне видимости
     *  @default "true"
     */
    preventOverflow: PropTypes.bool,
    trigger: PropTypes.oneOfType([
      function (props, propName) {
        if (props[propName] == null) {
          return new Error("Prop '" + propName + "' is required but wasn't specified");
        } else if (typeof props[propName] !== 'object' || props[propName].nodeType !== 1) {
          return new Error("Expected prop '" + propName + "' to be of type Element");
        }
      },
      PropTypes.shape({
        contextElement: function (props, propName) {
          if (props[propName] == null) {
            return null;
          } else if (typeof props[propName] !== 'object' || props[propName].nodeType !== 1) {
            return new Error("Expected prop '" + propName + "' to be of type Element");
          }
        },
        getBoundingClientRect: PropTypes.func.isRequired,
      }),
    ]),
    /**
     * При включении, тултип будет соответствовать ширине родительского компонента
     *  @default "false"
     */
    widthFitContent: PropTypes.bool,
  }),
  /**
   * Задаёт вид компонента
   *  @default primary
   */
  variant: PropTypes.oneOf(['primary']),
};

Tooltip.displayName = 'Tooltip';
exports['default'] = Tooltip;
