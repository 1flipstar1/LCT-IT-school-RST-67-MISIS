"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.DEFAULT_PLACEMENT = exports.DEFAULT_VARIANT = exports.DEFAULT_SIZE = exports.DEFAULT_TRIGGER = exports.ADDITIONAL_OFFSET = exports.TOOLTIP_VARIANTS = exports.TOOLTIP_SIZES = exports.TRIGGERS = void 0;
var constants_1 = require("../../hooks/usePopper/constants");
var TRIGGERS;
(function (TRIGGERS) {
  TRIGGERS["click"] = "click";
  TRIGGERS["hover"] = "hover";
})(TRIGGERS = exports.TRIGGERS || (exports.TRIGGERS = {}));
var TOOLTIP_SIZES;
(function (TOOLTIP_SIZES) {
  TOOLTIP_SIZES["s"] = "s";
  TOOLTIP_SIZES["m"] = "m";
})(TOOLTIP_SIZES = exports.TOOLTIP_SIZES || (exports.TOOLTIP_SIZES = {}));
var TOOLTIP_VARIANTS;
(function (TOOLTIP_VARIANTS) {
  TOOLTIP_VARIANTS["primary"] = "primary";
})(TOOLTIP_VARIANTS = exports.TOOLTIP_VARIANTS || (exports.TOOLTIP_VARIANTS = {}));
exports.ADDITIONAL_OFFSET = 4;
exports.DEFAULT_TRIGGER = TRIGGERS.click;
exports.DEFAULT_SIZE = TOOLTIP_SIZES.m;
exports.DEFAULT_VARIANT = TOOLTIP_VARIANTS.primary;
exports.DEFAULT_PLACEMENT = constants_1.PLACEMENTS.auto;