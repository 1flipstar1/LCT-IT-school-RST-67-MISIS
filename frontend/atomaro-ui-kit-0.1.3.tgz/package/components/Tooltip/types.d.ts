import React from 'react';
import { PlacementsType, UsePopperProps } from '../../hooks/usePopper/types';
import { TOOLTIP_SIZES, TOOLTIP_VARIANTS, TRIGGERS } from './constants';
export interface ITooltipProps extends React.HTMLAttributes<HTMLDivElement> {
    /** Задает заголовок */
    title?: string;
    /** Задает основной текст */
    subtitle?: React.ReactNode;
    /** Задаёт вид компонента
     *  @default primary */
    variant?: VariantsType;
    /** Задаёт размер элемента
     *  @default m */
    size?: SizeType;
    /** Задает отображение кнопки "Закрыть"
     *  @default true */
    closeButton?: boolean;
    /** Задает событие триггер для отображения
     *  @default click */
    trigger?: TooltipTriggersType;
    /** Задает расположение для отображения
     *  @default auto */
    placement?: PlacementsType;
    /** Включает отображение поинтера (стрелки)
     *  @default true */
    pointer?: boolean;
    /** Задаёт отступ для поинтера (стрелки) от края тултипа (не применяется при placement up, down, right, left)
     *  @default 0 */
    arrowPadding?: number;
    /** Задаёт вариант использования с React Portal
     * @default true */
    useInPortal?: boolean;
    /** Задаёт элемент, от которого будет позиционироваться тултип */
    children: React.ReactNode;
    /** Задаёт задержку перед появлением тултипа при наведении
     * @default 150 */
    enterDelay?: number;
    /** Задаёт задержку перед появлением тултипа при повторном наведении
     * @default 0 */
    enterNextDelay?: number;
    /** Задаёт задержку на исчезновение тултипа
     * @default 200 */
    leaveDelay?: number;
    /** Callback-функция, вызываемая при появлении тултипа */
    onOpen?: (e: React.MouseEvent<HTMLElement>) => void;
    /** Callback-функция, вызываемая при закрытии тултипа */
    onClose?: (e: React.SyntheticEvent | Event) => void;
    /** Задаёт смещение тултипа относительно родительского компонента по основной оси */
    offset?: number;
    /** Задаёт смещение тултипа относительно родительского компонента по поперченой оси (не применяется при placement up, down, right, left) */
    offsetCounterAxis?: number;
    /** Задаёт параметры для poppper.js */
    usePopperProps?: UsePopperProps;
    /** Центририровать pointer на родительский компонент
     *  @default "false" */
    pointerIsCentered?: boolean;
}
export type TooltipTriggersType = keyof typeof TRIGGERS;
export type SizeType = keyof typeof TOOLTIP_SIZES;
export type VariantsType = keyof typeof TOOLTIP_VARIANTS;
