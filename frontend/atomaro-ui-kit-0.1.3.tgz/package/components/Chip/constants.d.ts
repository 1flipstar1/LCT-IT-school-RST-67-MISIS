export declare enum CHIP_VARIANTS {
    primary = "primary",
    secondary = "secondary"
}
export declare enum CHIP_SIZES {
    m = "m"
}
export type ChipViewsType = keyof typeof CHIP_VARIANTS;
export type ChipSizesType = keyof typeof CHIP_SIZES;
export declare const DEFAULT_CHIP_TOTAL_LABEL = "\u0412\u0441\u0435";
