import { FC } from 'react';
import '../../../styles/components/chipGroup.scss';
import { IChipGroup } from './types';
declare const ChipGroup: FC<IChipGroup>;
export default ChipGroup;
