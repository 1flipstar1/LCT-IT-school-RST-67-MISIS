'use strict';
var PropTypes = require('prop-types');

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __createBinding =
  (this && this.__createBinding) ||
  (Object.create
    ? function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ('get' in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = {
            enumerable: true,
            get: function get() {
              return m[k];
            },
          };
        }
        Object.defineProperty(o, k2, desc);
      }
    : function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
      });
var __setModuleDefault =
  (this && this.__setModuleDefault) ||
  (Object.create
    ? function (o, v) {
        Object.defineProperty(o, 'default', {
          enumerable: true,
          value: v,
        });
      }
    : function (o, v) {
        o['default'] = v;
      });
var __importStar =
  (this && this.__importStar) ||
  function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null)
      for (var k in mod)
        if (k !== 'default' && Object.prototype.hasOwnProperty.call(mod, k))
          __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
  };
var __rest =
  (this && this.__rest) ||
  function (s, e) {
    var t = {};
    for (var p in s)
      if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === 'function')
      for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
          t[p[i]] = s[p[i]];
      }
    return t;
  };
var __spreadArray =
  (this && this.__spreadArray) ||
  function (to, from, pack) {
    if (pack || arguments.length === 2)
      for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
          if (!ar) ar = Array.prototype.slice.call(from, 0, i);
          ar[i] = from[i];
        }
      }
    return to.concat(ar || Array.prototype.slice.call(from));
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importStar(require('react'));
var clsx_1 = __importDefault(require('clsx'));
require('../../../styles/components/chipGroup.scss');
var constants_1 = require('../constants');
var Chip_1 = __importDefault(require('../Chip/Chip'));
var ChipGroup = function ChipGroup(props) {
  var _a = props.variant,
    variant = _a === void 0 ? constants_1.CHIP_VARIANTS.primary : _a,
    _b = props.size,
    size = _b === void 0 ? constants_1.CHIP_SIZES.m : _b,
    _c = props.items,
    items = _c === void 0 ? [] : _c,
    selectedItems = props.selectedItems,
    _d = props.defaultSelectedItems,
    defaultSelectedItems = _d === void 0 ? [] : _d,
    _e = props.disabledItems,
    disabledItems = _e === void 0 ? [] : _e,
    _f = props.onChange,
    onChange = _f === void 0 ? function () {} : _f,
    _g = props.chipTotal,
    showChipTotal = _g === void 0 ? false : _g,
    _h = props.chipTotalLabel,
    chipTotalLabel = _h === void 0 ? constants_1.DEFAULT_CHIP_TOTAL_LABEL : _h,
    itemsContainerProps = props.itemsContainerProps,
    className = props.className,
    restProps = __rest(props, [
      'variant',
      'size',
      'items',
      'selectedItems',
      'defaultSelectedItems',
      'disabledItems',
      'onChange',
      'chipTotal',
      'chipTotalLabel',
      'itemsContainerProps',
      'className',
    ]);
  var _j = (0, react_1.useState)(defaultSelectedItems),
    groupSelected = _j[0],
    setGroupSelected = _j[1];
  (0, react_1.useEffect)(
    function () {
      if (
        selectedItems !== undefined &&
        selectedItems.join() !== groupSelected.join() &&
        selectedItems.length > 0
      ) {
        setGroupSelected(selectedItems);
      }
    },
    [groupSelected, selectedItems]
  );
  var chipsTotalAmount = (0, react_1.useMemo)(
    function () {
      return items.reduce(function (sum, currentValue) {
        return sum + currentValue.contentItems.length;
      }, 0);
    },
    [items]
  );
  var changeHandler = function changeHandler(id) {
    if (!id) {
      return;
    }
    if (selectedItems === undefined) {
      var newGroupSelected = __spreadArray([], groupSelected, true);
      var indexValue = newGroupSelected.findIndex(function (key) {
        return id === key;
      });
      if (indexValue === -1) {
        newGroupSelected.push(id);
      } else {
        newGroupSelected.splice(indexValue, 1);
      }
      setGroupSelected(newGroupSelected);
    }
    onChange(id);
  };
  var deselectAllHandler = function deselectAllHandler() {
    setGroupSelected([]);
  };
  var chipTotal = react_1['default'].createElement(Chip_1['default'], {
    label: chipTotalLabel,
    counter: chipsTotalAmount,
    variant: variant,
    selected: groupSelected.length === 0 || groupSelected.length === items.length,
    onClick: deselectAllHandler,
  });
  var chipsOptions = items.map(function (chip) {
    return react_1['default'].createElement(Chip_1['default'], {
      id: chip.key,
      key: chip.key,
      label: chip.label,
      counter: chip.contentItems.length,
      variant: variant,
      size: size,
      selected: groupSelected.includes(chip.key),
      disabled: disabledItems.includes(chip.key),
      onClick: function onClick() {
        return changeHandler(chip.key);
      },
    });
  });
  var itemsContent = items.reduce(function (prevValue, currentValue) {
    if (
      (groupSelected.length === 0 || groupSelected.includes(currentValue.key)) &&
      !disabledItems.includes(currentValue.key)
    ) {
      return __spreadArray(__spreadArray([], prevValue, true), currentValue.contentItems, true);
    }
    return __spreadArray([], prevValue, true);
  }, []);
  var rootClassName = (0, clsx_1['default'])('chip-group', className);
  return react_1['default'].createElement(
    react_1['default'].Fragment,
    null,
    react_1['default'].createElement(
      'div',
      __assign(
        {
          className: rootClassName,
        },
        restProps
      ),
      react_1['default'].createElement(
        'div',
        {
          className: 'chip-group__inner',
        },
        showChipTotal && chipTotal,
        chipsOptions
      )
    ),
    react_1['default'].createElement(
      'div',
      __assign(
        {
          className: 'chip-group__content',
        },
        itemsContainerProps
      ),
      itemsContent
    )
  );
};

ChipGroup.propTypes = {
  /**
   * Добавляет общий чип
   *  @default false
   */
  chipTotal: PropTypes.bool,
  /**
   * Добавляет текст для общего чипа
   */
  chipTotalLabel: PropTypes.string,
  className: PropTypes.string,
  /**
   * Список выбранных чипов по умолчанию. Массив с ключами. Используется для неуправляемых компонентов
   * Не используется вместе с selectedChips
   * @param key - ключ selected чипа
   */
  defaultSelectedItems: PropTypes.arrayOf(PropTypes.string),
  /**
   * Список disabled чипов. Массив с ключами
   * @param key - ключ disabled чипа
   */
  disabledItems: PropTypes.arrayOf(PropTypes.string),
  /**
   * Список чипов. Массив объектов
   * @param key - ключ чипа
   * @param label - текст для кнопки чипа
   * @param items - массив сортируемых элементов
   */
  items: PropTypes.arrayOf(
    PropTypes.shape({
      contentItems: PropTypes.arrayOf(PropTypes.element).isRequired,
      key: PropTypes.string.isRequired,
      label: PropTypes.node,
    })
  ).isRequired,
  /**
   * Задает дополнительные props для контента
   */
  itemsContainerProps: PropTypes.any,
  /**
   * Callback функция, вызываемая при изменении значения
   */
  onChange: PropTypes.func,
  /**
   * Список выбранных чипов. Массив с ключами. Используется для управляемых компонентов
   * Не используется вместе с defaultSelectedChips
   * @param key - ключ selected чипа
   */
  selectedItems: PropTypes.arrayOf(PropTypes.string),
  /**
   * Задает размер
   *  @default m
   */
  size: PropTypes.oneOf(['m']),
  /**
   * Задает внешний вид
   *  @default primary
   */
  variant: PropTypes.oneOf(['primary', 'secondary']),
};

ChipGroup.displayName = 'ChipGroup';
exports['default'] = ChipGroup;
