import React from 'react';
import { ChipSizesType, ChipViewsType } from '../constants';
export type ChipType = {
    key: string;
    label: React.ReactNode;
    contentItems: React.ReactElement[];
};
export interface IChipGroup extends Omit<React.HTMLAttributes<HTMLDivElement>, 'onChange'> {
    /** Задает внешний вид
     *  @default primary */
    variant?: ChipViewsType;
    /** Задает размер
     *  @default m */
    size?: ChipSizesType;
    /** Добавляет общий чип
     *  @default false */
    chipTotal?: boolean;
    /** Добавляет текст для общего чипа */
    chipTotalLabel?: string;
    /** Список чипов. Массив объектов
     * @param key - ключ чипа
     * @param label - текст для кнопки чипа
     * @param items - массив сортируемых элементов
     */
    items: ChipType[];
    /** Список выбранных чипов. Массив с ключами. Используется для управляемых компонентов
     * Не используется вместе с defaultSelectedChips
     * @param key - ключ selected чипа
     */
    selectedItems?: string[];
    /** Список выбранных чипов по умолчанию. Массив с ключами. Используется для неуправляемых компонентов
     * Не используется вместе с selectedChips
     * @param key - ключ selected чипа
     */
    defaultSelectedItems?: string[];
    /** Callback функция, вызываемая при изменении значения */
    onChange?: (key: string) => void;
    /** Список disabled чипов. Массив с ключами
     * @param key - ключ disabled чипа
     */
    disabledItems?: string[];
    /** Задает дополнительные props для контента */
    itemsContainerProps?: any;
}
