import React from 'react';
import '../../../styles/components/chip.scss';
import { IChip } from './types';
declare const Chip: React.FC<IChip>;
export default Chip;
