import React from 'react';
import { ChipSizesType, ChipViewsType } from '../constants';
export interface IChip extends Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, 'children'> {
    /** Задаёт текст */
    label?: React.ReactNode;
    /** Задает внешний вид
     *  @default primary */
    variant?: ChipViewsType;
    /** Задает размер
     *  @default m */
    size?: ChipSizesType;
    /** Задает значение счетчика */
    counter?: number;
    /** Добавляет иконку */
    icon?: React.ReactNode;
    /** Ярлык активного чипа, используется для управляемых компонентов
     * Не используется вместе с defaultSelected
     */
    selected?: boolean;
    /** Ярлык активного чипа по умолчанию, используется для неуправляемых компонентов
     * Не используется вместе с selected
     * @default false
     */
    defaultSelected?: boolean;
    /** Устанавливает атрибут disabled */
    disabled?: boolean;
}
