'use strict';
var PropTypes = require('prop-types');

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __createBinding =
  (this && this.__createBinding) ||
  (Object.create
    ? function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ('get' in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = {
            enumerable: true,
            get: function get() {
              return m[k];
            },
          };
        }
        Object.defineProperty(o, k2, desc);
      }
    : function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
      });
var __setModuleDefault =
  (this && this.__setModuleDefault) ||
  (Object.create
    ? function (o, v) {
        Object.defineProperty(o, 'default', {
          enumerable: true,
          value: v,
        });
      }
    : function (o, v) {
        o['default'] = v;
      });
var __importStar =
  (this && this.__importStar) ||
  function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null)
      for (var k in mod)
        if (k !== 'default' && Object.prototype.hasOwnProperty.call(mod, k))
          __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
  };
var __rest =
  (this && this.__rest) ||
  function (s, e) {
    var t = {};
    for (var p in s)
      if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === 'function')
      for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
          t[p[i]] = s[p[i]];
      }
    return t;
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importStar(require('react'));
var clsx_1 = __importDefault(require('clsx'));
require('../../../styles/components/chip.scss');
var constants_1 = require('../constants');
var Chip = function Chip(props) {
  var _a = props.variant,
    variant = _a === void 0 ? constants_1.CHIP_VARIANTS.primary : _a,
    counter = props.counter,
    label = props.label,
    _b = props.size,
    size = _b === void 0 ? constants_1.CHIP_SIZES.m : _b,
    selected = props.selected,
    _c = props.defaultSelected,
    defaultSelected = _c === void 0 ? false : _c,
    _d = props.disabled,
    disabled = _d === void 0 ? false : _d,
    icon = props.icon,
    className = props.className,
    _e = props.onClick,
    onClick = _e === void 0 ? function () {} : _e,
    restProps = __rest(props, [
      'variant',
      'counter',
      'label',
      'size',
      'selected',
      'defaultSelected',
      'disabled',
      'icon',
      'className',
      'onClick',
    ]);
  var _f = (0, react_1.useState)(defaultSelected),
    isSelected = _f[0],
    setIsSelected = _f[1];
  var clickHandler = (0, react_1.useCallback)(
    function (evt) {
      if (selected === undefined) {
        setIsSelected(function (prevIsSelected) {
          return !prevIsSelected;
        });
      }
      onClick(evt);
    },
    [selected, onClick]
  );
  (0, react_1.useEffect)(
    function () {
      if (selected !== undefined && selected !== isSelected) {
        setIsSelected(selected);
      }
    },
    [isSelected, selected]
  );
  var rootClassName = (0, clsx_1['default'])(
    'chip',
    'chip--'.concat(variant),
    'chip--size-'.concat(size),
    isSelected && 'chip--selected',
    className
  );
  return react_1['default'].createElement(
    'button',
    __assign(
      {
        type: 'button',
        className: rootClassName,
        disabled: disabled,
        onClick: clickHandler,
      },
      restProps
    ),
    !!icon &&
      react_1['default'].createElement(
        'span',
        {
          className: 'chip__icon',
        },
        icon
      ),
    react_1['default'].createElement(
      'span',
      {
        className: 'chip__label',
      },
      label
    ),
    (counter || counter === 0) &&
      react_1['default'].createElement(
        'span',
        {
          className: 'chip__counter',
        },
        counter
      )
  );
};

Chip.propTypes = {
  className: PropTypes.string,
  /**
   * Задает значение счетчика
   */
  counter: PropTypes.number,
  /**
   * Ярлык активного чипа по умолчанию, используется для неуправляемых компонентов
   * Не используется вместе с selected
   * @default false
   */
  defaultSelected: PropTypes.bool,
  /**
   * Устанавливает атрибут disabled
   */
  disabled: PropTypes.bool,
  /**
   * Добавляет иконку
   */
  icon: PropTypes.node,
  /**
   * Задаёт текст
   */
  label: PropTypes.node,
  onClick: PropTypes.func,
  /**
   * Ярлык активного чипа, используется для управляемых компонентов
   * Не используется вместе с defaultSelected
   */
  selected: PropTypes.bool,
  /**
   * Задает размер
   *  @default m
   */
  size: PropTypes.oneOf(['m']),
  /**
   * Задает внешний вид
   *  @default primary
   */
  variant: PropTypes.oneOf(['primary', 'secondary']),
};

Chip.displayName = 'Chip';
exports['default'] = Chip;
