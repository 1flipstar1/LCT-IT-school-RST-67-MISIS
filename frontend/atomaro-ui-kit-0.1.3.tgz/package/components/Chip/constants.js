"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.DEFAULT_CHIP_TOTAL_LABEL = exports.CHIP_SIZES = exports.CHIP_VARIANTS = void 0;
var CHIP_VARIANTS;
(function (CHIP_VARIANTS) {
  CHIP_VARIANTS["primary"] = "primary";
  CHIP_VARIANTS["secondary"] = "secondary";
})(CHIP_VARIANTS = exports.CHIP_VARIANTS || (exports.CHIP_VARIANTS = {}));
var CHIP_SIZES;
(function (CHIP_SIZES) {
  CHIP_SIZES["m"] = "m";
})(CHIP_SIZES = exports.CHIP_SIZES || (exports.CHIP_SIZES = {}));
exports.DEFAULT_CHIP_TOTAL_LABEL = 'Все';