import { FC } from 'react';
import '../../../styles/components/functionButton.scss';
import { IFunctionButtonProps } from './types';
declare const FunctionButton: FC<IFunctionButtonProps>;
export default FunctionButton;
