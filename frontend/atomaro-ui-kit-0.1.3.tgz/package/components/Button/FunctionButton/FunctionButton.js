'use strict';
var PropTypes = require('prop-types');

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __rest =
  (this && this.__rest) ||
  function (s, e) {
    var t = {};
    for (var p in s)
      if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === 'function')
      for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
          t[p[i]] = s[p[i]];
      }
    return t;
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var clsx_1 = __importDefault(require('clsx'));
require('../../../styles/components/functionButton.scss');
var components_1 = require('../../../constants/components');
var constants_1 = require('./constants');
var FunctionButton = function FunctionButton(props) {
  var _a = props.variant,
    variant = _a === void 0 ? constants_1.DEFAULT_VARIANT : _a,
    _b = props.size,
    size = _b === void 0 ? constants_1.DEFAULT_SIZE : _b,
    icon = props.icon,
    _c = props.iconPosition,
    iconPosition = _c === void 0 ? components_1.ICON_POSITIONS.right : _c,
    label = props.label,
    disabled = props.disabled,
    className = props.className,
    restProps = __rest(props, [
      'variant',
      'size',
      'icon',
      'iconPosition',
      'label',
      'disabled',
      'className',
    ]);
  var renderText = function renderText() {
    if (iconPosition === components_1.ICON_POSITIONS.left) {
      return react_1['default'].createElement(
        react_1['default'].Fragment,
        null,
        icon,
        label &&
          react_1['default'].createElement(
            'span',
            {
              className: 'functionbutton__label',
            },
            label
          )
      );
    }
    return react_1['default'].createElement(
      react_1['default'].Fragment,
      null,
      label &&
        react_1['default'].createElement(
          'span',
          {
            className: 'functionbutton__label',
          },
          label
        ),
      icon
    );
  };
  var buttonText = renderText();
  var rootClassName = (0, clsx_1['default'])(
    'functionbutton',
    'functionbutton--'.concat(constants_1.FUNCTION_BUTTON_VARIANTS[variant]),
    'functionbutton--size-'.concat(constants_1.FUNCTION_BUTTON_SIZES[size]),
    'functionbutton--icon-position-'.concat(iconPosition),
    className
  );
  return react_1['default'].createElement(
    'button',
    __assign(
      {
        type: 'button',
        disabled: disabled,
        className: rootClassName,
      },
      restProps
    ),
    buttonText
  );
};

FunctionButton.propTypes = {
  className: PropTypes.string,
  /**
   * Устанавливает атрибут disabled
   */
  disabled: PropTypes.bool,
  /**
   * Задаёт иконку
   */
  icon: PropTypes.node,
  /**
   * Задает расположение иконки относительно текста
   *  @default left
   */
  iconPosition: PropTypes.oneOf(['left', 'right']),
  /**
   * Задаёт текст
   */
  label: PropTypes.node,
  /**
   * Задает размер
   *  @default s
   */
  size: PropTypes.oneOf(['s']),
  /**
   * Задает внешний вид
   *  @default primary
   */
  variant: PropTypes.oneOf(['primary', 'secondary', 'tertiary']),
};

FunctionButton.displayName = 'FunctionButton';
exports['default'] = FunctionButton;
