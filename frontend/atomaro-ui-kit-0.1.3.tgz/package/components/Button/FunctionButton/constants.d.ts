export declare enum FUNCTION_BUTTON_SIZES {
    s = "s"
}
export declare enum FUNCTION_BUTTON_VARIANTS {
    primary = "primary",
    secondary = "secondary",
    tertiary = "tertiary"
}
export type FunctionButtonSizesType = keyof typeof FUNCTION_BUTTON_SIZES;
export type FunctionButtonVariantsType = keyof typeof FUNCTION_BUTTON_VARIANTS;
export declare const DEFAULT_SIZE = FUNCTION_BUTTON_SIZES.s;
export declare const DEFAULT_VARIANT = FUNCTION_BUTTON_VARIANTS.primary;
