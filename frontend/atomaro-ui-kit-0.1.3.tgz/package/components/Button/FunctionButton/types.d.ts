import React from 'react';
import { IconPositionsType } from '../../../types/base';
import { FunctionButtonSizesType, FunctionButtonVariantsType } from './constants';
export interface IFunctionButtonProps extends Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, 'children'> {
    /** Задает внешний вид
     *  @default primary */
    variant?: FunctionButtonVariantsType;
    /** Задает размер
     *  @default s */
    size?: FunctionButtonSizesType;
    /** Задаёт иконку */
    icon?: React.ReactNode;
    /** Задает расположение иконки относительно текста
     *  @default left */
    iconPosition?: IconPositionsType;
    /** Устанавливает атрибут disabled */
    disabled?: boolean;
    /** Задаёт текст */
    label?: React.ReactNode;
}
