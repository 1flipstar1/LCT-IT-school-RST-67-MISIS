import React from 'react';
import { SizesType } from '../../../types/base';
import { iconButtonColorSchemes, iconButtonVariants } from './constants';
export interface IIconButtonProps extends Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, 'children'> {
    /** Задает размер
     *  @default m */
    size?: SizesType;
    /** Задает внешний вид
     *  @default primary */
    variant?: iconButtonVariants;
    /** Задает внешний вид
     *  @default accent */
    colorScheme?: iconButtonColorSchemes;
    /** Иконка для кнопки */
    icon: React.ReactNode;
    /** Устанавливает атрибут disabled */
    disabled?: boolean;
}
