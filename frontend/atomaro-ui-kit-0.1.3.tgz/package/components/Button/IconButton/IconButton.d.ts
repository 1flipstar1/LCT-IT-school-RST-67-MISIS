import { FC } from 'react';
import '../../../styles/components/iconButton.scss';
import { IIconButtonProps } from './types';
declare const IconButton: FC<IIconButtonProps>;
export default IconButton;
