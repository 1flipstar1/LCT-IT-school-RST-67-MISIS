'use strict';
var PropTypes = require('prop-types');

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __rest =
  (this && this.__rest) ||
  function (s, e) {
    var t = {};
    for (var p in s)
      if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === 'function')
      for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
          t[p[i]] = s[p[i]];
      }
    return t;
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var clsx_1 = __importDefault(require('clsx'));
require('../../../styles/components/iconButton.scss');
var components_1 = require('../../../constants/components');
var IconButton = function IconButton(props) {
  var _a = props.size,
    size = _a === void 0 ? components_1.SIZES.m : _a,
    _b = props.variant,
    variant = _b === void 0 ? components_1.BUTTON_VIEWS.primary : _b,
    _c = props.colorScheme,
    colorScheme = _c === void 0 ? components_1.COLORSCHEME.accent : _c,
    icon = props.icon,
    className = props.className,
    disabled = props.disabled,
    restProps = __rest(props, ['size', 'variant', 'colorScheme', 'icon', 'className', 'disabled']);
  var rootClassName = (0, clsx_1['default'])(
    'icon-button',
    'icon-button--'
      .concat(components_1.BUTTON_VIEWS[variant], '-')
      .concat(components_1.COLORSCHEME[colorScheme]),
    'icon-button--size-'.concat(components_1.SIZES[size]),
    className
  );
  return react_1['default'].createElement(
    'button',
    __assign(
      {
        className: rootClassName,
        disabled: disabled,
        type: 'button',
      },
      restProps
    ),
    icon
  );
};

IconButton.propTypes = {
  className: PropTypes.string,
  /**
   * Задает внешний вид
   *  @default accent
   */
  colorScheme: PropTypes.oneOf(['accent', 'neutral']),
  /**
   * Устанавливает атрибут disabled
   */
  disabled: PropTypes.bool,
  /**
   * Иконка для кнопки
   */
  icon: PropTypes.node,
  /**
   * Задает размер
   *  @default m
   */
  size: PropTypes.oneOf(['l', 'm', 's', 'xl']),
  /**
   * Задает внешний вид
   *  @default primary
   */
  variant: PropTypes.oneOf(['ghost', 'outline', 'primary', 'secondary']),
};

IconButton.displayName = 'IconButton';
exports['default'] = IconButton;
