import { COLORSCHEME, VARIANT } from '../../../constants/components';
export type iconButtonVariants = keyof typeof VARIANT;
export type iconButtonColorSchemes = keyof typeof COLORSCHEME;
