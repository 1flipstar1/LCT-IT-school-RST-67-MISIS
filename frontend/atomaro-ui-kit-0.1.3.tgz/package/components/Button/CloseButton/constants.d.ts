export declare enum CLOSE_BUTTON_SIZES {
    '2xs' = "2xs",
    xs = "xs",
    s = "s",
    m = "m",
    l = "l"
}
export declare enum CLOSE_BUTTON_VARIANTS {
    primary = "primary"
}
export type CloseButtonVariants = keyof typeof CLOSE_BUTTON_VARIANTS;
export type CloseButtonSizes = keyof typeof CLOSE_BUTTON_SIZES;
