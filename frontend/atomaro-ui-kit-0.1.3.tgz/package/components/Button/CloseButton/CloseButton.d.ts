import React from 'react';
import '../../../styles/components/closebutton.scss';
import { ICloseButtonProps } from './types';
declare const CloseButton: React.FC<ICloseButtonProps>;
export default CloseButton;
