"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.CLOSE_BUTTON_VARIANTS = exports.CLOSE_BUTTON_SIZES = void 0;
var CLOSE_BUTTON_SIZES;
(function (CLOSE_BUTTON_SIZES) {
  CLOSE_BUTTON_SIZES["2xs"] = "2xs";
  CLOSE_BUTTON_SIZES["xs"] = "xs";
  CLOSE_BUTTON_SIZES["s"] = "s";
  CLOSE_BUTTON_SIZES["m"] = "m";
  CLOSE_BUTTON_SIZES["l"] = "l";
})(CLOSE_BUTTON_SIZES = exports.CLOSE_BUTTON_SIZES || (exports.CLOSE_BUTTON_SIZES = {}));
var CLOSE_BUTTON_VARIANTS;
(function (CLOSE_BUTTON_VARIANTS) {
  CLOSE_BUTTON_VARIANTS["primary"] = "primary";
})(CLOSE_BUTTON_VARIANTS = exports.CLOSE_BUTTON_VARIANTS || (exports.CLOSE_BUTTON_VARIANTS = {}));