import React from 'react';
import { CloseButtonSizes, CloseButtonVariants } from './constants';
export interface ICloseButtonProps extends Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, 'children'> {
    /** Задает размер
     *  @default m */
    size?: CloseButtonSizes;
    /** Задает скругление, значение по умолчанию берется из темы */
    variant?: CloseButtonVariants;
}
