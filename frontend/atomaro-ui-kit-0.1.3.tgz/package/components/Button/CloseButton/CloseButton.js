'use strict';
var PropTypes = require('prop-types');

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __rest =
  (this && this.__rest) ||
  function (s, e) {
    var t = {};
    for (var p in s)
      if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === 'function')
      for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
          t[p[i]] = s[p[i]];
      }
    return t;
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
/* eslint-disable import/no-extraneous-dependencies */
var react_1 = __importDefault(require('react'));
var clsx_1 = __importDefault(require('clsx'));
require('../../../styles/components/closebutton.scss');
var navigation_1 = require('@atomaro/icons/16/navigation');
var navigation_2 = require('@atomaro/icons/24/navigation');
var CloseLarge_1 = __importDefault(require('@atomaro/icons/24/navigation/CloseLarge'));
var constants_1 = require('./constants');
var noop_1 = require('../../../utils/noop');
var CloseButton = function CloseButton(props) {
  var _a = props.variant,
    variant = _a === void 0 ? constants_1.CLOSE_BUTTON_VARIANTS.primary : _a,
    _b = props.size,
    size = _b === void 0 ? constants_1.CLOSE_BUTTON_SIZES.m : _b,
    _c = props.onClick,
    onClick = _c === void 0 ? noop_1.noop : _c,
    className = props.className,
    restProps = __rest(props, ['variant', 'size', 'onClick', 'className']);
  var rootClassName = (0, clsx_1['default'])(
    'closebutton',
    'closebutton--'.concat(constants_1.CLOSE_BUTTON_VARIANTS[variant]),
    'closebutton--size-'.concat(constants_1.CLOSE_BUTTON_SIZES[size]),
    className
  );
  var generateIcon = function generateIcon() {
    switch (size) {
      case '2xs':
        return react_1['default'].createElement(navigation_1.CloseSmall16, null);
      case 'xs':
        return react_1['default'].createElement(navigation_1.CloseSmall16, null);
      case 's':
        return react_1['default'].createElement(navigation_2.CloseSmall, null);
      case 'm':
        return react_1['default'].createElement(CloseLarge_1['default'], null);
      case 'l':
        return react_1['default'].createElement(CloseLarge_1['default'], null);
      default:
        return react_1['default'].createElement(CloseLarge_1['default'], null);
    }
  };
  return react_1['default'].createElement(
    'button',
    __assign(
      {
        type: 'button',
        onClick: onClick,
        className: rootClassName,
      },
      restProps
    ),
    generateIcon()
  );
};

CloseButton.propTypes = {
  className: PropTypes.string,
  onClick: PropTypes.func,
  /**
   * Задает размер
   *  @default m
   */
  size: PropTypes.oneOf(['2xs', 'l', 'm', 's', 'xs']),
  /**
   * Задает скругление, значение по умолчанию берется из темы
   */
  variant: PropTypes.oneOf(['primary']),
};

CloseButton.displayName = 'CloseButton';
exports['default'] = CloseButton;
