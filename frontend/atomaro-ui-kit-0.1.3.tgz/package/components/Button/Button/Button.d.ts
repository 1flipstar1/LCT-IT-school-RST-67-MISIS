import { FC } from 'react';
import '../../../styles/components/button.scss';
import { IButtonProps } from './types';
declare const Button: FC<IButtonProps>;
export default Button;
