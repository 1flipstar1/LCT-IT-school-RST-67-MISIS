import { COLORSCHEME, VARIANT } from '../../../constants/components';
export type ButtonVariantsType = keyof typeof VARIANT;
export type ButtonColorSchemesType = keyof typeof COLORSCHEME;
