'use strict';
var PropTypes = require('prop-types');

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __rest =
  (this && this.__rest) ||
  function (s, e) {
    var t = {};
    for (var p in s)
      if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === 'function')
      for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
          t[p[i]] = s[p[i]];
      }
    return t;
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var clsx_1 = __importDefault(require('clsx'));
require('../../../styles/components/button.scss');
var components_1 = require('../../../constants/components');
var Button = function Button(props) {
  var _a = props.size,
    size = _a === void 0 ? components_1.SIZES.m : _a,
    _b = props.variant,
    variant = _b === void 0 ? components_1.VARIANT.primary : _b,
    _c = props.colorScheme,
    colorScheme = _c === void 0 ? components_1.COLORSCHEME.accent : _c,
    iconPrefix = props.iconPrefix,
    iconSuffix = props.iconSuffix,
    label = props.label,
    _d = props.disabled,
    disabled = _d === void 0 ? false : _d,
    _e = props.id,
    id = _e === void 0 ? 'button' : _e,
    className = props.className,
    restProps = __rest(props, [
      'size',
      'variant',
      'colorScheme',
      'iconPrefix',
      'iconSuffix',
      'label',
      'disabled',
      'id',
      'className',
    ]);
  var rootClassName = (0, clsx_1['default'])(
    'button',
    'button--'.concat(components_1.VARIANT[variant]),
    'button--'.concat(components_1.COLORSCHEME[colorScheme]),
    'button--size-'.concat(components_1.SIZES[size]),
    className
  );
  return react_1['default'].createElement(
    'button',
    __assign(
      {
        className: rootClassName,
        disabled: disabled,
        type: 'button',
        id: id,
      },
      restProps
    ),
    iconPrefix && iconPrefix,
    label &&
      react_1['default'].createElement(
        'span',
        {
          className: 'button__label',
        },
        label
      ),
    iconSuffix && iconSuffix
  );
};

Button.propTypes = {
  className: PropTypes.string,
  /**
   * Задает внешний вид
   *  @default primary
   */
  colorScheme: PropTypes.oneOf(['accent', 'neutral']),
  /**
   * Устанавливает атрибут disabled
   */
  disabled: PropTypes.bool,
  /**
   * Иконка для кнопки слева
   */
  iconPrefix: PropTypes.node,
  /**
   * Иконка для кнопки справа
   */
  iconSuffix: PropTypes.node,
  id: PropTypes.string,
  label: PropTypes.node,
  /**
   * Задает размер
   *  @default m
   */
  size: PropTypes.oneOf(['l', 'm', 's', 'xl']),
  /**
   * Задает скругление, значение по умолчанию берется из темы
   */
  variant: PropTypes.oneOf(['ghost', 'outline', 'primary', 'secondary']),
};

Button.displayName = 'Button';
exports['default'] = Button;
