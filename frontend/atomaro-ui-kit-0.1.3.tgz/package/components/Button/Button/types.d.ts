import React from 'react';
import { SizesType } from '../../../types/base';
import { ButtonColorSchemesType, ButtonVariantsType } from './constants';
export interface IButtonProps extends Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, 'children'> {
    /** Задает размер
     *  @default m */
    size?: SizesType;
    /** Задает скругление, значение по умолчанию берется из темы */
    variant?: ButtonVariantsType;
    /** Задает внешний вид
     *  @default primary */
    colorScheme?: ButtonColorSchemesType;
    /** Иконка для кнопки слева */
    iconPrefix?: React.ReactNode;
    /** Иконка для кнопки справа */
    iconSuffix?: React.ReactNode;
    label?: React.ReactNode;
    /** Устанавливает атрибут disabled */
    disabled?: boolean;
}
