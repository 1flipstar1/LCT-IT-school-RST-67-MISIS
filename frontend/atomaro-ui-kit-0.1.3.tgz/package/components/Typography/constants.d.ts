export declare enum TYPOGRAPHY_VARIANTS {
    'display-s' = "display-s",
    'display-m' = "display-m",
    'display-l' = "display-l",
    'heading-h1' = "heading-h1",
    'heading-h2' = "heading-h2",
    'heading-h3' = "heading-h3",
    'heading-h4' = "heading-h4",
    'heading-h5' = "heading-h5",
    'body-s' = "body-s",
    'body-m' = "body-m",
    'body-l' = "body-l",
    'description-s' = "description-s",
    'description-m' = "description-m",
    'description-l' = "description-l",
    'caption' = "caption"
}
export type TypographyVariantsType = keyof typeof TYPOGRAPHY_VARIANTS;
export declare const DEFAULT_TYPOGRAPHY_VARIANT = TYPOGRAPHY_VARIANTS['display-s'];
