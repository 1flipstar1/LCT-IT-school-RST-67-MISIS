"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.DEFAULT_TYPOGRAPHY_VARIANT = exports.TYPOGRAPHY_VARIANTS = void 0;
var TYPOGRAPHY_VARIANTS;
(function (TYPOGRAPHY_VARIANTS) {
  TYPOGRAPHY_VARIANTS["display-s"] = "display-s";
  TYPOGRAPHY_VARIANTS["display-m"] = "display-m";
  TYPOGRAPHY_VARIANTS["display-l"] = "display-l";
  TYPOGRAPHY_VARIANTS["heading-h1"] = "heading-h1";
  TYPOGRAPHY_VARIANTS["heading-h2"] = "heading-h2";
  TYPOGRAPHY_VARIANTS["heading-h3"] = "heading-h3";
  TYPOGRAPHY_VARIANTS["heading-h4"] = "heading-h4";
  TYPOGRAPHY_VARIANTS["heading-h5"] = "heading-h5";
  TYPOGRAPHY_VARIANTS["body-s"] = "body-s";
  TYPOGRAPHY_VARIANTS["body-m"] = "body-m";
  TYPOGRAPHY_VARIANTS["body-l"] = "body-l";
  TYPOGRAPHY_VARIANTS["description-s"] = "description-s";
  TYPOGRAPHY_VARIANTS["description-m"] = "description-m";
  TYPOGRAPHY_VARIANTS["description-l"] = "description-l";
  TYPOGRAPHY_VARIANTS["caption"] = "caption";
})(TYPOGRAPHY_VARIANTS = exports.TYPOGRAPHY_VARIANTS || (exports.TYPOGRAPHY_VARIANTS = {}));
exports.DEFAULT_TYPOGRAPHY_VARIANT = TYPOGRAPHY_VARIANTS['display-s'];