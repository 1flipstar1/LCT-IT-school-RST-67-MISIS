import { FC } from 'react';
import { ITypographyProps } from './types';
import '../../styles/components/typography.scss';
declare const Typography: FC<ITypographyProps>;
export default Typography;
