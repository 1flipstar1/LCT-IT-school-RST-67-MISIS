import { ElementType, CSSProperties, HTMLAttributes } from 'react';
import { TypographyVariantsType } from './constants';
export interface ITypographyProps extends HTMLAttributes<HTMLParagraphElement> {
    /** Задает вариант типографики
     * @default display-s */
    variant?: TypographyVariantsType;
    /** Задает дополнительные классы для компонента */
    className?: string;
    /** Задает дополнительные стили для компонента */
    style?: CSSProperties;
    /** Задает тег для типографики (React.ElementType)
     *  @default "p" */
    as?: ElementType;
    /** Задает жирность шрифту по умолчанию false */
    strong?: boolean;
    /** В значении false - типографика адаптивна. В значении true - статична, используется desktop вариант
     *  @default false */
    isStatic?: boolean;
}
