import { SYSTEM_COLORS } from '../../constants/components';
export declare enum BADGE_SIZES {
    '2xs' = "2xs",
    s = "s"
}
export declare enum BADGE_VARIANTS {
    primary = "primary",
    secondary = "secondary"
}
export declare enum BADGE_COLORSCHEME {
    neutral = "neutral",
    'status-01' = "status-01",
    'status-02' = "status-02",
    'status-03' = "status-03",
    'status-04' = "status-04",
    'status-05' = "status-05",
    'status-06' = "status-06"
}
export type BadgeSizeType = keyof typeof BADGE_SIZES;
export type BadgeVariantType = keyof typeof BADGE_VARIANTS;
export type BadgeColorSchemeType = keyof typeof BADGE_COLORSCHEME;
export declare const DEFAULT_BADGE_VARIANT = BADGE_VARIANTS.primary;
export declare const DEFAULT_BADGE_SIZE = BADGE_SIZES['2xs'];
export declare const DEFAULT_BADGE_COLORSCHEME = SYSTEM_COLORS.info;
