"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.DEFAULT_BADGE_COLORSCHEME = exports.DEFAULT_BADGE_SIZE = exports.DEFAULT_BADGE_VARIANT = exports.BADGE_COLORSCHEME = exports.BADGE_VARIANTS = exports.BADGE_SIZES = void 0;
var components_1 = require("../../constants/components");
var BADGE_SIZES;
(function (BADGE_SIZES) {
  BADGE_SIZES["2xs"] = "2xs";
  BADGE_SIZES["s"] = "s";
})(BADGE_SIZES = exports.BADGE_SIZES || (exports.BADGE_SIZES = {}));
var BADGE_VARIANTS;
(function (BADGE_VARIANTS) {
  BADGE_VARIANTS["primary"] = "primary";
  BADGE_VARIANTS["secondary"] = "secondary";
})(BADGE_VARIANTS = exports.BADGE_VARIANTS || (exports.BADGE_VARIANTS = {}));
var BADGE_COLORSCHEME;
(function (BADGE_COLORSCHEME) {
  BADGE_COLORSCHEME["neutral"] = "neutral";
  BADGE_COLORSCHEME["status-01"] = "status-01";
  BADGE_COLORSCHEME["status-02"] = "status-02";
  BADGE_COLORSCHEME["status-03"] = "status-03";
  BADGE_COLORSCHEME["status-04"] = "status-04";
  BADGE_COLORSCHEME["status-05"] = "status-05";
  BADGE_COLORSCHEME["status-06"] = "status-06";
})(BADGE_COLORSCHEME = exports.BADGE_COLORSCHEME || (exports.BADGE_COLORSCHEME = {}));
exports.DEFAULT_BADGE_VARIANT = BADGE_VARIANTS.primary;
exports.DEFAULT_BADGE_SIZE = BADGE_SIZES['2xs'];
exports.DEFAULT_BADGE_COLORSCHEME = components_1.SYSTEM_COLORS.info;