import React from 'react';
import { SystemColorsType } from '../../types/base';
import { BadgeColorSchemeType, BadgeSizeType, BadgeVariantType } from './constants';
export interface IBadgeProps extends React.HTMLAttributes<HTMLDivElement> {
    /** Задаёт текст для компонента */
    label?: React.ReactNode;
    /** Задает внешний вид
     *  @default info */
    colorScheme?: SystemColorsType | BadgeColorSchemeType;
    /** Задает  размер
     * @default 2xs
     */
    size?: BadgeSizeType;
    /** Задает внешний вид
     *  @default primary */
    variant?: BadgeVariantType;
}
