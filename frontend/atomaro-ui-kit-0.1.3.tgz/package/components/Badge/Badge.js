'use strict';
var PropTypes = require('prop-types');

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __rest =
  (this && this.__rest) ||
  function (s, e) {
    var t = {};
    for (var p in s)
      if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === 'function')
      for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
          t[p[i]] = s[p[i]];
      }
    return t;
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var clsx_1 = __importDefault(require('clsx'));
require('../../styles/components/badge.scss');
var constants_1 = require('./constants');
var Badge = function Badge(props) {
  var label = props.label,
    _a = props.variant,
    variant = _a === void 0 ? constants_1.DEFAULT_BADGE_VARIANT : _a,
    _b = props.size,
    size = _b === void 0 ? constants_1.DEFAULT_BADGE_SIZE : _b,
    _c = props.colorScheme,
    colorScheme = _c === void 0 ? constants_1.DEFAULT_BADGE_COLORSCHEME : _c,
    className = props.className,
    restProps = __rest(props, ['label', 'variant', 'size', 'colorScheme', 'className']);
  var rootClassName = (0, clsx_1['default'])(
    'badge',
    'badge--size-'.concat(size),
    'badge--'.concat(variant),
    'badge--'.concat(colorScheme),
    className
  );
  return react_1['default'].createElement(
    'div',
    __assign(
      {
        className: rootClassName,
      },
      restProps
    ),
    react_1['default'].createElement(
      'div',
      {
        className: 'badge__text',
      },
      label
    )
  );
};

Badge.propTypes = {
  className: PropTypes.string,
  /**
   * Задает внешний вид
   *  @default info
   */
  colorScheme: PropTypes.oneOf([
    'error',
    'info',
    'neutral',
    'status-01',
    'status-02',
    'status-03',
    'status-04',
    'status-05',
    'status-06',
    'success',
    'warning',
  ]),
  /**
   * Задаёт текст для компонента
   */
  label: PropTypes.node,
  /**
   * Задает  размер
   * @default 2xs
   */
  size: PropTypes.oneOf(['2xs', 's']),
  /**
   * Задает внешний вид
   *  @default primary
   */
  variant: PropTypes.oneOf(['primary', 'secondary']),
};

Badge.displayName = 'Badge';
exports['default'] = Badge;
