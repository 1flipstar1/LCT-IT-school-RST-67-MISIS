import React from 'react';
import '../../styles/components/badge.scss';
import { IBadgeProps } from './types';
declare const Badge: React.FC<IBadgeProps>;
export default Badge;
