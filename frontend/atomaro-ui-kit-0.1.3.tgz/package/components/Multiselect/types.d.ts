import React from 'react';
import { IDropdownMenuItem } from '../DropdownMenu/types';
import { InputSizesType, InputVariantsType } from './constants';
import { DropDownMenuSizes } from '../DropdownMenu/constants';
import { PlacementsType } from '../../hooks/usePopper/types';
export interface IMultiselectProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'size' | 'onChange' | 'value' | 'defaultValue' | 'autoHeight'> {
    /** Задает label */
    label?: string;
    /** Скрывает label
     * @default false
     */
    hideLabel?: boolean;
    /** Задает основной цвет для чекбокса
     *  @default primary */
    variant?: InputVariantsType | string;
    /** Задает размер
     * @default medium
     */
    size?: InputSizesType | string;
    /** Задает placeholder */
    placeholder?: string;
    /** Задает список элементов для выбора
     * @default []
     * @param value - отображаемое значение
     * @param key - уникальный ключ в разрезе списка элементов
     * @param hint - дополнительная подпись
     * @param icon - иконка
     * @param disabled - задаёт состояние disabled для элемента
     * @param suffix - суффикс слот для элемента
     * @param isTitle - делает из элемента title
     * @param isDivider - делает из элемента divider
     */
    items?: IDropdownMenuItem[];
    /** Определяет, меняется ли высота контрола в зависимости от количества элементов
     *
     *  В значении true - появляется вторая строка с выбранными options
     *  @default false */
    autoHeight?: boolean;
    /** Отображает подсказку для заполнения поля */
    hint?: string;
    /** Задает значение компонента, используется для управляемых компонентов.
     *  Не используется вместе с defaultValue */
    value?: IDropdownMenuItem['key'] | IDropdownMenuItem[];
    /** Задает значение по умолчанию, для неуправляемых компонентов.
     *  Не используется вместе с value */
    defaultValue?: IDropdownMenuItem['key'] | IDropdownMenuItem[];
    /** Устанавливает атрибут required */
    required?: boolean;
    /** Устанавливает атрибут disabled */
    disabled?: boolean;
    /** Отображает ошибку заполнения поля */
    error?: string;
    /** Задаёт состояние open по умолчанию
     * @default false;
     */
    /** Задаёт счетчик */
    counter?: string;
    /** Раскрывает выпадающий список при первом рендере
     * @default false;
     */
    defaultOpen?: boolean;
    /** Задает конфиг для поиска
     * @param enabled - Включает фильтрацию опций по введённому значению в инпуте
     * @param onChange - Callback-функция, возвращает значение из инпута
     * @param filterOptions - Задаёт кастомную функцию фильтрации при поиске
     */
    autocomplete?: {
        enabled: boolean;
        onChange?: (value: string) => void;
        filterOptions?: (inputValue: string, options: IDropdownMenuItem[]) => IDropdownMenuItem[];
    };
    /** Задает элемент, отображающийся когда ничего не найдено
     * @default Не найдено
     */
    emptyText?: React.ReactNode;
    /** В значении true, при заполнении поля автокомплита, появится иконка для удаления введённого значения
     * @default false
     */
    clearable?: boolean;
    /** Callback функция, вызываемая при очищении поля */
    onClear?: (e: any) => void;
    /** Callback функция, вызываемая при изменении значения */
    onChange?: (value: IDropdownMenuItem[]) => void;
    /** Callback функция, вызываемая на фокус */
    onFocus?: () => void;
    /** Callback функция, вызываемая при потере фокуса */
    onBlur?: () => void;
    /** Определят размещение выпадающего списка */
    placement?: PlacementsType;
    /**  Соответствовать ширине родительского компонента (root-элемента)
     *  @default true */
    widthFitContent?: boolean;
    /** Задает иконку */
    icon?: React.ReactNode;
    /** Задаёт вариант использования с React Portal
     * @default false */
    useInPortal?: boolean;
    /** Задает размер дропдауна
     * @default medium
     */
    dropdownSize?: DropDownMenuSizes;
    /** Задает дополнительные классы для выпадающего меню */
    dropdownMenuClassName?: string;
    /** Задает дополнительные стли для выпадающего меню */
    dropdownMenuStyle?: React.CSSProperties;
    /** Устанавливает дополнительные классы для элемента */
    className?: string;
    /** Задает дополнительные стили для компонента */
    style?: React.CSSProperties;
    /** Включает виртуальный скролл */
    virtualScroll?: boolean;
    /** Определяет, скрывать ли выбранные значения в дропдауне
     *
     *  @default false */
    hideSelectedOptions?: boolean;
    /** Слот для контента в верхней части Dropdown Menu
     * @param close - функция для закрытия dropdown menu
     * @param selectedItems - массив выбранных элементов
     * @param dropdownItems - массив всех элементов
     */
    headerSlot?: (close: () => void, selectedItems: IDropdownMenuItem[], dropdownItems: IDropdownMenuItem[]) => React.ReactNode;
    /** Слот для контента в нижней части Dropdown Menu
     * @param close - функция для закрытия dropdown menu
     * @param selectedItems - массив выбранных элементов
     * @param dropdownItems - массив всех элементов
     */
    footerSlot?: (close: () => void, selectedItems: IDropdownMenuItem[], dropdownItems: IDropdownMenuItem[]) => React.ReactNode;
}
