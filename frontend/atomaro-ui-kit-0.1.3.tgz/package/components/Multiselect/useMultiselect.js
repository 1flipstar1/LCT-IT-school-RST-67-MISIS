'use strict';

var __spreadArray =
  (this && this.__spreadArray) ||
  function (to, from, pack) {
    if (pack || arguments.length === 2)
      for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
          if (!ar) ar = Array.prototype.slice.call(from, 0, i);
          ar[i] = from[i];
        }
      }
    return to.concat(ar || Array.prototype.slice.call(from));
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.useMultiselect = void 0;
var react_1 = require('react');
var function_1 = require('../../utils/function');
var constants_1 = require('./constants');
var useMultiselect = function useMultiselect(props) {
  var _a = props.value,
    inputValue = _a === void 0 ? [] : _a,
    _b = props.defaultValue,
    defaultValueProp = _b === void 0 ? [] : _b,
    _c = props.items,
    optionsProp = _c === void 0 ? [] : _c,
    _d = props.defaultOpen,
    defaultOpen = _d === void 0 ? false : _d,
    _e = props.onChange,
    onChange = _e === void 0 ? function_1.noop : _e,
    _f = props.autocomplete,
    autocomplete = _f === void 0 ? constants_1.DEFAULT_AUTOCOMPLETE : _f,
    disabled = props.disabled,
    _g = props.onClear,
    onClear = _g === void 0 ? function_1.noop : _g,
    _h = props.autoHeight,
    autoHeight = _h === void 0 ? false : _h,
    placeholder = props.placeholder,
    _j = props.onFocus,
    onFocus = _j === void 0 ? function_1.noop : _j,
    _k = props.onBlur,
    onBlur = _k === void 0 ? function_1.noop : _k;
  var _l = autocomplete.filterOptions,
    filterOptions = _l === void 0 ? constants_1.defaultFilterOptions : _l,
    autocompleteEnabled = autocomplete.enabled,
    autocompleteOnChange = autocomplete.onChange;
  var internalRef = (0, react_1.useRef)(null);
  var inputAutocompleteRef = (0, react_1.useRef)(null);
  var multiselectRef = (0, react_1.useRef)(null);
  var defaultValue;
  if (Array.isArray(defaultValueProp)) {
    defaultValue = defaultValueProp.length
      ? defaultValueProp.map(function (opt) {
          return opt.key;
        })
      : [];
  } else {
    defaultValue = [defaultValueProp];
  }
  var _m = (0, react_1.useState)(''),
    searchValue = _m[0],
    setSearchValue = _m[1];
  var _o = (0, react_1.useState)(optionsProp),
    options = _o[0],
    setOptions = _o[1];
  var _p = (0, react_1.useState)(defaultValue),
    selectedKeys = _p[0],
    setSelectedKeys = _p[1];
  var _q = (0, react_1.useState)([]),
    invalidOptions = _q[0],
    setInvalidOptions = _q[1];
  var _r = (0, react_1.useState)(optionsProp),
    dropdownItems = _r[0],
    setDropdownItems = _r[1];
  var _s = (0, react_1.useState)(defaultOpen),
    isMultiselectOpen = _s[0],
    setIsMultiselectOpen = _s[1];
  var _t = (0, react_1.useState)(false),
    multiselectIsFocus = _t[0],
    setMultiselectIsFocus = _t[1];
  var getSelectedOptions = function getSelectedOptions(opt, keys) {
    var o = [];
    var uniqueKeys = keys.filter(function (key, index, array) {
      return array.indexOf(key) === index;
    });
    opt.forEach(function (item) {
      if (uniqueKeys.includes(item.key)) {
        o[uniqueKeys.indexOf(item.key)] = item;
      }
    });
    return o.map(function (i) {
      return i;
    });
  };
  (0, react_1.useEffect)(
    function () {
      var uniqueOpt = new Set();
      options.forEach(function (item) {
        uniqueOpt.add(JSON.stringify(item));
      });
      optionsProp.forEach(function (item) {
        uniqueOpt.add(JSON.stringify(item));
      });
      var newOptions = Array.from(uniqueOpt).map(function (item) {
        return JSON.parse(item);
      });
      setOptions(newOptions);
      setDropdownItems(optionsProp);
      // eslint-disable-next-line react-hooks/exhaustive-deps
    },
    [JSON.stringify(optionsProp)]
  );
  (0, react_1.useEffect)(
    function () {
      if (Array.isArray(inputValue)) {
        var tmpSelectedKeys = inputValue.map(function (opt) {
          return opt.key;
        });
        setSelectedKeys(tmpSelectedKeys);
      } else {
        var tmpSelectedKeys = [inputValue];
        setSelectedKeys(tmpSelectedKeys);
      }
      // eslint-disable-next-line react-hooks/exhaustive-deps
    },
    [JSON.stringify(inputValue)]
  );
  var handleChangeSelectedKeys = function handleChangeSelectedKeys(keys) {
    setSelectedKeys(keys);
    onChange(getSelectedOptions(options, keys));
  };
  var removeOption = function removeOption(tag) {
    var tmpInvalidOptions = invalidOptions.filter(function (o) {
      return o.key !== tag;
    });
    setInvalidOptions(tmpInvalidOptions);
    var tmpSelectedKeysOptions = __spreadArray([], selectedKeys, true).filter(function (opt) {
      return opt !== tag;
    });
    setMultiselectIsFocus(false);
    onBlur();
    handleChangeSelectedKeys(tmpSelectedKeysOptions);
  };
  var clickOnMultiselect = function clickOnMultiselect(e) {
    var _a;
    e.preventDefault();
    if (!disabled) {
      if (!isMultiselectOpen) {
        setIsMultiselectOpen(true);
      }
      setMultiselectIsFocus(true);
      onFocus();
      if ((_a = inputAutocompleteRef.current) === null || _a === void 0 ? void 0 : _a.focus) {
        inputAutocompleteRef.current.focus();
      }
    }
  };
  var clickOnSchevron = function clickOnSchevron() {
    if (!disabled) {
      setIsMultiselectOpen(!isMultiselectOpen);
      setMultiselectIsFocus(!multiselectIsFocus);
    }
  };
  var onClickClearButton = function onClickClearButton(e) {
    e.stopPropagation();
    setSearchValue('');
    if (autocompleteOnChange) {
      autocompleteOnChange('');
    }
    setDropdownItems(optionsProp);
    onClear(e);
  };
  var onCloseDropDownMenu = function onCloseDropDownMenu() {
    setIsMultiselectOpen(false);
    setMultiselectIsFocus(false);
    onBlur();
  };
  var onSelect = function onSelect(valueProp) {
    var value = valueProp;
    setSearchValue('');
    if (autocompleteOnChange) {
      autocompleteOnChange('');
    }
    var key = value;
    options.forEach(function (o) {
      if (o.value === value) {
        key = o.key;
      }
    });
    var optionsKeys = options.map(function (o) {
      return o.key;
    });
    if (selectedKeys.includes(key)) {
      var newKeys = __spreadArray([], selectedKeys, true).filter(function (opt) {
        return opt !== key;
      });
      handleChangeSelectedKeys(newKeys);
    } else if (optionsKeys.includes(key)) {
      var newKeys = __spreadArray(__spreadArray([], selectedKeys, true), [key], false);
      handleChangeSelectedKeys(newKeys);
    } else {
      setInvalidOptions(
        __spreadArray(
          __spreadArray([], invalidOptions, true),
          [
            {
              value: key,
              key: ''.concat(key, '-').concat(invalidOptions.length),
              error: true,
            },
          ],
          false
        )
      );
    }
  };
  var onChangeDropdownMenu = function onChangeDropdownMenu(v) {
    handleChangeSelectedKeys(v);
  };
  var onChangeHandler = function onChangeHandler(e) {
    var value = e.target.value;
    setSearchValue(value);
    if (autocompleteOnChange) {
      autocompleteOnChange(value);
    }
    if (autocompleteEnabled && filterOptions) {
      setDropdownItems(filterOptions(value, options));
    }
    if (value.includes(',')) {
      if (value === ',') {
        setSearchValue('');
        if (autocompleteOnChange) {
          autocompleteOnChange('');
        }
        return;
      }
      var formattedValues = value
        .split(',')
        .filter(function (v) {
          return v;
        })
        .map(function (v) {
          return v.trim();
        });
      if (formattedValues.length > 1) {
        var invalidValues_1 = [];
        var keys = formattedValues
          .map(function (v) {
            var key = v;
            var optionsValues = options.map(function (o) {
              return o.value;
            });
            if (optionsValues.includes(v)) {
              key = options[optionsValues.indexOf(v)].key;
            } else {
              invalidValues_1.push({
                value: key,
                key: ''.concat(key, '-').concat(invalidOptions.length),
                error: true,
              });
              return null;
            }
            if (selectedKeys.includes(key)) {
              return null;
            }
            return key;
          })
          .filter(function (k) {
            return k !== null;
          });
        handleChangeSelectedKeys(__spreadArray(__spreadArray([], selectedKeys, true), keys, true));
        setInvalidOptions(
          __spreadArray(__spreadArray([], invalidOptions, true), invalidValues_1, true)
        );
      } else {
        onSelect(formattedValues[0]);
      }
      setSearchValue('');
      if (autocompleteOnChange) {
        autocompleteOnChange('');
      }
    }
  };
  var handleKeyPress = function handleKeyPress(e) {
    if (e.key === 'Enter' && searchValue) {
      onSelect(searchValue);
      setSearchValue('');
      if (autocompleteOnChange) {
        autocompleteOnChange('');
      }
      setDropdownItems(optionsProp);
    }
  };
  var selectedOptions = getSelectedOptions(options, selectedKeys);
  var tagsOptions = __spreadArray(__spreadArray([], selectedOptions, true), invalidOptions, true);
  var isAutoHeight = autoHeight && !!tagsOptions.length;
  var showAutocompleteInput =
    ((autocomplete === null || autocomplete === void 0 ? void 0 : autocomplete.enabled) &&
      tagsOptions.length === 0) ||
    (tagsOptions.length > 0 && multiselectIsFocus && isMultiselectOpen) ||
    !!placeholder;
  return {
    internalRef: internalRef,
    inputAutocompleteRef: inputAutocompleteRef,
    multiselectRef: multiselectRef,
    searchValue: searchValue,
    isMultiselectOpen: isMultiselectOpen,
    multiselectIsFocus: multiselectIsFocus,
    selectedOptions: selectedOptions,
    isAutoHeight: isAutoHeight,
    showAutocompleteInput: showAutocompleteInput,
    removeOption: removeOption,
    clickOnMultiselect: clickOnMultiselect,
    clickOnSchevron: clickOnSchevron,
    onChangeHandler: onChangeHandler,
    onCloseDropDownMenu: onCloseDropDownMenu,
    onSelect: onSelect,
    onChangeDropdownMenu: onChangeDropdownMenu,
    onClickClearButton: onClickClearButton,
    handleKeyPress: handleKeyPress,
    tagsOptions: tagsOptions,
    selectedKeys: selectedKeys,
    dropdownItems: dropdownItems,
  };
};
exports.useMultiselect = useMultiselect;
