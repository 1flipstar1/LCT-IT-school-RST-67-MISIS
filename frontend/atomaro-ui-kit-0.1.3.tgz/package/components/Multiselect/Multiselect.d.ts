import React from 'react';
import '../../styles/components/input.scss';
import '../../styles/components/dropdown.scss';
import { IMultiselectProps } from './types';
declare const Multiselect: React.ForwardRefExoticComponent<IMultiselectProps & React.RefAttributes<HTMLInputElement>>;
export default Multiselect;
