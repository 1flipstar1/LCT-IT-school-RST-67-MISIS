import { FC } from 'react';
import '../../../styles/components/multiselectTagsContainer.scss';
import { IDropdownMenuItem } from '../../DropdownMenu/types';
import { TAG_SIZES, TAG_VARIANTS } from '../../Tag/constants';
import { INPUT_SIZES } from '../constants';
interface ISelectedOptionsContainer {
    items: IDropdownMenuItem[];
    autoHeight: boolean;
    onRemove: (tag: string | number) => void;
    disabled: boolean;
    className?: string;
    autocompleteInputFocus?: boolean;
    size: TAG_SIZES;
    inputSize: INPUT_SIZES;
    variant: TAG_VARIANTS;
    inputVisible: boolean;
    inputRef: any;
    inputProps: any;
}
export declare const SelectedOptionsContainer: FC<ISelectedOptionsContainer>;
export {};
