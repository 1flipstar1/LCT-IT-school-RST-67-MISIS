'use strict';
var PropTypes = require('prop-types');

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __createBinding =
  (this && this.__createBinding) ||
  (Object.create
    ? function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ('get' in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = {
            enumerable: true,
            get: function get() {
              return m[k];
            },
          };
        }
        Object.defineProperty(o, k2, desc);
      }
    : function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
      });
var __setModuleDefault =
  (this && this.__setModuleDefault) ||
  (Object.create
    ? function (o, v) {
        Object.defineProperty(o, 'default', {
          enumerable: true,
          value: v,
        });
      }
    : function (o, v) {
        o['default'] = v;
      });
var __importStar =
  (this && this.__importStar) ||
  function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null)
      for (var k in mod)
        if (k !== 'default' && Object.prototype.hasOwnProperty.call(mod, k))
          __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.SelectedOptionsContainer = void 0;
var react_1 = __importStar(require('react'));
var clsx_1 = __importDefault(require('clsx'));
require('../../../styles/components/multiselectTagsContainer.scss');
var TagItem_1 = __importDefault(require('../../Tag/TagItem/TagItem'));
var noop_1 = require('../../../utils/noop');
var useCombinedRefs_1 = require('../../../hooks/useCombinedRefs');
var TagInput_1 = __importDefault(require('../../Tag/TagInput/TagInput'));
var SelectedOptionsContainer = function SelectedOptionsContainer(props) {
  var _a;
  var items = props.items,
    autoHeight = props.autoHeight,
    disabled = props.disabled,
    className = props.className,
    autocompleteInputFocus = props.autocompleteInputFocus,
    size = props.size,
    variant = props.variant,
    inputSize = props.inputSize,
    _b = props.onRemove,
    onRemove = _b === void 0 ? noop_1.noop : _b,
    inputVisible = props.inputVisible,
    _c = props.inputRef,
    inputRefProp = _c === void 0 ? null : _c,
    inputProps = props.inputProps;
  var inputRef = (0, react_1.useRef)(null);
  var combinedInputRef = (0, useCombinedRefs_1.useCombinedRefs)(inputRef, inputRefProp);
  var containerRef = (0, react_1.useRef)(null);
  var wrapperRef = (0, react_1.useRef)(null);
  var _d = (0, react_1.useState)(undefined),
    gradientSide = _d[0],
    setGradientSide = _d[1];
  var scrollHandler = function scrollHandler() {
    if (!autoHeight)
      if (containerRef.current.scrollWidth > containerRef.current.clientWidth) {
        if (
          containerRef.current.scrollLeft + containerRef.current.clientWidth >=
          containerRef.current.scrollWidth - 4
        ) {
          return 'left';
        }
        if (containerRef.current.scrollLeft <= 4) {
          return 'right';
        }
        return 'around';
      }
    return undefined;
  };
  (0, react_1.useEffect)(
    function () {
      var _a, _b, _c;
      if (
        !autoHeight &&
        ((_a = containerRef.current) === null || _a === void 0 ? void 0 : _a.scrollBy)
      ) {
        (_b = containerRef.current) === null || _b === void 0
          ? void 0
          : _b.scrollBy(
              (_c = containerRef.current) === null || _c === void 0 ? void 0 : _c.scrollWidth,
              0
            );
        scrollHandler();
      }
      // eslint-disable-next-line react-hooks/exhaustive-deps
    },
    [
      containerRef,
      (_a = containerRef.current) === null || _a === void 0 ? void 0 : _a.scrollWidth,
      items,
      autoHeight,
      autocompleteInputFocus,
    ]
  );
  var rootClassName = (0, clsx_1['default'])(
    'tags-container',
    'tags-container--gradient-side-'.concat(gradientSide),
    'tags-container--size-'.concat(inputSize),
    'tags-container--tagsize-'.concat(size),
    {
      'tags-container--autoHeight': autoHeight,
      'tags-container--disabled': !!disabled,
    },
    className
  );
  return react_1['default'].createElement(
    'div',
    {
      className: rootClassName,
    },
    react_1['default'].createElement(
      'div',
      {
        className: 'tags-container__innerContainer',
        ref: containerRef,
        onScroll: function onScroll() {
          return setGradientSide(scrollHandler());
        },
      },
      react_1['default'].createElement(
        'div',
        {
          className: 'tags-container__wrapper',
          ref: wrapperRef,
        },
        items.map(function (t) {
          return react_1['default'].createElement(
            TagItem_1['default'],
            {
              disabled: disabled || !!t.disabled,
              error: !!(t === null || t === void 0 ? void 0 : t.error),
              closable: true,
              onClose: function onClose(e) {
                e.stopPropagation();
                onRemove(t.key);
              },
              size: size,
              variant: variant,
              key: t.key,
            },
            t.value
          );
        }),
        inputVisible &&
          react_1['default'].createElement(
            TagInput_1['default'],
            __assign(
              {
                className: 'tags-container__taginput',
                ref: combinedInputRef,
                size: size,
                variant: variant,
              },
              inputProps
            )
          )
      )
    )
  );
};

SelectedOptionsContainer.propTypes = {
  autocompleteInputFocus: PropTypes.bool,
  autoHeight: PropTypes.bool.isRequired,
  className: PropTypes.string,
  disabled: PropTypes.bool.isRequired,
  inputProps: PropTypes.any.isRequired,
  inputRef: PropTypes.any.isRequired,
  inputSize: PropTypes.oneOf(['l', 'm', 's']).isRequired,
  inputVisible: PropTypes.bool.isRequired,
  items: PropTypes.arrayOf(
    PropTypes.shape({
      checkIcon: PropTypes.node,
      disabled: PropTypes.bool,
      error: PropTypes.bool,
      hint: PropTypes.string,
      isDivider: PropTypes.bool,
      isTitle: PropTypes.bool,
      key: PropTypes.oneOfType([PropTypes.number, PropTypes.string]).isRequired,
      prefix: PropTypes.func,
      suffix: PropTypes.func,
      value: PropTypes.node,
    })
  ).isRequired,
  onRemove: PropTypes.func.isRequired,
  size: PropTypes.oneOf(['m', 's', 'xs']).isRequired,
  variant: PropTypes.oneOf(['primary', 'secondary']).isRequired,
};

exports.SelectedOptionsContainer = SelectedOptionsContainer;
