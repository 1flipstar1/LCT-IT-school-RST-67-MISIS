'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.DEFAULT_AUTOCOMPLETE =
  exports.defaultFilterOptions =
  exports.INPUT_VARIANTS =
  exports.INPUT_SIZES =
    void 0;
var noop_1 = require('../../utils/noop');
var INPUT_SIZES;
(function (INPUT_SIZES) {
  INPUT_SIZES['s'] = 's';
  INPUT_SIZES['m'] = 'm';
  INPUT_SIZES['l'] = 'l';
})((INPUT_SIZES = exports.INPUT_SIZES || (exports.INPUT_SIZES = {})));
var INPUT_VARIANTS;
(function (INPUT_VARIANTS) {
  INPUT_VARIANTS['primary'] = 'primary';
})((INPUT_VARIANTS = exports.INPUT_VARIANTS || (exports.INPUT_VARIANTS = {})));
var defaultFilterOptions = function defaultFilterOptions(inputValue, options) {
  if (inputValue === void 0) {
    inputValue = '';
  }
  if (inputValue) {
    return options.filter(function (option) {
      return option.value.toLowerCase().indexOf(inputValue.toLowerCase()) > -1;
    });
  }
  return options;
};
exports.defaultFilterOptions = defaultFilterOptions;
exports.DEFAULT_AUTOCOMPLETE = {
  filterOptions: exports.defaultFilterOptions,
  enabled: false,
  onChange: noop_1.noop,
};
