'use strict';
var PropTypes = require('prop-types');

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __createBinding =
  (this && this.__createBinding) ||
  (Object.create
    ? function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ('get' in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = {
            enumerable: true,
            get: function get() {
              return m[k];
            },
          };
        }
        Object.defineProperty(o, k2, desc);
      }
    : function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
      });
var __setModuleDefault =
  (this && this.__setModuleDefault) ||
  (Object.create
    ? function (o, v) {
        Object.defineProperty(o, 'default', {
          enumerable: true,
          value: v,
        });
      }
    : function (o, v) {
        o['default'] = v;
      });
var __importStar =
  (this && this.__importStar) ||
  function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null)
      for (var k in mod)
        if (k !== 'default' && Object.prototype.hasOwnProperty.call(mod, k))
          __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
  };
var __rest =
  (this && this.__rest) ||
  function (s, e) {
    var t = {};
    for (var p in s)
      if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === 'function')
      for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
          t[p[i]] = s[p[i]];
      }
    return t;
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
/* eslint-disable jsx-a11y/no-static-element-interactions */
/* eslint-disable jsx-a11y/click-events-have-key-events */
var react_1 = __importStar(require('react'));
var clsx_1 = __importDefault(require('clsx'));
require('../../styles/components/input.scss');
require('../../styles/components/dropdown.scss');
var CheckLarge16_1 = __importDefault(require('@atomaro/icons/16/navigation/CheckLarge16'));
var ChevronDown_1 = __importDefault(require('@atomaro/icons/24/navigation/ChevronDown'));
var CloseSmall_1 = __importDefault(require('@atomaro/icons/24/navigation/CloseSmall'));
var constants_1 = require('../Tag/constants');
var constants_2 = require('./constants');
var DropdownMenu_1 = __importDefault(require('../DropdownMenu/DropdownMenu'));
var constants_3 = require('../DropdownMenu/constants');
var useCombinedRefs_1 = require('../../hooks/useCombinedRefs');
var noop_1 = require('../../utils/noop');
var useMultiselect_1 = require('./useMultiselect');
var getValueFromCssVariable_1 = require('../../utils/getValueFromCssVariable');
var function_1 = require('../../utils/function');
var SelectedOptionsContainer_1 = require('./SelectedOptionsContainer/SelectedOptionsContainer');
var Multiselect = (0, react_1.forwardRef)(function Select(props, ref) {
  var _a;
  var _b;
  var _c = props.variant,
    variant = _c === void 0 ? constants_2.INPUT_VARIANTS.primary : _c,
    _d = props.size,
    size = _d === void 0 ? constants_2.INPUT_SIZES.s : _d,
    labelProp = props.label,
    placeholder = props.placeholder,
    _e = props.disabled,
    disabled = _e === void 0 ? false : _e,
    hint = props.hint,
    counter = props.counter,
    error = props.error,
    _f = props.items,
    items = _f === void 0 ? [] : _f,
    value = props.value,
    defaultValue = props.defaultValue,
    _g = props.dropdownSize,
    dropdownSize = _g === void 0 ? constants_3.DEFAULT_DROPDOWN_MENU_SIZE : _g,
    _h = props.widthFitContent,
    widthFitContent = _h === void 0 ? true : _h,
    dropdownMenuClassName = props.dropdownMenuClassName,
    dropdownMenuStyle = props.dropdownMenuStyle,
    _j = props.onChange,
    onChange = _j === void 0 ? noop_1.noop : _j,
    autocomplete = props.autocomplete,
    emptyText = props.emptyText,
    className = props.className,
    _k = props.clearable,
    clearable = _k === void 0 ? false : _k,
    _l = props.virtualScroll,
    virtualScroll = _l === void 0 ? false : _l,
    _m = props.placement,
    placement = _m === void 0 ? 'bottom' : _m,
    _o = props.hideLabel,
    hideLabel = _o === void 0 ? false : _o,
    icon = props.icon,
    useInPortal = props.useInPortal,
    hideSelectedOptions = props.hideSelectedOptions,
    headerSlot = props.headerSlot,
    footerSlot = props.footerSlot,
    restProps = __rest(props, [
      'variant',
      'size',
      'label',
      'placeholder',
      'disabled',
      'hint',
      'counter',
      'error',
      'items',
      'value',
      'defaultValue',
      'dropdownSize',
      'widthFitContent',
      'dropdownMenuClassName',
      'dropdownMenuStyle',
      'onChange',
      'autocomplete',
      'emptyText',
      'className',
      'clearable',
      'virtualScroll',
      'placement',
      'hideLabel',
      'icon',
      'useInPortal',
      'hideSelectedOptions',
      'headerSlot',
      'footerSlot',
    ]);
  var label = hideLabel ? '' : labelProp;
  var _p = (0, useMultiselect_1.useMultiselect)(
      __assign(__assign({}, props), {
        onChange: onChange,
      })
    ),
    internalRef = _p.internalRef,
    inputAutocompleteRef = _p.inputAutocompleteRef,
    multiselectRef = _p.multiselectRef,
    searchValue = _p.searchValue,
    isMultiselectOpen = _p.isMultiselectOpen,
    multiselectIsFocus = _p.multiselectIsFocus,
    selectedKeys = _p.selectedKeys,
    isAutoHeight = _p.isAutoHeight,
    showAutocompleteInput = _p.showAutocompleteInput,
    removeOption = _p.removeOption,
    clickOnMultiselect = _p.clickOnMultiselect,
    clickOnSchevron = _p.clickOnSchevron,
    onChangeHandler = _p.onChangeHandler,
    onCloseDropDownMenu = _p.onCloseDropDownMenu,
    onClickClearButton = _p.onClickClearButton,
    handleKeyPress = _p.handleKeyPress,
    tagsOptions = _p.tagsOptions,
    onChangeDropdownMenu = _p.onChangeDropdownMenu,
    dropdownItems = _p.dropdownItems;
  var inputRef = (0, useCombinedRefs_1.useCombinedRefs)(ref, internalRef);
  var isClearable =
    clearable &&
    searchValue !== '' &&
    (autocomplete === null || autocomplete === void 0 ? void 0 : autocomplete.enabled);
  var isOpen = isMultiselectOpen && !(hideSelectedOptions && items.length === 0);
  var offsetVar = (0, getValueFromCssVariable_1.getValueFromCssVariable)(
    '--multiselect-'.concat(size, '-dropdownmenu-offset')
  );
  var formattedOffset = parseFloat(offsetVar);
  var rootClassName = (0, clsx_1['default'])(
    'dropdown',
    'dropdown--size-'.concat(dropdownSize),
    {
      'dropdown--open': isOpen,
    },
    className
  );
  var rootFieldClassName = (0, clsx_1['default'])(
    'input',
    'dropdown__trigger',
    'input--'.concat(constants_2.INPUT_VARIANTS[variant]),
    'input--size-'.concat(constants_2.INPUT_SIZES[size]),
    ((_a = {}),
    (_a['input--disabled'] = disabled),
    (_a['input--error'] = !!error),
    (_a['input--focus'] = multiselectIsFocus),
    (_a['input--icon-suffix'] = true),
    (_a['input--multiselect'] = true),
    (_a['input--autoheight'] = isAutoHeight),
    (_a['input--has-value'] = !!tagsOptions.length || searchValue || placeholder),
    (_a['input--hidelabel'] = !label),
    (_a['input--autocomplete'] =
      autocomplete === null || autocomplete === void 0 ? void 0 : autocomplete.enabled),
    (_a['input--with-hint'] = !!(hint || counter || error)),
    (_a['input--only-counter'] = !!counter && !hint && !error),
    _a)
  );
  var tagSize =
    size === constants_2.INPUT_SIZES.s ? constants_1.TAG_SIZES.xs : constants_1.TAG_SIZES.s;
  var field = function field() {
    if (
      tagsOptions.length ||
      placeholder ||
      (autocomplete === null || autocomplete === void 0 ? void 0 : autocomplete.enabled)
    ) {
      return react_1['default'].createElement(SelectedOptionsContainer_1.SelectedOptionsContainer, {
        autoHeight: isAutoHeight,
        items: tagsOptions,
        disabled: disabled,
        className: 'input__field',
        size: tagSize,
        inputSize: constants_2.INPUT_SIZES[size],
        variant: constants_1.TAG_VARIANTS[variant],
        onRemove: function onRemove(key) {
          return removeOption(key);
        },
        inputVisible: showAutocompleteInput,
        inputRef: inputAutocompleteRef,
        inputProps: {
          placeholder: tagsOptions.length === 0 ? placeholder : '',
          onChange: onChangeHandler,
          value: searchValue,
          onKeyUp: handleKeyPress,
          readOnly: !(autocomplete === null || autocomplete === void 0
            ? void 0
            : autocomplete.enabled),
          disabled: disabled,
        },
      });
    }
    return null;
  };
  var renderFooter =
    (hint || counter || error) &&
    react_1['default'].createElement(
      'div',
      {
        className: 'input__hint',
      },
      react_1['default'].createElement(
        'div',
        {
          className: 'input__hint-label',
        },
        error || hint
      ),
      counter &&
        react_1['default'].createElement(
          'div',
          {
            className: 'input__hint-counter',
          },
          counter
        )
    );
  var ICON_CLOSE_SIZE_MAP = {
    l: 24,
    m: 24,
    s: 16,
  };
  var renderIcon = isClearable
    ? react_1['default'].createElement(
        'button',
        {
          type: 'button',
          className: 'input__suffix',
          onClick: onClickClearButton,
          onMouseDown: function_1.preventDefaultFn,
          onTouchStart: function_1.preventDefaultFn,
          'aria-label': 'Clear',
        },
        react_1['default'].createElement(CloseSmall_1['default'], {
          size: (_b = ICON_CLOSE_SIZE_MAP[size]) !== null && _b !== void 0 ? _b : undefined,
        })
      )
    : react_1['default'].createElement(
        'div',
        {
          className: 'input__suffix dropdown__trigger-icon',
          onClick: clickOnSchevron,
        },
        react_1['default'].createElement(ChevronDown_1['default'], null)
      );
  return react_1['default'].createElement(
    DropdownMenu_1['default'],
    {
      headerSlot: headerSlot,
      footerSlot: footerSlot,
      placement: placement,
      offset: formattedOffset,
      size: dropdownSize,
      isOpened: isOpen,
      items: dropdownItems,
      checkIcon: react_1['default'].createElement(CheckLarge16_1['default'], null),
      className: dropdownMenuClassName,
      style: dropdownMenuStyle,
      hideOnSelect: false,
      value: selectedKeys,
      virtualScroll: virtualScroll,
      onClose: onCloseDropDownMenu,
      onChange: onChangeDropdownMenu,
      isSelectedTextColored: false,
      emptyText: emptyText,
      useInPortal: useInPortal,
      widthFitContent: widthFitContent,
      hideSelectedOptions: hideSelectedOptions,
      usePopperProps: {
        trigger: inputRef === null || inputRef === void 0 ? void 0 : inputRef.current,
      },
      isMultiselect: true,
      controlledComponent: true,
    },
    react_1['default'].createElement(
      'div',
      {
        className: rootClassName,
        ref: multiselectRef,
        onClick: clickOnMultiselect,
      },
      react_1['default'].createElement(
        'div',
        __assign(
          {
            className: rootFieldClassName,
            ref: inputRef,
          },
          restProps
        ),
        label &&
          react_1['default'].createElement(
            'div',
            {
              className: 'input__label',
            },
            label
          ),
        field(),
        renderIcon
      ),
      renderFooter
    )
  );
});

Multiselect.propTypes = {
  /**
   * Задает конфиг для поиска
   * @param enabled - Включает фильтрацию опций по введённому значению в инпуте
   * @param onChange - Callback-функция, возвращает значение из инпута
   * @param filterOptions - Задаёт кастомную функцию фильтрации при поиске
   */
  autocomplete: PropTypes.shape({
    enabled: PropTypes.bool.isRequired,
    filterOptions: PropTypes.func,
    onChange: PropTypes.func,
  }),
  /**
   * Устанавливает дополнительные классы для элемента
   */
  className: PropTypes.string,
  /**
   * В значении true, при заполнении поля автокомплита, появится иконка для удаления введённого значения
   * @default false
   */
  clearable: PropTypes.bool,
  /**
   * Задаёт счетчик
   */
  counter: PropTypes.string,
  /**
   * Задает значение по умолчанию, для неуправляемых компонентов.
   *  Не используется вместе с value
   */
  defaultValue: PropTypes.oneOfType([
    PropTypes.arrayOf(
      PropTypes.shape({
        checkIcon: PropTypes.node,
        disabled: PropTypes.bool,
        error: PropTypes.bool,
        hint: PropTypes.string,
        isDivider: PropTypes.bool,
        isTitle: PropTypes.bool,
        key: PropTypes.oneOfType([PropTypes.number, PropTypes.string]).isRequired,
        prefix: PropTypes.func,
        suffix: PropTypes.func,
        value: PropTypes.node,
      })
    ),
    PropTypes.number,
    PropTypes.string,
  ]),
  /**
   * Устанавливает атрибут disabled
   */
  disabled: PropTypes.bool,
  /**
   * Задает дополнительные классы для выпадающего меню
   */
  dropdownMenuClassName: PropTypes.string,
  /**
   * Задает дополнительные стли для выпадающего меню
   */
  dropdownMenuStyle: PropTypes.object,
  /**
   * Задает размер дропдауна
   * @default medium
   */
  dropdownSize: PropTypes.oneOf(['m', 's']),
  /**
   * Задает элемент, отображающийся когда ничего не найдено
   * @default Не найдено
   */
  emptyText: PropTypes.node,
  /**
   * Отображает ошибку заполнения поля
   */
  error: PropTypes.string,
  /**
   * Слот для контента в нижней части Dropdown Menu
   * @param close - функция для закрытия dropdown menu
   * @param selectedItems - массив выбранных элементов
   * @param dropdownItems - массив всех элементов
   */
  footerSlot: PropTypes.func,
  /**
   * Слот для контента в верхней части Dropdown Menu
   * @param close - функция для закрытия dropdown menu
   * @param selectedItems - массив выбранных элементов
   * @param dropdownItems - массив всех элементов
   */
  headerSlot: PropTypes.func,
  /**
   * Скрывает label
   * @default false
   */
  hideLabel: PropTypes.bool,
  /**
   * Определяет, скрывать ли выбранные значения в дропдауне
   *
   *  @default false
   */
  hideSelectedOptions: PropTypes.bool,
  /**
   * Отображает подсказку для заполнения поля
   */
  hint: PropTypes.string,
  /**
   * Задает иконку
   */
  icon: PropTypes.node,
  /**
   * Задает список элементов для выбора
   * @default []
   * @param value - отображаемое значение
   * @param key - уникальный ключ в разрезе списка элементов
   * @param hint - дополнительная подпись
   * @param icon - иконка
   * @param disabled - задаёт состояние disabled для элемента
   * @param suffix - суффикс слот для элемента
   * @param isTitle - делает из элемента title
   * @param isDivider - делает из элемента divider
   */
  items: PropTypes.arrayOf(
    PropTypes.shape({
      checkIcon: PropTypes.node,
      disabled: PropTypes.bool,
      error: PropTypes.bool,
      hint: PropTypes.string,
      isDivider: PropTypes.bool,
      isTitle: PropTypes.bool,
      key: PropTypes.oneOfType([PropTypes.number, PropTypes.string]).isRequired,
      prefix: PropTypes.func,
      suffix: PropTypes.func,
      value: PropTypes.node,
    })
  ),
  /**
   * Задает label
   */
  label: PropTypes.string,
  /**
   * Callback функция, вызываемая при изменении значения
   */
  onChange: PropTypes.func,
  /**
   * Задает placeholder
   */
  placeholder: PropTypes.string,
  /**
   * Определят размещение выпадающего списка
   */
  placement: PropTypes.oneOf([
    'auto',
    'bottom',
    'bottomLeft',
    'bottomRight',
    'left',
    'leftBottom',
    'leftTop',
    'right',
    'rightBottom',
    'rightTop',
    'top',
    'topLeft',
    'topRight',
  ]),
  /**
   * Задает размер
   * @default medium
   */
  size: PropTypes.string,
  /**
   * Задаёт вариант использования с React Portal
   * @default false
   */
  useInPortal: PropTypes.bool,
  /**
   * Задает значение компонента, используется для управляемых компонентов.
   *  Не используется вместе с defaultValue
   */
  value: PropTypes.oneOfType([
    PropTypes.arrayOf(
      PropTypes.shape({
        checkIcon: PropTypes.node,
        disabled: PropTypes.bool,
        error: PropTypes.bool,
        hint: PropTypes.string,
        isDivider: PropTypes.bool,
        isTitle: PropTypes.bool,
        key: PropTypes.oneOfType([PropTypes.number, PropTypes.string]).isRequired,
        prefix: PropTypes.func,
        suffix: PropTypes.func,
        value: PropTypes.node,
      })
    ),
    PropTypes.number,
    PropTypes.string,
  ]),
  /**
   * Задает основной цвет для чекбокса
   *  @default primary
   */
  variant: PropTypes.string,
  /**
   * Включает виртуальный скролл
   */
  virtualScroll: PropTypes.bool,
  /**
   * Соответствовать ширине родительского компонента (root-элемента)
   *  @default true
   */
  widthFitContent: PropTypes.bool,
};

Multiselect.displayName = 'Multiselect';
exports['default'] = Multiselect;
