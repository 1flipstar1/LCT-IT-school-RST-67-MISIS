/// <reference types="react" />
import { IDropdownMenuItem } from '../DropdownMenu/types';
import { IMultiselectProps } from './types';
export declare const useMultiselect: (props: IMultiselectProps) => {
    internalRef: import("react").MutableRefObject<HTMLInputElement>;
    inputAutocompleteRef: import("react").MutableRefObject<HTMLInputElement>;
    multiselectRef: import("react").MutableRefObject<HTMLDivElement>;
    searchValue: string;
    isMultiselectOpen: boolean;
    multiselectIsFocus: boolean;
    selectedOptions: IDropdownMenuItem[];
    isAutoHeight: boolean;
    showAutocompleteInput: boolean;
    removeOption: (tag: string | number) => void;
    clickOnMultiselect: (e: any) => void;
    clickOnSchevron: () => void;
    onChangeHandler: (e: any) => void;
    onCloseDropDownMenu: () => void;
    onSelect: (valueProp: any) => void;
    onChangeDropdownMenu: (v: any) => void;
    onClickClearButton: (e: any) => void;
    handleKeyPress: (e: any) => void;
    tagsOptions: IDropdownMenuItem[];
    selectedKeys: (string | number)[];
    dropdownItems: IDropdownMenuItem[];
};
