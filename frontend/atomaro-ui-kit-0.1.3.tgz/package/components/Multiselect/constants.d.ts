export declare enum INPUT_SIZES {
    s = "s",
    m = "m",
    l = "l"
}
export declare enum INPUT_VARIANTS {
    primary = "primary"
}
export declare const defaultFilterOptions: (inputValue: string, options: any) => any;
export declare const DEFAULT_AUTOCOMPLETE: {
    filterOptions: (inputValue: string, options: any) => any;
    enabled: boolean;
    onChange: () => void;
};
export type InputSizesType = keyof typeof INPUT_SIZES;
export type InputVariantsType = keyof typeof INPUT_VARIANTS;
