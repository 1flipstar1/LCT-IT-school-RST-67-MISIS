export declare const getNormalizedStringWithGaps: (str: string, gaps: number[]) => string;
export declare const getOnlyNumbersValue: (value: string) => string;
