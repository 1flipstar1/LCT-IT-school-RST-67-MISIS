import React from 'react';
import { IInputCardProps } from './types';
declare const InputCard: React.ForwardRefExoticComponent<IInputCardProps & React.RefAttributes<HTMLInputElement>>;
export default InputCard;
