'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.getOnlyNumbersValue = exports.getNormalizedStringWithGaps = void 0;
var getNormalizedStringWithGaps = function getNormalizedStringWithGaps(str, gaps) {
  return str
    .split('')
    .filter(function (_char) {
      return _char !== ' ';
    })
    .map(function (_char2, index) {
      return gaps.includes(index) ? ' '.concat(_char2) : _char2;
    })
    .join('');
};
exports.getNormalizedStringWithGaps = getNormalizedStringWithGaps;
var getOnlyNumbersValue = function getOnlyNumbersValue(value) {
  return value
    .split('')
    .filter(function (_char3) {
      return /^\d{1,}$/.test(_char3);
    })
    .join('');
};
exports.getOnlyNumbersValue = getOnlyNumbersValue;
