import { IInputProps } from '../Input/types';
export interface IInputCardProps extends Omit<IInputProps, 'validationRules' | 'transformationRule' | 'error' | 'fixedLabel' | 'inputControl' | 'iconLeft' | 'iconInputField'> {
    /** Текст ошибки валидации
     * @default Неправильный номер карты
     */
    error?: string;
    /** Устанавливает атрибут required
     * @default false
     */
    required?: boolean;
    /** Текст ошибки при обязательном поле
     * @default Поле обязательно для заполнения
     */
    requiredError?: string;
    /** Параметр принудительного отображения ошибки */
    forceError?: boolean;
}
