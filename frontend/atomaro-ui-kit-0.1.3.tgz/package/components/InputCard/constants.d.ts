import React from 'react';
export declare const CARD_ICONS: {
    'american-express': React.JSX.Element;
    discover: React.JSX.Element;
    jcb: React.JSX.Element;
    maestro: React.JSX.Element;
    mastercard: React.JSX.Element;
    mir: React.JSX.Element;
    unionpay: React.JSX.Element;
    visa: React.JSX.Element;
};
