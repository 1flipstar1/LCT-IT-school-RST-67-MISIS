'use strict';
var PropTypes = require('prop-types');

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __createBinding =
  (this && this.__createBinding) ||
  (Object.create
    ? function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ('get' in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = {
            enumerable: true,
            get: function get() {
              return m[k];
            },
          };
        }
        Object.defineProperty(o, k2, desc);
      }
    : function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
      });
var __setModuleDefault =
  (this && this.__setModuleDefault) ||
  (Object.create
    ? function (o, v) {
        Object.defineProperty(o, 'default', {
          enumerable: true,
          value: v,
        });
      }
    : function (o, v) {
        o['default'] = v;
      });
var __importStar =
  (this && this.__importStar) ||
  function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null)
      for (var k in mod)
        if (k !== 'default' && Object.prototype.hasOwnProperty.call(mod, k))
          __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
  };
var __rest =
  (this && this.__rest) ||
  function (s, e) {
    var t = {};
    for (var p in s)
      if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === 'function')
      for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
          t[p[i]] = s[p[i]];
      }
    return t;
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importStar(require('react'));
var clsx_1 = __importDefault(require('clsx'));
var card_validator_1 = __importDefault(require('card-validator'));
var PaymentCard_1 = __importDefault(require('@atomaro/icons/24/business/PaymentCard'));
var Input_1 = __importDefault(require('../Input/Input'));
var constants_1 = require('./constants');
var utils_1 = require('./utils');
var InputCard = (0, react_1.forwardRef)(function InputCard(props, ref) {
  var _a = props.error,
    error = _a === void 0 ? (props.forceError ? '' : 'Неправильный номер карты') : _a,
    _b = props.forceError,
    forceError = _b === void 0 ? false : _b,
    _c = props.clearable,
    clearable = _c === void 0 ? false : _c,
    _d = props.required,
    required = _d === void 0 ? false : _d,
    _e = props.requiredError,
    requiredError = _e === void 0 ? 'Поле обязательно для заполнения' : _e,
    _f = props.className,
    className = _f === void 0 ? '' : _f,
    restProps = __rest(props, [
      'error',
      'forceError',
      'clearable',
      'required',
      'requiredError',
      'className',
    ]);
  var _g = (0, react_1.useState)(react_1['default'].createElement(PaymentCard_1['default'], null)),
    icon = _g[0],
    setIcon = _g[1];
  var _h = (0, react_1.useState)(false),
    forceErrorOnComplition = _h[0],
    setForceErrorOnComplition = _h[1];
  var handleChange = function handleChange(e) {
    var formattedValue = (0, utils_1.getOnlyNumbersValue)(e.target.value);
    var _a = card_validator_1['default'].number(formattedValue),
      isValid = _a.isValid,
      isPotentiallyValid = _a.isPotentiallyValid,
      card = _a.card;
    if (!isValid && !isPotentiallyValid) {
      setForceErrorOnComplition(true);
    }
    if (
      card &&
      (card === null || card === void 0 ? void 0 : card.lengths[0]) <= formattedValue.length
    ) {
      setForceErrorOnComplition(!isValid);
    }
    if (card) {
      setIcon(constants_1.CARD_ICONS[card.type]);
    } else {
      setIcon(react_1['default'].createElement(PaymentCard_1['default'], null));
    }
  };
  var requiredRule = {
    error: requiredError,
    validate: function validate(value) {
      return value.length;
    },
  };
  var transformationRule = {
    transform: function transform(inputValue) {
      if (inputValue === void 0) {
        inputValue = '';
      }
      var formattedValue = (0, utils_1.getOnlyNumbersValue)(inputValue);
      var card = card_validator_1['default'].number(formattedValue).card;
      if (card) {
        return (0, utils_1.getNormalizedStringWithGaps)(formattedValue, card.gaps);
      }
      return formattedValue;
    },
  };
  var validationRules = [
    {
      error: error,
      validate: function validate(inputValue) {
        var _a = card_validator_1['default'].number(inputValue),
          isValid = _a.isValid,
          isPotentiallyValid = _a.isPotentiallyValid;
        return (inputValue === '' && !props.error) || (isPotentiallyValid && isValid);
      },
    },
  ];
  if (required) {
    validationRules.push(requiredRule);
  }
  var rootClassName = (0, clsx_1['default'])('input--card', className && className);
  return react_1['default'].createElement(
    Input_1['default'],
    __assign(
      {
        ref: ref,
        clearable: clearable,
        className: rootClassName,
        iconPrefix: icon,
        onChange: handleChange,
        validationRules: validationRules,
        transformationRule: transformationRule,
        inputMode: 'numeric',
        type: 'tel',
        maxLength: 22,
        forceError: forceErrorOnComplition || forceError,
      },
      restProps
    )
  );
});

InputCard.propTypes = {
  className: PropTypes.string,
  /**
   * В значении true, при заполнении поля, появится иконка для удаления данных
   * @default false
   */
  clearable: PropTypes.bool,
  /**
   * Текст ошибки валидации
   * @default Неправильный номер карты
   */
  error: PropTypes.string,
  /**
   * Параметр принудительного отображения ошибки
   */
  forceError: PropTypes.bool,
  /**
   * Устанавливает атрибут required
   * @default false
   */
  required: PropTypes.bool,
  /**
   * Текст ошибки при обязательном поле
   * @default Поле обязательно для заполнения
   */
  requiredError: PropTypes.string,
};

exports['default'] = InputCard;
