'use strict';

var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.CARD_ICONS = void 0;
var react_1 = __importDefault(require('react'));
var logotypes_1 = require('../Icons/logotypes');
exports.CARD_ICONS = {
  'american-express': react_1['default'].createElement(logotypes_1.AmExpress, null),
  discover: react_1['default'].createElement(logotypes_1.Discover, null),
  jcb: react_1['default'].createElement(logotypes_1.JCB, null),
  maestro: react_1['default'].createElement(logotypes_1.Maestro, null),
  mastercard: react_1['default'].createElement(logotypes_1.Mastercard, null),
  mir: react_1['default'].createElement(logotypes_1.Mir, null),
  unionpay: react_1['default'].createElement(logotypes_1.UnionPay, null),
  visa: react_1['default'].createElement(logotypes_1.Visa, null),
};
