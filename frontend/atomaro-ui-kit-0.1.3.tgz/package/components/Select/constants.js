'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.DEFAULT_AUTOCOMPLETE =
  exports.DEFAULT_EMPTY_TEXT =
  exports.defaultFilterOptions =
  exports.INPUT_VARIANTS =
  exports.INPUT_SIZES =
    void 0;
var noop_1 = require('../../utils/noop');
var INPUT_SIZES;
(function (INPUT_SIZES) {
  INPUT_SIZES['s'] = 's';
  INPUT_SIZES['m'] = 'm';
  INPUT_SIZES['l'] = 'l';
})((INPUT_SIZES = exports.INPUT_SIZES || (exports.INPUT_SIZES = {})));
var INPUT_VARIANTS;
(function (INPUT_VARIANTS) {
  INPUT_VARIANTS['primary'] = 'primary';
})((INPUT_VARIANTS = exports.INPUT_VARIANTS || (exports.INPUT_VARIANTS = {})));
var defaultFilterOptions = function defaultFilterOptions(inputValue, options) {
  if (inputValue === void 0) {
    inputValue = '';
  }
  if (!Array.isArray(options)) {
    return [];
  }
  return options.filter(function (option) {
    return option.value.toString().toLowerCase().indexOf(inputValue.toLowerCase()) !== -1;
  });
};
exports.defaultFilterOptions = defaultFilterOptions;
exports.DEFAULT_EMPTY_TEXT = 'Ничего не найдено';
exports.DEFAULT_AUTOCOMPLETE = {
  filterOptions: exports.defaultFilterOptions,
  enabled: true,
  onChange: noop_1.noop,
};
