export declare enum INPUT_SIZES {
    s = "s",
    m = "m",
    l = "l"
}
export declare enum INPUT_VARIANTS {
    primary = "primary"
}
export declare const defaultFilterOptions: (inputValue: string, options: any) => any[];
export type InputSizesType = keyof typeof INPUT_SIZES;
export type InputVariantsType = keyof typeof INPUT_VARIANTS;
export declare const DEFAULT_EMPTY_TEXT = "\u041D\u0438\u0447\u0435\u0433\u043E \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u043E";
export declare const DEFAULT_AUTOCOMPLETE: {
    filterOptions: (inputValue: string, options: any) => any[];
    enabled: boolean;
    onChange: () => void;
};
