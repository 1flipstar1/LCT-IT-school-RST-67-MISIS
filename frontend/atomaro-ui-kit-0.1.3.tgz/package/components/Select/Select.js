'use strict';
var PropTypes = require('prop-types');

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __createBinding =
  (this && this.__createBinding) ||
  (Object.create
    ? function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ('get' in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = {
            enumerable: true,
            get: function get() {
              return m[k];
            },
          };
        }
        Object.defineProperty(o, k2, desc);
      }
    : function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
      });
var __setModuleDefault =
  (this && this.__setModuleDefault) ||
  (Object.create
    ? function (o, v) {
        Object.defineProperty(o, 'default', {
          enumerable: true,
          value: v,
        });
      }
    : function (o, v) {
        o['default'] = v;
      });
var __importStar =
  (this && this.__importStar) ||
  function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null)
      for (var k in mod)
        if (k !== 'default' && Object.prototype.hasOwnProperty.call(mod, k))
          __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
  };
var __rest =
  (this && this.__rest) ||
  function (s, e) {
    var t = {};
    for (var p in s)
      if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === 'function')
      for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
          t[p[i]] = s[p[i]];
      }
    return t;
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
/* eslint-disable react-hooks/exhaustive-deps */
var react_1 = __importStar(require('react'));
var clsx_1 = __importDefault(require('clsx'));
require('../../styles/components/select.scss');
var ChevronDown16_1 = __importDefault(require('@atomaro/icons/16/navigation/ChevronDown16'));
var ChevronDown_1 = __importDefault(require('@atomaro/icons/24/navigation/ChevronDown'));
var DropdownMenu_1 = __importDefault(require('../DropdownMenu/DropdownMenu'));
var useCombinedRefs_1 = require('../../hooks/useCombinedRefs');
var function_1 = require('../../utils/function');
var constants_1 = require('./constants');
var Input_1 = __importDefault(require('../Input/Input'));
var getValueFromCssVariable_1 = require('../../utils/getValueFromCssVariable');
var Select = (0, react_1.forwardRef)(function Select(props, ref) {
  var _a;
  var _b, _c, _d;
  var _e = props.variant,
    variant = _e === void 0 ? constants_1.INPUT_VARIANTS.primary : _e,
    _f = props.size,
    size = _f === void 0 ? constants_1.INPUT_SIZES.m : _f,
    _g = props.dropdownSize,
    dropdownSize = _g === void 0 ? 'm' : _g,
    _h = props.items,
    items = _h === void 0 ? [] : _h,
    value = props.value,
    defaultValue = props.defaultValue,
    _j = props.disabled,
    disabled = _j === void 0 ? false : _j,
    _k = props.defaultOpen,
    defaultOpen = _k === void 0 ? false : _k,
    _l = props.onChange,
    onChange = _l === void 0 ? function_1.noop : _l,
    _m = props.onFocus,
    onFocus = _m === void 0 ? function_1.noop : _m,
    _o = props.onBlur,
    onBlur = _o === void 0 ? function_1.noop : _o,
    _p = props.onClear,
    onClear = _p === void 0 ? function_1.noop : _p,
    _q = props.autocomplete,
    autocomplete = _q === void 0 ? constants_1.DEFAULT_AUTOCOMPLETE : _q,
    emptyText = props.emptyText,
    className = props.className,
    _r = props.clearable,
    clearable = _r === void 0 ? false : _r,
    _s = props.virtualScroll,
    virtualScroll = _s === void 0 ? false : _s,
    _t = props.placement,
    placement = _t === void 0 ? 'auto' : _t,
    hint = props.hint,
    error = props.error,
    _u = props.hideLabel,
    hideLabel = _u === void 0 ? false : _u,
    iconSuffix = props.iconSuffix,
    useInPortal = props.useInPortal,
    dropdownMenuClassName = props.dropdownMenuClassName,
    dropdownMenuStyle = props.dropdownMenuStyle,
    _v = props.widthFitContent,
    widthFitContent = _v === void 0 ? true : _v,
    restProps = __rest(props, [
      'variant',
      'size',
      'dropdownSize',
      'items',
      'value',
      'defaultValue',
      'disabled',
      'defaultOpen',
      'onChange',
      'onFocus',
      'onBlur',
      'onClear',
      'autocomplete',
      'emptyText',
      'className',
      'clearable',
      'virtualScroll',
      'placement',
      'hint',
      'error',
      'hideLabel',
      'iconSuffix',
      'useInPortal',
      'dropdownMenuClassName',
      'dropdownMenuStyle',
      'widthFitContent',
    ]);
  var internalRef = (0, react_1.useRef)(null);
  var inputRef = (0, useCombinedRefs_1.useCombinedRefs)(ref, internalRef);
  var _w = autocomplete.filterOptions,
    filterOptions = _w === void 0 ? constants_1.defaultFilterOptions : _w,
    autocompleteEnabled = autocomplete.enabled,
    autocompleteOnChange = autocomplete.onChange;
  var getSelectedItemByKey = function getSelectedItemByKey(key) {
    return items.find(function (item) {
      return item.key === key;
    });
  };
  var _x = (0, react_1.useState)(defaultOpen),
    isOpen = _x[0],
    setIsOpen = _x[1];
  var _y = (0, react_1.useState)(undefined),
    searchText = _y[0],
    setSearchText = _y[1];
  var _z = (0, react_1.useState)(
      defaultValue !== undefined ? getSelectedItemByKey(defaultValue) : undefined
    ),
    selection = _z[0],
    setSelection = _z[1];
  var onDropdownClose = function onDropdownClose() {
    setIsOpen(false);
    setSearchText(undefined);
  };
  var handleOnChange = function handleOnChange(keys) {
    onChange(keys[0]);
    setSearchText(undefined);
    if (value === undefined) {
      setSelection(getSelectedItemByKey(keys[0]));
    }
  };
  (0, react_1.useEffect)(
    function () {
      if (value !== undefined) {
        setSelection(getSelectedItemByKey(value));
      }
    },
    [value, items, setSelection]
  );
  var filteredOptions = filterOptions && filterOptions(searchText, items);
  var toggleDropdownMenu = function toggleDropdownMenu(e, field) {
    if (autocompleteEnabled && isOpen && field === 'input') {
      e.nativeEvent.stopImmediatePropagation();
      return;
    }
    if (!disabled && !isOpen) {
      setIsOpen(true);
    }
    if (!disabled && isOpen) {
      if (inputRef.current) {
        inputRef.current.blur();
      }
      setIsOpen(false);
    }
  };
  (0, react_1.useEffect)(
    function () {
      var _a;
      if (isOpen) {
        (_a = inputRef.current) === null || _a === void 0 ? void 0 : _a.focus();
      }
    },
    [isOpen, inputRef]
  );
  var renderIcon =
    iconSuffix ||
    react_1['default'].createElement(
      'div',
      {
        className: 'select__icon-wrapper',
        onKeyDown: function onKeyDown() {},
        role: 'button',
        tabIndex: 0,
        onClick: function onClick(e) {
          toggleDropdownMenu(e);
        },
      },
      size === constants_1.INPUT_SIZES.s
        ? react_1['default'].createElement(ChevronDown16_1['default'], null)
        : react_1['default'].createElement(ChevronDown_1['default'], {
            size: size === constants_1.INPUT_SIZES.m ? 20 : 24,
          })
    );
  var handleSearch = function handleSearch(e) {
    setSearchText(e.target.value);
    if (autocompleteOnChange) {
      autocompleteOnChange(e.target.value);
    }
  };
  var handleClear = function handleClear() {
    setSelection(undefined);
    if (inputRef.current) {
      inputRef.current.blur();
    }
    onClear();
  };
  var currentEmptyText = function currentEmptyText() {
    if (
      (searchText === '' && !filteredOptions.length) ||
      (searchText === undefined && !filteredOptions.length)
    ) {
      if (emptyText) {
        return emptyText;
      }
      return constants_1.DEFAULT_EMPTY_TEXT;
    }
    if (
      searchText &&
      (searchText === null || searchText === void 0 ? void 0 : searchText.length) > 0 &&
      !filteredOptions.length
    ) {
      return constants_1.DEFAULT_EMPTY_TEXT;
    }
    return undefined;
  };
  var generateOffset = function generateOffset() {
    var offsetVar = (0, getValueFromCssVariable_1.getValueFromCssVariable)(
      '--select-'.concat(size, '-dropdownmenu-offset')
    );
    var formattedOffset = parseFloat(offsetVar);
    if (hint || error) {
      var footer = document.querySelector('.input__hint');
      var hintOffset = (0, getValueFromCssVariable_1.getValueFromCssVariable)(
        '--input-'.concat(size, '-labeloutside-spacing')
      );
      var formattedHintOffset = parseFloat(hintOffset);
      if (footer !== null) {
        return (
          formattedOffset -
          formattedHintOffset -
          (footer === null || footer === void 0 ? void 0 : footer.offsetHeight)
        );
      }
    }
    return formattedOffset;
  };
  var inputClassName = (0, clsx_1['default'])(
    'select',
    ((_a = {}),
    (_a['select--open'] = isOpen),
    (_a['select--readOnly'] = !autocompleteEnabled),
    (_a['input--has-value'] = !!value || isOpen),
    (_a['select--disabled'] = disabled),
    _a),
    className
  );
  var renderInput = react_1['default'].createElement(
    Input_1['default'],
    __assign(
      {
        className: inputClassName,
        onClick: function onClick(e) {
          toggleDropdownMenu(e, 'input');
        },
        value:
          searchText !== undefined
            ? searchText
            : ((_b = selection === null || selection === void 0 ? void 0 : selection.value) ===
                null || _b === void 0
                ? void 0
                : _b.toString()) || '',
        iconSuffix: renderIcon,
        disabled: disabled,
        onFocus: onFocus,
        onBlur: onBlur,
        ref: inputRef,
        readOnly: !autocompleteEnabled,
        size: size,
        variant: variant,
        onChange: handleSearch,
        clearable: clearable,
        onClear: handleClear,
        hint: hint,
        error: error,
        hideLabel: hideLabel,
      },
      restProps
    )
  );
  return react_1['default'].createElement(
    DropdownMenu_1['default'],
    {
      isOpened: isOpen,
      placement: placement,
      items: filteredOptions,
      size: dropdownSize,
      onChange: handleOnChange,
      onClose: onDropdownClose,
      isEmpty: !filteredOptions.length,
      emptyText: currentEmptyText(),
      virtualScroll: virtualScroll,
      useInPortal: useInPortal,
      offset: generateOffset(),
      value: [
        (_c = selection === null || selection === void 0 ? void 0 : selection.key) !== null &&
        _c !== void 0
          ? _c
          : '',
      ],
      defaultValue: [
        (_d = selection === null || selection === void 0 ? void 0 : selection.key) !== null &&
        _d !== void 0
          ? _d
          : '',
      ],
      className: dropdownMenuClassName,
      style: dropdownMenuStyle,
      widthFitContent: widthFitContent,
      controlledComponent: true,
    },
    renderInput
  );
});

Select.propTypes = {
  /**
   * Задает конфиг для поиска
   * @param enabled - Включает фильтрацию опций по введённому значению в инпуте
   * @param onChange - Callback-функция, возвращает значение из инпута
   * @param filterOptions - Задаёт кастомную функцию фильтрации при поиске
   */
  autocomplete: PropTypes.shape({
    enabled: PropTypes.bool.isRequired,
    filterOptions: PropTypes.func,
    onChange: PropTypes.func,
  }),
  className: PropTypes.string,
  /**
   * В значении true, при заполнении поля, появится иконка для удаления данных
   * @default false
   */
  clearable: PropTypes.bool,
  /**
   * Задает первоначально открытое состояние раскрывающегося списка
   * @default false
   */
  defaultOpen: PropTypes.bool,
  /**
   * Задает значение по умолчанию, для неуправляемых компонентов.
   *  Не используется вместе с value
   */
  defaultValue: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  /**
   * Устанавливает атрибут disabled
   */
  disabled: PropTypes.bool,
  /**
   * Задает дополнительные классы для выпадающего меню
   */
  dropdownMenuClassName: PropTypes.string,
  /**
   * Задает дополнительные стли для выпадающего меню
   */
  dropdownMenuStyle: PropTypes.object,
  /**
   * Задает размер дропдауна
   * @default medium
   */
  dropdownSize: PropTypes.oneOf(['m', 's']),
  /**
   * Задает элемент, отображающийся когда ничего не найдено
   * @default Не найдено
   */
  emptyText: PropTypes.node,
  /**
   * Отображает ошибку заполнения поля
   */
  error: PropTypes.string,
  /**
   * Прячет label, но оставляет поле доступным, добавляет аттрибут aria-label
   * @default false
   */
  hideLabel: PropTypes.bool,
  /**
   * Отображает подсказку для заполнения поля
   */
  hint: PropTypes.string,
  /**
   * Задает иконку
   */
  iconSuffix: PropTypes.node,
  /**
   * Задает список элементов для выбора
   * @default []
   * @param value - отображаемое значение
   * @param key - уникальный ключ в разрезе списка элементов
   * @param hint - дополнительная подпись
   * @param icon - иконка
   * @param disabled - задаёт состояние disabled для элемента
   * @param suffix - суффикс слот для элемента
   * @param isTitle - делает из элемента title
   * @param isDivider - делает из элемента divider
   */
  items: PropTypes.arrayOf(
    PropTypes.shape({
      checkIcon: PropTypes.node,
      disabled: PropTypes.bool,
      error: PropTypes.bool,
      hint: PropTypes.string,
      isDivider: PropTypes.bool,
      isTitle: PropTypes.bool,
      key: PropTypes.oneOfType([PropTypes.number, PropTypes.string]).isRequired,
      prefix: PropTypes.func,
      suffix: PropTypes.func,
      value: PropTypes.node,
    })
  ),
  /**
   * Callback функция, вызываемая при потере фокуса
   */
  onBlur: PropTypes.func,
  /**
   * Callback функция, вызываемая при изменении значения
   */
  onChange: PropTypes.func,
  /**
   * Callback функция, вызываемая при очищении поля
   */
  onClear: PropTypes.func,
  /**
   * Callback функция, вызываемая на фокус
   */
  onFocus: PropTypes.func,
  /**
   * Определят размещение выпадающего списка
   */
  placement: PropTypes.oneOf([
    'auto',
    'bottom',
    'bottomLeft',
    'bottomRight',
    'left',
    'leftBottom',
    'leftTop',
    'right',
    'rightBottom',
    'rightTop',
    'top',
    'topLeft',
    'topRight',
  ]),
  /**
   * Задает размер
   * @default m
   */
  size: PropTypes.string,
  /**
   * Задаёт вариант использования с React Portal
   * @default false
   */
  useInPortal: PropTypes.bool,
  /**
   * Задает значение компонента, используется для управляемых компонентов.
   *  Не используется вместе с defaultValue
   */
  value: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  /**
   * Задает основной цвет для чекбокса
   *  @default primary
   */
  variant: PropTypes.string,
  /**
   * Включает виртуальный скролл
   */
  virtualScroll: PropTypes.bool,
  /**
   * Соответствовать ширине родительского компонента (root-элемента)
   *  @default true
   */
  widthFitContent: PropTypes.bool,
};

Select.displayName = 'Select';
exports['default'] = Select;
