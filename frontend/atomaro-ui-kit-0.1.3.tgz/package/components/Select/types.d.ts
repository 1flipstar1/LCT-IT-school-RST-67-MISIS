import React, { ReactNode, InputHTMLAttributes } from 'react';
import { IDropdownMenuItem } from '../DropdownMenu/types';
import { InputSizesType, InputVariantsType } from './constants';
import { DropDownMenuSizes } from '../DropdownMenu/constants';
import { PlacementsType } from '../../hooks/usePopper/types';
export interface ISelectProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'size' | 'onChange' | 'value'> {
    /** Задает основной цвет для чекбокса
     *  @default primary */
    variant?: InputVariantsType | string;
    /** Задает размер
     * @default m
     */
    size?: InputSizesType | string;
    /** Задает label */
    label?: string;
    /**
     * Прячет label, но оставляет поле доступным, добавляет аттрибут aria-label
     * @default false
     */
    hideLabel?: boolean;
    /** Задает placeholder */
    placeholder?: string;
    /** Задает список элементов для выбора
     * @default []
     * @param value - отображаемое значение
     * @param key - уникальный ключ в разрезе списка элементов
     * @param hint - дополнительная подпись
     * @param icon - иконка
     * @param disabled - задаёт состояние disabled для элемента
     * @param suffix - суффикс слот для элемента
     * @param isTitle - делает из элемента title
     * @param isDivider - делает из элемента divider
     */
    items?: IDropdownMenuItem[];
    /** Отображает подсказку для заполнения поля */
    hint?: string;
    /** Задает значение компонента, используется для управляемых компонентов.
     *  Не используется вместе с defaultValue */
    value?: IDropdownMenuItem['key'] | null;
    /** Задает значение по умолчанию, для неуправляемых компонентов.
     *  Не используется вместе с value */
    defaultValue?: IDropdownMenuItem['key'];
    /** Устанавливает атрибут disabled */
    disabled?: boolean;
    /** Отображает ошибку заполнения поля */
    error?: string;
    /** Задает размер дропдауна
     * @default medium
     */
    dropdownSize?: DropDownMenuSizes;
    /** Задает дополнительные классы для выпадающего меню */
    dropdownMenuClassName?: string;
    /** Задает дополнительные стли для выпадающего меню */
    dropdownMenuStyle?: React.CSSProperties;
    /** Задает первоначально открытое состояние раскрывающегося списка
     * @default false
     */
    defaultOpen?: boolean;
    /** Задает конфиг для поиска
     * @param enabled - Включает фильтрацию опций по введённому значению в инпуте
     * @param onChange - Callback-функция, возвращает значение из инпута
     * @param filterOptions - Задаёт кастомную функцию фильтрации при поиске
     */
    autocomplete?: {
        enabled: boolean;
        onChange?: (value: string) => void;
        filterOptions?: (inputValue: string, options: IDropdownMenuItem[]) => IDropdownMenuItem[];
    };
    /** Задает элемент, отображающийся когда ничего не найдено
     * @default Не найдено
     */
    emptyText?: ReactNode;
    /** В значении true, при заполнении поля, появится иконка для удаления данных
     * @default false
     */
    clearable?: boolean;
    /** Callback функция, вызываемая при очищении поля */
    onClear?: () => void;
    /** Callback функция, вызываемая при изменении значения */
    onChange?: (value: IDropdownMenuItem['key']) => void;
    /** Callback функция, вызываемая на фокус */
    onFocus?: () => void;
    /** Callback функция, вызываемая при потере фокуса */
    onBlur?: () => void;
    /** Определят размещение выпадающего списка */
    placement?: PlacementsType;
    /** Задает иконку */
    iconSuffix?: ReactNode;
    /** Включает виртуальный скролл */
    virtualScroll?: boolean;
    /**  Соответствовать ширине родительского компонента (root-элемента)
     *  @default true */
    widthFitContent?: boolean;
    /** Задаёт вариант использования с React Portal
     * @default false */
    useInPortal?: boolean;
}
