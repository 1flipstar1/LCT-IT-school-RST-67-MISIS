import React from 'react';
import '../../styles/components/select.scss';
import { ISelectProps } from './types';
declare const Select: React.ForwardRefExoticComponent<ISelectProps & React.RefAttributes<HTMLInputElement>>;
export default Select;
