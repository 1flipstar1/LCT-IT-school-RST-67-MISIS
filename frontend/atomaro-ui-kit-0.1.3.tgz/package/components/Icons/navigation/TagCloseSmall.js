'use strict';

var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var TagCloseSmall = function TagCloseSmall() {
  return react_1['default'].createElement(
    'svg',
    {
      xmlns: 'http://www.w3.org/2000/svg',
      width: '10',
      height: '10',
      viewBox: '0 0 10 10',
      fill: 'none',
    },
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M6.06043 5.00101L9.11872 8.05932L8.05806 9.11998L4.99977 6.06167L1.94148 9.11998L0.880819 8.05932L3.93911 5.00101L0.880127 1.94201L1.94078 0.881348L4.99977 3.94035L8.05876 0.881348L9.11941 1.94201L6.06043 5.00101Z',
    })
  );
};
TagCloseSmall.displayName = 'TagCloseSmall';
exports['default'] = TagCloseSmall;
