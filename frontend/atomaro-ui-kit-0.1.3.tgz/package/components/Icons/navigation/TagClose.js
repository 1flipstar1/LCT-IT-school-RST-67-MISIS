'use strict';

var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var TagClose = function TagClose() {
  return react_1['default'].createElement(
    'svg',
    {
      xmlns: 'http://www.w3.org/2000/svg',
      width: '16',
      height: '16',
      viewBox: '0 0 16 16',
      fill: 'none',
    },
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M9.0615 8.00013L13.0306 11.9693L11.97 13.0299L8.00072 9.06067L4.03057 13.03L2.97003 11.9692L6.94006 8.00001L2.96997 4.0299L4.03063 2.96924L8.00084 6.93947L11.97 2.97113L13.0306 4.03191L9.0615 8.00013Z',
    })
  );
};
TagClose.displayName = 'TagClose';
exports['default'] = TagClose;
