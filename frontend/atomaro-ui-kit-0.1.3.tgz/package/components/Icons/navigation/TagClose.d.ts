import React from 'react';
declare const TagClose: {
    (): React.JSX.Element;
    displayName: string;
};
export default TagClose;
