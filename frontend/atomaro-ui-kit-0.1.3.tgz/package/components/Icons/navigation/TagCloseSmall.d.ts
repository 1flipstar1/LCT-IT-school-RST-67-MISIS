import React from 'react';
declare const TagCloseSmall: {
    (): React.JSX.Element;
    displayName: string;
};
export default TagCloseSmall;
