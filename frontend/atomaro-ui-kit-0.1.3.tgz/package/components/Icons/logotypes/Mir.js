'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('@atomaro/icons/Icon'));
var Mir = function Mir(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      xmlns: 'http://www.w3.org/2000/svg',
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M6.4672 9V9.00295C6.46423 9.00295 5.52975 9 5.28056 9.88721C5.05213 10.7007 4.40838 12.9468 4.39058 13.0087H4.21258C4.21258 13.0087 3.55399 10.7125 3.3226 9.88426C3.0734 8.99705 2.13596 9 2.13596 9H0V15.7499H2.13596V11.7412H2.22495H2.31395L3.55993 15.7499H5.04323L6.2892 11.7442H6.4672V15.7499H8.60316V9H6.4672Z',
      fill: '#4DB45E',
    }),
    react_1['default'].createElement('path', {
      xmlns: 'http://www.w3.org/2000/svg',
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M14.27 9C14.27 9 13.6441 9.056 13.3504 9.70741L11.8374 13.0087H11.6594V9H9.52344V15.7499H11.5407C11.5407 15.7499 12.1963 15.6909 12.49 15.0425L13.9733 11.7412H14.1513V15.7499H16.2873V9H14.27Z',
      fill: '#4DB45E',
    }),
    react_1['default'].createElement('path', {
      xmlns: 'http://www.w3.org/2000/svg',
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M17.2344 12.0657V15.7501H19.3703V13.5984H21.6843C22.6929 13.5984 23.5473 12.9588 23.8647 12.0657H17.2344Z',
      fill: '#4DB45E',
    }),
    react_1['default'].createElement('path', {
      xmlns: 'http://www.w3.org/2000/svg',
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M21.687 9H16.9375C17.1748 10.2851 18.1449 11.3168 19.3998 11.6528C19.6846 11.7294 19.9842 11.7707 20.2927 11.7707H23.9535C23.9862 11.6174 24.001 11.4612 24.001 11.2991C24.001 10.0287 22.9656 9 21.687 9Z',
      fill: 'url(#paint0_linear_21591_381992)',
    }),
    react_1['default'].createElement(
      'defs',
      {
        xmlns: 'http://www.w3.org/2000/svg',
      },
      react_1['default'].createElement(
        'linearGradient',
        {
          id: 'paint0_linear_21591_381992',
          x1: '16.9381',
          y1: '10.3853',
          x2: '24.001',
          y2: '10.3853',
          gradientUnits: 'userSpaceOnUse',
        },
        react_1['default'].createElement('stop', {
          stopColor: '#00B4E6',
        }),
        react_1['default'].createElement('stop', {
          offset: '1',
          stopColor: '#088CCB',
        })
      )
    )
  );
};
Mir.displayName = 'Mir';
exports['default'] = Mir;
