'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('@atomaro/icons/Icon'));
var AmExpress = function AmExpress(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      xmlns: 'http://www.w3.org/2000/svg',
      d: 'M18.4294 6.908L19.0692 5.168H21.992V4C21.992 2.89543 21.0966 2 19.992 2H4C2.89543 2 2 2.89543 2 4V20C2 21.1046 2.89543 22 4 22H19.992C21.0966 22 21.992 21.1046 21.992 20V18.856H19.2291L18.2095 17.656L17.1499 18.856H9.32507V12.488H6.7421L9.97281 5.168H13.1196L13.8792 6.828V5.168H17.7817L18.4294 6.908ZM16.2303 8.056V7.356L16.4902 8.056L17.7897 11.536H19.0812L20.3886 8.056L20.6405 7.364V11.536H22V6.2H19.7409L18.7173 8.908L18.4294 9.656L18.1495 8.924L17.118 6.216H14.8709V11.536H16.2303V8.056ZM13.3035 11.536H14.8709L12.5238 6.2H10.7045L8.34546 11.536H9.89284L10.2927 10.508H12.8796L13.2795 11.536H13.3035ZM11.3323 8.008L11.6002 7.34L11.8641 8.008L12.4318 9.356H10.7925L11.3443 8.008H11.3323ZM10.4326 12.496V17.808H14.8709V16.656H11.7801V15.728H14.8309V14.58H11.7801V13.656H14.8709V12.496H10.4326ZM19.8209 17.808H21.5882L19.0972 15.14L21.5882 12.496H19.8489L18.2495 14.22L16.6501 12.496H14.8709L17.3579 15.16L14.8709 17.808H16.5902L18.2095 16.076L19.8089 17.808H19.8209ZM20.4966 15.136L22 16.668V13.62L20.4966 15.136Z',
      fill: '#006FCF',
    })
  );
};
AmExpress.displayName = 'AmExpress';
exports['default'] = AmExpress;
