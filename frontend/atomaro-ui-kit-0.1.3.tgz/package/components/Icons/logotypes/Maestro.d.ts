import React from 'react';
import { IIconProps } from '@atomaro/icons/types';
declare const Maestro: {
    (props: IIconProps): React.JSX.Element;
    displayName: string;
};
export default Maestro;
