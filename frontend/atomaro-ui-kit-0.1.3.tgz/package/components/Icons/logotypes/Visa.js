'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('@atomaro/icons/Icon'));
var Visa = function Visa(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      fillRule: 'evenodd',
      clipRule: 'evenodd',
      d: 'M12.4122 11.1826C12.3985 12.2969 13.3744 12.9188 14.1094 13.2886C14.8647 13.668 15.1184 13.9112 15.1155 14.2505C15.1097 14.7697 14.513 14.9988 13.9545 15.0077C12.9801 15.0233 12.4136 14.7362 11.9632 14.519L11.6123 16.2143C12.0641 16.4294 12.9008 16.6168 13.7686 16.625C15.8052 16.625 17.1377 15.5872 17.1449 13.9782C17.1529 11.9362 14.4085 11.8231 14.4272 10.9103C14.4337 10.6336 14.6896 10.3382 15.2503 10.2631C15.5277 10.2252 16.2938 10.1961 17.1622 10.609L17.5031 8.96873C17.0361 8.79315 16.4357 8.625 15.6884 8.625C13.7714 8.625 12.4231 9.67689 12.4122 11.1826ZM20.7786 8.76633C20.4067 8.76633 20.0932 8.99029 19.9534 9.33396L17.044 16.5045H19.0792L19.4842 15.3492H21.9713L22.2062 16.5045H24L22.4347 8.76633H20.7786ZM21.0632 10.8567L21.6506 13.7624H20.042L21.0632 10.8567ZM9.94464 8.76633L8.34042 16.5045H10.2797L11.8832 8.76633H9.94464ZM7.07562 8.76633L5.05698 14.0332L4.24044 9.55488C4.14462 9.05501 3.76626 8.76633 3.34608 8.76633H0.0461398L0 8.99103C0.67746 9.14277 1.44714 9.38753 1.9134 9.64939C2.19876 9.8093 2.28024 9.94915 2.3739 10.3293L3.92046 16.5045H5.97012L9.11226 8.76633H7.07562Z',
      fill: '#1A1F71',
    })
  );
};
Visa.displayName = 'Visa';
exports['default'] = Visa;
