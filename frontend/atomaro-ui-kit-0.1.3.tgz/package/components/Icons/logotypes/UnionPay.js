'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('@atomaro/icons/Icon'));
var UnionPay = function UnionPay(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement(
      'g',
      {
        xmlns: 'http://www.w3.org/2000/svg',
        clipPath: 'url(#clip0_21591_382240)',
      },
      react_1['default'].createElement('path', {
        d: 'M5.30847 5.00004H10.7995C10.9716 4.99246 11.1431 5.02734 11.2991 5.1017C11.4552 5.17607 11.5912 5.28771 11.6957 5.42711C11.8002 5.56652 11.87 5.72956 11.8992 5.90233C11.9283 6.07511 11.916 6.2525 11.8632 6.41938L9.3066 17.5859C9.20594 17.9764 8.98548 18.3241 8.67726 18.5784C8.36904 18.8327 7.98913 18.9804 7.59275 19H2.10174C1.93016 19.0073 1.75939 18.9724 1.60387 18.8984C1.44836 18.8243 1.31268 18.7132 1.20832 18.5744C1.10396 18.4357 1.03399 18.2734 1.00434 18.1014C0.974686 17.9293 0.986221 17.7525 1.03797 17.5859L3.60746 6.41938C3.70729 6.02819 3.92745 5.6797 4.23578 5.42482C4.54411 5.16994 4.92447 5.02202 5.32131 5.00265',
        fill: '#ED171F',
      }),
      react_1['default'].createElement('path', {
        d: 'M10.3391 5H16.6524C17.4232 5 17.0738 5.63517 16.8939 6.41673L14.3372 17.5833C14.16 18.3674 14.2165 18.9974 13.4456 18.9974H7.13239C6.96066 19.0055 6.78956 18.9711 6.63376 18.8972C6.47795 18.8233 6.34207 18.712 6.23775 18.573C6.13344 18.434 6.0638 18.2714 6.03479 18.099C6.00578 17.9266 6.01827 17.7497 6.07119 17.5833L8.62526 6.41934C8.72582 6.02854 8.94618 5.68051 9.25436 5.42576C9.56254 5.171 9.94251 5.02279 10.3391 5.00261',
        fill: '#082F67',
      }),
      react_1['default'].createElement('path', {
        d: 'M16.4022 5.00016H21.8932C22.0656 4.99214 22.2373 5.0267 22.3937 5.10087C22.5501 5.17505 22.6865 5.28664 22.7913 5.42611C22.8961 5.56558 22.9661 5.72878 22.9954 5.90177C23.0247 6.07477 23.0124 6.2524 22.9596 6.4195L20.3901 17.5834C20.2896 17.9745 20.0689 18.3227 19.7601 18.5772C19.4513 18.8316 19.0706 18.9789 18.6737 18.9975H13.1955C13.0239 19.0048 12.8531 18.9699 12.6976 18.8959C12.5421 18.8218 12.4064 18.7107 12.3021 18.5719C12.1977 18.4332 12.1277 18.2709 12.0981 18.0989C12.0684 17.9268 12.08 17.75 12.1317 17.5834L14.6884 6.4195C14.7882 6.0283 15.0083 5.67982 15.3167 5.42494C15.625 5.17006 16.0054 5.02214 16.4022 5.00277',
        fill: '#006A65',
      })
    ),
    react_1['default'].createElement(
      'defs',
      {
        xmlns: 'http://www.w3.org/2000/svg',
      },
      react_1['default'].createElement(
        'clipPath',
        {
          id: 'clip0_21591_382240',
        },
        react_1['default'].createElement('rect', {
          width: '22',
          height: '14',
          fill: 'white',
          transform: 'translate(1 5)',
        })
      )
    )
  );
};
UnionPay.displayName = 'UnionPay';
exports['default'] = UnionPay;
