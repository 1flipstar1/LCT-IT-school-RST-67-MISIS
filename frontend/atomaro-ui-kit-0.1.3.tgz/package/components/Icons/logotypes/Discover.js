'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('@atomaro/icons/Icon'));
var Discover = function Discover(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement(
      'g',
      {
        xmlns: 'http://www.w3.org/2000/svg',
        filter: 'url(#filter0_i_21591_381974)',
      },
      react_1['default'].createElement('circle', {
        cx: '12',
        cy: '12',
        r: '10',
        fill: 'url(#paint0_linear_21591_381974)',
      })
    ),
    react_1['default'].createElement(
      'defs',
      {
        xmlns: 'http://www.w3.org/2000/svg',
      },
      react_1['default'].createElement(
        'filter',
        {
          id: 'filter0_i_21591_381974',
          x: '2',
          y: '2',
          width: '21.7391',
          height: '21.7391',
          filterUnits: 'userSpaceOnUse',
          colorInterpolationFilters: 'sRGB',
        },
        react_1['default'].createElement('feFlood', {
          floodOpacity: '0',
          result: 'BackgroundImageFix',
        }),
        react_1['default'].createElement('feBlend', {
          mode: 'normal',
          in: 'SourceGraphic',
          in2: 'BackgroundImageFix',
          result: 'shape',
        }),
        react_1['default'].createElement('feColorMatrix', {
          in: 'SourceAlpha',
          type: 'matrix',
          values: '0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0',
          result: 'hardAlpha',
        }),
        react_1['default'].createElement('feOffset', {
          dx: '1.73913',
          dy: '1.73913',
        }),
        react_1['default'].createElement('feGaussianBlur', {
          stdDeviation: '0.869565',
        }),
        react_1['default'].createElement('feComposite', {
          in2: 'hardAlpha',
          operator: 'arithmetic',
          k2: '-1',
          k3: '1',
        }),
        react_1['default'].createElement('feColorMatrix', {
          type: 'matrix',
          values: '0 0 0 0 0.501961 0 0 0 0 0.145098 0 0 0 0 0.101961 0 0 0 0.74 0',
        }),
        react_1['default'].createElement('feBlend', {
          mode: 'normal',
          in2: 'shape',
          result: 'effect1_innerShadow_21591_381974',
        })
      ),
      react_1['default'].createElement(
        'linearGradient',
        {
          id: 'paint0_linear_21591_381974',
          x1: '4.17391',
          y1: '5.26087',
          x2: '18.7391',
          y2: '19.8261',
          gradientUnits: 'userSpaceOnUse',
        },
        react_1['default'].createElement('stop', {
          offset: '0.213542',
          stopColor: '#DF471F',
        }),
        react_1['default'].createElement('stop', {
          offset: '1',
          stopColor: '#F59314',
        })
      )
    )
  );
};
Discover.displayName = 'Discover';
exports['default'] = Discover;
