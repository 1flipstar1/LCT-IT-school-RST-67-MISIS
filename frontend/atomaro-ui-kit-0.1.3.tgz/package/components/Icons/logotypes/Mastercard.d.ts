import React from 'react';
import { IIconProps } from '@atomaro/icons/types';
declare const Mastercard: {
    (props: IIconProps): React.JSX.Element;
    displayName: string;
};
export default Mastercard;
