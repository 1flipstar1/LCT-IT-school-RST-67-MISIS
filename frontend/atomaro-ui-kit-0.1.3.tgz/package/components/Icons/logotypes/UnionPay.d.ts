import React from 'react';
import { IIconProps } from '@atomaro/icons/types';
declare const UnionPay: {
    (props: IIconProps): React.JSX.Element;
    displayName: string;
};
export default UnionPay;
