'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('@atomaro/icons/Icon'));
var JCB = function JCB(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      xmlns: 'http://www.w3.org/2000/svg',
      d: 'M24 17.5952C24 19.6786 22.3276 21.375 20.2738 21.375H0V6.40476C0 4.32143 1.67237 2.625 3.72616 2.625H24V17.5952Z',
      fill: 'white',
    }),
    react_1['default'].createElement('path', {
      xmlns: 'http://www.w3.org/2000/svg',
      d: 'M17.3984 13.756H18.9388C18.9828 13.756 19.0855 13.7411 19.1295 13.7411C19.4229 13.6816 19.6723 13.4137 19.6723 13.0417C19.6723 12.6845 19.4229 12.4167 19.1295 12.3423C19.0855 12.3274 18.9975 12.3274 18.9388 12.3274H17.3984V13.756Z',
      fill: 'url(#paint0_linear_21591_382014)',
    }),
    react_1['default'].createElement('path', {
      xmlns: 'http://www.w3.org/2000/svg',
      d: 'M18.7627 3.88989C17.2957 3.88989 16.0928 5.09525 16.0928 6.59823V9.41073H19.863C19.951 9.41073 20.0537 9.41073 20.127 9.42561C20.9779 9.47025 21.6087 9.91668 21.6087 10.6905C21.6087 11.3006 21.1833 11.8214 20.3911 11.9256V11.9554C21.2566 12.0149 21.9168 12.506 21.9168 13.2649C21.9168 14.0833 21.1833 14.6191 20.215 14.6191H16.0781V20.125H19.995C21.462 20.125 22.6649 18.9197 22.6649 17.4167V3.88989H18.7627Z',
      fill: 'url(#paint1_linear_21591_382014)',
    }),
    react_1['default'].createElement('path', {
      xmlns: 'http://www.w3.org/2000/svg',
      d: 'M19.4816 10.8691C19.4816 10.512 19.2322 10.2739 18.9388 10.2292C18.9094 10.2292 18.8361 10.2144 18.7921 10.2144H17.3984V11.5239H18.7921C18.8361 11.5239 18.9241 11.5239 18.9388 11.509C19.2322 11.4644 19.4816 11.2263 19.4816 10.8691Z',
      fill: 'url(#paint2_linear_21591_382014)',
    }),
    react_1['default'].createElement('path', {
      xmlns: 'http://www.w3.org/2000/svg',
      d: 'M4.00491 3.88989C2.53792 3.88989 1.33498 5.09525 1.33498 6.59823V13.2798C2.08315 13.6518 2.86065 13.8899 3.63816 13.8899C4.56237 13.8899 5.06114 13.3244 5.06114 12.5506V9.39585H7.34965V12.5357C7.34965 13.756 6.60148 14.753 4.06359 14.753C2.52325 14.753 1.32031 14.4107 1.32031 14.4107V20.1101H5.23718C6.70417 20.1101 7.90711 18.9048 7.90711 17.4018V3.88989H4.00491Z',
      fill: 'url(#paint3_linear_21591_382014)',
    }),
    react_1['default'].createElement('path', {
      xmlns: 'http://www.w3.org/2000/svg',
      d: 'M11.3848 3.88989C9.91778 3.88989 8.71484 5.09525 8.71484 6.59823V10.1399C9.38966 9.55954 10.5633 9.18751 12.4557 9.2768C13.4679 9.32144 14.5535 9.60418 14.5535 9.60418V10.75C14.0107 10.4673 13.3652 10.2143 12.529 10.1548C11.0914 10.0506 10.2258 10.7649 10.2258 12.0149C10.2258 13.2798 11.0914 13.9941 12.529 13.875C13.3652 13.8155 14.0107 13.5476 14.5535 13.2798V14.4256C14.5535 14.4256 13.4826 14.7083 12.4557 14.753C10.5633 14.8423 9.38966 14.4702 8.71484 13.8899V20.1399H12.6317C14.0987 20.1399 15.3016 18.9345 15.3016 17.4316V3.88989H11.3848Z',
      fill: 'url(#paint4_linear_21591_382014)',
    }),
    react_1['default'].createElement(
      'defs',
      {
        xmlns: 'http://www.w3.org/2000/svg',
      },
      react_1['default'].createElement(
        'linearGradient',
        {
          id: 'paint0_linear_21591_382014',
          x1: '16.0899',
          y1: '13.0432',
          x2: '22.683',
          y2: '13.0432',
          gradientUnits: 'userSpaceOnUse',
        },
        react_1['default'].createElement('stop', {
          stopColor: '#007940',
        }),
        react_1['default'].createElement('stop', {
          offset: '0.2285',
          stopColor: '#00873F',
        }),
        react_1['default'].createElement('stop', {
          offset: '0.7433',
          stopColor: '#40A737',
        }),
        react_1['default'].createElement('stop', {
          offset: '1',
          stopColor: '#5CB531',
        })
      ),
      react_1['default'].createElement(
        'linearGradient',
        {
          id: 'paint1_linear_21591_382014',
          x1: '16.0901',
          y1: '12.0007',
          x2: '22.6829',
          y2: '12.0007',
          gradientUnits: 'userSpaceOnUse',
        },
        react_1['default'].createElement('stop', {
          stopColor: '#007940',
        }),
        react_1['default'].createElement('stop', {
          offset: '0.2285',
          stopColor: '#00873F',
        }),
        react_1['default'].createElement('stop', {
          offset: '0.7433',
          stopColor: '#40A737',
        }),
        react_1['default'].createElement('stop', {
          offset: '1',
          stopColor: '#5CB531',
        })
      ),
      react_1['default'].createElement(
        'linearGradient',
        {
          id: 'paint2_linear_21591_382014',
          x1: '16.0899',
          y1: '10.8669',
          x2: '22.6824',
          y2: '10.8669',
          gradientUnits: 'userSpaceOnUse',
        },
        react_1['default'].createElement('stop', {
          stopColor: '#007940',
        }),
        react_1['default'].createElement('stop', {
          offset: '0.2285',
          stopColor: '#00873F',
        }),
        react_1['default'].createElement('stop', {
          offset: '0.7433',
          stopColor: '#40A737',
        }),
        react_1['default'].createElement('stop', {
          offset: '1',
          stopColor: '#5CB531',
        })
      ),
      react_1['default'].createElement(
        'linearGradient',
        {
          id: 'paint3_linear_21591_382014',
          x1: '1.33165',
          y1: '12.0007',
          x2: '8.02614',
          y2: '12.0007',
          gradientUnits: 'userSpaceOnUse',
        },
        react_1['default'].createElement('stop', {
          stopColor: '#1F286F',
        }),
        react_1['default'].createElement('stop', {
          offset: '0.4751',
          stopColor: '#004E94',
        }),
        react_1['default'].createElement('stop', {
          offset: '0.8261',
          stopColor: '#0066B1',
        }),
        react_1['default'].createElement('stop', {
          offset: '1',
          stopColor: '#006FBC',
        })
      ),
      react_1['default'].createElement(
        'linearGradient',
        {
          id: 'paint4_linear_21591_382014',
          x1: '8.67672',
          y1: '12.0007',
          x2: '15.1784',
          y2: '12.0007',
          gradientUnits: 'userSpaceOnUse',
        },
        react_1['default'].createElement('stop', {
          stopColor: '#6C2C2F',
        }),
        react_1['default'].createElement('stop', {
          offset: '0.1735',
          stopColor: '#882730',
        }),
        react_1['default'].createElement('stop', {
          offset: '0.5731',
          stopColor: '#BE1833',
        }),
        react_1['default'].createElement('stop', {
          offset: '0.8585',
          stopColor: '#DC0436',
        }),
        react_1['default'].createElement('stop', {
          offset: '1',
          stopColor: '#E60039',
        })
      )
    )
  );
};
JCB.displayName = 'JCB';
exports['default'] = JCB;
