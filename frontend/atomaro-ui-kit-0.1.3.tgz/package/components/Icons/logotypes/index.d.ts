export { default as AmExpress } from './AmExpress';
export { default as Discover } from './Discover';
export { default as JCB } from './JCB';
export { default as Maestro } from './Maestro';
export { default as Mastercard } from './Mastercard';
export { default as Mir } from './Mir';
export { default as UnionPay } from './UnionPay';
export { default as Visa } from './Visa';
