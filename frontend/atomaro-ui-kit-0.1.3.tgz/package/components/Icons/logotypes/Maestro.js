'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var Icon_1 = __importDefault(require('@atomaro/icons/Icon'));
var Maestro = function Maestro(props) {
  return react_1['default'].createElement(
    Icon_1['default'],
    __assign({}, props),
    react_1['default'].createElement('path', {
      xmlns: 'http://www.w3.org/2000/svg',
      d: 'M14.9999 6.60938H9V16.6406H14.9999V6.60938Z',
      fill: '#6C6BBD',
    }),
    react_1['default'].createElement('path', {
      xmlns: 'http://www.w3.org/2000/svg',
      d: 'M9.52123 11.6259C9.52019 10.6603 9.74282 9.70714 10.1723 8.83858C10.6017 7.97002 11.2267 7.20883 12 6.61266C11.0426 5.87355 9.8928 5.41395 8.68205 5.28637C7.4713 5.15879 6.24844 5.36839 5.15322 5.89121C4.058 6.41403 3.13462 7.22897 2.4886 8.24291C1.84259 9.25684 1.5 10.4289 1.5 11.625C1.5 12.8211 1.84259 13.9932 2.4886 15.0071C3.13462 16.021 4.058 16.836 5.15322 17.3588C6.24844 17.8816 7.4713 18.0912 8.68205 17.9636C9.8928 17.8361 11.0426 17.3764 12 16.6373C11.227 16.0414 10.6021 15.2805 10.1727 14.4122C9.74322 13.544 9.52046 12.5912 9.52123 11.6259V11.6259Z',
      fill: '#D32011',
    }),
    react_1['default'].createElement('path', {
      xmlns: 'http://www.w3.org/2000/svg',
      d: 'M22.5 11.6259C22.5 12.822 22.1573 13.9939 21.5113 15.0078C20.8652 16.0216 19.9418 16.8365 18.8465 17.3592C17.7512 17.8818 16.5284 18.0913 15.3177 17.9635C14.1069 17.8358 12.9573 17.376 12 16.6368C12.7726 16.0403 13.3973 15.2793 13.8268 14.4111C14.2563 13.5429 14.4795 12.5903 14.4795 11.625C14.4795 10.6597 14.2563 9.70707 13.8268 8.83889C13.3973 7.97071 12.7726 7.20969 12 6.61324C12.9573 5.87399 14.1069 5.41421 15.3177 5.28646C16.5284 5.15872 17.7512 5.36816 18.8465 5.89084C19.9418 6.41353 20.8652 7.22836 21.5113 8.24222C22.1573 9.25607 22.5 10.428 22.5 11.6241V11.6259Z',
      fill: '#0099DF',
    })
  );
};
Maestro.displayName = 'Maestro';
exports['default'] = Maestro;
