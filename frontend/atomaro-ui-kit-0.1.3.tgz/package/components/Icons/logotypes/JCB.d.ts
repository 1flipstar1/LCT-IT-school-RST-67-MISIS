import React from 'react';
import { IIconProps } from '@atomaro/icons/types';
declare const JCB: {
    (props: IIconProps): React.JSX.Element;
    displayName: string;
};
export default JCB;
