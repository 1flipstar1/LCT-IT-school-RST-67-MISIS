'use strict';
var PropTypes = require('prop-types');

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __createBinding =
  (this && this.__createBinding) ||
  (Object.create
    ? function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ('get' in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = {
            enumerable: true,
            get: function get() {
              return m[k];
            },
          };
        }
        Object.defineProperty(o, k2, desc);
      }
    : function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
      });
var __setModuleDefault =
  (this && this.__setModuleDefault) ||
  (Object.create
    ? function (o, v) {
        Object.defineProperty(o, 'default', {
          enumerable: true,
          value: v,
        });
      }
    : function (o, v) {
        o['default'] = v;
      });
var __importStar =
  (this && this.__importStar) ||
  function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null)
      for (var k in mod)
        if (k !== 'default' && Object.prototype.hasOwnProperty.call(mod, k))
          __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
  };
var __rest =
  (this && this.__rest) ||
  function (s, e) {
    var t = {};
    for (var p in s)
      if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === 'function')
      for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
          t[p[i]] = s[p[i]];
      }
    return t;
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importStar(require('react'));
var AddSmall_1 = __importDefault(require('@atomaro/icons/24/action/AddSmall'));
var RemoveSmall_1 = __importDefault(require('@atomaro/icons/24/action/RemoveSmall'));
var clsx_1 = __importDefault(require('clsx'));
var input_1 = require('../../utils/input');
var useFocus_1 = require('../../hooks/useFocus');
var InputNumberStepper_1 = require('../../utils/InputNumberStepper/InputNumberStepper');
var number_1 = require('../../utils/number');
var function_1 = require('../../utils/function');
require('../../styles/components/inputNumberStepper.scss');
var constants_1 = require('./constants');
var Typography_1 = __importDefault(require('../Typography/Typography'));
var InputNumberStepper = (0, react_1.forwardRef)(function Stepper(props, ref) {
  var _a;
  var _b = props.className,
    className = _b === void 0 ? '' : _b,
    style = props.style,
    // color = DEFAULT_COLOR,
    _c = props.defaultValue,
    // color = DEFAULT_COLOR,
    defaultValue = _c === void 0 ? constants_1.DEFAULT_VALUE : _c,
    disabled = props.disabled,
    error = props.error,
    hint = props.hint,
    leftIcon = props.leftIcon,
    min = props.min,
    max = props.max,
    rightIcon = props.rightIcon,
    _d = props.size,
    size = _d === void 0 ? constants_1.DEFAULT_SIZE : _d,
    _e = props.variant,
    variant = _e === void 0 ? constants_1.DEFAULT_VARIANT : _e,
    _f = props.step,
    step = _f === void 0 ? constants_1.DEFAULT_STEP : _f,
    value = props.value,
    _g = props.onLeftClick,
    onLeftClick = _g === void 0 ? function_1.noop : _g,
    _h = props.onRightClick,
    onRightClick = _h === void 0 ? function_1.noop : _h,
    _j = props.onChange,
    onChange = _j === void 0 ? function_1.noop : _j,
    otherProps = __rest(props, [
      'className',
      'style',
      'defaultValue',
      'disabled',
      'error',
      'hint',
      'leftIcon',
      'min',
      'max',
      'rightIcon',
      'size',
      'variant',
      'step',
      'value',
      'onLeftClick',
      'onRightClick',
      'onChange',
    ]);
  var containerRef = (0, react_1.useRef)(null);
  // const baseColorFromProps = useGetBaseColorFromProps(color);
  var checkedDefaultValue = (0, react_1.useMemo)(
    function () {
      return (0, InputNumberStepper_1.getDisplayValue)((0, number_1.clamp)(defaultValue, min, max));
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  );
  var displayLeftIcon =
    leftIcon || react_1['default'].createElement(RemoveSmall_1['default'], null);
  var displayRightIcon = rightIcon || react_1['default'].createElement(AddSmall_1['default'], null);
  var additionalText = error || hint;
  var _k = (0, useFocus_1.useFocus)({}),
    focused = _k.focused,
    onBlur = _k.onBlur,
    onFocus = _k.onFocus;
  var _l = (0, react_1.useState)(constants_1.DEFAULT_DISABLED_STATE),
    _m = _l[0],
    isAllDisabled = _m.isAllDisabled,
    isLeftDisabled = _m.isLeftDisabled,
    isRightDisabled = _m.isRightDisabled,
    setDisabled = _l[1];
  var _o = (0, react_1.useState)(0),
    hintWidth = _o[0],
    setHintWidth = _o[1];
  var _p = (0, react_1.useState)(checkedDefaultValue),
    inputValue = _p[0],
    setInputValue = _p[1];
  // TODO: Сделать обработку ввода минуса
  var handleChange = (0, react_1.useCallback)(
    function (event) {
      var input = event.target;
      var currentValue = Number(input.value.replace(/[^\d]/g, ''));
      var displayValue = (0, InputNumberStepper_1.getDisplayValue)(currentValue);
      if (
        !(0, number_1.withinTheInterval)(currentValue, min, max) ||
        !(0, InputNumberStepper_1.checkNumStepperValLength)(displayValue)
      ) {
        if (max && currentValue > max) {
          setInputValue((0, InputNumberStepper_1.getDisplayValue)(max));
          (0, input_1.correctCaretPosition)(input);
          onChange(max);
        } else if (min && currentValue < min) {
          setInputValue((0, InputNumberStepper_1.getDisplayValue)(min));
          (0, input_1.correctCaretPosition)(input);
          onChange(min);
        }
        return;
      }
      setInputValue(displayValue);
      (0, input_1.correctCaretPosition)(input);
      onChange(currentValue);
    },
    [max, min, onChange]
  );
  var handleLeftClick = (0, react_1.useCallback)(
    function () {
      onLeftClick();
      var prevNumVal = (0, InputNumberStepper_1.displayValToNumberVal)(inputValue);
      var newNumValue = prevNumVal - step;
      if (min) {
        newNumValue = (0, number_1.clamp)(newNumValue, min, prevNumVal);
      }
      var newInputValue = (0, InputNumberStepper_1.getDisplayValue)(newNumValue);
      if (!(0, InputNumberStepper_1.checkNumStepperValLength)(newInputValue)) {
        return;
      }
      setInputValue(newInputValue);
      onChange(newNumValue);
    },
    [inputValue, min, step, onChange, onLeftClick]
  );
  var handleRightClick = (0, react_1.useCallback)(
    function () {
      onRightClick();
      var prevNumVal = (0, InputNumberStepper_1.displayValToNumberVal)(inputValue);
      var newNumValue = prevNumVal + step;
      if (max) {
        newNumValue = (0, number_1.clamp)(newNumValue, prevNumVal, max);
      }
      var newInputValue = (0, InputNumberStepper_1.getDisplayValue)(newNumValue);
      if (!(0, InputNumberStepper_1.checkNumStepperValLength)(newInputValue)) {
        return;
      }
      setInputValue(newInputValue);
      onChange(newNumValue);
    },
    [inputValue, max, step, onChange, onRightClick]
  );
  // Обработка disabled из пропсов и при наличии min/max
  (0, react_1.useEffect)(
    function () {
      var allDisabled = disabled === constants_1.NUMBER_STEPPER_DISABLED.all;
      var val = (0, InputNumberStepper_1.displayValToNumberVal)(inputValue);
      setDisabled({
        isAllDisabled: allDisabled,
        isLeftDisabled:
          allDisabled || disabled === constants_1.NUMBER_STEPPER_DISABLED.left || val === min,
        isRightDisabled:
          allDisabled || disabled === constants_1.NUMBER_STEPPER_DISABLED.right || val === max,
      });
      // eslint-disable-next-line react-hooks/exhaustive-deps
    },
    [disabled, inputValue, min, max]
  );
  // Обработка value из пропсов
  (0, react_1.useEffect)(
    function () {
      if (
        typeof value === 'number' &&
        (0, InputNumberStepper_1.getDisplayValue)(value) !== inputValue
      ) {
        var displayValue = (0, InputNumberStepper_1.getDisplayValue)(
          (0, number_1.clamp)(value, min, max)
        );
        setInputValue(displayValue);
      }
      // eslint-disable-next-line react-hooks/exhaustive-deps
    },
    [value]
  );
  // Расчет ширины хинта в зависимости от изменения ширины контейнера
  (0, react_1.useEffect)(
    function () {
      if (!containerRef.current) {
        return;
      }
      var width = containerRef.current.getBoundingClientRect().width;
      if (hintWidth !== width) {
        setHintWidth(width);
      }
      // eslint-disable-next-line react-hooks/exhaustive-deps
    },
    [inputValue]
  );
  var rootClassName = (0, clsx_1['default'])(
    'number-stepper',
    'number-stepper--'.concat(constants_1.NUMBER_STEPPER_VARIANTS[variant]),
    'number-stepper--size-'.concat(constants_1.NUMBER_STEPPER_SIZES[size]),
    'number-stepper--size-'.concat(constants_1.NUMBER_STEPPER_SIZES[size]),
    ((_a = {}),
    (_a['number-stepper--disabled'] = isAllDisabled),
    (_a['number-stepper--error'] = error),
    (_a['number-stepper--focused'] = focused),
    _a),
    className
  );
  return react_1['default'].createElement(
    'div',
    {
      className: rootClassName,
      style: style,
      onTouchStart: function_1.noop,
    },
    react_1['default'].createElement(
      'div',
      {
        className: 'number-stepper__inner',
        ref: containerRef,
      },
      react_1['default'].createElement(
        'button',
        {
          type: 'button',
          className: 'number-stepper__button number-stepper__button--decrement',
          disabled: isLeftDisabled || isAllDisabled,
          onClick: handleLeftClick,
        },
        displayLeftIcon
      ),
      react_1['default'].createElement(
        'input',
        __assign(
          {
            ref: ref,
            type: 'text',
            className: 'number-stepper__input',
            disabled: isAllDisabled,
            value: inputValue,
            size: inputValue === null || inputValue === void 0 ? void 0 : inputValue.length,
            onFocus: onFocus,
            onBlur: onBlur,
            onChange: handleChange,
          },
          otherProps
        )
      ),
      react_1['default'].createElement(
        'button',
        {
          type: 'button',
          className: 'number-stepper__button number-stepper__button--increment',
          disabled: isRightDisabled || isAllDisabled,
          onClick: handleRightClick,
        },
        displayRightIcon
      )
    ),
    additionalText
      ? react_1['default'].createElement(
          Typography_1['default'],
          {
            className: 'number-stepper__hint',
            variant: 'caption',
            style: {
              maxWidth: hintWidth,
            },
            isStatic: true,
          },
          additionalText
        )
      : null
  );
});

InputNumberStepper.propTypes = {
  /**
   * Задает дополнительные классы для элемента
   */
  className: PropTypes.string,
  /**
   * Задает значение по умолчанию
   * @default 0
   */
  defaultValue: PropTypes.number,
  /**
   * Устанавливает атрибут disabled
   */
  disabled: PropTypes.oneOf(['all', 'left', 'right']),
  /**
   * Устанавливает текст ошибки
   */
  error: PropTypes.string,
  /**
   * Устанавливает пояснительный текст
   */
  hint: PropTypes.string,
  /**
   * Устанавливает кастомную иконку для левой кнопки
   */
  leftIcon: PropTypes.node,
  /**
   * Устанавливает максимальное допустимое значение
   */
  max: PropTypes.number,
  /**
   * Устанавливает минимальное допустимое значение
   */
  min: PropTypes.number,
  /**
   * Callback функция, вызываемая при изменении значения
   * @returns {undefined}
   */
  onChange: PropTypes.func,
  /**
   * Callback функция, вызываемая при нажатии на левую кнопку
   * @returns {undefined}
   */
  onLeftClick: PropTypes.func,
  /**
   * Callback функция, вызываемая при нажатии на правую кнопку
   * @returns {undefined}
   */
  onRightClick: PropTypes.func,
  /**
   * Устанавливает кастомную иконку для правой кнопки
   */
  rightIcon: PropTypes.node,
  /**
   * Задает размер компонента
   * @default medium
   */
  size: PropTypes.oneOf(['l', 'm']),
  /**
   * Задает шаг увеличения/уменьшения значения
   * @default 1
   */
  step: PropTypes.number,
  /**
   * Задает дополнительные стили для компонента
   */
  style: PropTypes.object,
  /**
   * Устанавливает значение для компонента
   */
  value: PropTypes.number,
  /**
   * Задает внешний вид
   *  @default primary
   */
  variant: PropTypes.oneOf(['primary']),
};

InputNumberStepper.displayName = 'InputNumberStepper';
exports['default'] = InputNumberStepper;
