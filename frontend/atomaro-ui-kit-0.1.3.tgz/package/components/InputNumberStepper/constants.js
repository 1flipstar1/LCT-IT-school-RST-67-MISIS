'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.DEFAULT_VARIANT =
  exports.DEFAULT_SIZE =
  exports.NUMBER_STEPPER_VARIANTS =
  exports.NUMBER_STEPPER_SIZES =
  exports.NUMBER_STEPPER_DISABLED =
  exports.MAX_LENGTH_FOR_CORRECT_DISPLAY_VAL =
  exports.NUMBER_STEPPER_VAL_MAX_LENGTH =
  exports.DEFAULT_DISABLED_STATE =
  exports.DEFAULT_STEP =
  exports.DEFAULT_VALUE =
    void 0;
exports.DEFAULT_VALUE = 0;
exports.DEFAULT_STEP = 1;
exports.DEFAULT_DISABLED_STATE = {
  isAllDisabled: false,
  isLeftDisabled: false,
  isRightDisabled: false,
};
exports.NUMBER_STEPPER_VAL_MAX_LENGTH = 20;
exports.MAX_LENGTH_FOR_CORRECT_DISPLAY_VAL = 13;
var NUMBER_STEPPER_DISABLED;
(function (NUMBER_STEPPER_DISABLED) {
  NUMBER_STEPPER_DISABLED['all'] = 'all';
  NUMBER_STEPPER_DISABLED['left'] = 'left';
  NUMBER_STEPPER_DISABLED['right'] = 'right';
})(
  (NUMBER_STEPPER_DISABLED =
    exports.NUMBER_STEPPER_DISABLED || (exports.NUMBER_STEPPER_DISABLED = {}))
);
var NUMBER_STEPPER_SIZES;
(function (NUMBER_STEPPER_SIZES) {
  NUMBER_STEPPER_SIZES['m'] = 'm';
  NUMBER_STEPPER_SIZES['l'] = 'l';
})((NUMBER_STEPPER_SIZES = exports.NUMBER_STEPPER_SIZES || (exports.NUMBER_STEPPER_SIZES = {})));
var NUMBER_STEPPER_VARIANTS;
(function (NUMBER_STEPPER_VARIANTS) {
  NUMBER_STEPPER_VARIANTS['primary'] = 'primary';
})(
  (NUMBER_STEPPER_VARIANTS =
    exports.NUMBER_STEPPER_VARIANTS || (exports.NUMBER_STEPPER_VARIANTS = {}))
);
exports.DEFAULT_SIZE = NUMBER_STEPPER_SIZES.m;
exports.DEFAULT_VARIANT = NUMBER_STEPPER_VARIANTS.primary;
