export declare const DEFAULT_VALUE = 0;
export declare const DEFAULT_STEP = 1;
export declare const DEFAULT_DISABLED_STATE: {
    isAllDisabled: boolean;
    isLeftDisabled: boolean;
    isRightDisabled: boolean;
};
export declare const NUMBER_STEPPER_VAL_MAX_LENGTH = 20;
export declare const MAX_LENGTH_FOR_CORRECT_DISPLAY_VAL = 13;
export declare enum NUMBER_STEPPER_DISABLED {
    all = "all",
    left = "left",
    right = "right"
}
export declare enum NUMBER_STEPPER_SIZES {
    m = "m",
    l = "l"
}
export declare enum NUMBER_STEPPER_VARIANTS {
    primary = "primary"
}
export declare const DEFAULT_SIZE = NUMBER_STEPPER_SIZES.m;
export declare const DEFAULT_VARIANT = NUMBER_STEPPER_VARIANTS.primary;
