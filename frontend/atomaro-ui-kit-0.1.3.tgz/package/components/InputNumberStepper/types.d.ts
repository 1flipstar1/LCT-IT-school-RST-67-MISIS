import { ReactNode, InputHTMLAttributes, CSSProperties } from 'react';
import { NUMBER_STEPPER_VARIANTS, NUMBER_STEPPER_SIZES, NUMBER_STEPPER_DISABLED } from './constants';
export type StepperDisabledType = keyof typeof NUMBER_STEPPER_DISABLED;
export type StepperSizesType = keyof typeof NUMBER_STEPPER_SIZES;
export type StepperVariantsType = keyof typeof NUMBER_STEPPER_VARIANTS;
export interface IInputNumberStepperProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'onChange' | 'type' | 'disabled' | 'size'> {
    /** Задает внешний вид
     *  @default primary */
    variant?: StepperVariantsType;
    /** Задает значение по умолчанию
     * @default 0
     */
    defaultValue?: number;
    /** Устанавливает атрибут disabled */
    disabled?: StepperDisabledType;
    /** Устанавливает текст ошибки */
    error?: string;
    /** Устанавливает пояснительный текст */
    hint?: string;
    /** Устанавливает кастомную иконку для левой кнопки */
    leftIcon?: ReactNode;
    /** Устанавливает минимальное допустимое значение */
    min?: number;
    /** Устанавливает максимальное допустимое значение */
    max?: number;
    /** Устанавливает кастомную иконку для правой кнопки */
    rightIcon?: ReactNode;
    /** Задает размер компонента
     * @default medium
     */
    size?: StepperSizesType;
    /** Задает шаг увеличения/уменьшения значения
     * @default 1
     */
    step?: number;
    /** Устанавливает значение для компонента */
    value?: number;
    /** Callback функция, вызываемая при нажатии на левую кнопку
     * @returns {undefined}
     */
    onLeftClick?: () => void;
    /** Callback функция, вызываемая при нажатии на правую кнопку
     * @returns {undefined}
     */
    onRightClick?: () => void;
    /** Callback функция, вызываемая при изменении значения
     * @returns {undefined}
     */
    onChange?: (value: number) => void;
    /** Задает дополнительные классы для элемента */
    className?: string;
    /** Задает дополнительные стили для компонента */
    style?: CSSProperties;
}
export type DisabledType = {
    isAllDisabled: boolean;
    isLeftDisabled: boolean;
    isRightDisabled: boolean;
};
export type NumberStepperContainerPropsType = {
    disabled: boolean;
    size: StepperSizesType;
    isFocused: boolean;
    color?: string;
    error?: string;
};
export type NumberStepperBtnPropsType = Pick<NumberStepperContainerPropsType, 'disabled' | 'size'> & {
    order: number;
    type: 'left' | 'right';
};
export type NumberStepperInputPropsType = NumberStepperContainerPropsType & {
    $stepperSize: StepperSizesType;
    size: number;
    disabled?: boolean;
};
export type NumberStepperHintPropsType = Pick<NumberStepperContainerPropsType, 'error' | 'disabled'> & {
    width: number;
};
