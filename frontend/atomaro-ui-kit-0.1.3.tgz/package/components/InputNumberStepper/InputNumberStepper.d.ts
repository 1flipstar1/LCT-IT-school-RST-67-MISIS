import React from 'react';
import '../../styles/components/inputNumberStepper.scss';
import { IInputNumberStepperProps } from './types';
declare const InputNumberStepper: React.FC<IInputNumberStepperProps>;
export default InputNumberStepper;
