export declare enum DRAWER_POSITION {
    top = "top",
    right = "right",
    bottom = "bottom",
    left = "left"
}
