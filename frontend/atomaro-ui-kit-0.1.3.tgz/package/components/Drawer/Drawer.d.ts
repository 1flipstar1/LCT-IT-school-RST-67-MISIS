import { FC } from 'react';
import { IDrawer } from './types';
import '../../styles/components/drawer.scss';
declare const Drawer: FC<IDrawer>;
export default Drawer;
