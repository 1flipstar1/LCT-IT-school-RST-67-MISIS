import { CSSProperties, ReactNode } from 'react';
import { DRAWER_POSITION } from './constats';
import { OverlayVariantType } from '../Overlay/constants';
export interface IDrawer {
    /** Задает открытие панели */
    open?: boolean;
    /** Callback функция, вызываемая при закрытии панели */
    onClose?: () => void;
    /** Задает расположение панели */
    position?: DrawerPositionType;
    /** Задает отображение overlay при открытой панели */
    showOverlay?: boolean;
    /** Задает тип overlay при открытой панели */
    overlayVariant?: OverlayVariantType;
    /** Callback функция, вызываемая при клике на Overlay */
    onClickOverlay?: () => void;
    /** Задает использование в Portal
     *  @default true */
    useInPortal?: boolean;
    /** Задает ширину и высоту в зависимости от позиции размещения панели */
    dimension?: number;
    /** Задает дополнительные стили для компонента */
    style?: CSSProperties;
    children?: ReactNode;
}
export type DrawerPositionType = keyof typeof DRAWER_POSITION;
