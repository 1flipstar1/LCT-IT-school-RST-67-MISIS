'use strict';
var PropTypes = require('prop-types');

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var react_transition_group_1 = require('react-transition-group');
var react_dom_1 = require('react-dom');
var clsx_1 = __importDefault(require('clsx'));
var constats_1 = require('./constats');
var function_1 = require('../../utils/function');
var constants_1 = require('../Overlay/constants');
var Overlay_1 = __importDefault(require('../Overlay/Overlay'));
require('../../styles/components/drawer.scss');
var Drawer = function Drawer(props) {
  var open = props.open,
    _a = props.overlayVariant,
    overlayVariant = _a === void 0 ? constants_1.OVERLAY_VARIANTS.primary : _a,
    _b = props.showOverlay,
    showOverlay = _b === void 0 ? true : _b,
    _c = props.onClickOverlay,
    onClickOverlay = _c === void 0 ? function_1.noop : _c,
    _d = props.position,
    position = _d === void 0 ? constats_1.DRAWER_POSITION.right : _d,
    dimension = props.dimension,
    style = props.style,
    _e = props.useInPortal,
    useInPortal = _e === void 0 ? true : _e,
    children = props.children;
  var rootClassName = function rootClassName(transitionState) {
    return (0, clsx_1['default'])(
      'drawer',
      'drawer--'.concat(transitionState),
      'drawer--'.concat(position)
    );
  };
  var renderDrawer = function renderDrawer(transitionState) {
    return react_1['default'].createElement(
      'div',
      {
        className: rootClassName(transitionState),
        // @ts-ignore
        style: __assign(
          {
            '--drawer-dimension': dimension ? ''.concat(dimension, 'px') : 'auto',
          },
          style
        ),
      },
      children
    );
  };
  return react_1['default'].createElement(
    react_transition_group_1.Transition,
    {
      in: open,
      timeout: 300,
      mountOnEnter: true,
      unmountOnExit: true,
    },
    function (state) {
      return react_1['default'].createElement(
        react_1['default'].Fragment,
        null,
        react_1['default'].createElement(Overlay_1['default'], {
          variant: overlayVariant,
          onClick: onClickOverlay,
          isOpened: showOverlay && open,
        }),
        useInPortal
          ? (0, react_dom_1.createPortal)(renderDrawer(state), document.body)
          : renderDrawer(state)
      );
    }
  );
};

Drawer.propTypes = {
  children: PropTypes.node,
  /**
   * Задает ширину и высоту в зависимости от позиции размещения панели
   */
  dimension: PropTypes.number,
  /**
   * Callback функция, вызываемая при клике на Overlay
   */
  onClickOverlay: PropTypes.func,
  /**
   * Задает открытие панели
   */
  open: PropTypes.bool,
  /**
   * Задает тип overlay при открытой панели
   */
  overlayVariant: PropTypes.oneOf(['primary', 'secondary']),
  /**
   * Задает расположение панели
   */
  position: PropTypes.oneOf(['bottom', 'left', 'right', 'top']),
  /**
   * Задает отображение overlay при открытой панели
   */
  showOverlay: PropTypes.bool,
  /**
   * Задает дополнительные стили для компонента
   */
  style: PropTypes.object,
  /**
   * Задает использование в Portal
   *  @default true
   */
  useInPortal: PropTypes.bool,
};

Drawer.displayName = 'Drawer';
exports['default'] = Drawer;
