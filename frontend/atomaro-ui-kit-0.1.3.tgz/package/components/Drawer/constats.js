"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.DRAWER_POSITION = void 0;
var DRAWER_POSITION;
(function (DRAWER_POSITION) {
  DRAWER_POSITION["top"] = "top";
  DRAWER_POSITION["right"] = "right";
  DRAWER_POSITION["bottom"] = "bottom";
  DRAWER_POSITION["left"] = "left";
})(DRAWER_POSITION = exports.DRAWER_POSITION || (exports.DRAWER_POSITION = {}));