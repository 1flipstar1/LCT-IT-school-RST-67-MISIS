import { PLACEMENTS } from '../../hooks/usePopper/constants';
export declare enum TRIGGERS {
    click = "click",
    hover = "hover"
}
export declare enum POPOVER_SIZES {
    m = "m"
}
export declare enum POPOVER_VARIANTS {
    primary = "primary"
}
export declare const ADDITIONAL_OFFSET = 4;
export declare const DEFAULT_SIZE = POPOVER_SIZES.m;
export declare const DEFAULT_PLACEMENT = PLACEMENTS.auto;
export declare const DEFAULT_TRIGGER = TRIGGERS.click;
export declare const DEFAULT_VARIANT = POPOVER_VARIANTS.primary;
