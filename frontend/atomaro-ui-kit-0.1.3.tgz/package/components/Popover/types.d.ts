import React from 'react';
import { POPOVER_SIZES, POPOVER_VARIANTS, TRIGGERS } from './constants';
import { PlacementsType, UsePopperProps } from '../../hooks/usePopper/types';
export interface IPopoverProps extends React.HTMLAttributes<HTMLDivElement> {
    /** Задает внутренний компонент */
    innerChildren?: React.ReactNode;
    /** Задает расположение для отображения
     *  @default auto */
    placement?: PlacementsType;
    /** Задаёт вид компонента
     *  @default primary */
    variant?: VariantsType;
    /** Задаёт размер элемента
     *  @default m */
    size?: SizesType;
    /** Задает отображение поинтера (стрелки)
     *  @default true */
    pointer?: boolean;
    /** Задаёт отступ для поинтера (стрелки) от края поповера (не применяется при placement top, bottom, right, left)
     *  @default 0 */
    arrowPadding?: number;
    /** Задаёт смещение поповера относительно родительского компонента по основной оси */
    offset?: number;
    /** Задаёт смещение поповера относительно родительского компонента по поперченой оси (не применяется при placement top, bottom, right, left) */
    offsetCounterAxis?: number;
    /** Задает событие триггер для отображения
     *  @default click */
    trigger?: PopoverTriggersType;
    /** Запрещает показывать popover
     *  @default false */
    disabled?: boolean;
    /** Показывает поповер */
    isOpened?: boolean;
    /** Callback-функция, вызываемая при появлении поповера */
    onOpen?: (e: React.MouseEvent<HTMLElement>) => void;
    /** Callback-функция, вызываемая при закрытии поповера */
    onClose?: () => void;
    /** Задаёт вариант использования с React Portal
     * @default true */
    useInPortal?: boolean;
    /** Задаёт параметры для poppper.js */
    usePopperProps?: UsePopperProps;
    /** Центририровать pointer на родительский компонент
     *  @default "false" */
    pointerIsCentered?: boolean;
}
export type PopoverTriggersType = keyof typeof TRIGGERS;
export type VariantsType = keyof typeof POPOVER_VARIANTS;
export type SizesType = keyof typeof POPOVER_SIZES;
