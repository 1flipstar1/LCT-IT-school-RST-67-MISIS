"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.DEFAULT_VARIANT = exports.DEFAULT_TRIGGER = exports.DEFAULT_PLACEMENT = exports.DEFAULT_SIZE = exports.ADDITIONAL_OFFSET = exports.POPOVER_VARIANTS = exports.POPOVER_SIZES = exports.TRIGGERS = void 0;
var constants_1 = require("../../hooks/usePopper/constants");
var TRIGGERS;
(function (TRIGGERS) {
  TRIGGERS["click"] = "click";
  TRIGGERS["hover"] = "hover";
})(TRIGGERS = exports.TRIGGERS || (exports.TRIGGERS = {}));
var POPOVER_SIZES;
(function (POPOVER_SIZES) {
  POPOVER_SIZES["m"] = "m";
})(POPOVER_SIZES = exports.POPOVER_SIZES || (exports.POPOVER_SIZES = {}));
var POPOVER_VARIANTS;
(function (POPOVER_VARIANTS) {
  POPOVER_VARIANTS["primary"] = "primary";
})(POPOVER_VARIANTS = exports.POPOVER_VARIANTS || (exports.POPOVER_VARIANTS = {}));
exports.ADDITIONAL_OFFSET = 4;
exports.DEFAULT_SIZE = POPOVER_SIZES.m;
exports.DEFAULT_PLACEMENT = constants_1.PLACEMENTS.auto;
exports.DEFAULT_TRIGGER = TRIGGERS.click;
exports.DEFAULT_VARIANT = POPOVER_VARIANTS.primary;