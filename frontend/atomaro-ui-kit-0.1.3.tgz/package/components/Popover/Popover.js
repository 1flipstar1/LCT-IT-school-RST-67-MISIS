'use strict';
var PropTypes = require('prop-types');

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __createBinding =
  (this && this.__createBinding) ||
  (Object.create
    ? function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ('get' in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = {
            enumerable: true,
            get: function get() {
              return m[k];
            },
          };
        }
        Object.defineProperty(o, k2, desc);
      }
    : function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
      });
var __setModuleDefault =
  (this && this.__setModuleDefault) ||
  (Object.create
    ? function (o, v) {
        Object.defineProperty(o, 'default', {
          enumerable: true,
          value: v,
        });
      }
    : function (o, v) {
        o['default'] = v;
      });
var __importStar =
  (this && this.__importStar) ||
  function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null)
      for (var k in mod)
        if (k !== 'default' && Object.prototype.hasOwnProperty.call(mod, k))
          __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
  };
var __rest =
  (this && this.__rest) ||
  function (s, e) {
    var t = {};
    for (var p in s)
      if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === 'function')
      for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
          t[p[i]] = s[p[i]];
      }
    return t;
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importStar(require('react'));
var react_dom_1 = require('react-dom');
var clsx_1 = __importDefault(require('clsx'));
require('../../styles/components/popover.scss');
var constants_1 = require('./constants');
var getValueFromCssVariable_1 = require('../../utils/getValueFromCssVariable');
var usePopper_1 = require('../../hooks/usePopper/usePopper');
var useOutsideClick_1 = __importDefault(require('../../hooks/useOutsideClick'));
var noop_1 = require('../../utils/noop');
var Popover = function Popover(props) {
  var _a = props.placement,
    placement = _a === void 0 ? constants_1.DEFAULT_PLACEMENT : _a,
    _b = props.innerChildren,
    innerChildren = _b === void 0 ? null : _b,
    _c = props.variant,
    variant = _c === void 0 ? constants_1.DEFAULT_VARIANT : _c,
    _d = props.size,
    size = _d === void 0 ? constants_1.DEFAULT_SIZE : _d,
    isOpened = props.isOpened,
    _e = props.onClose,
    onClose = _e === void 0 ? noop_1.noop : _e,
    _f = props.onOpen,
    onOpen = _f === void 0 ? noop_1.noop : _f,
    _g = props.pointer,
    pointer = _g === void 0 ? true : _g,
    _h = props.disabled,
    disabled = _h === void 0 ? false : _h,
    _j = props.trigger,
    trigger = _j === void 0 ? constants_1.DEFAULT_TRIGGER : _j,
    _k = props.useInPortal,
    useInPortal = _k === void 0 ? true : _k,
    offset = props.offset,
    offsetCounterAxis = props.offsetCounterAxis,
    arrowPadding = props.arrowPadding,
    className = props.className,
    children = props.children,
    pointerIsCentered = props.pointerIsCentered,
    usePopperProps = props.usePopperProps,
    restProps = __rest(props, [
      'placement',
      'innerChildren',
      'variant',
      'size',
      'isOpened',
      'onClose',
      'onOpen',
      'pointer',
      'disabled',
      'trigger',
      'useInPortal',
      'offset',
      'offsetCounterAxis',
      'arrowPadding',
      'className',
      'children',
      'pointerIsCentered',
      'usePopperProps',
    ]);
  var popoverRef = (0, react_1.useRef)();
  var popoverTriggerRef = (0, react_1.useRef)();
  var _l = (0, react_1.useState)(false),
    open = _l[0],
    setOpen = _l[1];
  var pointerOffsetVar = (0, getValueFromCssVariable_1.getValueFromCssVariable)(
    '--popover-'.concat(size, '-pointer-offset')
  );
  var formattedPointerOffset = parseFloat(pointerOffsetVar);
  var pointerHeigth = (0, getValueFromCssVariable_1.getValueFromCssVariable)(
    '--popover-'.concat(size, '-pointer-height')
  );
  var formattedPointerHeigth = parseFloat(pointerHeigth);
  var _m = (0, usePopper_1.usePopper)(
      __assign(
        {
          enabled: open,
          placement: placement,
          popper: popoverRef === null || popoverRef === void 0 ? void 0 : popoverRef.current,
          trigger:
            popoverTriggerRef === null || popoverTriggerRef === void 0
              ? void 0
              : popoverTriggerRef.current,
          eventListeners: open,
          arrowPadding:
            arrowPadding !== null && arrowPadding !== void 0
              ? arrowPadding
              : formattedPointerOffset,
          offset:
            offset !== null && offset !== void 0
              ? offset
              : formattedPointerHeigth + constants_1.ADDITIONAL_OFFSET,
          offsetCounterAxis: offsetCounterAxis,
          pointerIsCentered: pointerIsCentered,
        },
        usePopperProps
      )
    ),
    getArrowProps = _m.getArrowProps,
    getArrowInnerProps = _m.getArrowInnerProps;
  (0, react_1.useEffect)(
    function () {
      if (isOpened) {
        setOpen(isOpened);
      } else {
        setOpen(false);
      }
      // eslint-disable-next-line react-hooks/exhaustive-deps
    },
    [isOpened]
  );
  var showPopover = function showPopover(e) {
    if (innerChildren && !disabled && isOpened !== true) {
      setOpen(true);
      onOpen(e);
    }
  };
  var hidePopover = (0, react_1.useCallback)(
    function () {
      onClose();
      setOpen(false);
    },
    [onClose]
  );
  (0, useOutsideClick_1['default'])(popoverRef, function (target) {
    if (!popoverTriggerRef.current.contains(target)) {
      hidePopover();
    }
  });
  (0, react_1.useEffect)(function () {
    window.addEventListener('scroll', hidePopover);
    window.addEventListener('resize', hidePopover);
    return function () {
      window.removeEventListener('scroll', hidePopover);
      window.removeEventListener('resize', hidePopover);
    };
  });
  var popoverClassName = (0, clsx_1['default'])(
    'popover',
    'popover--'.concat(constants_1.POPOVER_VARIANTS[variant]),
    'popover--size-'.concat(constants_1.POPOVER_SIZES[size]),
    className
  );
  var renderArrow = react_1['default'].createElement(
    'div',
    __assign(
      {
        className: 'popover__pointer_wrapper',
      },
      getArrowProps()
    ),
    react_1['default'].createElement(
      'div',
      __assign(
        {
          className: 'popover__pointer',
        },
        getArrowInnerProps()
      )
    )
  );
  var renderPopover = react_1['default'].createElement(
    'div',
    __assign(
      {
        ref: popoverRef,
        className: popoverClassName,
        'data-show': open,
      },
      restProps
    ),
    innerChildren,
    pointer && renderArrow
  );
  return react_1['default'].createElement(
    'div',
    {
      className: 'popover__root',
    },
    react_1['default'].createElement(
      'div',
      {
        'aria-hidden': true,
        ref: popoverTriggerRef,
        className: 'popover_trigger',
        onClick: function onClick(e) {
          return trigger === constants_1.TRIGGERS.click && showPopover(e);
        },
        onMouseEnter: function onMouseEnter(e) {
          return trigger === constants_1.TRIGGERS.hover && showPopover(e);
        },
        onMouseLeave: function onMouseLeave() {
          return trigger === constants_1.TRIGGERS.hover && hidePopover();
        },
      },
      children
    ),
    useInPortal ? (0, react_dom_1.createPortal)(renderPopover, document.body) : renderPopover
  );
};

Popover.propTypes = {
  /**
   * Задаёт отступ для поинтера (стрелки) от края поповера (не применяется при placement top, bottom, right, left)
   *  @default 0
   */
  arrowPadding: PropTypes.number,
  children: PropTypes.node,
  className: PropTypes.string,
  /**
   * Запрещает показывать popover
   *  @default false
   */
  disabled: PropTypes.bool,
  /**
   * Задает внутренний компонент
   */
  innerChildren: PropTypes.node,
  /**
   * Показывает поповер
   */
  isOpened: PropTypes.bool,
  /**
   * Задаёт смещение поповера относительно родительского компонента по основной оси
   */
  offset: PropTypes.number,
  /**
   * Задаёт смещение поповера относительно родительского компонента по поперченой оси (не применяется при placement top, bottom, right, left)
   */
  offsetCounterAxis: PropTypes.number,
  /**
   * Callback-функция, вызываемая при закрытии поповера
   */
  onClose: PropTypes.func,
  /**
   * Callback-функция, вызываемая при появлении поповера
   */
  onOpen: PropTypes.func,
  /**
   * Задает расположение для отображения
   *  @default auto
   */
  placement: PropTypes.oneOf([
    'auto',
    'bottom',
    'bottomLeft',
    'bottomRight',
    'left',
    'leftBottom',
    'leftTop',
    'right',
    'rightBottom',
    'rightTop',
    'top',
    'topLeft',
    'topRight',
  ]),
  /**
   * Задает отображение поинтера (стрелки)
   *  @default true
   */
  pointer: PropTypes.bool,
  /**
   * Центририровать pointer на родительский компонент
   *  @default "false"
   */
  pointerIsCentered: PropTypes.bool,
  /**
   * Задаёт размер элемента
   *  @default m
   */
  size: PropTypes.oneOf(['m']),
  /**
   * Задает событие триггер для отображения
   *  @default click
   */
  trigger: PropTypes.oneOf(['click', 'hover']),
  /**
   * Задаёт вариант использования с React Portal
   * @default true
   */
  useInPortal: PropTypes.bool,
  /**
   * Задаёт параметры для poppper.js
   */
  usePopperProps: PropTypes.shape({
    /**
     * Задаёт отступ для поинтера (стрелки) от края поппера (не применяется при placement up, down, right, left)
     *  @default 0
     */
    arrowPadding: PropTypes.number,
    /**
     * Задаёт область для preventOverflow
     *  @default 'clippingParents'
     */
    boundary: PropTypes.oneOfType([
      PropTypes.oneOf(['clippingParents', 'scrollParent']),
      function (props, propName) {
        if (props[propName] == null) {
          return new Error("Prop '" + propName + "' is required but wasn't specified");
        } else if (typeof props[propName] !== 'object' || props[propName].nodeType !== 1) {
          return new Error("Expected prop '" + propName + "' to be of type Element");
        }
      },
    ]),
    /**
     * Включает popper.js для позиционирования
     *  @default "true"
     */
    enabled: PropTypes.bool,
    /**
     * При включении, тултип будет обновлять позицию при scroll, resize
     *  @default "false"
     */
    eventListeners: PropTypes.bool,
    /**
     * При включении, тултип будет менять своё положение на противоположное при нехватке места для отображения
     *  @default "true"
     */
    flip: PropTypes.bool,
    /**
     * Задаёт модификаторы Popper.js
     */
    modifiers: PropTypes.arrayOf(
      PropTypes.shape({
        data: PropTypes.object,
        effect: PropTypes.func,
        enabled: PropTypes.bool,
        fn: PropTypes.func,
        name: PropTypes.string,
        options: PropTypes.object,
        phase: PropTypes.oneOf([
          'afterMain',
          'afterRead',
          'afterWrite',
          'beforeMain',
          'beforeRead',
          'beforeWrite',
          'main',
          'read',
          'write',
        ]),
        requires: PropTypes.arrayOf(PropTypes.string),
        requiresIfExists: PropTypes.arrayOf(PropTypes.string),
      })
    ),
    /**
     * Задаёт смещение поппера относительно родительского компонента по основной оси
     *  @default 11
     */
    offset: PropTypes.number,
    /**
     * Задаёт смещение поппера относительно родительского компонента по поперченой оси (не применяется при placement up, down, right, left)
     *  @default 0
     */
    offsetCounterAxis: PropTypes.number,
    /**
     * Задает расположение
     *  @default "auto"
     */
    placement: PropTypes.oneOf([
      'auto',
      'bottom',
      'bottomLeft',
      'bottomRight',
      'left',
      'leftBottom',
      'leftTop',
      'right',
      'rightBottom',
      'rightTop',
      'top',
      'topLeft',
      'topRight',
    ]),
    /**
     * Центририровать pointer на родительский компонент
     *  @default "false"
     */
    pointerIsCentered: PropTypes.bool,
    popper: function (props, propName) {
      if (props[propName] == null) {
        return null;
      } else if (typeof props[propName] !== 'object' || props[propName].nodeType !== 1) {
        return new Error("Expected prop '" + propName + "' to be of type Element");
      }
    },
    /**
     * При включении, тултип будет смещаться, чтобы оставаться в зоне видимости
     *  @default "true"
     */
    preventOverflow: PropTypes.bool,
    trigger: PropTypes.oneOfType([
      function (props, propName) {
        if (props[propName] == null) {
          return new Error("Prop '" + propName + "' is required but wasn't specified");
        } else if (typeof props[propName] !== 'object' || props[propName].nodeType !== 1) {
          return new Error("Expected prop '" + propName + "' to be of type Element");
        }
      },
      PropTypes.shape({
        contextElement: function (props, propName) {
          if (props[propName] == null) {
            return null;
          } else if (typeof props[propName] !== 'object' || props[propName].nodeType !== 1) {
            return new Error("Expected prop '" + propName + "' to be of type Element");
          }
        },
        getBoundingClientRect: PropTypes.func.isRequired,
      }),
    ]),
    /**
     * При включении, тултип будет соответствовать ширине родительского компонента
     *  @default "false"
     */
    widthFitContent: PropTypes.bool,
  }),
  /**
   * Задаёт вид компонента
   *  @default primary
   */
  variant: PropTypes.oneOf(['primary']),
};

Popover.displayName = 'Popover';
exports['default'] = Popover;
