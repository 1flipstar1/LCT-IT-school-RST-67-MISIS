import React from 'react';
import '../../styles/components/popover.scss';
import { IPopoverProps } from './types';
declare const Popover: React.FC<IPopoverProps>;
export default Popover;
