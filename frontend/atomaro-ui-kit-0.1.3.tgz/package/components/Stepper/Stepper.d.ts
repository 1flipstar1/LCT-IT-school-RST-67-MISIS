import { FC } from 'react';
import '../../styles/components/stepper.scss';
import { IStepperProps } from './types';
declare const Stepper: FC<IStepperProps>;
export default Stepper;
