'use strict';

var _a, _b;
Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.STEPPER_SIZE_DEFAULT =
  exports.STEPPER_COLORSCHEME_DEFAULT =
  exports.STEPPER_VARIANT_DEFAULT =
  exports.STEPPER_HEIGHT_LIST =
  exports.STEPPER_WIDTH_LIST =
  exports.STEPPER_COLORSCHEMES =
  exports.STEPPER_VARIANTS =
  exports.STEPPER_SIZES =
  exports.STEPPER_DISABLED =
    void 0;
var STEPPER_DISABLED;
(function (STEPPER_DISABLED) {
  STEPPER_DISABLED['all'] = 'all';
  STEPPER_DISABLED['left'] = 'left';
  STEPPER_DISABLED['right'] = 'right';
})((STEPPER_DISABLED = exports.STEPPER_DISABLED || (exports.STEPPER_DISABLED = {})));
var STEPPER_SIZES;
(function (STEPPER_SIZES) {
  STEPPER_SIZES['m'] = 'm';
  STEPPER_SIZES['l'] = 'l';
})((STEPPER_SIZES = exports.STEPPER_SIZES || (exports.STEPPER_SIZES = {})));
var STEPPER_VARIANTS;
(function (STEPPER_VARIANTS) {
  STEPPER_VARIANTS['primary'] = 'primary';
})((STEPPER_VARIANTS = exports.STEPPER_VARIANTS || (exports.STEPPER_VARIANTS = {})));
var STEPPER_COLORSCHEMES;
(function (STEPPER_COLORSCHEMES) {
  STEPPER_COLORSCHEMES['accent'] = 'accent';
  STEPPER_COLORSCHEMES['neutral'] = 'neutral';
})((STEPPER_COLORSCHEMES = exports.STEPPER_COLORSCHEMES || (exports.STEPPER_COLORSCHEMES = {})));
exports.STEPPER_WIDTH_LIST =
  ((_a = {}), (_a[STEPPER_SIZES.l] = 96), (_a[STEPPER_SIZES.m] = 80), _a);
exports.STEPPER_HEIGHT_LIST =
  ((_b = {}), (_b[STEPPER_SIZES.l] = 48), (_b[STEPPER_SIZES.m] = 32), _b);
exports.STEPPER_VARIANT_DEFAULT = STEPPER_VARIANTS.primary;
exports.STEPPER_COLORSCHEME_DEFAULT = STEPPER_COLORSCHEMES.accent;
exports.STEPPER_SIZE_DEFAULT = STEPPER_SIZES.m;
