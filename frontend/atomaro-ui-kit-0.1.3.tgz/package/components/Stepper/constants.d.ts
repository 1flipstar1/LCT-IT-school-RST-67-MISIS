export declare enum STEPPER_DISABLED {
    all = "all",
    left = "left",
    right = "right"
}
export declare enum STEPPER_SIZES {
    m = "m",
    l = "l"
}
export declare enum STEPPER_VARIANTS {
    primary = "primary"
}
export declare enum STEPPER_COLORSCHEMES {
    accent = "accent",
    neutral = "neutral"
}
export type StepperDisabledType = keyof typeof STEPPER_DISABLED;
export type StepperSizesType = keyof typeof STEPPER_SIZES;
export type StepperVariantsType = keyof typeof STEPPER_VARIANTS;
export type StepperColorSchemesType = keyof typeof STEPPER_COLORSCHEMES;
export declare const STEPPER_WIDTH_LIST: {
    l: number;
    m: number;
};
export declare const STEPPER_HEIGHT_LIST: {
    l: number;
    m: number;
};
export declare const STEPPER_VARIANT_DEFAULT = STEPPER_VARIANTS.primary;
export declare const STEPPER_COLORSCHEME_DEFAULT = STEPPER_COLORSCHEMES.accent;
export declare const STEPPER_SIZE_DEFAULT = STEPPER_SIZES.m;
