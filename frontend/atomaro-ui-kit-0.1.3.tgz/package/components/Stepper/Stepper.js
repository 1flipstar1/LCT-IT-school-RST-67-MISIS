'use strict';
var PropTypes = require('prop-types');

var __createBinding =
  (this && this.__createBinding) ||
  (Object.create
    ? function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ('get' in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = {
            enumerable: true,
            get: function get() {
              return m[k];
            },
          };
        }
        Object.defineProperty(o, k2, desc);
      }
    : function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
      });
var __setModuleDefault =
  (this && this.__setModuleDefault) ||
  (Object.create
    ? function (o, v) {
        Object.defineProperty(o, 'default', {
          enumerable: true,
          value: v,
        });
      }
    : function (o, v) {
        o['default'] = v;
      });
var __importStar =
  (this && this.__importStar) ||
  function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null)
      for (var k in mod)
        if (k !== 'default' && Object.prototype.hasOwnProperty.call(mod, k))
          __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importStar(require('react'));
var clsx_1 = __importDefault(require('clsx'));
require('../../styles/components/stepper.scss');
var AddSmall_1 = __importDefault(require('@atomaro/icons/24/action/AddSmall'));
var RemoveSmall_1 = __importDefault(require('@atomaro/icons/24/action/RemoveSmall'));
var function_1 = require('../../utils/function');
var constants_1 = require('./constants');
var Stepper = function Stepper(props) {
  var _a;
  var className = props.className,
    style = props.style,
    _b = props.variant,
    variant = _b === void 0 ? constants_1.STEPPER_VARIANT_DEFAULT : _b,
    disabled = props.disabled,
    leftIcon = props.leftIcon,
    rightIcon = props.rightIcon,
    _c = props.size,
    size = _c === void 0 ? constants_1.STEPPER_SIZE_DEFAULT : _c,
    _d = props.colorScheme,
    colorScheme = _d === void 0 ? constants_1.STEPPER_COLORSCHEME_DEFAULT : _d,
    text = props.text,
    onLeftClick = props.onLeftClick,
    onRightClick = props.onRightClick;
  var _e = (0, react_1.useMemo)(
      function () {
        var allDisabled = disabled === constants_1.STEPPER_DISABLED.all;
        return {
          isAllDisabled: allDisabled,
          isLeftDisabled: allDisabled || disabled === constants_1.STEPPER_DISABLED.left,
          isRightDisabled: allDisabled || disabled === constants_1.STEPPER_DISABLED.right,
        };
      },
      [disabled]
    ),
    isAllDisabled = _e.isAllDisabled,
    isLeftDisabled = _e.isLeftDisabled,
    isRightDisabled = _e.isRightDisabled;
  var handleLeftClick = (0, react_1.useCallback)(
    function () {
      if (onLeftClick && !isLeftDisabled) {
        onLeftClick();
      }
    },
    [onLeftClick, isLeftDisabled]
  );
  var handleRightClick = (0, react_1.useCallback)(
    function () {
      if (onRightClick && !isRightDisabled) {
        onRightClick();
      }
    },
    [onRightClick, isRightDisabled]
  );
  var rootClassName = (0, clsx_1['default'])(
    'stepper',
    'stepper--size-'.concat(constants_1.STEPPER_SIZES[size]),
    'stepper--'.concat(constants_1.STEPPER_VARIANTS[variant]),
    'stepper--'.concat(constants_1.STEPPER_COLORSCHEMES[colorScheme]),
    ((_a = {}), (_a['stepper--disabled'] = isAllDisabled), _a),
    className
  );
  return react_1['default'].createElement(
    'div',
    {
      className: rootClassName,
      style: style,
      onTouchStart: function_1.noop,
    },
    react_1['default'].createElement(
      'button',
      {
        type: 'button',
        className: 'stepper__button stepper__button--prev',
        disabled: isLeftDisabled || isAllDisabled,
        onClick: handleLeftClick,
      },
      leftIcon || react_1['default'].createElement(RemoveSmall_1['default'], null)
    ),
    text
      ? react_1['default'].createElement(
          'div',
          {
            className: 'stepper__text',
          },
          text
        )
      : react_1['default'].createElement('span', {
          className: 'stepper__divider',
        }),
    react_1['default'].createElement(
      'button',
      {
        type: 'button',
        className: 'stepper__button stepper__button--next',
        disabled: isRightDisabled || isAllDisabled,
        onClick: handleRightClick,
      },
      rightIcon || react_1['default'].createElement(AddSmall_1['default'], null)
    )
  );
};

Stepper.propTypes = {
  /**
   * Устанавливает дополнительные классы для элемента
   */
  className: PropTypes.string,
  /**
   * Задает внешний вид
   *  @default accent
   */
  colorScheme: PropTypes.oneOf(['accent', 'neutral']),
  /**
   * Устанавливает атрибут disabled
   */
  disabled: PropTypes.oneOf(['all', 'left', 'right']),
  /**
   * Устанавливает кастомную иконку для левой кнопки
   */
  leftIcon: PropTypes.node,
  /**
   * Callback функция, вызываемая при нажатии на левую кнопку
   * @returns {undefined}
   */
  onLeftClick: PropTypes.func,
  /**
   * Callback функция, вызываемая при нажатии на правую кнопку
   * @returns {undefined}
   */
  onRightClick: PropTypes.func,
  /**
   * Устанавливает кастомную иконку для правой кнопки
   */
  rightIcon: PropTypes.node,
  /**
   * Задает размер компонента
   * @default medium
   */
  size: PropTypes.oneOf(['l', 'm']),
  /**
   * Задает дополнительные стили для компонента
   */
  style: PropTypes.object,
  /**
   * Устанавливает текст между кнопок вместо вертикальной черты
   */
  text: PropTypes.string,
  /**
   * Задает основной цвет для чекбокса
   *  @default primary
   */
  variant: PropTypes.oneOf(['primary']),
};

Stepper.displayName = 'Stepper';
exports['default'] = Stepper;
