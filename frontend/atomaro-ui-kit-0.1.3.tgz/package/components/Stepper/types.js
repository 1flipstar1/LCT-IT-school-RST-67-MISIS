"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
// export type StepperContainerPropsType = Pick<IStepperProps, 'text'> & {
//   disabled: boolean;
//   shape: ShapesType;
//   theme: ITheme;
//   size: StepperSizesType;
//   color?: string;
// };
//
// export type StepperBtnPropsType = Pick<
//   StepperContainerPropsType,
//   'theme' | 'color' | 'size' | 'text' | 'disabled' | 'shape'
// > & {
//   currentTheme: ThemeNamesType;
//   order: number;
// };
//
// export type StepperTextPropsType = Pick<
//   StepperBtnPropsType,
//   'theme' | 'color' | 'size' | 'currentTheme' | 'disabled' | 'order'
// >;
//
// export type StepperDividerPropsType = Pick<StepperBtnPropsType, 'theme' | 'order'>;