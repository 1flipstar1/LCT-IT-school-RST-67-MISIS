import { ReactNode, CSSProperties } from 'react';
import { StepperSizesType, StepperDisabledType, StepperVariantsType, StepperColorSchemesType } from './constants';
export interface IStepperProps {
    /** Задает основной цвет для чекбокса
     *  @default primary */
    variant?: StepperVariantsType;
    /** Задает внешний вид
     *  @default accent */
    colorScheme?: StepperColorSchemesType;
    /** Устанавливает атрибут disabled */
    disabled?: StepperDisabledType;
    /** Устанавливает кастомную иконку для левой кнопки */
    leftIcon?: ReactNode;
    /** Устанавливает кастомную иконку для правой кнопки */
    rightIcon?: ReactNode;
    /** Задает размер компонента
     * @default medium
     */
    size?: StepperSizesType;
    /** Устанавливает текст между кнопок вместо вертикальной черты */
    text?: string;
    /** Устанавливает дополнительные классы для элемента */
    className?: string;
    /** Задает дополнительные стили для компонента */
    style?: CSSProperties;
    /** Callback функция, вызываемая при нажатии на левую кнопку
     * @returns {undefined}
     */
    onLeftClick?: () => void;
    /** Callback функция, вызываемая при нажатии на правую кнопку
     * @returns {undefined}
     */
    onRightClick?: () => void;
}
