'use strict';
var PropTypes = require('prop-types');

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __createBinding =
  (this && this.__createBinding) ||
  (Object.create
    ? function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ('get' in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = {
            enumerable: true,
            get: function get() {
              return m[k];
            },
          };
        }
        Object.defineProperty(o, k2, desc);
      }
    : function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
      });
var __setModuleDefault =
  (this && this.__setModuleDefault) ||
  (Object.create
    ? function (o, v) {
        Object.defineProperty(o, 'default', {
          enumerable: true,
          value: v,
        });
      }
    : function (o, v) {
        o['default'] = v;
      });
var __importStar =
  (this && this.__importStar) ||
  function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null)
      for (var k in mod)
        if (k !== 'default' && Object.prototype.hasOwnProperty.call(mod, k))
          __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
  };
var __rest =
  (this && this.__rest) ||
  function (s, e) {
    var t = {};
    for (var p in s)
      if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === 'function')
      for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
          t[p[i]] = s[p[i]];
      }
    return t;
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importStar(require('react'));
var clsx_1 = __importDefault(require('clsx'));
require('../../styles/components/input.scss');
require('../../styles/components/scroll-bar.scss');
var useCombinedRefs_1 = require('../../hooks/useCombinedRefs');
var function_1 = require('../../utils/function');
var constants_1 = require('../Input/constants');
var TextArea = (0, react_1.forwardRef)(function TextArea(props, ref) {
  var _a;
  var _b = props.variant,
    variant = _b === void 0 ? constants_1.INPUT_VARIANTS.primary : _b,
    _c = props.size,
    size = _c === void 0 ? constants_1.INPUT_SIZES.m : _c,
    labelProp = props.label,
    hideLabel = props.hideLabel,
    placeholder = props.placeholder,
    valueProp = props.value,
    defaultValue = props.defaultValue,
    error = props.error,
    hint = props.hint,
    counter = props.counter,
    _d = props.disabled,
    disabled = _d === void 0 ? false : _d,
    // autoHeight = false,
    _e = props.rows,
    // autoHeight = false,
    rowsProp = _e === void 0 ? 3 : _e,
    className = props.className,
    _f = props.onChange,
    onChange = _f === void 0 ? function_1.noop : _f,
    _g = props.onFocus,
    onFocus = _g === void 0 ? function_1.noop : _g,
    _h = props.onBlur,
    onBlur = _h === void 0 ? function_1.noop : _h,
    restProps = __rest(props, [
      'variant',
      'size',
      'label',
      'hideLabel',
      'placeholder',
      'value',
      'defaultValue',
      'error',
      'hint',
      'counter',
      'disabled',
      'rows',
      'className',
      'onChange',
      'onFocus',
      'onBlur',
    ]);
  var internalRef = (0, react_1.useRef)(null);
  var inputRef = (0, useCombinedRefs_1.useCombinedRefs)(ref, internalRef);
  var label = hideLabel ? null : labelProp;
  var rows = rowsProp <= 3 ? 3 : rowsProp;
  var _j = (0, react_1.useState)(defaultValue),
    value = _j[0],
    setValue = _j[1];
  var handleChange = function handleChange(event) {
    event.persist();
    onChange(event);
    var newValue = event.target.value;
    setValue(newValue);
  };
  (0, react_1.useEffect)(
    function () {
      if (valueProp !== undefined && valueProp !== value) {
        setValue(valueProp);
      }
    },
    [value, valueProp]
  );
  var renderFooter =
    (hint || counter || error) &&
    react_1['default'].createElement(
      'div',
      {
        className: 'input__hint',
      },
      (error || hint) &&
        react_1['default'].createElement(
          'div',
          {
            className: 'input__hint-label',
          },
          error || hint
        ),
      counter &&
        react_1['default'].createElement(
          'div',
          {
            className: 'input__hint-counter',
          },
          counter
        )
    );
  var rootClassName = (0, clsx_1['default'])(
    'input',
    'input--'.concat(constants_1.INPUT_VARIANTS[variant]),
    'input--size-'.concat(constants_1.INPUT_SIZES[size]),
    ((_a = {}),
    (_a['input--has-placeholder'] = !!placeholder),
    (_a['input--has-value'] = !!value),
    (_a['input--with-hint'] = !!(hint || counter || error)),
    (_a['input--only-counter'] = !!counter && !hint && !error),
    (_a['input--error'] = !!error),
    (_a['input--disabled'] = !!disabled),
    (_a['input--textarea'] = true),
    // [`input--textarea-autoheight`]: autoHeight,
    (_a['input--textarea-hidelabel'] = hideLabel),
    (_a['input--hidelabel'] = !!hideLabel),
    _a),
    className
  );
  return react_1['default'].createElement(
    react_1['default'].Fragment,
    null,
    react_1['default'].createElement(
      'div',
      {
        className: rootClassName,
      },
      label &&
        react_1['default'].createElement(
          'div',
          {
            className: 'input__label',
          },
          label
        ),
      react_1['default'].createElement(
        'textarea',
        __assign(
          {
            className: 'input__field scroll-bar',
            ref: inputRef,
            disabled: disabled,
            onBlur: onBlur,
            onChange: handleChange,
            onFocus: onFocus,
            placeholder: placeholder,
            rows: rows,
          },
          restProps
        ),
        value
      )
    ),
    renderFooter
  );
});

TextArea.propTypes = {
  className: PropTypes.string,
  /**
   * Задаёт счетчик
   */
  counter: PropTypes.string,
  /**
   * Задает значение по умолчанию, для неуправляемых компонентов.
   *  Не используется вместе с value
   */
  defaultValue: PropTypes.string,
  /**
   * Устанавливает атрибут disabled
   */
  disabled: PropTypes.bool,
  /**
   * Отображает ошибку заполнения поля
   */
  error: PropTypes.string,
  /**
   * Скрывает  label
   */
  hideLabel: PropTypes.bool,
  /**
   * Отображает подсказку для заполнения поля
   */
  hint: PropTypes.string,
  /**
   * Задает label
   */
  label: PropTypes.string,
  onBlur: PropTypes.func,
  onChange: PropTypes.func,
  onFocus: PropTypes.func,
  /**
   * Задаёт плэйсхолдер для поля ввода
   */
  placeholder: PropTypes.string,
  /**
   * Задаёт количество строк, минимальное значение - 3
   * @default 3
   */
  rows: PropTypes.number,
  /**
   * Задает размер
   * @default m
   */
  size: PropTypes.string,
  /**
   * Задает значение компонента, используется для управляемых компонентов.
   *  Не используется вместе с defaultValue
   */
  value: PropTypes.string,
  /**
   * Задает основной цвет для компонента
   *  @default primary
   */
  variant: PropTypes.string,
};

TextArea.displayName = 'TextArea';
exports['default'] = TextArea;
