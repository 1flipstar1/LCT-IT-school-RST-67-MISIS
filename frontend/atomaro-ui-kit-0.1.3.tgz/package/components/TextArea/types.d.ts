import React from 'react';
import { InputSizesType, InputVariantsType } from '../Input/constants';
export interface ITextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
    /** Задает основной цвет для компонента
     *  @default primary */
    variant?: InputVariantsType | string;
    /** Задает размер
     * @default m
     */
    size?: InputSizesType | string;
    /** Задает значение компонента, используется для управляемых компонентов.
     *  Не используется вместе с defaultValue */
    value?: string;
    /** Задает значение по умолчанию, для неуправляемых компонентов.
     *  Не используется вместе с value */
    defaultValue?: string;
    /** Задаёт количество строк, минимальное значение - 3
     * @default 3 */
    rows?: number;
    /** Отображает ошибку заполнения поля */
    error?: string;
    /** Отображает подсказку для заполнения поля */
    hint?: string;
    /** Задает label */
    label?: string;
    /** Скрывает  label */
    hideLabel?: boolean;
    /** Задаёт счетчик */
    counter?: string;
    /** Устанавливает атрибут disabled */
    disabled?: boolean;
    /** Задаёт плэйсхолдер для поля ввода */
    placeholder?: string;
}
