import React from 'react';
import '../../styles/components/input.scss';
import '../../styles/components/scroll-bar.scss';
import { ITextareaProps } from './types';
declare const TextArea: React.ForwardRefExoticComponent<ITextareaProps & React.RefAttributes<HTMLTextAreaElement>>;
export default TextArea;
