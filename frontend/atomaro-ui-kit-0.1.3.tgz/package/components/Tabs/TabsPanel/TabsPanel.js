'use strict';
var PropTypes = require('prop-types');

var __createBinding =
  (this && this.__createBinding) ||
  (Object.create
    ? function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ('get' in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = {
            enumerable: true,
            get: function get() {
              return m[k];
            },
          };
        }
        Object.defineProperty(o, k2, desc);
      }
    : function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
      });
var __setModuleDefault =
  (this && this.__setModuleDefault) ||
  (Object.create
    ? function (o, v) {
        Object.defineProperty(o, 'default', {
          enumerable: true,
          value: v,
        });
      }
    : function (o, v) {
        o['default'] = v;
      });
var __importStar =
  (this && this.__importStar) ||
  function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null)
      for (var k in mod)
        if (k !== 'default' && Object.prototype.hasOwnProperty.call(mod, k))
          __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importStar(require('react'));
require('../../../styles/components/tabs/tabsPanel.scss');
var TabsPanel = (0, react_1.forwardRef)(function TabsPanel(props, ref) {
  var children = props.children,
    value = props.value,
    index = props.index,
    _a = props.className,
    className = _a === void 0 ? '' : _a;
  var _b = (0, react_1.useState)(false),
    visible = _b[0],
    setVisible = _b[1];
  (0, react_1.useEffect)(
    function () {
      if (value === index) {
        setVisible(true);
      } else {
        setVisible(false);
      }
    },
    [value, index]
  );
  return visible
    ? react_1['default'].createElement(
        'div',
        {
          ref: ref,
          role: 'tabpanel',
          tabIndex: 0,
          className: 'tabs-panel '.concat(className),
        },
        children
      )
    : null;
});

TabsPanel.propTypes = {
  children: PropTypes.node,
  className: PropTypes.string,
  /**
   * Индекс видимой панели таба
   */
  index: PropTypes.string.isRequired,
  /**
   * Индекс текущей панели таба
   *  Если value равен index - панель видима
   */
  value: PropTypes.string.isRequired,
};

TabsPanel.displayName = 'TabsPanel';
exports['default'] = TabsPanel;
