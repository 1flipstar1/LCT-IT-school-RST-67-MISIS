import React from 'react';
import '../../../styles/components/tabs/tabsPanel.scss';
import { ITabsPanel } from './types';
declare const TabsPanel: React.ForwardRefExoticComponent<ITabsPanel & React.RefAttributes<HTMLDivElement>>;
export default TabsPanel;
