import React from 'react';
export interface ITabsPanel extends React.HTMLAttributes<HTMLDivElement> {
    /** Индекс видимой панели таба */
    index: string;
    /** Индекс текущей панели таба
     *  Если value равен index - панель видима
     */
    value: string;
}
