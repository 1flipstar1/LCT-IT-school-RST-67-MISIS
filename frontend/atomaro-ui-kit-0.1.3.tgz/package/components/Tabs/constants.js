"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.DEFAULT_TAB_SIZE = exports.DEFAULT_TAB_VARIANT = exports.TABS_VARIANTS = exports.TABS_SIZES = exports.TABS_ICON_POSITIONS = void 0;
var components_1 = require("../../constants/components");
var TABS_ICON_POSITIONS;
(function (TABS_ICON_POSITIONS) {
  TABS_ICON_POSITIONS["top"] = "top";
  TABS_ICON_POSITIONS["left"] = "left";
  TABS_ICON_POSITIONS["right"] = "right";
})(TABS_ICON_POSITIONS = exports.TABS_ICON_POSITIONS || (exports.TABS_ICON_POSITIONS = {}));
var TABS_SIZES;
(function (TABS_SIZES) {
  TABS_SIZES["m"] = "m";
  TABS_SIZES["s"] = "s";
})(TABS_SIZES = exports.TABS_SIZES || (exports.TABS_SIZES = {}));
var TABS_VARIANTS;
(function (TABS_VARIANTS) {
  TABS_VARIANTS["primary"] = "primary";
})(TABS_VARIANTS = exports.TABS_VARIANTS || (exports.TABS_VARIANTS = {}));
exports.DEFAULT_TAB_VARIANT = components_1.VARIANT.primary;
exports.DEFAULT_TAB_SIZE = components_1.SIZES.m;