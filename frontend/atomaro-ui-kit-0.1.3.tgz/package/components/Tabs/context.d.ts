import React, { MutableRefObject } from 'react';
import { TabsSizesType, TabsVariants } from './constants';
export declare const TabsContext: React.Context<ITabsContext>;
declare const TabsContextProvider: React.Provider<ITabsContext>;
export default TabsContextProvider;
export interface ITabsContext {
    size?: TabsSizesType;
    variant?: TabsVariants;
    activeIndex?: string;
    disabledAll?: boolean;
    scrollable?: boolean;
    handleChange?: (index: string) => void;
    tabsRef?: MutableRefObject<HTMLDivElement>;
}
