import { FC } from 'react';
import '../../../styles/components/tabs/tabsItem.scss';
import { ITabsItem } from './types';
declare const TabsItem: FC<ITabsItem>;
export default TabsItem;
