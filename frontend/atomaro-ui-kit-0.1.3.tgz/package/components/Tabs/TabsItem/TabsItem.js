'use strict';
var PropTypes = require('prop-types');

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __createBinding =
  (this && this.__createBinding) ||
  (Object.create
    ? function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ('get' in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = {
            enumerable: true,
            get: function get() {
              return m[k];
            },
          };
        }
        Object.defineProperty(o, k2, desc);
      }
    : function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
      });
var __setModuleDefault =
  (this && this.__setModuleDefault) ||
  (Object.create
    ? function (o, v) {
        Object.defineProperty(o, 'default', {
          enumerable: true,
          value: v,
        });
      }
    : function (o, v) {
        o['default'] = v;
      });
var __importStar =
  (this && this.__importStar) ||
  function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null)
      for (var k in mod)
        if (k !== 'default' && Object.prototype.hasOwnProperty.call(mod, k))
          __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
  };
var __rest =
  (this && this.__rest) ||
  function (s, e) {
    var t = {};
    for (var p in s)
      if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === 'function')
      for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
          t[p[i]] = s[p[i]];
      }
    return t;
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importStar(require('react'));
var clsx_1 = __importDefault(require('clsx'));
require('../../../styles/components/tabs/tabsItem.scss');
var context_1 = require('../context');
var components_1 = require('../../../constants/components');
var constants_1 = require('../constants');
var noop_1 = require('../../../utils/noop');
var TabsItem = function TabsItem(props) {
  var index = props.index,
    label = props.label,
    icon = props.icon,
    _a = props.iconPosition,
    iconPosition = _a === void 0 ? constants_1.TABS_ICON_POSITIONS.left : _a,
    _b = props.disabled,
    disabled = _b === void 0 ? false : _b,
    className = props.className,
    _c = props.size,
    sizeProp = _c === void 0 ? constants_1.DEFAULT_TAB_SIZE : _c,
    _d = props.onClick,
    onClick = _d === void 0 ? noop_1.noop : _d,
    _e = props.dot,
    dot = _e === void 0 ? false : _e,
    restProps = __rest(props, [
      'index',
      'label',
      'icon',
      'iconPosition',
      'disabled',
      'className',
      'size',
      'onClick',
      'dot',
    ]);
  var _f = (0, react_1.useContext)(context_1.TabsContext),
    _g = _f.size,
    size = _g === void 0 ? sizeProp : _g,
    _h = _f.variant,
    variant = _h === void 0 ? constants_1.DEFAULT_TAB_VARIANT : _h,
    scrollable = _f.scrollable,
    activeIndex = _f.activeIndex,
    disabledAll = _f.disabledAll,
    handleChange = _f.handleChange;
  var itemRef = (0, react_1.useRef)();
  var isActive = activeIndex === index;
  var isDisabled = disabledAll || disabled;
  var tabIndex = isActive ? 0 : -1;
  var onClickHandler = function onClickHandler(event) {
    if (!isDisabled) {
      if (handleChange) {
        handleChange(index);
      }
      onClick(event);
    }
    if (scrollable) {
      itemRef.current.scrollIntoView({
        block: 'center',
        inline: 'center',
        behavior: 'smooth',
      });
    }
  };
  var rootClassName = (0, clsx_1['default'])(
    'tabs-item',
    'tabs-item--'.concat(components_1.VARIANT[variant]),
    'tabs-item--size-'.concat(components_1.SIZES[size]),
    icon && 'tabs-item--icon-'.concat(iconPosition),
    icon && 'tabs-item--icon',
    isActive && 'tabs-item--selected',
    isDisabled && 'tabs-item--disabled',
    scrollable && 'tabs-item--scrollable',
    dot && 'tabs-item--dot',
    className
  );
  return react_1['default'].createElement(
    'button',
    __assign(
      {
        type: 'button',
        className: rootClassName,
        ref: itemRef,
        disabled: isDisabled,
        onClick: onClickHandler,
        role: 'tab',
        'aria-selected': isActive,
        tabIndex: tabIndex,
        'aria-label': label,
      },
      restProps
    ),
    icon && icon,
    react_1['default'].createElement(
      'span',
      {
        className: 'tabs-item__text',
      },
      label
    )
  );
};

TabsItem.propTypes = {
  className: PropTypes.string,
  /**
   * Устанавливает атрибут disabled для таба
   */
  disabled: PropTypes.bool,
  /**
   * Добавляет точку справа от Label
   */
  dot: PropTypes.bool,
  /**
   * Иконка для кнопки таба
   */
  icon: PropTypes.node,
  /**
   * Задает расположение иконки относительно текста
   *  @default left
   */
  iconPosition: PropTypes.oneOf(['left', 'right', 'top']),
  /**
   * Индекс текущей кнопки таба
   */
  index: PropTypes.string.isRequired,
  /**
   * Текст кнопки таба
   */
  label: PropTypes.string.isRequired,
  onClick: PropTypes.func,
  /**
   * Задает размер
   *  @default m
   */
  size: PropTypes.oneOf(['m', 's']),
};

TabsItem.displayName = 'TabsItem';
exports['default'] = TabsItem;
