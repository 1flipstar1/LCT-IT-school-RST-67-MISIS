import React from 'react';
import { TabsSizesType, TabsIconPositionsType } from '../constants';
export interface ITabsItem extends React.ButtonHTMLAttributes<HTMLButtonElement> {
    /** Индекс текущей кнопки таба */
    index: string;
    /** Текст кнопки таба */
    label: string;
    /** Задает размер
     *  @default m */
    size?: TabsSizesType;
    /** Иконка для кнопки таба */
    icon?: React.ReactNode;
    /** Задает расположение иконки относительно текста
     *  @default left */
    iconPosition?: TabsIconPositionsType;
    /** Добавляет точку справа от Label */
    dot?: boolean;
    /** Устанавливает атрибут disabled для таба */
    disabled?: boolean;
}
