import { SIZES, VARIANT } from '../../constants/components';
export declare enum TABS_ICON_POSITIONS {
    top = "top",
    left = "left",
    right = "right"
}
export declare enum TABS_SIZES {
    m = "m",
    s = "s"
}
export declare enum TABS_VARIANTS {
    primary = "primary"
}
export type TabsSizesType = keyof typeof TABS_SIZES;
export type TabsIconPositionsType = keyof typeof TABS_ICON_POSITIONS;
export type TabsVariants = keyof typeof TABS_VARIANTS;
export declare const DEFAULT_TAB_VARIANT = VARIANT.primary;
export declare const DEFAULT_TAB_SIZE = SIZES.m;
