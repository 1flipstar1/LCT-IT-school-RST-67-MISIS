'use strict';
var PropTypes = require('prop-types');

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __createBinding =
  (this && this.__createBinding) ||
  (Object.create
    ? function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ('get' in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = {
            enumerable: true,
            get: function get() {
              return m[k];
            },
          };
        }
        Object.defineProperty(o, k2, desc);
      }
    : function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
      });
var __setModuleDefault =
  (this && this.__setModuleDefault) ||
  (Object.create
    ? function (o, v) {
        Object.defineProperty(o, 'default', {
          enumerable: true,
          value: v,
        });
      }
    : function (o, v) {
        o['default'] = v;
      });
var __importStar =
  (this && this.__importStar) ||
  function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null)
      for (var k in mod)
        if (k !== 'default' && Object.prototype.hasOwnProperty.call(mod, k))
          __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
  };
var __rest =
  (this && this.__rest) ||
  function (s, e) {
    var t = {};
    for (var p in s)
      if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === 'function')
      for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
          t[p[i]] = s[p[i]];
      }
    return t;
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importStar(require('react'));
var clsx_1 = __importDefault(require('clsx'));
require('../../../styles/components/tabs/tabsGroup.scss');
var constants_1 = require('../constants');
var context_1 = __importDefault(require('../context'));
var components_1 = require('../../../constants/components');
var TabsGroup = function TabsGroup(props) {
  var _a = props.variant,
    variant = _a === void 0 ? constants_1.DEFAULT_TAB_VARIANT : _a,
    _b = props.size,
    size = _b === void 0 ? constants_1.DEFAULT_TAB_SIZE : _b,
    _c = props.disabledAll,
    disabledAll = _c === void 0 ? false : _c,
    value = props.value,
    _d = props.border,
    border = _d === void 0 ? true : _d,
    _e = props.scrollable,
    scrollable = _e === void 0 ? false : _e,
    _f = props.className,
    classes = _f === void 0 ? '' : _f,
    _g = props.onChange,
    onChange = _g === void 0 ? function () {} : _g,
    children = props.children,
    restProps = __rest(props, [
      'variant',
      'size',
      'disabledAll',
      'value',
      'border',
      'scrollable',
      'className',
      'onChange',
      'children',
    ]);
  var ref = (0, react_1.useRef)();
  var _h = (0, react_1.useState)(value),
    activeIndex = _h[0],
    setActiveIndex = _h[1];
  var _j = (0, react_1.useState)(false),
    isScrolling = _j[0],
    setIsScrolling = _j[1];
  var _k = (0, react_1.useState)(0),
    startX = _k[0],
    setStartX = _k[1];
  var _l = (0, react_1.useState)(0),
    scrollX = _l[0],
    setScrollX = _l[1];
  var handleChange = function handleChange(index) {
    setActiveIndex(index);
    onChange(index);
  };
  var onMouseDown = function onMouseDown(event) {
    setIsScrolling(true);
    var x = event.pageX - ref.current.offsetLeft;
    setStartX(x);
    setScrollX(ref.current.scrollLeft);
  };
  var onMouseUp = function onMouseUp() {
    ref.current.classList.remove('grab');
    setIsScrolling(false);
  };
  var onMouseLeave = function onMouseLeave() {
    setIsScrolling(false);
  };
  var onMouseMove = function onMouseMove(event) {
    if (!isScrolling) return;
    event.preventDefault();
    ref.current.classList.add('tabs-group--grab');
    var x = event.pageX - ref.current.offsetLeft;
    var step = x - startX;
    ref.current.scrollLeft = scrollX - step;
  };
  var handleValueChanged = (0, react_1.useCallback)(
    function () {
      if (value !== undefined && value !== activeIndex) {
        setActiveIndex(value);
      }
      // eslint-disable-next-line react-hooks/exhaustive-deps
    },
    [value]
  );
  (0, react_1.useEffect)(handleValueChanged, [handleValueChanged]);
  var rootClassName = (0, clsx_1['default'])(
    'tabs-group',
    'tabs-group--'.concat(components_1.VARIANT[variant]),
    'tabs-group--size-'.concat(components_1.SIZES[size]),
    scrollable && 'tabs-group--scrollable',
    border && 'tabs-group--border',
    ''.concat(classes)
  );
  return react_1['default'].createElement(
    context_1['default'],
    {
      value: {
        size: size,
        scrollable: scrollable,
        disabledAll: disabledAll,
        activeIndex: activeIndex,
        handleChange: handleChange,
        tabsRef: ref,
      },
    },
    react_1['default'].createElement(
      'div',
      __assign(
        {
          ref: ref,
        },
        scrollable && {
          onMouseDown: onMouseDown,
          onMouseUp: onMouseUp,
          onMouseMove: onMouseMove,
          onMouseLeave: onMouseLeave,
        },
        {
          className: rootClassName,
          role: 'tablist',
        },
        restProps
      ),
      react_1['default'].createElement(
        'div',
        {
          className: 'tabs-group__tabs',
        },
        children
      )
    )
  );
};

TabsGroup.propTypes = {
  /**
   * Задает полосу внизу панели
   *  @default true
   */
  border: PropTypes.bool,
  children: PropTypes.arrayOf(PropTypes.element).isRequired,
  className: PropTypes.string,
  /**
   * Задает disabled для всей группы
   */
  disabledAll: PropTypes.bool,
  /**
   * Callback функция, вызываемая при изменении значения
   */
  onChange: PropTypes.func,
  /**
   * Задает прокрутку для табов.
   *  @param false Табы устанавливаются на всю ширину, если не помещаются - обрезаются многоточием
   *  @param true Табы занимают только ширину табов, оставляя пространство, если не помещаются - появляется прокрутка
   *  @default false
   */
  scrollable: PropTypes.bool,
  /**
   * Задает размер
   *  @default m
   */
  size: PropTypes.oneOf(['m', 's']),
  /**
   * Задает выбор активного таба.
   *  Рекомендуется по умолчанию выбирать первый tab
   */
  value: PropTypes.string.isRequired,
  /**
   * Задает вариант активной кнопки группы
   *  @default primary
   */
  variant: PropTypes.oneOf(['primary']),
};

TabsGroup.displayName = 'TabsGroup';
exports['default'] = TabsGroup;
