import React from 'react';
import { TabsIconPositionsType, TabsSizesType, TabsVariants } from '../constants';
export interface ITabsGroup extends Omit<React.HTMLAttributes<HTMLDivElement>, 'onChange'> {
    /** Задает вариант активной кнопки группы
     *  @default primary */
    variant?: TabsVariants;
    /** Задает размер
     *  @default m */
    size?: TabsSizesType;
    /** Задает выбор активного таба.
     *  Рекомендуется по умолчанию выбирать первый tab */
    value: string;
    /** Задает disabled для всей группы */
    disabledAll?: boolean;
    /** Задает полосу внизу панели
     *  @default true
     */
    border?: boolean;
    /** Задает прокрутку для табов.
     *  @param false Табы устанавливаются на всю ширину, если не помещаются - обрезаются многоточием
     *  @param true Табы занимают только ширину табов, оставляя пространство, если не помещаются - появляется прокрутка
     *  @default false
     */
    scrollable?: boolean;
    /** Задает расположение иконки относительно текста
     *  @default left */
    iconPosition?: TabsIconPositionsType;
    /** Callback функция, вызываемая при изменении значения */
    onChange?: (index: string) => void;
    children: React.ReactElement[];
}
