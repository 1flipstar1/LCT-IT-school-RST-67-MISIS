import { FC } from 'react';
import '../../../styles/components/tabs/tabsGroup.scss';
import { ITabsGroup } from './types';
declare const TabsGroup: FC<ITabsGroup>;
export default TabsGroup;
