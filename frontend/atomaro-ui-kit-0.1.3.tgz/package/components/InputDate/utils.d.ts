import dayjs from 'dayjs';
import IMask from 'imask';
export declare const isValidDateFormat: (dateString: string, dateFormat: string) => boolean;
export declare const isValidDateRangeFormat: (dateString: string, dateFormat: string) => boolean;
export declare const isPartiallyValidDateRangeFormat: (dateString: string, dateFormat: string) => {
    from: {
        valid: boolean;
        date: string;
    };
    to: {
        valid: boolean;
        date: string;
    };
};
export declare const getDateMaskParams: (dateFormat: string, minYear: number, maxYear: number, minDate?: Date, maxDate?: Date) => {
    mask: DateConstructor;
    pattern: string;
    overwrite: boolean;
    autofix: boolean;
    min: Date;
    max: Date;
    format: (date: any) => string;
    parse: (str: any) => dayjs.Dayjs;
    blocks: {
        YYYY: {
            mask: typeof IMask.MaskedRange;
            from: number;
            to: number;
        };
        MM: {
            mask: typeof IMask.MaskedRange;
            from: number;
            to: number;
        };
        DD: {
            mask: typeof IMask.MaskedRange;
            from: number;
            to: number;
        };
        HH: {
            mask: typeof IMask.MaskedRange;
            from: number;
            to: number;
        };
        mm: {
            mask: typeof IMask.MaskedRange;
            from: number;
            to: number;
        };
    };
};
export declare const parseToInputString: (dates: {
    start?: Date;
    end?: Date;
}, params: {
    isRange: boolean;
    dateFormat: string;
    isOpenCalendar: boolean;
}) => string;
