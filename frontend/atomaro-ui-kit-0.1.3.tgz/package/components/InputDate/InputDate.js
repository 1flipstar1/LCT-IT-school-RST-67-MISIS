'use strict';
var PropTypes = require('prop-types');

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __createBinding =
  (this && this.__createBinding) ||
  (Object.create
    ? function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ('get' in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = {
            enumerable: true,
            get: function get() {
              return m[k];
            },
          };
        }
        Object.defineProperty(o, k2, desc);
      }
    : function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
      });
var __setModuleDefault =
  (this && this.__setModuleDefault) ||
  (Object.create
    ? function (o, v) {
        Object.defineProperty(o, 'default', {
          enumerable: true,
          value: v,
        });
      }
    : function (o, v) {
        o['default'] = v;
      });
var __importStar =
  (this && this.__importStar) ||
  function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null)
      for (var k in mod)
        if (k !== 'default' && Object.prototype.hasOwnProperty.call(mod, k))
          __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
  };
var __rest =
  (this && this.__rest) ||
  function (s, e) {
    var t = {};
    for (var p in s)
      if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === 'function')
      for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
          t[p[i]] = s[p[i]];
      }
    return t;
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importStar(require('react'));
var Calendar_1 = __importDefault(require('@atomaro/icons/24/communication/Calendar'));
var Popover_1 = __importDefault(require('../Popover/Popover'));
var Input_1 = __importDefault(require('../Input/Input'));
var PickerDate_1 = __importDefault(require('../PickerDate/PickerDate'));
var function_1 = require('../../utils/function');
var constants_1 = require('../PickerDate/constants');
var constants_2 = require('./constants');
var hooks_1 = require('./hooks');
var constants_3 = require('../Input/constants');
var getValueFromCssVariable_1 = require('../../utils/getValueFromCssVariable');
var InputDate = (0, react_1.forwardRef)(function InputDate(props, ref) {
  var _a = props.variant,
    variant = _a === void 0 ? constants_3.INPUT_VARIANTS.primary : _a,
    _b = props.size,
    size = _b === void 0 ? constants_3.INPUT_SIZES.m : _b,
    _c = props.disabled,
    disabled = _c === void 0 ? false : _c,
    _d = props.showTime,
    showTime = _d === void 0 ? false : _d,
    _e = props.dateFormat,
    dateFormat =
      _e === void 0 ? (showTime ? 'DD.MM.YYYY HH:mm' : constants_2.DEFAULT_DATE_FORMAT) : _e,
    _f = props.isRange,
    isRange = _f === void 0 ? false : _f,
    minDate = props.minDate,
    maxDate = props.maxDate,
    _g = props.disabledDates,
    disabledDates = _g === void 0 ? [] : _g,
    _h = props.enabledDates,
    enabledDates = _h === void 0 ? [] : _h,
    activeValue = props.activeDate,
    secondValue = props.secondDate,
    _j = props.onChange,
    onChange = _j === void 0 ? function_1.noop : _j,
    _k = props.onChangeMonth,
    onChangeMonth = _k === void 0 ? function_1.noop : _k,
    _l = props.onChangeYear,
    onChangeYear = _l === void 0 ? function_1.noop : _l,
    firstDayIndex = props.firstDayIndex,
    _m = props.daysOfWeek,
    daysOfWeek = _m === void 0 ? constants_1.DAYS_OF_WEEK : _m,
    months = props.months,
    _o = props.minYear,
    minYear = _o === void 0 ? constants_1.MIN_YEAR : _o,
    _p = props.maxYear,
    maxYear = _p === void 0 ? constants_1.MAX_YEAR : _p,
    transformationRule = props.transformationRule,
    _q = props.placeholder,
    placeholder = _q === void 0 ? 'Выберите дату' : _q,
    _r = props.iconSuffix,
    iconSuffix =
      _r === void 0
        ? react_1['default'].createElement(Calendar_1['default'], {
            size: 1,
          })
        : _r,
    _s = props.onClickIconSuffix,
    onClickIconSuffix = _s === void 0 ? function_1.noop : _s,
    renderDate = props.renderDate,
    calendarMode = props.calendarMode,
    useInPortal = props.useInPortal,
    _t = props.placement,
    placement = _t === void 0 ? 'bottom' : _t,
    offset = props.offset,
    offsetCounterAxis = props.offsetCounterAxis,
    otherProps = __rest(props, [
      'variant',
      'size',
      'disabled',
      'showTime',
      'dateFormat',
      'isRange',
      'minDate',
      'maxDate',
      'disabledDates',
      'enabledDates',
      'activeDate',
      'secondDate',
      'onChange',
      'onChangeMonth',
      'onChangeYear',
      'firstDayIndex',
      'daysOfWeek',
      'months',
      'minYear',
      'maxYear',
      'transformationRule',
      'placeholder',
      'iconSuffix',
      'onClickIconSuffix',
      'renderDate',
      'calendarMode',
      'useInPortal',
      'placement',
      'offset',
      'offsetCounterAxis',
    ]);
  var _u = (0, hooks_1.useInputTimeOrDate)(
      __assign(
        {
          ref: ref,
          disabled: disabled,
          activeValue: activeValue,
          secondValue: secondValue,
          isRange: isRange,
          dateFormat: dateFormat,
          onChange: onChange,
          onClickIconSuffix: onClickIconSuffix,
          onChangeMonth: onChangeMonth,
          onChangeYear: onChangeYear,
        },
        props
      )
    ),
    inputRef = _u.inputRef,
    defaultTransformationRule = _u.defaultTransformationRule,
    isOpenCalendar = _u.isOpenCalendar,
    // displayInputAsFocused,
    activeDate = _u.activeDate,
    secondDate = _u.secondDate,
    value = _u.value,
    handleClickIcon = _u.handleClickIcon,
    handleInputClick = _u.handleInputClick,
    hideCalendar = _u.hideCalendar,
    handleSelectDate = _u.handleSelectDate,
    handleChangeDate = _u.handleChangeDate,
    handleChangeDateRange = _u.handleChangeDateRange,
    handleChangeMonth = _u.handleChangeMonth,
    handleChangeYear = _u.handleChangeYear;
  var offsetVar = (0, getValueFromCssVariable_1.getValueFromCssVariable)(
    '--inputdate-'.concat(size, '-pickerdatetime-offset')
  );
  var formattedOffset = parseFloat(offsetVar);
  var renderPickerDate = react_1['default'].createElement(PickerDate_1['default'], {
    variant: variant,
    size: 'm',
    onSelect: handleSelectDate,
    onChangeMonth: handleChangeMonth,
    onChangeYear: handleChangeYear,
    activeDate: activeDate,
    secondDate: secondDate,
    isRange: isRange,
    minDate: minDate,
    maxDate: maxDate,
    enabledDates: enabledDates,
    disabledDates: disabledDates,
    firstDayIndex: firstDayIndex,
    daysOfWeek: daysOfWeek,
    months: months,
    minYear: minYear,
    maxYear: maxYear,
    showTime: showTime,
    renderDate: renderDate,
    calendarMode: calendarMode,
  });
  return react_1['default'].createElement(
    Popover_1['default'],
    {
      className: 'popover--inputDate',
      isOpened: isOpenCalendar,
      innerChildren: renderPickerDate,
      offset: offset !== null && offset !== void 0 ? offset : formattedOffset,
      placement: placement,
      offsetCounterAxis: offsetCounterAxis,
      useInPortal: useInPortal,
      pointer: false,
      trigger: 'click',
      onClose: hideCalendar,
      disabled: disabled,
    },
    react_1['default'].createElement(
      Input_1['default'],
      __assign({}, otherProps, {
        variant: variant,
        size: size,
        iconSuffix: iconSuffix,
        onClickIconSuffix: handleClickIcon,
        onClick: handleInputClick,
        // fixedLabel={displayInputAsFocused}
        value: value,
        disabled: disabled,
        onChange: isRange ? handleChangeDateRange : handleChangeDate,
        ref: inputRef,
        transformationRule: __assign(__assign({}, defaultTransformationRule), transformationRule),
        placeholder: placeholder,
      })
    )
  );
});

InputDate.propTypes = {
  /**
   * Значение активной даты по умолчанию
   */
  activeDate: PropTypes.instanceOf(Date),
  /**
   * Конфигурация календаря – определяет какие календари отображать
   * @default CALENDAR_MODE.YEARS_WITH_MONTH_DAYS_TIMES
   */
  calendarMode: PropTypes.oneOf([
    'DAYS_ONLY',
    'DAYS_WITH_TIMES',
    'MONTHS_ONLY',
    'MONTHS_WITH_DAYS_TIMES',
    'MONTHS_WITH_DAYS',
    'TIMES_ONLY',
    'YEARS_ONLY',
    'YEARS_WITH_MONTH_DAYS_TIMES',
    'YEARS_WITH_MONTH_DAYS',
    'YEARS_WITH_MONTH',
  ]),
  /**
   * Задает формат отображения даты
   *  @default DD.MM.YYYY
   */
  dateFormat: PropTypes.string,
  /**
   * Задает названия дней недели
   *  @default ['пн', 'вт', 'ср', 'чт', 'пт', 'сб', 'вс']
   */
  daysOfWeek: PropTypes.arrayOf(PropTypes.string),
  /**
   * Устанавливает атрибут disabled
   */
  disabled: PropTypes.bool,
  /**
   * Задает дизейбленые даты, которые нельзя выбрать
   */
  disabledDates: PropTypes.arrayOf(PropTypes.instanceOf(Date)),
  /**
   * Задает доступные даты с самым большим приоритетом
   */
  enabledDates: PropTypes.arrayOf(PropTypes.instanceOf(Date)),
  /**
   * Задает индекс первого дня недели
   * @default 1
   */
  firstDayIndex: PropTypes.number,
  /**
   * Добавляет иконку справа от поля ввода
   */
  iconSuffix: PropTypes.node,
  /**
   * Дает возможность выбрать период из двух дат
   *  @default false
   */
  isRange: PropTypes.bool,
  /**
   * Задает максимальную дату для выбора
   */
  maxDate: PropTypes.instanceOf(Date),
  /**
   * Задает максимальный отображаемый год в календаре, по умолчанию текущий + 10
   * @default 2031
   */
  maxYear: PropTypes.number,
  /**
   * Задает минимальную дату для выбора
   */
  minDate: PropTypes.instanceOf(Date),
  /**
   * Задает минимальный отображаемый год в календаре
   * @default 1980
   */
  minYear: PropTypes.number,
  /**
   * Задает названия месяцов
   *  @default [
   * 'Январь',
   * 'Февраль',
   * 'Март',
   * 'Апрель',
   * 'Май',
   * 'Июнь',
   * 'Июль',
   * 'Август',
   * 'Сентябрь',
   * 'Октябрь',
   * 'Ноябрь',
   * 'Декабрь',
   * ]
   */
  months: PropTypes.arrayOf(PropTypes.string),
  /**
   * Задаёт смещение поповера относительно родительского компонента по основной оси
   */
  offset: PropTypes.number,
  /**
   * Задаёт смещение поповера относительно родительского компонента по поперченой оси (не применяется при placement up, down, right, left)
   */
  offsetCounterAxis: PropTypes.number,
  /**
   * Callback функция, вызываемая при изменении значения
   * @param activeDate - выбранная дата
   * @param secondDate - вторая выбранная дата
   */
  onChange: PropTypes.func,
  /**
   * Callback, вызываемый при изменении месяца
   * @param month – выбранный месяц
   */
  onChangeMonth: PropTypes.func,
  /**
   * Callback, вызываемый при изменении года
   * @param year – выбранный год
   */
  onChangeYear: PropTypes.func,
  /**
   * Callback функция, вызываемая при клике на иконку
   */
  onClickIconSuffix: PropTypes.func,
  /**
   * Задает контент плейсхолдера
   */
  placeholder: PropTypes.string,
  /**
   * Определят размещение выпадающего списка
   */
  placement: PropTypes.oneOf([
    'auto',
    'bottom',
    'bottomLeft',
    'bottomRight',
    'left',
    'leftBottom',
    'leftTop',
    'right',
    'rightBottom',
    'rightTop',
    'top',
    'topLeft',
    'topRight',
  ]),
  /**
   * Функция, которая дает возможность кастомного вывода даты
   * @param date - дата
   */
  renderDate: PropTypes.func,
  /**
   * Значение второй даты по умолчанию (когда isRange = true)
   */
  secondDate: PropTypes.instanceOf(Date),
  /**
   * Добавляет возможность выбора времени PickerTime (не работает при isRange = true)
   * @default false
   */
  showTime: PropTypes.bool,
  /**
   * Задает размер
   * @default m
   */
  size: PropTypes.string,
  /**
   * Задаёт правила трансформации
   *
   * @param transform - метод, изменяющий значение при вводе
   * @param onBlurTransform - метод, изменяющий значение при потере фокуса
   */
  transformationRule: PropTypes.shape({
    onBlurTransform: PropTypes.func,
    transform: PropTypes.func.isRequired,
  }),
  /**
   * Задаёт вариант использования с React Portal
   * @default false
   */
  useInPortal: PropTypes.bool,
  /**
   * Задает основной цвет для компонента
   *  @default primary
   */
  variant: PropTypes.string,
};

InputDate.displayName = 'InputDate';
exports['default'] = InputDate;
