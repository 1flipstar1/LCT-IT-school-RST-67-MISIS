import { ReactNode } from 'react';
import { IInputProps } from '../Input/types';
import { CALENDAR_MODE } from '../PickerDate/constants';
import { PlacementsType } from '../../hooks/usePopper/types';
export interface IInputDateProps extends Omit<IInputProps, 'onChange' | 'fixedLabel' | 'inputControl' | 'iconInputField' | 'defaultValue' | 'value'> {
    /** Callback функция, вызываемая при изменении значения
     * @param activeDate - выбранная дата
     * @param secondDate - вторая выбранная дата
     */
    onChange?: (activeDate?: Date, secondDate?: Date) => void;
    /** Callback, вызываемый при изменении месяца
     * @param month – выбранный месяц
     */
    onChangeMonth?: (month: number) => void;
    /** Callback, вызываемый при изменении года
     * @param year – выбранный год
     */
    onChangeYear?: (year: number) => void;
    /** Добавляет возможность выбора времени PickerTime (не работает при isRange = true)
     * @default false
     */
    showTime?: boolean;
    /** Задает формат отображения даты
     *  @default DD.MM.YYYY */
    dateFormat?: string;
    /** Дает возможность выбрать период из двух дат
     *  @default false */
    isRange?: boolean;
    /** Задает минимальную дату для выбора */
    minDate?: Date;
    /** Задает максимальную дату для выбора */
    maxDate?: Date;
    /** Задает дизейбленые даты, которые нельзя выбрать */
    disabledDates?: Date[];
    /** Задает доступные даты с самым большим приоритетом */
    enabledDates?: Date[];
    /** Значение активной даты по умолчанию */
    activeDate?: Date;
    /** Значение второй даты по умолчанию (когда isRange = true) */
    secondDate?: Date;
    /** Задает индекс первого дня недели
     * @default 1 */
    firstDayIndex?: number;
    /** Задает названия дней недели
     *  @default ['пн', 'вт', 'ср', 'чт', 'пт', 'сб', 'вс'] */
    daysOfWeek?: string[];
    /** Задает названия месяцов
     *  @default [
      'Январь',
      'Февраль',
      'Март',
      'Апрель',
      'Май',
      'Июнь',
      'Июль',
      'Август',
      'Сентябрь',
      'Октябрь',
      'Ноябрь',
      'Декабрь',
    ] */
    months?: string[];
    /** Задает минимальный отображаемый год в календаре
     * @default 1980 */
    minYear?: number;
    /** Задает максимальный отображаемый год в календаре, по умолчанию текущий + 10
     * @default 2031 */
    maxYear?: number;
    /** Функция, которая дает возможность кастомного вывода даты
     * @param date - дата
     */
    renderDate?: (date: Date) => ReactNode;
    placeholder?: string;
    /** Конфигурация календаря – определяет какие календари отображать
     * @default CALENDAR_MODE.YEARS_WITH_MONTH_DAYS_TIMES */
    calendarMode?: CALENDAR_MODE;
    /** Задаёт вариант использования с React Portal
     * @default false */
    useInPortal?: boolean;
    /** Определят размещение выпадающего списка */
    placement?: PlacementsType;
    /** Задаёт смещение поповера относительно родительского компонента по основной оси */
    offset?: number;
    /** Задаёт смещение поповера относительно родительского компонента по поперченой оси (не применяется при placement up, down, right, left) */
    offsetCounterAxis?: number;
}
