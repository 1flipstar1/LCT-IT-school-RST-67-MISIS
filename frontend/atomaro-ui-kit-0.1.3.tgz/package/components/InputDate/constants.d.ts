export declare const DEFAULT_DATE_FORMAT = "DD.MM.YYYY";
export declare const DATE_RANGE_SEPARATOR = " - ";
