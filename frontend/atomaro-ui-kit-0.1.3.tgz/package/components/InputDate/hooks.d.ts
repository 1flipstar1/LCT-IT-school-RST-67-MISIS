import React from 'react';
import dayjs from 'dayjs';
import IMask from 'imask';
import { IInputDateProps } from './types';
export declare const useInputTimeOrDate: ({ ref, disabled, activeValue, secondValue, isRange, dateFormat, minDate, maxDate, minYear, maxYear, onChange, onClickIconSuffix, onChangeMonth, onChangeYear, }: IInputDateProps & {
    activeValue: Date | undefined;
    secondValue: Date | undefined;
    ref: React.Ref<HTMLInputElement> | null;
}) => {
    internalRef: React.MutableRefObject<HTMLInputElement>;
    inputRef: React.MutableRefObject<HTMLInputElement>;
    dateMaskParams: {
        mask: DateConstructor;
        pattern: string;
        overwrite: boolean;
        autofix: boolean;
        min: Date;
        max: Date;
        format: (date: any) => string;
        parse: (str: any) => dayjs.Dayjs;
        blocks: {
            YYYY: {
                mask: typeof IMask.MaskedRange;
                from: number;
                to: number;
            };
            MM: {
                mask: typeof IMask.MaskedRange;
                from: number;
                to: number;
            };
            DD: {
                mask: typeof IMask.MaskedRange;
                from: number;
                to: number;
            };
            HH: {
                mask: typeof IMask.MaskedRange;
                from: number;
                to: number;
            };
            mm: {
                mask: typeof IMask.MaskedRange;
                from: number;
                to: number;
            };
        };
    };
    dateMask: IMask.MaskedFunction;
    dateRangeMask: IMask.MaskedPattern<string>;
    defaultTransformationRule: {
        transform: (inputValue?: string) => string;
    };
    isOpenCalendar: boolean;
    setIsOpenCalendar: React.Dispatch<React.SetStateAction<boolean>>;
    displayInputAsFocused: boolean;
    setDisplayInputAsFocused: React.Dispatch<React.SetStateAction<boolean>>;
    activeDate: Date;
    setActiveDate: React.Dispatch<React.SetStateAction<Date>>;
    secondDate: Date;
    setSecondDate: React.Dispatch<React.SetStateAction<Date>>;
    value: string;
    setValue: React.Dispatch<React.SetStateAction<string>>;
    handleClickIcon: (e: any) => void;
    handleInputClick: React.MouseEventHandler<Element>;
    hideCalendar: () => void;
    toggleCalendar: () => void;
    handleSelectDate: (start: Date, end?: Date) => void;
    handleChangeDate: (e: any) => void;
    handleChangeDateRange: (e: any) => void;
    handleChangeMonth: (month: number) => void;
    handleChangeYear: (year: number) => void;
};
