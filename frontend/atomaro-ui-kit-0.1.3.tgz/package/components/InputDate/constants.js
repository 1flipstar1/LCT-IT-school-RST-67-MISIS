"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.DATE_RANGE_SEPARATOR = exports.DEFAULT_DATE_FORMAT = void 0;
exports.DEFAULT_DATE_FORMAT = 'DD.MM.YYYY';
exports.DATE_RANGE_SEPARATOR = ' - ';