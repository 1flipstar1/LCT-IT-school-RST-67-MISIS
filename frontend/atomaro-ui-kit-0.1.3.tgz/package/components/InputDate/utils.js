'use strict';

var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.parseToInputString =
  exports.getDateMaskParams =
  exports.isPartiallyValidDateRangeFormat =
  exports.isValidDateRangeFormat =
  exports.isValidDateFormat =
    void 0;
/* eslint-disable no-nested-ternary */
var dayjs_1 = __importDefault(require('dayjs'));
var imask_1 = __importDefault(require('imask'));
var constants_1 = require('./constants');
var isValidDateFormat = function isValidDateFormat(dateString, dateFormat) {
  var formattedDate = (0, dayjs_1['default'])(dateString, dateFormat).format(dateFormat);
  return formattedDate === dateString && formattedDate.length === dateFormat.length;
};
exports.isValidDateFormat = isValidDateFormat;
var isValidDateRangeFormat = function isValidDateRangeFormat(dateString, dateFormat) {
  var _a = dateString.split(constants_1.DATE_RANGE_SEPARATOR),
    dateFrom = _a[0],
    dateTo = _a[1];
  var formattedDateFrom = (0, dayjs_1['default'])(dateFrom, dateFormat).format(dateFormat);
  var formattedDateTo = (0, dayjs_1['default'])(dateTo, dateFormat).format(dateFormat);
  var formattedDate = ''
    .concat(formattedDateFrom)
    .concat(constants_1.DATE_RANGE_SEPARATOR)
    .concat(formattedDateTo);
  return (
    formattedDate === dateString &&
    formattedDate.length === dateFormat.length * 2 + constants_1.DATE_RANGE_SEPARATOR.length
  );
};
exports.isValidDateRangeFormat = isValidDateRangeFormat;
var isPartiallyValidDateRangeFormat = function isPartiallyValidDateRangeFormat(
  dateString,
  dateFormat
) {
  var _a = dateString.split(constants_1.DATE_RANGE_SEPARATOR),
    dateFrom = _a[0],
    dateTo = _a[1];
  var formattedDateFrom = (0, dayjs_1['default'])(dateFrom, dateFormat).format(dateFormat);
  var formattedDateTo = (0, dayjs_1['default'])(dateTo, dateFormat).format(dateFormat);
  return {
    from: {
      valid: formattedDateFrom !== 'Invalid Date',
      date: formattedDateFrom,
    },
    to: {
      valid: formattedDateTo !== 'Invalid Date',
      date: formattedDateTo,
    },
  };
};
exports.isPartiallyValidDateRangeFormat = isPartiallyValidDateRangeFormat;
var getDateMaskParams = function getDateMaskParams(dateFormat, minYear, maxYear, minDate, maxDate) {
  return {
    mask: Date,
    pattern: dateFormat,
    overwrite: true,
    autofix: true,
    min: minDate,
    max: maxDate,
    format: function format(date) {
      return (0, dayjs_1['default'])(date, dateFormat).format(dateFormat);
    },
    parse: function parse(str) {
      return (0, dayjs_1['default'])(str, dateFormat);
    },
    blocks: {
      YYYY: {
        mask: imask_1['default'].MaskedRange,
        from: minYear,
        to: maxYear,
      },
      MM: {
        mask: imask_1['default'].MaskedRange,
        from: 1,
        to: 12,
      },
      DD: {
        mask: imask_1['default'].MaskedRange,
        from: 1,
        to: 31,
      },
      HH: {
        mask: imask_1['default'].MaskedRange,
        from: 0,
        to: 23,
      },
      mm: {
        mask: imask_1['default'].MaskedRange,
        from: 0,
        to: 59,
      },
    },
  };
};
exports.getDateMaskParams = getDateMaskParams;
var parseToInputString = function parseToInputString(dates, params) {
  if (params.isRange) {
    return dates.start && dates.end
      ? ''
          .concat((0, dayjs_1['default'])(dates.start).format(params.dateFormat))
          .concat(constants_1.DATE_RANGE_SEPARATOR)
          .concat((0, dayjs_1['default'])(dates.end).format(params.dateFormat))
      : dates.start
      ? params.isOpenCalendar
        ? ''
            .concat((0, dayjs_1['default'])(dates.start).format(params.dateFormat))
            .concat(constants_1.DATE_RANGE_SEPARATOR)
        : ''
            .concat((0, dayjs_1['default'])(dates.start).format(params.dateFormat))
            .concat(constants_1.DATE_RANGE_SEPARATOR, '...')
      : '';
  }
  return dates.start ? (0, dayjs_1['default'])(dates.start).format(params.dateFormat) : '';
};
exports.parseToInputString = parseToInputString;
