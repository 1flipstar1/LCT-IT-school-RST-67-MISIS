import React from 'react';
import { IInputDateProps } from './types';
declare const InputDate: React.ForwardRefExoticComponent<IInputDateProps & React.RefAttributes<HTMLInputElement>>;
export default InputDate;
