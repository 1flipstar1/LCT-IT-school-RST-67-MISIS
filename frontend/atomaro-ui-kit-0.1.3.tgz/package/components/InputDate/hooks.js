'use strict';

var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.useInputTimeOrDate = void 0;
var react_1 = require('react');
var dayjs_1 = __importDefault(require('dayjs'));
var imask_1 = __importDefault(require('imask'));
var customParseFormat_1 = __importDefault(require('dayjs/plugin/customParseFormat'));
var constants_1 = require('./constants');
var constants_2 = require('../PickerDate/constants');
var utils_1 = require('./utils');
var function_1 = require('../../utils/function');
var useCombinedRefs_1 = require('../../hooks/useCombinedRefs');
var useInputTimeOrDate = function useInputTimeOrDate(_a) {
  var ref = _a.ref,
    disabled = _a.disabled,
    activeValue = _a.activeValue,
    secondValue = _a.secondValue,
    _b = _a.isRange,
    isRange = _b === void 0 ? false : _b,
    dateFormat = _a.dateFormat,
    minDate = _a.minDate,
    maxDate = _a.maxDate,
    _c = _a.minYear,
    minYear = _c === void 0 ? constants_2.MIN_YEAR : _c,
    _d = _a.maxYear,
    maxYear = _d === void 0 ? constants_2.MAX_YEAR : _d,
    _e = _a.onChange,
    onChange = _e === void 0 ? function_1.noop : _e,
    _f = _a.onClickIconSuffix,
    onClickIconSuffix = _f === void 0 ? function_1.noop : _f,
    _g = _a.onChangeMonth,
    onChangeMonth = _g === void 0 ? function_1.noop : _g,
    _h = _a.onChangeYear,
    onChangeYear = _h === void 0 ? function_1.noop : _h;
  dayjs_1['default'].extend(customParseFormat_1['default']);
  var internalRef = (0, react_1.useRef)(null);
  var inputRef = (0, useCombinedRefs_1.useCombinedRefs)(ref, internalRef);
  var dateMaskParams = (0, utils_1.getDateMaskParams)(
    dateFormat,
    minYear,
    maxYear,
    minDate,
    maxDate
  );
  var dateMask = imask_1['default'].createMask(dateMaskParams);
  var dateRangeMask = imask_1['default'].createMask({
    mask: 'from'.concat(constants_1.DATE_RANGE_SEPARATOR, 'to'),
    blocks: {
      from: dateMaskParams,
      to: dateMaskParams,
    },
  });
  var defaultTransformationRule = {
    transform: function transform(inputValue) {
      if (inputValue === void 0) {
        inputValue = '';
      }
      var isValid = isRange
        ? (0, utils_1.isValidDateRangeFormat)(inputValue, dateFormat)
        : (0, utils_1.isValidDateFormat)(inputValue, dateFormat);
      if (isValid) {
        return isRange ? dateRangeMask.resolve(inputValue) : dateMask.resolve(inputValue);
      }
      return inputValue;
    },
  };
  var _j = (0, react_1.useState)(activeValue),
    activeDate = _j[0],
    setActiveDate = _j[1];
  var _k = (0, react_1.useState)(secondValue),
    secondDate = _k[0],
    setSecondDate = _k[1];
  var _l = (0, react_1.useState)(false),
    isOpenCalendar = _l[0],
    setIsOpenCalendar = _l[1];
  var _m = (0, react_1.useState)(false),
    displayInputAsFocused = _m[0],
    setDisplayInputAsFocused = _m[1];
  var _o = (0, react_1.useState)(
      (0, utils_1.parseToInputString)(
        {
          start: activeValue,
          end: secondValue,
        },
        {
          isRange: isRange,
          dateFormat: dateFormat,
          isOpenCalendar: isOpenCalendar,
        }
      )
    ),
    value = _o[0],
    setValue = _o[1];
  var toggleCalendar = function toggleCalendar() {
    if (!disabled) {
      setIsOpenCalendar(!isOpenCalendar);
      if (activeDate && !secondDate) {
        setValue(value.replace('...', ''));
      }
    }
  };
  var handleClickIcon = function handleClickIcon(e) {
    var _a;
    (_a = inputRef.current) === null || _a === void 0 ? void 0 : _a.focus();
    toggleCalendar();
    onClickIconSuffix(e);
  };
  var handleInputClick = function handleInputClick() {
    // e.nativeEvent.stopImmediatePropagation();
    if (!disabled) {
      setIsOpenCalendar(true);
      if (activeDate && !secondDate) {
        setValue(value.replace('...', ''));
      }
    }
  };
  var hideCalendar = function hideCalendar() {
    if (isOpenCalendar) {
      setIsOpenCalendar(false);
    }
  };
  var handleSelectDate = function handleSelectDate(start, end) {
    setActiveDate(start);
    setSecondDate(end);
    setValue(
      (0, utils_1.parseToInputString)(
        {
          start: start,
          end: end,
        },
        {
          isRange: isRange,
          dateFormat: dateFormat,
          isOpenCalendar: isOpenCalendar,
        }
      )
    );
    onChange(start, end);
    if (start && end) {
      setIsOpenCalendar(false);
      setDisplayInputAsFocused(false);
    }
  };
  (0, react_1.useEffect)(
    function () {
      if (!isRange) {
        setIsOpenCalendar(false);
      }
    },
    [isRange, activeDate]
  );
  var handleChangeDate = function handleChangeDate(e) {
    e.stopPropagation();
    var inputValue = e.target.value;
    setValue(inputValue);
    if (!inputValue) {
      setActiveDate(undefined);
      onChange(undefined);
    }
    if ((0, utils_1.isValidDateFormat)(inputValue, dateFormat)) {
      var valueDate = (0, dayjs_1['default'])(inputValue, dateFormat).format();
      setActiveDate(new Date(valueDate));
      onChange(new Date(valueDate));
    }
  };
  var handleChangeDateRange = function handleChangeDateRange(e) {
    setIsOpenCalendar(true);
    var inputValue = e.target.value;
    setValue(inputValue);
    if (!inputValue) {
      setActiveDate(undefined);
      setSecondDate(undefined);
      onChange(undefined, undefined);
    }
    if ((0, utils_1.isValidDateFormat)(inputValue, dateFormat)) {
      var valueDate = (0, dayjs_1['default'])(inputValue, dateFormat).format();
      setActiveDate(new Date(valueDate));
      setSecondDate(undefined);
      onChange(new Date(valueDate), undefined);
      if (inputValue !== (0, dayjs_1['default'])(activeDate).format(dateFormat)) {
        setValue(
          (0, utils_1.parseToInputString)(
            {
              start: new Date(valueDate),
              end: undefined,
            },
            {
              isRange: isRange,
              dateFormat: dateFormat,
              isOpenCalendar: true,
            }
          )
        );
      }
    }
    if ((0, utils_1.isValidDateRangeFormat)(inputValue, dateFormat)) {
      var _a = inputValue.split(constants_1.DATE_RANGE_SEPARATOR),
        dateFrom = _a[0],
        dateTo = _a[1];
      var valueDateFrom = (0, dayjs_1['default'])(dateFrom, dateFormat).format();
      var valueDateTo = (0, dayjs_1['default'])(dateTo, dateFormat).format();
      setActiveDate(new Date(valueDateFrom));
      setSecondDate(new Date(valueDateTo));
      onChange(new Date(valueDateFrom), new Date(valueDateTo));
    }
    if (
      (0, utils_1.isPartiallyValidDateRangeFormat)(inputValue, dateFormat).from.valid &&
      !(0, utils_1.isPartiallyValidDateRangeFormat)(inputValue, dateFormat).to.valid
    ) {
      setSecondDate(undefined);
    }
    if (
      !(0, utils_1.isPartiallyValidDateRangeFormat)(inputValue, dateFormat).from.valid &&
      (0, utils_1.isPartiallyValidDateRangeFormat)(inputValue, dateFormat).to.valid
    ) {
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      var _b = inputValue.split(constants_1.DATE_RANGE_SEPARATOR),
        _1 = _b[0],
        dateTo = _b[1];
      var valueDateTo = (0, dayjs_1['default'])(
        (0, dayjs_1['default'])(dateTo, dateFormat).format()
      ).toDate();
      setActiveDate(valueDateTo);
      setSecondDate(undefined);
    }
    if (
      !(0, utils_1.isPartiallyValidDateRangeFormat)(inputValue, dateFormat).from.valid &&
      !(0, utils_1.isPartiallyValidDateRangeFormat)(inputValue, dateFormat).to.valid
    ) {
      setSecondDate(undefined);
      setActiveDate(undefined);
    }
  };
  (0, react_1.useEffect)(
    function () {
      setDisplayInputAsFocused(isOpenCalendar);
      // eslint-disable-next-line react-hooks/exhaustive-deps
    },
    [isOpenCalendar]
  );
  (0, react_1.useEffect)(
    function () {
      if (!isOpenCalendar) {
        setValue(
          (0, utils_1.parseToInputString)(
            {
              start: activeDate,
              end: secondDate,
            },
            {
              isRange: isRange,
              dateFormat: dateFormat,
              isOpenCalendar: isOpenCalendar,
            }
          )
        );
        if (activeDate === secondDate) {
          setSecondDate(undefined);
        }
      }
    },
    [isOpenCalendar, activeDate, secondDate, setValue, setSecondDate, isRange, dateFormat]
  );
  (0, react_1.useEffect)(
    function () {
      minDate === null || minDate === void 0 ? void 0 : minDate.setHours(0, 0, 0, 0);
      var formattedValue = (0, utils_1.parseToInputString)(
        {
          start: activeValue,
          end: secondValue,
        },
        {
          isRange: isRange,
          dateFormat: dateFormat,
          isOpenCalendar: isOpenCalendar,
        }
      );
      if (formattedValue !== value) {
        setValue(formattedValue);
        if (isRange) {
          if (!formattedValue) {
            setActiveDate(undefined);
            setSecondDate(undefined);
          }
          if ((0, utils_1.isValidDateRangeFormat)(formattedValue, dateFormat)) {
            var _a = formattedValue.split(constants_1.DATE_RANGE_SEPARATOR),
              dateFrom = _a[0],
              dateTo = _a[1];
            var valueDateFrom = (0, dayjs_1['default'])(dateFrom, dateFormat).format();
            var valueDateTo = (0, dayjs_1['default'])(dateTo, dateFormat).format();
            setActiveDate(new Date(valueDateFrom));
            setSecondDate(new Date(valueDateTo));
          }
        } else {
          if (!formattedValue) {
            setActiveDate(undefined);
          }
          if ((0, utils_1.isValidDateFormat)(formattedValue, dateFormat)) {
            var valueDate = (0, dayjs_1['default'])(formattedValue, dateFormat).format();
            setActiveDate(new Date(valueDate));
          }
        }
      }
      // eslint-disable-next-line react-hooks/exhaustive-deps
    },
    [activeValue, secondValue, isRange, dateFormat]
  );
  var handleChangeMonth = function handleChangeMonth(month) {
    onChangeMonth(month);
  };
  var handleChangeYear = function handleChangeYear(year) {
    onChangeYear(year);
  };
  return {
    internalRef: internalRef,
    inputRef: inputRef,
    dateMaskParams: dateMaskParams,
    dateMask: dateMask,
    dateRangeMask: dateRangeMask,
    defaultTransformationRule: defaultTransformationRule,
    isOpenCalendar: isOpenCalendar,
    setIsOpenCalendar: setIsOpenCalendar,
    displayInputAsFocused: displayInputAsFocused,
    setDisplayInputAsFocused: setDisplayInputAsFocused,
    activeDate: activeDate,
    setActiveDate: setActiveDate,
    secondDate: secondDate,
    setSecondDate: setSecondDate,
    value: value,
    setValue: setValue,
    handleClickIcon: handleClickIcon,
    handleInputClick: handleInputClick,
    hideCalendar: hideCalendar,
    toggleCalendar: toggleCalendar,
    handleSelectDate: handleSelectDate,
    handleChangeDate: handleChangeDate,
    handleChangeDateRange: handleChangeDateRange,
    handleChangeMonth: handleChangeMonth,
    handleChangeYear: handleChangeYear,
  };
};
exports.useInputTimeOrDate = useInputTimeOrDate;
