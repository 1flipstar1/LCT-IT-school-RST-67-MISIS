'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __rest =
  (this && this.__rest) ||
  function (s, e) {
    var t = {};
    for (var p in s)
      if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === 'function')
      for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
          t[p[i]] = s[p[i]];
      }
    return t;
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var react_transition_group_1 = require('react-transition-group');
var ToastNotification_1 = __importDefault(
  require('../../Notifications/ToastNotification/ToastNotification')
);
var CustomToastNotification_1 = __importDefault(
  require('../../Notifications/CustomToastNotification/CustomToastNotification')
);
var styles_1 = require('./styles');
var ToastNotifications = function ToastNotifications(props) {
  var position = props.position,
    notifications = props.notifications;
  return react_1['default'].createElement(
    styles_1.StyledToastNotifications,
    {
      position: position,
    },
    react_1['default'].createElement(
      react_transition_group_1.TransitionGroup,
      {
        component: null,
      },
      notifications.map(function (_a) {
        var isCustom = _a.isCustom,
          notification = __rest(_a, ['isCustom']);
        return react_1['default'].createElement(
          react_transition_group_1.CSSTransition,
          {
            key: notification.id,
            mountOnEnter: true,
            unmountOnExit: true,
            timeout: 300,
            classNames: 'toast-notification',
          },
          isCustom
            ? react_1['default'].createElement(
                CustomToastNotification_1['default'],
                __assign({}, notification)
              )
            : react_1['default'].createElement(
                ToastNotification_1['default'],
                __assign({}, notification)
              )
        );
      })
    )
  );
};
exports['default'] = ToastNotifications;
