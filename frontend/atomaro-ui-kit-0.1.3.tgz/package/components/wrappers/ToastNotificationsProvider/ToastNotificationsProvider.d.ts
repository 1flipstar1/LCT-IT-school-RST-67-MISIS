import React from 'react';
import { IToastNotificationsProvider } from './types';
declare const ToastNotificationsProvider: React.FC<IToastNotificationsProvider>;
export default ToastNotificationsProvider;
