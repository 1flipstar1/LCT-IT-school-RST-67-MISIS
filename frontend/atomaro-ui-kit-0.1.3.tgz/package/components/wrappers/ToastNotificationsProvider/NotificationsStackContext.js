'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.NotificationsStackContext = void 0;
var react_1 = require('react');
exports.NotificationsStackContext = (0, react_1.createContext)({
  addCustomNotification: function addCustomNotification() {},
  addNotification: function addNotification() {},
  closeNotification: function closeNotification() {},
});
