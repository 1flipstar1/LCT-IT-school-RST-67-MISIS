'use strict';
var PropTypes = require('prop-types');

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __createBinding =
  (this && this.__createBinding) ||
  (Object.create
    ? function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ('get' in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = {
            enumerable: true,
            get: function get() {
              return m[k];
            },
          };
        }
        Object.defineProperty(o, k2, desc);
      }
    : function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
      });
var __setModuleDefault =
  (this && this.__setModuleDefault) ||
  (Object.create
    ? function (o, v) {
        Object.defineProperty(o, 'default', {
          enumerable: true,
          value: v,
        });
      }
    : function (o, v) {
        o['default'] = v;
      });
var __importStar =
  (this && this.__importStar) ||
  function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null)
      for (var k in mod)
        if (k !== 'default' && Object.prototype.hasOwnProperty.call(mod, k))
          __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
  };
var __rest =
  (this && this.__rest) ||
  function (s, e) {
    var t = {};
    for (var p in s)
      if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === 'function')
      for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
          t[p[i]] = s[p[i]];
      }
    return t;
  };
var __spreadArray =
  (this && this.__spreadArray) ||
  function (to, from, pack) {
    if (pack || arguments.length === 2)
      for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
          if (!ar) ar = Array.prototype.slice.call(from, 0, i);
          ar[i] = from[i];
        }
      }
    return to.concat(ar || Array.prototype.slice.call(from));
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importStar(require('react'));
var react_dom_1 = require('react-dom');
var constants_1 = require('../../Notifications/constants');
var NotificationsStackContext_1 = require('./NotificationsStackContext');
var ToastNotifications_1 = __importDefault(require('./ToastNotifications'));
var useIdGenerator_1 = require('../../../hooks/useIdGenerator');
var portalDiv = typeof window !== 'undefined' ? document.createElement('div') : null;
var ToastNotificationsProvider = function ToastNotificationsProvider(_a) {
  var children = _a.children,
    _b = _a.maxCount,
    maxCount = _b === void 0 ? 3 : _b,
    _c = _a.position,
    position = _c === void 0 ? constants_1.NOTIFICATION_POSITION.topRight : _c,
    _d = _a.useInPortal,
    useInPortal = _d === void 0 ? true : _d;
  var _e = (0, react_1.useState)([]),
    notifications = _e[0],
    setNotifications = _e[1];
  var generateNewId = (0, useIdGenerator_1.useIdGenerator)(maxCount).generateNewId;
  var addNotification = (0, react_1.useCallback)(
    function (_a, isCustom) {
      var content = _a.content,
        props = __rest(_a, ['content']);
      var last = generateNewId().toString();
      var newNotes = __spreadArray(
        __spreadArray([], notifications, true),
        [
          __assign(__assign({}, props), {
            id: last,
            isCustom: isCustom,
          }),
        ],
        false
      );
      if (newNotes.length > maxCount) {
        newNotes.shift();
      }
      setNotifications(newNotes);
    },
    [generateNewId, maxCount, notifications]
  );
  var addCustomNotification = (0, react_1.useCallback)(
    function (props) {
      return addNotification(props, true);
    },
    [addNotification]
  );
  var closeNotification = (0, react_1.useCallback)(function (closeId) {
    setNotifications(function (notes) {
      return notes.filter(function (note) {
        return note.id !== closeId;
      });
    });
  }, []);
  (0, react_1.useEffect)(
    function () {
      if (portalDiv && useInPortal) {
        document.body.appendChild(portalDiv);
      }
      return function () {
        if (portalDiv && document.body.contains(portalDiv)) {
          document.body.removeChild(portalDiv);
        }
      };
    },
    [useInPortal]
  );
  var toastNotifications = react_1['default'].createElement(ToastNotifications_1['default'], {
    position: position,
    notifications: notifications,
  });
  return react_1['default'].createElement(
    NotificationsStackContext_1.NotificationsStackContext.Provider,
    {
      value: {
        addCustomNotification: addCustomNotification,
        addNotification: addNotification,
        closeNotification: closeNotification,
      },
    },
    children,
    useInPortal && portalDiv
      ? (0, react_dom_1.createPortal)(toastNotifications, portalDiv)
      : toastNotifications
  );
};

ToastNotificationsProvider.propTypes = {
  children: PropTypes.node,
  /**
   * Задает максимальное количество уведомлений
   *  @default 3
   */
  maxCount: PropTypes.number,
  /**
   * Задает расположение уведомления
   */
  position: PropTypes.oneOf([
    'bottomCenter',
    'bottomLeft',
    'bottomRight',
    'topCenter',
    'topLeft',
    'topRight',
  ]).isRequired,
  /**
   * Задает использование в Portal
   */
  useInPortal: PropTypes.bool,
};

exports['default'] = ToastNotificationsProvider;
