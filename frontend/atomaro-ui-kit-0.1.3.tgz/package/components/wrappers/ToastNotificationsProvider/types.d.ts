import { ReactElement, ReactNode } from 'react';
import { ICustomToastNotification } from '../../Notifications/CustomToastNotification/types';
import { IToastNotification } from '../../Notifications/ToastNotification/types';
import { NotificationPositionType } from '../../Notifications/types';
export type TNotificationButton = {
    text: string;
    action: () => void;
};
export interface IAddNotificationProps extends IToastNotification {
    content?: string;
}
export interface IAddCustomNotificationProps extends ICustomToastNotification {
    content?: (id: string) => ReactElement;
}
export interface IToastNotificationsProvider {
    /** Задает максимальное количество уведомлений
     *  @default 3 */
    maxCount?: number;
    /** Задает расположение уведомления */
    position: NotificationPositionType;
    /** Задает использование в Portal */
    useInPortal?: boolean;
    children?: ReactNode;
}
