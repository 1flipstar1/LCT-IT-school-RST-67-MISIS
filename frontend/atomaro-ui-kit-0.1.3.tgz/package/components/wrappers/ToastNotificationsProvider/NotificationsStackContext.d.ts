/// <reference types="react" />
import { IToastNotification } from '../../Notifications/ToastNotification/types';
import { ICustomToastNotification } from '../../Notifications/CustomToastNotification/types';
export declare const NotificationsStackContext: import("react").Context<{
    addCustomNotification: (props: ICustomToastNotification) => void;
    addNotification: (props: IToastNotification) => void;
    closeNotification: (id: string) => void;
}>;
