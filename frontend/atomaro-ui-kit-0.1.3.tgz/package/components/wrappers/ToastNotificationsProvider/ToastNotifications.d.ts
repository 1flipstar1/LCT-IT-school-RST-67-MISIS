import React from 'react';
import { IToastNotificationWithIsCustom } from '../../Notifications/ToastNotification/types';
import { ICustomToastNotificationWithIsCustom } from '../../Notifications/CustomToastNotification/types';
import { NotificationPositionType } from '../../Notifications/types';
declare const ToastNotifications: (props: {
    position: NotificationPositionType;
    notifications: Array<IToastNotificationWithIsCustom | ICustomToastNotificationWithIsCustom>;
}) => React.JSX.Element;
export default ToastNotifications;
