/// <reference types="react" />
import { NotificationPositionType } from '../../Notifications/types';
export declare const generatePosition: ({ position }: {
    position: NotificationPositionType;
}) => "" | import("styled-components").RuleSet<object>;
export declare const StyledToastNotifications: import("styled-components").IStyledComponent<"web", import("styled-components/dist/types").Substitute<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, {
    position: NotificationPositionType;
}>>;
