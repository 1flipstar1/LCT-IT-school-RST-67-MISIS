'use strict';

var __makeTemplateObject =
  (this && this.__makeTemplateObject) ||
  function (cooked, raw) {
    if (Object.defineProperty) {
      Object.defineProperty(cooked, 'raw', {
        value: raw,
      });
    } else {
      cooked.raw = raw;
    }
    return cooked;
  };
var __createBinding =
  (this && this.__createBinding) ||
  (Object.create
    ? function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ('get' in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = {
            enumerable: true,
            get: function get() {
              return m[k];
            },
          };
        }
        Object.defineProperty(o, k2, desc);
      }
    : function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
      });
var __setModuleDefault =
  (this && this.__setModuleDefault) ||
  (Object.create
    ? function (o, v) {
        Object.defineProperty(o, 'default', {
          enumerable: true,
          value: v,
        });
      }
    : function (o, v) {
        o['default'] = v;
      });
var __importStar =
  (this && this.__importStar) ||
  function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null)
      for (var k in mod)
        if (k !== 'default' && Object.prototype.hasOwnProperty.call(mod, k))
          __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.StyledToastNotifications = exports.generatePosition = void 0;
var styled_components_1 = __importStar(require('styled-components'));
var constants_1 = require('../../Notifications/constants');
var generatePosition = function generatePosition(_a) {
  var position = _a.position;
  var baseBottom = (0, styled_components_1.css)(
    templateObject_1 ||
      (templateObject_1 = __makeTemplateObject(
        [
          '\n    // max-width, \u043F\u043E\u0442\u043E\u043C\u0443 \u0447\u0442\u043E mobile-first \u043D\u0435 \u0440\u0430\u0431\u043E\u0442\u0430\u0435\u0442 \u0434\u043B\u044F \u0443\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u0439.\n    // \u043E\u043D\u0438 \u0434\u043E\u043B\u0436\u043D\u044B \u0431\u044B\u0442\u044C \u0440\u0430\u0441\u0441\u0447\u0438\u0442\u0430\u043D\u044B \u043D\u0430 \u0432\u0441\u044E \u0448\u0438\u0440\u0438\u043D\u0443 \u0442\u043E\u043B\u044C\u043A\u043E \u0434\u043B\u044F 320px \u0438 \u043C\u0435\u043D\u044C\u0448\u0435\n    @media screen and (max-width: 320px) {\n      width: calc(100% - 40px);\n      bottom: 20px;\n      left: 50%;\n      transform: translateX(-50%);\n      flex-flow: wrap;\n      flex-direction: column;\n    }\n  ',
        ],
        [
          '\n    // max-width, \u043F\u043E\u0442\u043E\u043C\u0443 \u0447\u0442\u043E mobile-first \u043D\u0435 \u0440\u0430\u0431\u043E\u0442\u0430\u0435\u0442 \u0434\u043B\u044F \u0443\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u0439.\n    // \u043E\u043D\u0438 \u0434\u043E\u043B\u0436\u043D\u044B \u0431\u044B\u0442\u044C \u0440\u0430\u0441\u0441\u0447\u0438\u0442\u0430\u043D\u044B \u043D\u0430 \u0432\u0441\u044E \u0448\u0438\u0440\u0438\u043D\u0443 \u0442\u043E\u043B\u044C\u043A\u043E \u0434\u043B\u044F 320px \u0438 \u043C\u0435\u043D\u044C\u0448\u0435\n    @media screen and (max-width: 320px) {\n      width: calc(100% - 40px);\n      bottom: 20px;\n      left: 50%;\n      transform: translateX(-50%);\n      flex-flow: wrap;\n      flex-direction: column;\n    }\n  ',
        ]
      ))
  );
  var baseTop = (0, styled_components_1.css)(
    templateObject_2 ||
      (templateObject_2 = __makeTemplateObject(
        [
          '\n    @media screen and (max-width: 320px) {\n      width: calc(100% - 40px);\n      top: 20px;\n      left: 50%;\n      transform: translateX(-50%);\n      flex-flow: wrap;\n      flex-direction: column-reverse;\n    }\n  ',
        ],
        [
          '\n    @media screen and (max-width: 320px) {\n      width: calc(100% - 40px);\n      top: 20px;\n      left: 50%;\n      transform: translateX(-50%);\n      flex-flow: wrap;\n      flex-direction: column-reverse;\n    }\n  ',
        ]
      ))
  );
  switch (position) {
    case constants_1.NOTIFICATION_POSITION.bottomCenter:
      return (0, styled_components_1.css)(
        templateObject_3 ||
          (templateObject_3 = __makeTemplateObject(
            [
              '\n        bottom: 20px;\n        left: 50%;\n        flex-flow: wrap;\n        transform: translateX(-50%);\n        ',
              '\n      ',
            ],
            [
              '\n        bottom: 20px;\n        left: 50%;\n        flex-flow: wrap;\n        transform: translateX(-50%);\n        ',
              '\n      ',
            ]
          )),
        baseBottom
      );
    case constants_1.NOTIFICATION_POSITION.bottomLeft:
      return (0, styled_components_1.css)(
        templateObject_4 ||
          (templateObject_4 = __makeTemplateObject(
            [
              '\n        left: 20px;\n        bottom: 20px;\n        flex-flow: wrap;\n        ',
              '\n      ',
            ],
            [
              '\n        left: 20px;\n        bottom: 20px;\n        flex-flow: wrap;\n        ',
              '\n      ',
            ]
          )),
        baseBottom
      );
    case constants_1.NOTIFICATION_POSITION.bottomRight:
      return (0, styled_components_1.css)(
        templateObject_5 ||
          (templateObject_5 = __makeTemplateObject(
            [
              '\n        right: 20px;\n        bottom: 20px;\n        flex-flow: wrap;\n        ',
              '\n      ',
            ],
            [
              '\n        right: 20px;\n        bottom: 20px;\n        flex-flow: wrap;\n        ',
              '\n      ',
            ]
          )),
        baseBottom
      );
    case constants_1.NOTIFICATION_POSITION.topCenter:
      return (0, styled_components_1.css)(
        templateObject_6 ||
          (templateObject_6 = __makeTemplateObject(
            [
              '\n        top: 20px;\n        left: 50%;\n        flex-flow: wrap-reverse;\n        transform: translateX(-50%);\n        ',
              '\n      ',
            ],
            [
              '\n        top: 20px;\n        left: 50%;\n        flex-flow: wrap-reverse;\n        transform: translateX(-50%);\n        ',
              '\n      ',
            ]
          )),
        baseTop
      );
    case constants_1.NOTIFICATION_POSITION.topLeft:
      return (0, styled_components_1.css)(
        templateObject_7 ||
          (templateObject_7 = __makeTemplateObject(
            [
              '\n        left: 20px;\n        top: 20px;\n        flex-flow: wrap-reverse;\n        ',
              '\n      ',
            ],
            [
              '\n        left: 20px;\n        top: 20px;\n        flex-flow: wrap-reverse;\n        ',
              '\n      ',
            ]
          )),
        baseTop
      );
    case constants_1.NOTIFICATION_POSITION.topRight:
      return (0, styled_components_1.css)(
        templateObject_8 ||
          (templateObject_8 = __makeTemplateObject(
            [
              '\n        right: 20px;\n        top: 20px;\n        flex-flow: wrap-reverse;\n        ',
              '\n      ',
            ],
            [
              '\n        right: 20px;\n        top: 20px;\n        flex-flow: wrap-reverse;\n        ',
              '\n      ',
            ]
          )),
        baseTop
      );
    default:
      return '';
  }
};
exports.generatePosition = generatePosition;
exports.StyledToastNotifications = styled_components_1['default'].div(
  templateObject_9 ||
    (templateObject_9 = __makeTemplateObject(
      [
        '\n  position: fixed;\n  z-index: 100;\n  width: 375px;\n  display: flex;\n  flex-wrap: wrap;\n  ',
        '\n',
      ],
      [
        '\n  position: fixed;\n  z-index: 100;\n  width: 375px;\n  display: flex;\n  flex-wrap: wrap;\n  ',
        '\n',
      ]
    )),
  exports.generatePosition
);
var templateObject_1,
  templateObject_2,
  templateObject_3,
  templateObject_4,
  templateObject_5,
  templateObject_6,
  templateObject_7,
  templateObject_8,
  templateObject_9;
