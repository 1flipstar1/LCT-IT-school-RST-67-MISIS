import { ReactNode } from 'react';
import { ThemeNamesType, ICustomTheme } from '../../../../types/theme';
export interface IThemeProvider {
    themeName: ThemeNamesType;
    themeConfig?: ICustomTheme;
    useCssVariables?: boolean;
    children?: ReactNode;
}
