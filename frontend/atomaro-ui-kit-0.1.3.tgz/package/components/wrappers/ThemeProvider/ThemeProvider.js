// import React, { useEffect } from 'react';
// import { ThemeProvider as StyledThemeProvider } from 'styled-components';
// // import generateTheme from '../../../utils/generateTheme';
// import { IThemeProvider } from './interfaces/IThemeProvider';
// import { ThemeContext } from './ThemeContext';
// // import generateCssVariables from '../../../utils/generateCssVariables';
// const ThemeProvider: React.FC<IThemeProvider> = ({
//   children,
//   themeName,
//   themeConfig,
//   useCssVariables = false,
// }) => {
//   const generatedTheme = generateTheme(themeName, themeConfig);
//   useEffect(() => {
//     if (useCssVariables) {
//       generateCssVariables(generatedTheme);
//     }
//   }, [generatedTheme, useCssVariables]);
//   return (
//     <StyledThemeProvider theme={generatedTheme}>
//       <ThemeContext.Provider value={{ themeName, themeConfig: generatedTheme }}>
//         {children}
//       </ThemeContext.Provider>
//     </StyledThemeProvider>
//   );
// };
// export default ThemeProvider;