/// <reference types="react" />
import { ITheme, ThemeNamesType } from '../../../types/theme';
export declare const ThemeContext: import("react").Context<{
    themeName: ThemeNamesType;
    themeConfig?: ITheme;
}>;
