'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.ThemeContext = void 0;
var react_1 = require('react');
var components_1 = require('../../../constants/components');
// import theme from '../../../constants/theme';
var defaultContextState = {
  themeName: components_1.THEMES.light,
};
exports.ThemeContext = (0, react_1.createContext)(defaultContextState);
