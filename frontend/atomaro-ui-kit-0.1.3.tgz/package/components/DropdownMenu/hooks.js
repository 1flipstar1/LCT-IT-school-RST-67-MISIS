'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __createBinding =
  (this && this.__createBinding) ||
  (Object.create
    ? function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ('get' in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = {
            enumerable: true,
            get: function get() {
              return m[k];
            },
          };
        }
        Object.defineProperty(o, k2, desc);
      }
    : function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
      });
var __setModuleDefault =
  (this && this.__setModuleDefault) ||
  (Object.create
    ? function (o, v) {
        Object.defineProperty(o, 'default', {
          enumerable: true,
          value: v,
        });
      }
    : function (o, v) {
        o['default'] = v;
      });
var __importStar =
  (this && this.__importStar) ||
  function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null)
      for (var k in mod)
        if (k !== 'default' && Object.prototype.hasOwnProperty.call(mod, k))
          __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
  };
var __spreadArray =
  (this && this.__spreadArray) ||
  function (to, from, pack) {
    if (pack || arguments.length === 2)
      for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
          if (!ar) ar = Array.prototype.slice.call(from, 0, i);
          ar[i] = from[i];
        }
      }
    return to.concat(ar || Array.prototype.slice.call(from));
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.useMenuItems = exports.useMenu = void 0;
/* eslint-disable import/no-extraneous-dependencies */
var react_1 = __importStar(require('react'));
var navigation_1 = require('@atomaro/icons/24/navigation');
var noop_1 = require('../../utils/noop');
var useMenu = function useMenu(props) {
  var defaultValue = props.defaultValue,
    valueFromProps = props.value,
    _a = props.hideOnSelect,
    hideOnSelect = _a === void 0 ? true : _a,
    _b = props.onClose,
    onClose = _b === void 0 ? noop_1.noop : _b,
    _c = props.isOpened,
    isOpened = _c === void 0 ? false : _c,
    _d = props.virtualScroll,
    virtualScroll = _d === void 0 ? false : _d,
    _e = props.onChange,
    onChange = _e === void 0 ? noop_1.noop : _e,
    isMultiselect = props.isMultiselect,
    _f = props.controlledComponent,
    controlledComponent = _f === void 0 ? false : _f;
  var _g = (0, react_1.useState)(
      defaultValue !== null && defaultValue !== void 0 ? defaultValue : []
    ),
    selectedOptions = _g[0],
    setSelectedOptions = _g[1];
  var outerRef = (0, react_1.useRef)(null);
  var hideDropdownMenuHandler = function hideDropdownMenuHandler() {
    if (isOpened) {
      onClose();
    }
  };
  var handleChangeSelectedOptions = function handleChangeSelectedOptions(opts) {
    if (!controlledComponent) {
      setSelectedOptions(opts);
    }
    onChange(opts);
  };
  var changeSelectedOption = function changeSelectedOption(valueToSet) {
    var isSelected = selectedOptions.includes(valueToSet);
    if (isMultiselect) {
      if (isSelected) {
        handleChangeSelectedOptions(
          selectedOptions.filter(function (o) {
            return o !== valueToSet;
          })
        );
      } else {
        handleChangeSelectedOptions(
          __spreadArray(__spreadArray([], selectedOptions, true), [valueToSet], false)
        );
      }
    } else if (isSelected) {
      handleChangeSelectedOptions([]);
    } else {
      handleChangeSelectedOptions([valueToSet]);
    }
    if (hideOnSelect) {
      hideDropdownMenuHandler();
    }
  };
  var handleClickOption = function handleClickOption(item, e) {
    e.nativeEvent.stopImmediatePropagation();
    changeSelectedOption(item.key);
  };
  (0, react_1.useEffect)(
    function () {
      if (outerRef && virtualScroll && isOpened && outerRef.current) {
        outerRef.current.style.width = '100%';
      }
    },
    [outerRef, virtualScroll, isOpened]
  );
  (0, react_1.useEffect)(
    function () {
      if (valueFromProps) {
        setSelectedOptions(valueFromProps);
        onChange(valueFromProps);
      }
      // eslint-disable-next-line react-hooks/exhaustive-deps
    },
    [JSON.stringify(valueFromProps)]
  );
  return {
    outerRef: outerRef,
    selectedValues: selectedOptions,
    hideDropdownMenuHandler: hideDropdownMenuHandler,
    handleClickOption: handleClickOption,
  };
};
exports.useMenu = useMenu;
var useMenuItems = function useMenuItems(opts) {
  var hideSelectedOptions = opts.hideSelectedOptions,
    _a = opts.checkIcon,
    checkIcon =
      _a === void 0
        ? react_1['default'].createElement(navigation_1.CheckLarge, {
            size: 16,
          })
        : _a,
    value = opts.value,
    items = opts.items;
  var selected = value !== null && value !== void 0 ? value : [];
  var generateIcon = function generateIcon(isSelected) {
    if (checkIcon === null) {
      return null;
    }
    return isSelected ? checkIcon : null;
  };
  var options = items
    .map(function (_a) {
      var key = _a.key,
        prefix = _a.prefix,
        _b = _a.disabled,
        disabled = _b === void 0 ? false : _b,
        suffix = _a.suffix,
        isTitle = _a.isTitle,
        isDivider = _a.isDivider,
        error = _a.error,
        valueItem = _a.value,
        hint = _a.hint,
        check = _a.checkIcon;
      var isSelected = selected.includes(key);
      return __assign(
        {
          key: key,
          isTitle: isTitle,
          isDivider: isDivider,
          error: error,
          value: valueItem,
          hint: hint,
          isSelected: isSelected,
          prefix: undefined,
          checkIcon: undefined,
          disabled: false,
          suffix: undefined,
        },
        !isTitle &&
          !isDivider && {
            isSelected: isSelected,
            prefix: prefix,
            checkIcon: check || generateIcon(isSelected),
            disabled: disabled,
            suffix: suffix,
          }
      );
    })
    .filter(function (o) {
      return hideSelectedOptions ? !o.isSelected : true;
    });
  return {
    options: options,
    selected: options.filter(function (o) {
      return o.isSelected;
    }),
  };
};
exports.useMenuItems = useMenuItems;
