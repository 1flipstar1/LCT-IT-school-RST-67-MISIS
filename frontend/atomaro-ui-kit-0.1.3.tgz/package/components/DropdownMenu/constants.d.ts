export declare enum DROPDOWN_MENU_SIZES {
    s = "s",
    m = "m"
}
export declare enum DROPDOWN_MENU_VARIANTS {
    primary = "primary"
}
export type DropDownMenuVariants = keyof typeof DROPDOWN_MENU_VARIANTS;
export type DropDownMenuSizes = keyof typeof DROPDOWN_MENU_SIZES;
export declare const DEFAULT_DROPDOWN_MENU_VARIANT = DROPDOWN_MENU_VARIANTS.primary;
export declare const DEFAULT_DROPDOWN_MENU_SIZE = DROPDOWN_MENU_SIZES.m;
