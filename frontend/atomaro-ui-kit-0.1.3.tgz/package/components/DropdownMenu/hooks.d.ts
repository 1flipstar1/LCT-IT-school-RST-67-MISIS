import React, { SyntheticEvent } from 'react';
import { IDropdownMenuOption, IDropdownMenuProps } from './types';
export declare const useMenu: (props: IDropdownMenuProps) => {
    outerRef: React.MutableRefObject<HTMLDivElement>;
    selectedValues: (string | number)[];
    hideDropdownMenuHandler: () => void;
    handleClickOption: (item: IDropdownMenuOption, e: SyntheticEvent<HTMLLIElement>) => void;
};
export declare const useMenuItems: (opts: IDropdownMenuProps) => {
    options: IDropdownMenuOption[];
    selected: IDropdownMenuOption[];
};
