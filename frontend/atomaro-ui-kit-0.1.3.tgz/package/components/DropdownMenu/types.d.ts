import React, { ReactNode, ReactElement } from 'react';
import { DropDownMenuSizes, DropDownMenuVariants } from './constants';
import { PlacementsType, UsePopperProps } from '../../hooks/usePopper/types';
export interface IDropdownMenuItem {
    value: string | ReactNode;
    key: number | string;
    hint?: string;
    prefix?: (item: IDropdownMenuItem) => ReactNode;
    checkIcon?: ReactNode;
    suffix?: (item: IDropdownMenuItem) => ReactNode;
    isTitle?: boolean;
    isDivider?: boolean;
    disabled?: boolean;
    error?: boolean;
}
export interface IDropdownMenuOption {
    value: string | ReactNode;
    key: number | string;
    hint?: string;
    prefix?: (item: IDropdownMenuItem) => ReactNode;
    checkIcon?: ReactNode;
    suffix?: (item: IDropdownMenuItem) => ReactNode;
    isTitle?: boolean;
    isDivider?: boolean;
    isSelected?: boolean;
    disabled?: boolean;
    error?: boolean;
}
export interface IDropdownMenuProps extends Omit<React.HTMLAttributes<HTMLDivElement>, 'onChange' | 'defaultValue'> {
    /** Задает вариант
     *  @default primary */
    variant?: DropDownMenuVariants | string;
    /** Задает размер компонента
     * @default m
     */
    size?: DropDownMenuSizes | string;
    /** Переключает на множественный выбор */
    isMultiselect?: boolean;
    /** Задает список элементов для выбора
     * @param value - отображаемое значение
     * @param key - уникальный ключ в разрезе списка элементов
     * @param hint - дополнительная подпись
     * @param icon - иконка
     * @param disabled - задаёт состояние disabled для элемента
     * @param suffix - суффикс слот для элемента
     * @param isTitle - делает из элемента title
     * @param isDivider - делает из элемента divider
     */
    items: IDropdownMenuItem[];
    /** Устанавливает показывать ли  Dropdown
     *  @default false */
    isOpened?: boolean;
    /** Задает значение компонента, используется для управляемых компонентов.
     * Не используется вместе с defaultValue
     */
    value?: IDropdownMenuItem['key'][];
    /** Задает выбранный элемент по умолчанию
     * Не используется вместе с value
     */
    defaultValue?: IDropdownMenuItem['key'][];
    /** Задает задизейбленный элемент
     */
    disabledItems?: IDropdownMenuItem['key'][];
    /** Слот для контента в верхней части Dropdown Menu
     * @param close - функция для закрытия dropdown menu
     * @param selectedItems - массив выбранных элементов
     * @param dropdownItems - массив всех элементов
     */
    headerSlot?: (close: () => void, selectedItems: IDropdownMenuItem[], dropdownItems: IDropdownMenuItem[]) => ReactNode;
    /** Слот для контента в нижней части Dropdown Menu
     * @param close - функция для закрытия dropdown menu
     * @param selectedItems - массив выбранных элементов
     * @param dropdownItems - массив всех элементов
     */
    footerSlot?: (close: () => void, selectedItems: IDropdownMenuItem[], dropdownItems: IDropdownMenuItem[]) => ReactNode;
    /** Задает признак скрывания при выборе элемента
     *  @default true */
    hideOnSelect?: boolean;
    /** Определяет, скрывать ли выбранные значения в дропдауне
     *
     *  @default false */
    hideSelectedOptions?: boolean;
    /**  Соответствовать ширине родительского компонента (root-элемента)
     *  @default true */
    widthFitContent?: boolean;
    /** Задает одинковую иконку для выбранных опций */
    checkIcon?: ReactNode;
    /** Callback функция, вызываемая при выборе значения из списка.
     * при isMultiselect = false возвращает ключ выбранного элемента
     * @param value - ключ выбранного значения из списка
     */
    onChange?: (value: IDropdownMenuItem['key'][]) => void;
    /** Callback функция, вызываемая при закрытии выпадающего списка */
    onClose?: () => void;
    /** Задает элемент, от которого будет позиционирован дропдаун */
    children?: ReactElement;
    /** Пустой поиск */
    isEmpty?: boolean;
    /** Задаёт окрашивать ли текст элемента при выборе */
    isSelectedTextColored?: boolean;
    /** Задает элемент, отображающийся когда ничего не найдено
     * @default Не найдено
     */
    emptyText?: ReactNode;
    /** Определят размещение выпадающего списка */
    placement?: PlacementsType;
    /** Включает виртуальный скролл */
    virtualScroll?: boolean;
    /** Задаёт смещение дропдауна относительно родительского компонента по вертикали
     * @default 4 */
    offset?: number;
    /** Задаёт смещение тултипа относительно родительского компонента по поперченой оси (не применяется при placement up, down, right, left)
     * @default 0 */
    offsetCounterAxis?: number;
    /** Задаёт вариант использования с React Portal
     * @default true */
    useInPortal?: boolean;
    /** Переключает в специальный режим работы, при котором выбранное значение возвращается в onChange, но не отрисовывается.
     * Для того, чтобы отрисовать выбранную опцию используется value
     * @default false */
    controlledComponent?: boolean;
    /** Задаёт параметры для poppper.js */
    usePopperProps?: UsePopperProps;
}
