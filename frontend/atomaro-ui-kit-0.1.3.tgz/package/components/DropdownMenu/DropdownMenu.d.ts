import React from 'react';
import { IDropdownMenuProps } from './types';
import '../../styles/components/dropdownMenu.scss';
declare const DropdownMenu: React.ForwardRefExoticComponent<IDropdownMenuProps & React.RefAttributes<HTMLDivElement>>;
export default DropdownMenu;
