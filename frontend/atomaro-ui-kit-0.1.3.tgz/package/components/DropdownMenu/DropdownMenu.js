'use strict';
var PropTypes = require('prop-types');

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __createBinding =
  (this && this.__createBinding) ||
  (Object.create
    ? function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ('get' in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = {
            enumerable: true,
            get: function get() {
              return m[k];
            },
          };
        }
        Object.defineProperty(o, k2, desc);
      }
    : function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
      });
var __setModuleDefault =
  (this && this.__setModuleDefault) ||
  (Object.create
    ? function (o, v) {
        Object.defineProperty(o, 'default', {
          enumerable: true,
          value: v,
        });
      }
    : function (o, v) {
        o['default'] = v;
      });
var __importStar =
  (this && this.__importStar) ||
  function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null)
      for (var k in mod)
        if (k !== 'default' && Object.prototype.hasOwnProperty.call(mod, k))
          __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
  };
var __spreadArray =
  (this && this.__spreadArray) ||
  function (to, from, pack) {
    if (pack || arguments.length === 2)
      for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
          if (!ar) ar = Array.prototype.slice.call(from, 0, i);
          ar[i] = from[i];
        }
      }
    return to.concat(ar || Array.prototype.slice.call(from));
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
/* eslint-disable jsx-a11y/no-noninteractive-element-interactions */
/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable import/no-extraneous-dependencies */
var react_1 = __importStar(require('react'));
var react_dom_1 = require('react-dom');
var clsx_1 = __importDefault(require('clsx'));
var react_window_1 = require('react-window');
var Typography_1 = __importDefault(require('../Typography/Typography'));
require('../../styles/components/dropdownMenu.scss');
var hooks_1 = require('./hooks');
var constants_1 = require('./constants');
var usePopper_1 = require('../../hooks/usePopper/usePopper');
var useOutsideClick_1 = __importDefault(require('../../hooks/useOutsideClick'));
var noop_1 = require('../../utils/noop');
var useCombinedRefs_1 = require('../../hooks/useCombinedRefs');
var getValueFromCssVariable_1 = require('../../utils/getValueFromCssVariable');
var DropdownMenu = (0, react_1.forwardRef)(function DropdownMenu(props, ref) {
  var _a = props.variant,
    variant = _a === void 0 ? constants_1.DEFAULT_DROPDOWN_MENU_VARIANT : _a,
    _b = props.size,
    size = _b === void 0 ? constants_1.DEFAULT_DROPDOWN_MENU_SIZE : _b,
    classNameProp = props.className,
    children = props.children,
    _c = props.isEmpty,
    isEmpty = _c === void 0 ? false : _c,
    emptyTextProp = props.emptyText,
    placement = props.placement,
    _d = props.isOpened,
    isOpened = _d === void 0 ? false : _d,
    _e = props.virtualScroll,
    virtualScroll = _e === void 0 ? false : _e,
    _f = props.useInPortal,
    useInPortal = _f === void 0 ? true : _f,
    _g = props.widthFitContent,
    widthFitContent = _g === void 0 ? false : _g,
    offset = props.offset,
    offsetCounterAxis = props.offsetCounterAxis,
    headerSlot = props.headerSlot,
    footerSlot = props.footerSlot,
    _h = props.onClose,
    onClose = _h === void 0 ? noop_1.noop : _h,
    styleProp = props.style,
    usePopperProps = props.usePopperProps;
  var emptyText =
    emptyTextProp ||
    react_1['default'].createElement(
      Typography_1['default'],
      {
        variant: 'body-l',
        style: {
          margin: 'var(--spacing-1x) 0',
        },
      },
      '\u041D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u043E'
    );
  var _j = (0, hooks_1.useMenu)(props),
    outerRef = _j.outerRef,
    hideDropdownMenuHandler = _j.hideDropdownMenuHandler,
    handleClickOption = _j.handleClickOption,
    selectedValues = _j.selectedValues;
  var _k = (0, hooks_1.useMenuItems)(
      __assign(__assign({}, props), {
        value: selectedValues,
      })
    ),
    dropdownItems = _k.options,
    selectedItems = _k.selected;
  var dropdownRef = (0, react_1.useRef)();
  var dropdownMenuRef = (0, useCombinedRefs_1.useCombinedRefs)(ref, dropdownRef);
  var rootRef = (0, react_1.useRef)();
  (0, useOutsideClick_1['default'])(rootRef, function () {
    onClose();
  });
  (0, usePopper_1.usePopper)(
    __assign(
      {
        enabled: isOpened,
        placement: placement,
        popper:
          dropdownMenuRef === null || dropdownMenuRef === void 0 ? void 0 : dropdownMenuRef.current,
        trigger: rootRef === null || rootRef === void 0 ? void 0 : rootRef.current,
        eventListeners: isOpened,
        offset: offset,
        offsetCounterAxis: offsetCounterAxis,
        widthFitContent: widthFitContent,
        pointerIsCentered: true,
      },
      usePopperProps
    )
  );
  var listRef = (0, react_1.useRef)(null);
  var virtualItemSizes = __spreadArray([], Array(dropdownItems.length), true).fill(36);
  var virtualItemsSpacing = (0, getValueFromCssVariable_1.getValueFromCssVariable)(
    '--dropdownmenu-'.concat(size, '-itemlist-spacing')
  );
  var formattedSpacing = parseFloat(virtualItemsSpacing);
  var renderOptionHint = function renderOptionHint(item) {
    return (
      item.hint &&
      react_1['default'].createElement(
        'div',
        {
          className: 'dropdown-menu__hint',
        },
        item.hint
      )
    );
  };
  var renderOptionIcon = function renderOptionIcon(item) {
    return (
      item.prefix &&
      react_1['default'].createElement(
        'div',
        {
          className: 'dropdown-menu__prefix',
        },
        item.prefix(item)
      )
    );
  };
  var renderOptionCheckIcon = function renderOptionCheckIcon(item) {
    return (
      item.checkIcon &&
      react_1['default'].createElement(
        'div',
        {
          className: 'dropdown-menu__check-icon',
        },
        item.checkIcon
      )
    );
  };
  var rootOptionClassName = function rootOptionClassName(item) {
    return (0, clsx_1['default'])('dropdown-menu__item', {
      'dropdown-menu__item--selected': item.isSelected,
      'dropdown-menu__item--title': item.isTitle,
      'dropdown-menu__item--divider': item.isDivider,
      'dropdown-menu__item--disabled': item.disabled,
    });
  };
  var renderOption = function renderOption(item) {
    return react_1['default'].createElement(
      'li',
      {
        key: item.key,
        'data-key': item.key,
        className: rootOptionClassName(item),
        onClick: function onClick(e) {
          if (!item.disabled) handleClickOption(item, e);
        },
      },
      !item.isDivider
        ? react_1['default'].createElement(
            react_1['default'].Fragment,
            null,
            renderOptionCheckIcon(item),
            renderOptionIcon(item),
            react_1['default'].createElement(
              'div',
              {
                className: 'dropdown-menu__wrapper',
              },
              react_1['default'].createElement(
                'div',
                {
                  className: 'dropdown-menu__content',
                },
                react_1['default'].createElement(
                  'div',
                  {
                    className: 'dropdown-menu__text',
                  },
                  item.value
                ),
                renderOptionHint(item)
              ),
              (item === null || item === void 0 ? void 0 : item.suffix) &&
                react_1['default'].createElement(
                  'div',
                  {
                    className: 'dropdown-menu__suffix',
                  },
                  item === null || item === void 0 ? void 0 : item.suffix(item)
                )
            )
          )
        : react_1['default'].createElement(
            react_1['default'].Fragment,
            null,
            react_1['default'].createElement('div', {
              className: 'dropdown-menu__divider',
            })
          )
    );
  };
  var RenderVirtualVariableListItem = function RenderVirtualVariableListItem(_a) {
    var _b, _c;
    var index = _a.index,
      style = _a.style;
    var rowRef = (0, react_1.useRef)(null);
    // eslint-disable-next-line consistent-return
    (0, react_1.useEffect)(
      function () {
        if (listRef && rowRef && rowRef.current && virtualItemSizes.length) {
          virtualItemSizes[index] = rowRef.current.offsetHeight + formattedSpacing;
          var frameId_1 = requestAnimationFrame(function () {
            var _a;
            (_a = listRef.current) === null || _a === void 0 ? void 0 : _a.resetAfterIndex(index);
          });
          return function () {
            cancelAnimationFrame(frameId_1);
          };
        }
      },
      [
        rowRef,
        (_b = rowRef.current) === null || _b === void 0 ? void 0 : _b.offsetHeight,
        listRef,
        index,
        virtualItemSizes,
      ]
    );
    return react_1['default'].createElement(
      'div',
      {
        style: style,
        className: 'dropdown-menu__scroll-item',
      },
      react_1['default'].createElement(
        'li',
        {
          key: dropdownItems[index].key,
          className: rootOptionClassName(dropdownItems[index]),
          ref: rowRef,
          onClick: function onClick(e) {
            if (!dropdownItems[index].disabled) handleClickOption(dropdownItems[index], e);
          },
        },
        !dropdownItems[index].isDivider
          ? react_1['default'].createElement(
              react_1['default'].Fragment,
              null,
              renderOptionCheckIcon(dropdownItems[index]),
              renderOptionIcon(dropdownItems[index]),
              react_1['default'].createElement(
                'div',
                {
                  className: 'dropdown-menu__wrapper',
                },
                react_1['default'].createElement(
                  'div',
                  {
                    className: 'dropdown-menu__content',
                  },
                  react_1['default'].createElement(
                    'div',
                    {
                      className: 'dropdown-menu__text',
                    },
                    dropdownItems[index].value
                  ),
                  renderOptionHint(dropdownItems[index])
                ),
                ((_c = dropdownItems[index]) === null || _c === void 0 ? void 0 : _c.suffix) &&
                  react_1['default'].createElement(
                    'div',
                    {
                      className: 'dropdown-menu__suffix',
                    },
                    dropdownItems[index].suffix(dropdownItems[index])
                  )
              )
            )
          : react_1['default'].createElement(
              react_1['default'].Fragment,
              null,
              react_1['default'].createElement('div', {
                className: 'dropdown-menu__divider',
              })
            )
      )
    );
  };
  var getItemSize = (0, react_1.useCallback)(
    function (index) {
      return virtualItemSizes[index];
    },
    [virtualItemSizes]
  );
  var renderVirtualVariableList = isOpened
    ? react_1['default'].createElement(
        react_window_1.VariableSizeList,
        {
          className: 'dropdown-menu__scrollbar',
          height: 256,
          itemCount: virtualItemSizes.length,
          itemSize: getItemSize,
          outerRef: outerRef,
          ref: listRef,
        },
        RenderVirtualVariableListItem
      )
    : null;
  var dropdownMenuOptions = isOpened
    ? dropdownItems.map(function (item) {
        return renderOption(item);
      })
    : null;
  var menuClassName = (0, clsx_1['default'])(
    'dropdown-menu',
    'dropdown-menu--size-'.concat(constants_1.DROPDOWN_MENU_SIZES[size]),
    'dropdown-menu--'.concat(constants_1.DROPDOWN_MENU_VARIANTS[variant]),
    ''.concat(classNameProp)
  );
  var renderMenu = react_1['default'].createElement(
    'div',
    {
      className: menuClassName,
      ref: dropdownMenuRef,
      'data-show': isOpened,
      style: styleProp,
    },
    isEmpty || dropdownItems.length === 0
      ? emptyText &&
          react_1['default'].createElement(
            'div',
            {
              className: 'dropdown-menu__empty',
            },
            emptyText
          )
      : react_1['default'].createElement(
          'div',
          {
            className: 'dropdown-menu__menu',
          },
          headerSlot === null || headerSlot === void 0
            ? void 0
            : headerSlot(hideDropdownMenuHandler, selectedItems, dropdownItems),
          react_1['default'].createElement(
            'ul',
            {
              className: 'dropdown-menu__list',
              role: 'listbox',
            },
            virtualScroll ? renderVirtualVariableList : dropdownMenuOptions
          ),
          footerSlot === null || footerSlot === void 0
            ? void 0
            : footerSlot(hideDropdownMenuHandler, selectedItems, dropdownItems)
        )
  );
  return react_1['default'].createElement(
    react_1['default'].Fragment,
    null,
    react_1['default'].createElement(
      'div',
      {
        ref: rootRef,
        className: 'dropdown-menu-root',
      },
      children
    ),
    useInPortal ? (0, react_dom_1.createPortal)(renderMenu, document.body) : renderMenu
  );
});

DropdownMenu.propTypes = {
  /**
   * Задает элемент, от которого будет позиционирован дропдаун
   */
  children: PropTypes.element,
  className: PropTypes.string,
  /**
   * Задает элемент, отображающийся когда ничего не найдено
   * @default Не найдено
   */
  emptyText: PropTypes.node,
  /**
   * Слот для контента в нижней части Dropdown Menu
   * @param close - функция для закрытия dropdown menu
   * @param selectedItems - массив выбранных элементов
   * @param dropdownItems - массив всех элементов
   */
  footerSlot: PropTypes.func,
  /**
   * Слот для контента в верхней части Dropdown Menu
   * @param close - функция для закрытия dropdown menu
   * @param selectedItems - массив выбранных элементов
   * @param dropdownItems - массив всех элементов
   */
  headerSlot: PropTypes.func,
  /**
   * Пустой поиск
   */
  isEmpty: PropTypes.bool,
  /**
   * Устанавливает показывать ли  Dropdown
   *  @default false
   */
  isOpened: PropTypes.bool,
  /**
   * Задаёт смещение дропдауна относительно родительского компонента по вертикали
   * @default 4
   */
  offset: PropTypes.number,
  /**
   * Задаёт смещение тултипа относительно родительского компонента по поперченой оси (не применяется при placement up, down, right, left)
   * @default 0
   */
  offsetCounterAxis: PropTypes.number,
  /**
   * Callback функция, вызываемая при закрытии выпадающего списка
   */
  onClose: PropTypes.func,
  /**
   * Определят размещение выпадающего списка
   */
  placement: PropTypes.oneOf([
    'auto',
    'bottom',
    'bottomLeft',
    'bottomRight',
    'left',
    'leftBottom',
    'leftTop',
    'right',
    'rightBottom',
    'rightTop',
    'top',
    'topLeft',
    'topRight',
  ]),
  /**
   * Задает размер компонента
   * @default m
   */
  size: PropTypes.string,
  style: PropTypes.object,
  /**
   * Задаёт вариант использования с React Portal
   * @default true
   */
  useInPortal: PropTypes.bool,
  /**
   * Задаёт параметры для poppper.js
   */
  usePopperProps: PropTypes.shape({
    /**
     * Задаёт отступ для поинтера (стрелки) от края поппера (не применяется при placement up, down, right, left)
     *  @default 0
     */
    arrowPadding: PropTypes.number,
    /**
     * Задаёт область для preventOverflow
     *  @default 'clippingParents'
     */
    boundary: PropTypes.oneOfType([
      PropTypes.oneOf(['clippingParents', 'scrollParent']),
      function (props, propName) {
        if (props[propName] == null) {
          return new Error("Prop '" + propName + "' is required but wasn't specified");
        } else if (typeof props[propName] !== 'object' || props[propName].nodeType !== 1) {
          return new Error("Expected prop '" + propName + "' to be of type Element");
        }
      },
    ]),
    /**
     * Включает popper.js для позиционирования
     *  @default "true"
     */
    enabled: PropTypes.bool,
    /**
     * При включении, тултип будет обновлять позицию при scroll, resize
     *  @default "false"
     */
    eventListeners: PropTypes.bool,
    /**
     * При включении, тултип будет менять своё положение на противоположное при нехватке места для отображения
     *  @default "true"
     */
    flip: PropTypes.bool,
    /**
     * Задаёт модификаторы Popper.js
     */
    modifiers: PropTypes.arrayOf(
      PropTypes.shape({
        data: PropTypes.object,
        effect: PropTypes.func,
        enabled: PropTypes.bool,
        fn: PropTypes.func,
        name: PropTypes.string,
        options: PropTypes.object,
        phase: PropTypes.oneOf([
          'afterMain',
          'afterRead',
          'afterWrite',
          'beforeMain',
          'beforeRead',
          'beforeWrite',
          'main',
          'read',
          'write',
        ]),
        requires: PropTypes.arrayOf(PropTypes.string),
        requiresIfExists: PropTypes.arrayOf(PropTypes.string),
      })
    ),
    /**
     * Задаёт смещение поппера относительно родительского компонента по основной оси
     *  @default 11
     */
    offset: PropTypes.number,
    /**
     * Задаёт смещение поппера относительно родительского компонента по поперченой оси (не применяется при placement up, down, right, left)
     *  @default 0
     */
    offsetCounterAxis: PropTypes.number,
    /**
     * Задает расположение
     *  @default "auto"
     */
    placement: PropTypes.oneOf([
      'auto',
      'bottom',
      'bottomLeft',
      'bottomRight',
      'left',
      'leftBottom',
      'leftTop',
      'right',
      'rightBottom',
      'rightTop',
      'top',
      'topLeft',
      'topRight',
    ]),
    /**
     * Центририровать pointer на родительский компонент
     *  @default "false"
     */
    pointerIsCentered: PropTypes.bool,
    popper: function (props, propName) {
      if (props[propName] == null) {
        return null;
      } else if (typeof props[propName] !== 'object' || props[propName].nodeType !== 1) {
        return new Error("Expected prop '" + propName + "' to be of type Element");
      }
    },
    /**
     * При включении, тултип будет смещаться, чтобы оставаться в зоне видимости
     *  @default "true"
     */
    preventOverflow: PropTypes.bool,
    trigger: PropTypes.oneOfType([
      function (props, propName) {
        if (props[propName] == null) {
          return new Error("Prop '" + propName + "' is required but wasn't specified");
        } else if (typeof props[propName] !== 'object' || props[propName].nodeType !== 1) {
          return new Error("Expected prop '" + propName + "' to be of type Element");
        }
      },
      PropTypes.shape({
        contextElement: function (props, propName) {
          if (props[propName] == null) {
            return null;
          } else if (typeof props[propName] !== 'object' || props[propName].nodeType !== 1) {
            return new Error("Expected prop '" + propName + "' to be of type Element");
          }
        },
        getBoundingClientRect: PropTypes.func.isRequired,
      }),
    ]),
    /**
     * При включении, тултип будет соответствовать ширине родительского компонента
     *  @default "false"
     */
    widthFitContent: PropTypes.bool,
  }),
  /**
   * Задает вариант
   *  @default primary
   */
  variant: PropTypes.string,
  /**
   * Включает виртуальный скролл
   */
  virtualScroll: PropTypes.bool,
  /**
   * Соответствовать ширине родительского компонента (root-элемента)
   *  @default true
   */
  widthFitContent: PropTypes.bool,
};

DropdownMenu.displayName = 'DropdownMenu';
exports['default'] = DropdownMenu;
