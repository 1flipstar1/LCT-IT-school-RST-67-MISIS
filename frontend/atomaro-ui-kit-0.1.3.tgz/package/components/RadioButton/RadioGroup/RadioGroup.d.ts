import { FC } from 'react';
import { IRadioGroup } from './types';
import '../../../styles/components/radioButton/radioGroup.scss';
declare const RadioGroup: FC<IRadioGroup>;
export default RadioGroup;
