import React from 'react';
export interface IRadioGroup extends Omit<React.HTMLAttributes<HTMLDivElement>, 'onChange'> {
    /** Callback функция, вызываемая при изменении значения */
    onChange?: (val: string) => void;
    /** Устанавливает checked для radio с совпадающим value */
    value?: string;
    /** Устанавливает атрибут disabled для всей группы */
    disabledAll?: boolean;
}
