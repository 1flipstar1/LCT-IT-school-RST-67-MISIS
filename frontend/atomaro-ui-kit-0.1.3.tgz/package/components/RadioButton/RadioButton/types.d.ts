import { ChangeEvent, InputHTMLAttributes, ReactNode } from 'react';
import { RADIOBUTTON_SIZES, RADIOBUTTON_VARIANTS } from '../constants';
type RadioButtonSizesType = keyof typeof RADIOBUTTON_SIZES;
type RadioButtonVariantsType = keyof typeof RADIOBUTTON_VARIANTS;
export interface IRadioButtonProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'onChange' | 'type' | 'size'> {
    /** Задает текст лейбла для компонента */
    label?: ReactNode;
    /** Задает value */
    value?: string;
    /** Устанавливает атрибут disabled */
    disabled?: boolean;
    /** Задает размер компонента
     * @default s
     */
    size?: RadioButtonSizesType;
    /** Задает внешний вид компонента
     * @default default
     */
    variant?: RadioButtonVariantsType;
    /** Заменяет иконку на кастомную
     * @default <Bullet />
     */
    icon?: ReactNode;
    /** Callback функция, вызываемая при изменении значения */
    onChange?: (event: ChangeEvent<HTMLInputElement>) => void;
}
export {};
