'use strict';
var PropTypes = require('prop-types');

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __createBinding =
  (this && this.__createBinding) ||
  (Object.create
    ? function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ('get' in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = {
            enumerable: true,
            get: function get() {
              return m[k];
            },
          };
        }
        Object.defineProperty(o, k2, desc);
      }
    : function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
      });
var __setModuleDefault =
  (this && this.__setModuleDefault) ||
  (Object.create
    ? function (o, v) {
        Object.defineProperty(o, 'default', {
          enumerable: true,
          value: v,
        });
      }
    : function (o, v) {
        o['default'] = v;
      });
var __importStar =
  (this && this.__importStar) ||
  function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null)
      for (var k in mod)
        if (k !== 'default' && Object.prototype.hasOwnProperty.call(mod, k))
          __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
  };
var __rest =
  (this && this.__rest) ||
  function (s, e) {
    var t = {};
    for (var p in s)
      if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === 'function')
      for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
          t[p[i]] = s[p[i]];
      }
    return t;
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
/* eslint-disable import/no-extraneous-dependencies */
/* eslint-disable jsx-a11y/label-has-associated-control */
var react_1 = __importStar(require('react'));
var clsx_1 = __importDefault(require('clsx'));
require('../../../styles/components/radioButton/radioButton.scss');
var Bullet_1 = __importDefault(require('@atomaro/icons/24/editor/Bullet'));
var context_1 = require('../context/context');
var noop_1 = require('../../../utils/noop');
var constants_1 = require('../constants');
var RadioButton = (0, react_1.forwardRef)(function RadioButton(props, ref) {
  var context = (0, react_1.useContext)(context_1.RadioGroupContext);
  var label = props.label,
    _a = props.disabled,
    disabledProp = _a === void 0 ? false : _a,
    value = props.value,
    _b = props.size,
    size = _b === void 0 ? constants_1.RADIOBUTTON_SIZES.s : _b,
    _c = props.variant,
    variant = _c === void 0 ? constants_1.RADIOBUTTON_VARIANTS.primary : _c,
    _d = props.icon,
    icon = _d === void 0 ? react_1['default'].createElement(Bullet_1['default'], null) : _d,
    _e = props.onChange,
    onChange = _e === void 0 ? noop_1.noop : _e,
    className = props.className,
    restProps = __rest(props, [
      'label',
      'disabled',
      'value',
      'size',
      'variant',
      'icon',
      'onChange',
      'className',
    ]);
  var _f = context.handleChange,
    handleChange = _f === void 0 ? noop_1.noop : _f,
    groupDisabled = context.groupDisabled,
    groupValue = context.groupValue;
  var handleInputChange = (0, react_1.useCallback)(
    function (event) {
      handleChange(event.target.value);
      onChange(event);
    },
    [handleChange, onChange]
  );
  var isDisabled = groupDisabled || disabledProp;
  // const disabled = isDisabled ? 'disabled' : 'default';
  var isChecked = value === groupValue;
  // const checked = isChecked ? '-checked' : '';
  var rootClassName = (0, clsx_1['default'])(
    'radiobutton',
    'radiobutton--'.concat(constants_1.RADIOBUTTON_VARIANTS[variant]),
    'radiobutton--size-'.concat(constants_1.RADIOBUTTON_SIZES[size]),
    isDisabled && 'radiobutton--disabled',
    className
  );
  return react_1['default'].createElement(
    'label',
    {
      className: rootClassName,
    },
    react_1['default'].createElement(
      'input',
      __assign(
        {
          className: 'radiobutton__input',
          ref: ref,
          type: 'radio',
          disabled: isDisabled,
          value: value,
          onChange: handleInputChange,
          checked: isChecked,
        },
        restProps
      )
    ),
    react_1['default'].createElement(
      'span',
      {
        className: 'radiobutton__container',
        role: 'radio',
        'aria-checked': isChecked,
        tabIndex: isDisabled ? -1 : 0,
      },
      isChecked && icon,
      react_1['default'].createElement('div', {
        className: 'radiobutton__innerframe',
      })
    ),
    label &&
      react_1['default'].createElement(
        'span',
        {
          className: 'radiobutton__label',
        },
        label
      )
  );
});

RadioButton.propTypes = {
  className: PropTypes.string,
  /**
   * Устанавливает атрибут disabled
   */
  disabled: PropTypes.bool,
  /**
   * Заменяет иконку на кастомную
   * @default <Bullet />
   */
  icon: PropTypes.node,
  /**
   * Задает текст лейбла для компонента
   */
  label: PropTypes.node,
  /**
   * Callback функция, вызываемая при изменении значения
   */
  onChange: PropTypes.func,
  /**
   * Задает размер компонента
   * @default s
   */
  size: PropTypes.oneOf(['s', 'xs']),
  /**
   * Задает value
   */
  value: PropTypes.string,
  /**
   * Задает внешний вид компонента
   * @default default
   */
  variant: PropTypes.oneOf(['primary', 'secondary']),
};

RadioButton.displayName = 'RadioButton';
exports['default'] = RadioButton;
