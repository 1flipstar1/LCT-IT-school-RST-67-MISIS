import { FC } from 'react';
import '../../../styles/components/radioButton/radioButton.scss';
import { IRadioButtonProps } from './types';
declare const RadioButton: FC<IRadioButtonProps>;
export default RadioButton;
