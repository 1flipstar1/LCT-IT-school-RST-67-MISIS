export declare enum RADIOBUTTON_SIZES {
    s = "s",
    xs = "xs"
}
export declare enum RADIOBUTTON_VARIANTS {
    primary = "primary",
    secondary = "secondary"
}
