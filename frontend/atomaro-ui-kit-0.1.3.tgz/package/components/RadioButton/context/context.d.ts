import React from 'react';
export declare const RadioGroupContext: React.Context<IRadioGroupContext>;
declare const RadioGroupContextProvider: React.Provider<IRadioGroupContext>;
export default RadioGroupContextProvider;
export interface IRadioGroupContext {
    handleChange?: (value: string) => void;
    groupValue?: string;
    groupDisabled?: boolean;
}
