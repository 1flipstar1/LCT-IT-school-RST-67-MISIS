"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.RADIOBUTTON_VARIANTS = exports.RADIOBUTTON_SIZES = void 0;
var RADIOBUTTON_SIZES;
(function (RADIOBUTTON_SIZES) {
  RADIOBUTTON_SIZES["s"] = "s";
  RADIOBUTTON_SIZES["xs"] = "xs";
})(RADIOBUTTON_SIZES = exports.RADIOBUTTON_SIZES || (exports.RADIOBUTTON_SIZES = {}));
var RADIOBUTTON_VARIANTS;
(function (RADIOBUTTON_VARIANTS) {
  RADIOBUTTON_VARIANTS["primary"] = "primary";
  RADIOBUTTON_VARIANTS["secondary"] = "secondary";
})(RADIOBUTTON_VARIANTS = exports.RADIOBUTTON_VARIANTS || (exports.RADIOBUTTON_VARIANTS = {}));