'use strict';
var PropTypes = require('prop-types');

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __createBinding =
  (this && this.__createBinding) ||
  (Object.create
    ? function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ('get' in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = {
            enumerable: true,
            get: function get() {
              return m[k];
            },
          };
        }
        Object.defineProperty(o, k2, desc);
      }
    : function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
      });
var __setModuleDefault =
  (this && this.__setModuleDefault) ||
  (Object.create
    ? function (o, v) {
        Object.defineProperty(o, 'default', {
          enumerable: true,
          value: v,
        });
      }
    : function (o, v) {
        o['default'] = v;
      });
var __importStar =
  (this && this.__importStar) ||
  function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null)
      for (var k in mod)
        if (k !== 'default' && Object.prototype.hasOwnProperty.call(mod, k))
          __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
  };
var __rest =
  (this && this.__rest) ||
  function (s, e) {
    var t = {};
    for (var p in s)
      if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === 'function')
      for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
          t[p[i]] = s[p[i]];
      }
    return t;
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
/* eslint-disable import/no-extraneous-dependencies */
var react_1 = __importStar(require('react'));
var clsx_1 = __importDefault(require('clsx'));
require('../../../styles/components/tag/tagMore.scss');
var action_1 = require('@atomaro/icons/24/action');
var constants_1 = require('../constants');
var TagMore = function TagMore(props) {
  var _a = props.size,
    size = _a === void 0 ? constants_1.DEFAULT_SIZE : _a,
    _b = props.variant,
    variant = _b === void 0 ? constants_1.DEFAULT_VARIANT : _b,
    className = props.className,
    onClick = props.onClick,
    iconProp = props.icon,
    children = props.children,
    restProps = __rest(props, ['size', 'variant', 'className', 'onClick', 'icon', 'children']);
  var generateIcon = (0, react_1.useMemo)(
    function () {
      switch (size) {
        case 'xs':
          return react_1['default'].createElement(action_1.AddLarge, {
            size: 12,
          });
        case 's':
          return react_1['default'].createElement(action_1.AddLarge, {
            size: 12,
          });
        case 'm':
          return react_1['default'].createElement(action_1.AddLarge, {
            size: 16,
          });
        default:
          return react_1['default'].createElement(action_1.AddLarge, {
            size: 16,
          });
      }
    },
    [size]
  );
  var icon = iconProp !== null && iconProp !== void 0 ? iconProp : generateIcon;
  var addButton = react_1['default'].createElement(
    'span',
    {
      className: 'tagmore__button',
    },
    icon
  );
  var rootClassName = (0, clsx_1['default'])(
    'tagmore',
    'tagmore--'.concat(constants_1.TAG_VARIANTS[variant]),
    'tagmore--size-'.concat(constants_1.TAG_SIZES[size]),
    className
  );
  return react_1['default'].createElement(
    'button',
    __assign(
      {
        type: 'button',
        className: rootClassName,
        onClick: onClick,
      },
      restProps
    ),
    react_1['default'].createElement(
      'span',
      {
        className: 'tagmore__label',
      },
      children
    ),
    addButton
  );
};

TagMore.propTypes = {
  children: PropTypes.node,
  className: PropTypes.string,
  /**
   * Позволяет задать кастомную иконку для закрытия
   */
  icon: PropTypes.node,
  onClick: PropTypes.func,
  /**
   * Задает размер
   *  @default m
   */
  size: PropTypes.oneOf(['m', 's', 'xs']),
  /**
   * Задает внешний вид
   *  @default primary
   */
  variant: PropTypes.oneOf(['primary', 'secondary']),
};

TagMore.displayName = 'TagMore';
exports['default'] = TagMore;
