import { ButtonHTMLAttributes, ReactNode } from 'react';
import { TagsSizesType, TagsVariantsType } from '../constants';
export interface ITagMore extends ButtonHTMLAttributes<HTMLButtonElement> {
    /** Задает внешний вид
     *  @default primary */
    variant?: TagsVariantsType;
    /** Задает размер
     *  @default m */
    size?: TagsSizesType;
    /** Позволяет задать кастомную иконку для закрытия  */
    icon?: ReactNode;
}
