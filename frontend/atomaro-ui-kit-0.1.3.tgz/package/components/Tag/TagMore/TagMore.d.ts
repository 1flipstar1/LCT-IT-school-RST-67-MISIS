import { FC } from 'react';
import '../../../styles/components/tag/tagMore.scss';
import { ITagMore } from './types';
declare const TagMore: FC<ITagMore>;
export default TagMore;
