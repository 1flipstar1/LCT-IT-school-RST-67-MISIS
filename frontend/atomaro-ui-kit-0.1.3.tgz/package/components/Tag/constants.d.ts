export declare enum TAG_SIZES {
    xs = "xs",
    s = "s",
    m = "m"
}
export declare enum TAG_VARIANTS {
    primary = "primary",
    secondary = "secondary"
}
export declare const DEFAULT_TAG_MORE_BUTTON_TEXT = "\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C";
export declare const DEFAULT_SIZE = TAG_SIZES.m;
export declare const DEFAULT_VARIANT = TAG_VARIANTS.primary;
export type TagsSizesType = keyof typeof TAG_SIZES;
export type TagsVariantsType = keyof typeof TAG_VARIANTS;
