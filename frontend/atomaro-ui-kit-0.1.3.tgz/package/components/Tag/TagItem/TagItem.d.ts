import React from 'react';
import '../../../styles/components/tag/tagItem.scss';
import { ITagItem } from './types';
declare const TagItem: React.ForwardRefExoticComponent<ITagItem & React.RefAttributes<HTMLDivElement>>;
export default TagItem;
