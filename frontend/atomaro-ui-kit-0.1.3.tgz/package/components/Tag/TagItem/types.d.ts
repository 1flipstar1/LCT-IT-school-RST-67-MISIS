import React, { ReactNode, MouseEvent } from 'react';
import { TagsVariantsType, TagsSizesType } from '../constants';
export interface ITagItem extends React.HTMLAttributes<HTMLDivElement> {
    /** Задает внешний вид
     *  @default primary */
    variant?: TagsVariantsType;
    /** Задает размер
     *  @default m */
    size?: TagsSizesType;
    /** Устанавливает атрибут disabled */
    disabled?: boolean;
    /** Устанавливает состояние ошибки */
    error?: boolean;
    /** Включает отображение кнопки для удаления тега */
    closable?: boolean;
    /** Устанавливает ограничение по количеству символов для тега */
    maxSymbols?: number;
    /** Callback-функция, вызываемая при клике на значок закрытия */
    onClose?: (event: MouseEvent<HTMLButtonElement>) => void;
    /** Позволяет задать кастомную иконку для закрытия  */
    icon?: ReactNode;
}
