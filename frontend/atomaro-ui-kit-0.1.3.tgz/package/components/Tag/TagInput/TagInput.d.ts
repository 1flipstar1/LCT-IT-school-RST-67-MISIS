import React from 'react';
import '../../../styles/components/tag/tagInput.scss';
import { ITagInput } from './types';
declare const TagInput: React.ForwardRefExoticComponent<ITagInput & React.RefAttributes<HTMLInputElement>>;
export default TagInput;
