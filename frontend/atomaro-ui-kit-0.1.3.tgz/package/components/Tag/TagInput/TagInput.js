'use strict';
var PropTypes = require('prop-types');

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __createBinding =
  (this && this.__createBinding) ||
  (Object.create
    ? function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ('get' in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = {
            enumerable: true,
            get: function get() {
              return m[k];
            },
          };
        }
        Object.defineProperty(o, k2, desc);
      }
    : function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
      });
var __setModuleDefault =
  (this && this.__setModuleDefault) ||
  (Object.create
    ? function (o, v) {
        Object.defineProperty(o, 'default', {
          enumerable: true,
          value: v,
        });
      }
    : function (o, v) {
        o['default'] = v;
      });
var __importStar =
  (this && this.__importStar) ||
  function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null)
      for (var k in mod)
        if (k !== 'default' && Object.prototype.hasOwnProperty.call(mod, k))
          __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
  };
var __rest =
  (this && this.__rest) ||
  function (s, e) {
    var t = {};
    for (var p in s)
      if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === 'function')
      for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
          t[p[i]] = s[p[i]];
      }
    return t;
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importStar(require('react'));
var clsx_1 = __importDefault(require('clsx'));
require('../../../styles/components/tag/tagInput.scss');
var constants_1 = require('../constants');
var TagInput = (0, react_1.forwardRef)(function TagInput(props, ref) {
  var value = props.value,
    _a = props.size,
    size = _a === void 0 ? constants_1.DEFAULT_SIZE : _a,
    _b = props.variant,
    variant = _b === void 0 ? constants_1.DEFAULT_VARIANT : _b,
    className = props.className,
    onChange = props.onChange,
    onBlur = props.onBlur,
    onKeyDown = props.onKeyDown,
    restProps = __rest(props, [
      'value',
      'size',
      'variant',
      'className',
      'onChange',
      'onBlur',
      'onKeyDown',
    ]);
  var rootClassName = (0, clsx_1['default'])(
    'taginput',
    'taginput--'.concat(constants_1.TAG_VARIANTS[variant]),
    'taginput--size-'.concat(constants_1.TAG_SIZES[size]),
    className
  );
  return react_1['default'].createElement(
    'input',
    __assign(
      {
        type: 'text',
        ref: ref,
        className: rootClassName,
        disabled: false,
        value: value,
        onChange: onChange,
        onBlur: onBlur,
        onKeyDown: onKeyDown,
      },
      restProps
    )
  );
});

TagInput.propTypes = {
  className: PropTypes.string,
  /**
   * Callback-функция, вызываемая при потере фокуса
   */
  onBlur: PropTypes.func.isRequired,
  /**
   * Callback-функция, вызываемая при изменении значения
   */
  onChange: PropTypes.func.isRequired,
  /**
   * Callback-функция, вызываемая при нажатии на клавишу клавиатуры
   */
  onKeyDown: PropTypes.func.isRequired,
  /**
   * Задает размер
   *  @default m
   */
  size: PropTypes.oneOf(['m', 's', 'xs']),
  /**
   * Задает значение компонента
   */
  value: PropTypes.string.isRequired,
  /**
   * Задает внешний вид
   *  @default primary
   */
  variant: PropTypes.oneOf(['primary', 'secondary']),
};

TagInput.displayName = 'TagInput';
exports['default'] = TagInput;
