import { ChangeEvent, InputHTMLAttributes, KeyboardEvent } from 'react';
import { TagsSizesType, TagsVariantsType } from '../constants';
export interface ITagInput extends Omit<InputHTMLAttributes<HTMLInputElement>, 'size'> {
    /** Задает значение компонента */
    value: string;
    /** Задает размер
     *  @default m */
    size?: TagsSizesType;
    /** Задает внешний вид
     *  @default primary */
    variant?: TagsVariantsType;
    /** Callback-функция, вызываемая при изменении значения */
    onChange: (event: ChangeEvent<HTMLInputElement>) => void;
    /** Callback-функция, вызываемая при потере фокуса */
    onBlur: () => void;
    /** Callback-функция, вызываемая при нажатии на клавишу клавиатуры */
    onKeyDown: (event: KeyboardEvent) => void;
}
