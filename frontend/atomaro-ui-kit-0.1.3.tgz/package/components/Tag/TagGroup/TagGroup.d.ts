import { FC } from 'react';
import '../../../styles/components/tag/tagGroup.scss';
import { ITagGroup } from './types';
declare const TagGroup: FC<ITagGroup>;
export default TagGroup;
