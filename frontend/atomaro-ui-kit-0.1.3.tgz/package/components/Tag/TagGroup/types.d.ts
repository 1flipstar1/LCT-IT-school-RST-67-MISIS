import React from 'react';
import { TagsSizesType, TagsVariantsType } from '../constants';
export interface ITagGroupItem {
    value: string | React.ReactNode;
    key: string | number;
}
export interface ITagGroup extends React.HTMLAttributes<HTMLDivElement> {
    /** Задает внешний вид
     *  @default primary */
    variant?: TagsVariantsType;
    /** Задает размер
     *  @default medium */
    size?: TagsSizesType;
    /** Список тегов
     * @param value - отображаемое значение
     * @param key - уникальный ключ в списке тегов
     */
    items: ITagGroupItem[];
    /** Список disabled тегов
     * @param value - отображаемое значение
     * @param key - уникальный ключ в списке тегов
     */
    disabledItems?: ITagGroupItem[];
    /** Список тегов в состоянии error
     * @param value - отображаемое значение
     * @param key - уникальный ключ в списке тегов
     */
    errorItems?: ITagGroupItem[];
    /** Позволяет удалять теги
     *  @default false */
    closable?: boolean;
    /** Позволяет добавлять теги
     *  @default false */
    editable?: boolean;
    /** Задает текст для кнопки добавления нового тега */
    editLabel?: string;
    /** Устанавливает ограничение по количеству символов для каждого тега */
    maxSymbols?: number;
    /** Callback-функция, вызываемая при добавлении тега */
    onAdd?: (addedTag: ITagGroupItem) => void;
    /** Callback-функция, вызываемая при удалении тега */
    onRemove?: (removedTag: ITagGroupItem) => void;
    /** Callback-функция, вызываемая при введении данных в инпут */
    onChangeInput?: (value: string) => void;
    /** Задаёт постоянное отображение поля ввода */
    inputVisible?: boolean;
    inputRef?: React.RefObject<HTMLInputElement>;
    inputProps?: any;
}
