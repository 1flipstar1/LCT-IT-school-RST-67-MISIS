'use strict';
var PropTypes = require('prop-types');

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __createBinding =
  (this && this.__createBinding) ||
  (Object.create
    ? function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ('get' in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = {
            enumerable: true,
            get: function get() {
              return m[k];
            },
          };
        }
        Object.defineProperty(o, k2, desc);
      }
    : function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
      });
var __setModuleDefault =
  (this && this.__setModuleDefault) ||
  (Object.create
    ? function (o, v) {
        Object.defineProperty(o, 'default', {
          enumerable: true,
          value: v,
        });
      }
    : function (o, v) {
        o['default'] = v;
      });
var __importStar =
  (this && this.__importStar) ||
  function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null)
      for (var k in mod)
        if (k !== 'default' && Object.prototype.hasOwnProperty.call(mod, k))
          __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
  };
var __rest =
  (this && this.__rest) ||
  function (s, e) {
    var t = {};
    for (var p in s)
      if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === 'function')
      for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
          t[p[i]] = s[p[i]];
      }
    return t;
  };
var __spreadArray =
  (this && this.__spreadArray) ||
  function (to, from, pack) {
    if (pack || arguments.length === 2)
      for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
          if (!ar) ar = Array.prototype.slice.call(from, 0, i);
          ar[i] = from[i];
        }
      }
    return to.concat(ar || Array.prototype.slice.call(from));
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importStar(require('react'));
var clsx_1 = __importDefault(require('clsx'));
require('../../../styles/components/tag/tagGroup.scss');
var useCombinedRefs_1 = require('../../../hooks/useCombinedRefs');
var TagItem_1 = __importDefault(require('../TagItem/TagItem'));
var TagMore_1 = __importDefault(require('../TagMore/TagMore'));
var TagInput_1 = __importDefault(require('../TagInput/TagInput'));
var constants_1 = require('../constants');
var noop_1 = require('../../../utils/noop');
var TagGroup = function TagGroup(props) {
  var _a = props.size,
    size = _a === void 0 ? constants_1.DEFAULT_SIZE : _a,
    _b = props.variant,
    variant = _b === void 0 ? constants_1.DEFAULT_VARIANT : _b,
    _c = props.items,
    items = _c === void 0 ? [] : _c,
    _d = props.disabledItems,
    disabledItems = _d === void 0 ? [] : _d,
    _e = props.errorItems,
    errorItems = _e === void 0 ? [] : _e,
    _f = props.closable,
    closable = _f === void 0 ? false : _f,
    _g = props.editable,
    editable = _g === void 0 ? false : _g,
    maxSymbols = props.maxSymbols,
    _h = props.editLabel,
    editLabel = _h === void 0 ? constants_1.DEFAULT_TAG_MORE_BUTTON_TEXT : _h,
    className = props.className,
    _j = props.onAdd,
    onAdd = _j === void 0 ? noop_1.noop : _j,
    _k = props.onRemove,
    onRemove = _k === void 0 ? noop_1.noop : _k,
    _l = props.onChangeInput,
    onChangeInput = _l === void 0 ? noop_1.noop : _l,
    inputVisibleProp = props.inputVisible,
    _m = props.inputRef,
    inputRefProp = _m === void 0 ? null : _m,
    inputProps = props.inputProps,
    restProps = __rest(props, [
      'size',
      'variant',
      'items',
      'disabledItems',
      'errorItems',
      'closable',
      'editable',
      'maxSymbols',
      'editLabel',
      'className',
      'onAdd',
      'onRemove',
      'onChangeInput',
      'inputVisible',
      'inputRef',
      'inputProps',
    ]);
  var inputRef = (0, react_1.useRef)(null);
  var combinedInputRef = (0, useCombinedRefs_1.useCombinedRefs)(inputRef, inputRefProp);
  var _o = (0, react_1.useState)(items),
    groupValue = _o[0],
    setGroupValue = _o[1];
  var _p = (0, react_1.useState)(false),
    inputVisible = _p[0],
    setInputVisible = _p[1];
  var _q = (0, react_1.useState)(''),
    inputValue = _q[0],
    setInputValue = _q[1];
  var closeHandler = function closeHandler(removedTag, event) {
    event.stopPropagation();
    if (
      disabledItems.some(function (disabledTag) {
        return removedTag.key === disabledTag.key;
      })
    )
      return;
    var tagsArray = groupValue.filter(function (tag) {
      return tag.key !== removedTag.key;
    });
    setGroupValue(tagsArray);
    onRemove(removedTag);
  };
  var showInputHandler = function showInputHandler() {
    setInputVisible(true);
  };
  var inputChangeHandler = function inputChangeHandler(event) {
    var newInputValue = event.target.value;
    setInputValue(newInputValue);
    onChangeInput(newInputValue);
  };
  var inputSubmitHandler = function inputSubmitHandler() {
    var newTagValue = inputValue.trim();
    if (
      newTagValue.length &&
      !groupValue.some(function (gv) {
        return gv.key === newTagValue;
      })
    ) {
      var newTag = {
        key: newTagValue,
        value: newTagValue,
      };
      var newGroupValue = __spreadArray(__spreadArray([], groupValue, true), [newTag], false);
      setGroupValue(newGroupValue);
      onAdd(newTag);
    }
    setInputValue('');
    setInputVisible(false);
  };
  var keyPressHandler = function keyPressHandler(event) {
    if (event.key === 'Enter') {
      inputSubmitHandler();
    }
  };
  (0, react_1.useEffect)(
    function () {
      var _a;
      if (inputVisible) {
        (_a = combinedInputRef.current) === null || _a === void 0 ? void 0 : _a.focus();
      }
      // eslint-disable-next-line react-hooks/exhaustive-deps
    },
    [inputVisible]
  );
  (0, react_1.useEffect)(
    function () {
      setGroupValue(items);
    },
    [items]
  );
  var rootClassName = (0, clsx_1['default'])(
    'taggroup',
    'taggroup--'.concat(constants_1.TAG_VARIANTS[variant]),
    'taggroup--size-'.concat(constants_1.TAG_SIZES[size]),
    className
  );
  var editButton =
    !inputVisible && editable
      ? react_1['default'].createElement(
          TagMore_1['default'],
          {
            variant: variant,
            size: size,
            onClick: showInputHandler,
          },
          editLabel
        )
      : null;
  var groupOptions = groupValue.map(function (tag) {
    var disableTag =
      Array.isArray(disabledItems) &&
      disabledItems.some(function (disabledTag) {
        return disabledTag.key === tag.key;
      });
    var errorTag = errorItems.some(function (invalidTag) {
      return invalidTag.key === tag.key;
    });
    return react_1['default'].createElement(
      TagItem_1['default'],
      {
        key: tag.key,
        'data-key': tag.key,
        variant: variant,
        size: size,
        closable: closable,
        disabled: disableTag,
        error: errorTag,
        maxSymbols: maxSymbols,
        onClose: function onClose(e) {
          return closeHandler(tag, e);
        },
      },
      tag.value
    );
  });
  return react_1['default'].createElement(
    'div',
    __assign(
      {
        className: rootClassName,
      },
      restProps
    ),
    react_1['default'].createElement(
      'div',
      {
        className: 'taggroup__inner',
      },
      groupOptions,
      (inputVisible || inputVisibleProp) &&
        react_1['default'].createElement(
          TagInput_1['default'],
          __assign(
            {
              ref: combinedInputRef,
              value: inputValue,
              size: size,
              variant: variant,
              onChange: inputChangeHandler,
              onBlur: inputSubmitHandler,
              onKeyDown: keyPressHandler,
            },
            inputProps
          )
        ),
      editButton
    )
  );
};

TagGroup.propTypes = {
  className: PropTypes.string,
  /**
   * Позволяет удалять теги
   *  @default false
   */
  closable: PropTypes.bool,
  /**
   * Список disabled тегов
   * @param value - отображаемое значение
   * @param key - уникальный ключ в списке тегов
   */
  disabledItems: PropTypes.arrayOf(
    PropTypes.shape({
      key: PropTypes.oneOfType([PropTypes.number, PropTypes.string]).isRequired,
      value: PropTypes.node,
    })
  ),
  /**
   * Позволяет добавлять теги
   *  @default false
   */
  editable: PropTypes.bool,
  /**
   * Задает текст для кнопки добавления нового тега
   */
  editLabel: PropTypes.string,
  /**
   * Список тегов в состоянии error
   * @param value - отображаемое значение
   * @param key - уникальный ключ в списке тегов
   */
  errorItems: PropTypes.arrayOf(
    PropTypes.shape({
      key: PropTypes.oneOfType([PropTypes.number, PropTypes.string]).isRequired,
      value: PropTypes.node,
    })
  ),
  inputProps: PropTypes.any,
  inputRef: PropTypes.shape({
    current: PropTypes.oneOfType([PropTypes.oneOf([null]), PropTypes.object]).isRequired,
  }),
  /**
   * Задаёт постоянное отображение поля ввода
   */
  inputVisible: PropTypes.bool,
  /**
   * Список тегов
   * @param value - отображаемое значение
   * @param key - уникальный ключ в списке тегов
   */
  items: PropTypes.arrayOf(
    PropTypes.shape({
      key: PropTypes.oneOfType([PropTypes.number, PropTypes.string]).isRequired,
      value: PropTypes.node,
    })
  ).isRequired,
  /**
   * Устанавливает ограничение по количеству символов для каждого тега
   */
  maxSymbols: PropTypes.number,
  /**
   * Callback-функция, вызываемая при добавлении тега
   */
  onAdd: PropTypes.func,
  /**
   * Callback-функция, вызываемая при введении данных в инпут
   */
  onChangeInput: PropTypes.func,
  /**
   * Callback-функция, вызываемая при удалении тега
   */
  onRemove: PropTypes.func,
  /**
   * Задает размер
   *  @default medium
   */
  size: PropTypes.oneOf(['m', 's', 'xs']),
  /**
   * Задает внешний вид
   *  @default primary
   */
  variant: PropTypes.oneOf(['primary', 'secondary']),
};

TagGroup.displayName = 'TagGroup';
exports['default'] = TagGroup;
