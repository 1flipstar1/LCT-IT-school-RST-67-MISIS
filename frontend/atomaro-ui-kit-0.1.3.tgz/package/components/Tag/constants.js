"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.DEFAULT_VARIANT = exports.DEFAULT_SIZE = exports.DEFAULT_TAG_MORE_BUTTON_TEXT = exports.TAG_VARIANTS = exports.TAG_SIZES = void 0;
var TAG_SIZES;
(function (TAG_SIZES) {
  TAG_SIZES["xs"] = "xs";
  TAG_SIZES["s"] = "s";
  TAG_SIZES["m"] = "m";
})(TAG_SIZES = exports.TAG_SIZES || (exports.TAG_SIZES = {}));
var TAG_VARIANTS;
(function (TAG_VARIANTS) {
  TAG_VARIANTS["primary"] = "primary";
  TAG_VARIANTS["secondary"] = "secondary";
})(TAG_VARIANTS = exports.TAG_VARIANTS || (exports.TAG_VARIANTS = {}));
exports.DEFAULT_TAG_MORE_BUTTON_TEXT = 'Добавить';
exports.DEFAULT_SIZE = TAG_SIZES.m;
exports.DEFAULT_VARIANT = TAG_VARIANTS.primary;