'use strict';
var PropTypes = require('prop-types');

var __createBinding =
  (this && this.__createBinding) ||
  (Object.create
    ? function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ('get' in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = {
            enumerable: true,
            get: function get() {
              return m[k];
            },
          };
        }
        Object.defineProperty(o, k2, desc);
      }
    : function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
      });
var __setModuleDefault =
  (this && this.__setModuleDefault) ||
  (Object.create
    ? function (o, v) {
        Object.defineProperty(o, 'default', {
          enumerable: true,
          value: v,
        });
      }
    : function (o, v) {
        o['default'] = v;
      });
var __importStar =
  (this && this.__importStar) ||
  function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null)
      for (var k in mod)
        if (k !== 'default' && Object.prototype.hasOwnProperty.call(mod, k))
          __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
/* eslint-disable jsx-a11y/no-static-element-interactions */
var react_1 = __importStar(require('react'));
var clsx_1 = __importDefault(require('clsx'));
require('../../styles/components/slider.scss');
var Slider = function Slider(props) {
  var _a, _b;
  var trackRef = (0, react_1.useRef)();
  var _c = props.min,
    min = _c === void 0 ? 1 : _c,
    _d = props.max,
    max = _d === void 0 ? 100 : _d,
    _e = props.marks,
    marks = _e === void 0 ? [] : _e,
    _f = props.step,
    step = _f === void 0 ? 1 : _f,
    label = props.label,
    subLabel = props.subLabel,
    _g = props.disabled,
    disabled = _g === void 0 ? false : _g,
    _h = props.size,
    size = _h === void 0 ? 'm' : _h,
    _j = props.variant,
    variant = _j === void 0 ? 'primary' : _j,
    _values = props.values,
    _k = props.dots,
    dots = _k === void 0 ? false : _k,
    _l = props.track,
    track = _l === void 0 ? 'normal' : _l,
    colorTrack = props.colorTrack,
    showTooltip = props.showTooltip;
  var offsetPadding = 8;
  var _m = (0, react_1.useState)(0),
    moveWidth = _m[0],
    setMoveWidth = _m[1];
  var _o = (0, react_1.useState)(0),
    moveStepSize = _o[0],
    setMoveStepSize = _o[1];
  var _p = (0, react_1.useState)(false),
    isMoving = _p[0],
    setIsMoving = _p[1];
  var _q = (0, react_1.useState)(Array.isArray(_values) ? _values : [_values]),
    values = _q[0],
    setValues = _q[1];
  var isRange = (0, react_1.useMemo)(
    function () {
      if (Array.isArray(values) && values.length > 1) return true;
      return false;
    },
    [values]
  );
  var mouseMoveHandler = (0, react_1.useCallback)(
    function (e) {
      if (!disabled && isMoving && typeof isMoving === 'number') {
        var newWidth = moveWidth + e.movementX;
        var v = Math.round(newWidth / moveStepSize) * step;
        var pos = isMoving - 1;
        var newValues = values;
        newValues[pos] = v;
        if (v < min || v > max) {
          return;
        }
        if (v < newValues[pos - 1]) {
          var tmp = newValues[pos - 1];
          newValues[pos - 1] = v;
          newValues[pos] = tmp;
          setIsMoving(isMoving - 1);
        }
        if (v > newValues[pos + 1]) {
          var tmp = newValues[pos + 1];
          newValues[pos + 1] = v;
          newValues[pos] = tmp;
          setIsMoving(isMoving + 1);
        }
        setValues(newValues);
        setMoveWidth(newWidth);
      }
    },
    [moveWidth, isMoving, moveStepSize, step, values, min, max, disabled]
  );
  var calcWidthFromValue = (0, react_1.useCallback)(
    function (v) {
      var res = Math.round((Math.round(v / step) - Math.round(min / step)) * moveStepSize);
      if (res < offsetPadding) return offsetPadding;
      return res;
    },
    [moveStepSize, step, min]
  );
  var calcPxWidthFromValue = (0, react_1.useCallback)(
    function (v) {
      return ''.concat(calcWidthFromValue(v), 'px');
    },
    [calcWidthFromValue]
  );
  (0, react_1.useEffect)(
    function () {
      if (Array.isArray(_values)) {
        setValues(_values);
      } else {
        setValues([_values]);
      }
    },
    [_values]
  );
  (0, react_1.useEffect)(
    function () {
      if (trackRef.current) {
        var width = trackRef.current.getBoundingClientRect().width;
        var amount = (max - min) / step;
        setMoveStepSize((width - offsetPadding) / amount);
        trackRef.current.addEventListener('mousemove', mouseMoveHandler);
      }
      return function () {
        var _a;
        (_a = trackRef.current) === null || _a === void 0
          ? void 0
          : _a.removeEventListener('mousemove', mouseMoveHandler);
      };
    },
    [mouseMoveHandler, max, min, step]
  );
  var rootClassName = (0, clsx_1['default'])(
    'slider',
    'slider--size-'.concat(size),
    'slider--'.concat(variant),
    'slider--track-'.concat(track),
    {
      'slider--range': isRange,
    },
    {
      'slider--disabled': disabled,
    },
    ((_a = {}), (_a['slider--move-'.concat(isMoving)] = !!isMoving), _a),
    {
      'slider--focus': !!isMoving,
    },
    {
      'slider--custom-track': colorTrack,
    },
    ((_b = {}), (_b['slider--show-tooltip-'.concat(showTooltip)] = showTooltip), _b)
  );
  var counter = subLabel
    ? subLabel(values)
    : react_1['default'].createElement(react_1['default'].Fragment, null, values.join(' - '));
  var points = (0, react_1.useMemo)(
    function () {
      if (!dots) return null;
      var steps = Array.from(Array((max - min) / step + 1).keys());
      return react_1['default'].createElement(
        'div',
        {
          className: 'slider__dots',
        },
        steps.map(function (s) {
          return react_1['default'].createElement('div', {
            className: 'slider__dot',
            style: {
              '--dot-position': calcPxWidthFromValue(s + 1),
            },
          });
        })
      );
    },
    [max, min, step, dots, calcPxWidthFromValue]
  );
  return react_1['default'].createElement(
    'div',
    {
      className: rootClassName,
      onMouseUp: function onMouseUp() {
        setIsMoving(false);
        setMoveWidth(0);
      },
      onMouseLeave: function onMouseLeave() {
        setIsMoving(false);
        setMoveWidth(0);
      },
      ref: trackRef,
    },
    react_1['default'].createElement(
      'div',
      {
        className: 'slider__label',
      },
      label,
      react_1['default'].createElement(
        'div',
        {
          className: 'slider__counter',
        },
        counter
      )
    ),
    react_1['default'].createElement(
      'div',
      {
        className: 'slider__track',
        style: {
          '--custom-track-color': colorTrack,
          '--highlight-position': isRange
            ? calcPxWidthFromValue(Math.min.apply(Math, values))
            : ''.concat(offsetPadding, 'px'),
          '--highlight-width': isRange
            ? calcPxWidthFromValue(Math.max.apply(Math, values) - Math.min.apply(Math, values) + 1)
            : calcPxWidthFromValue(Math.max.apply(Math, values)),
        },
      },
      react_1['default'].createElement('div', {
        className: 'slider__line',
      }),
      values.map(function (value, i) {
        return react_1['default'].createElement(
          'div',
          {
            className: (0, clsx_1['default'])('slider__handler', {
              active: i + 1 === isMoving,
            }),
            style: {
              '--position': calcPxWidthFromValue(value),
            },
            onMouseDown: function onMouseDown() {
              setIsMoving(i + 1);
              setMoveWidth(calcWidthFromValue(value + min));
            },
          },
          react_1['default'].createElement(
            'div',
            {
              className: 'slider__tooltip',
            },
            react_1['default'].createElement(
              'div',
              {
                className: 'slider__tooltip-content',
              },
              value
            )
          )
        );
      }),
      points
    ),
    marks.length > 0 &&
      react_1['default'].createElement(
        'div',
        {
          className: 'slider__marks',
        },
        marks.map(function (m) {
          return react_1['default'].createElement(
            'div',
            {
              className: 'slider__mark',
              style: {
                '--mark-position': calcPxWidthFromValue(m.value),
              },
            },
            m.label
          );
        })
      )
  );
};

Slider.propTypes = {
  /**
   * Задаёт цвет трека
   */
  colorTrack: PropTypes.string,
  /**
   * Устанавливает атрибут disabled
   */
  disabled: PropTypes.bool,
  /**
   * Включает отображение точек внутри трека
   */
  dots: PropTypes.bool,
  /**
   * Задаёт лейбл компонента
   */
  label: PropTypes.string,
  /**
   * Задаёт текстовые метки под шкалой, не должны выходить из диапазона min max
   */
  marks: PropTypes.arrayOf(
    PropTypes.shape({
      label: PropTypes.string,
      value: PropTypes.number.isRequired,
    })
  ),
  /**
   * Задаёт максимальное значение слайдера
   *  @default 100
   */
  max: PropTypes.number,
  /**
   * Задаёт минимальное значение слайдера
   *  @default 0
   */
  min: PropTypes.number,
  /**
   * Задаёт отображение тултипа
   */
  showTooltip: PropTypes.oneOf(['always', 'hover']),
  /**
   * Задаёт размер элемента
   *  @default m
   */
  size: PropTypes.oneOf(['m']),
  /**
   * Задаёт шаг, с которым можно перемещать метки
   */
  step: PropTypes.number,
  /**
   * Задаёт текстовое значение позиций ручек справа от лейбла
   */
  subLabel: PropTypes.func,
  /**
   * Задаёт отображение выделенного участка
   */
  track: PropTypes.oneOf(['inverted', 'none', 'normal']),
  /**
   * Задаёт значение одного или нескольких ползунков, не должны превышать значения width
   *  @default 0
   */
  values: PropTypes.oneOfType([PropTypes.arrayOf(PropTypes.number), PropTypes.number]),
  /**
   * Задаёт вид компонента
   *  @default primary
   */
  variant: PropTypes.oneOf(['primary']),
};

Slider.displayName = 'Slider';
exports['default'] = Slider;
