export declare enum SLIDER_SIZES {
    m = "m"
}
export declare enum SLIDER_VARIANTS {
    primary = "primary"
}
export declare const ADDITIONAL_OFFSET = 4;
export declare const DEFAULT_SIZE = SLIDER_SIZES.m;
export declare const DEFAULT_VARIANT = SLIDER_VARIANTS.primary;
