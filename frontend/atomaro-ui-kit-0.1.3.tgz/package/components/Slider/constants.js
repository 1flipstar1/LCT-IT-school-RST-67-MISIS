"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.DEFAULT_VARIANT = exports.DEFAULT_SIZE = exports.ADDITIONAL_OFFSET = exports.SLIDER_VARIANTS = exports.SLIDER_SIZES = void 0;
var SLIDER_SIZES;
(function (SLIDER_SIZES) {
  SLIDER_SIZES["m"] = "m";
})(SLIDER_SIZES = exports.SLIDER_SIZES || (exports.SLIDER_SIZES = {}));
var SLIDER_VARIANTS;
(function (SLIDER_VARIANTS) {
  SLIDER_VARIANTS["primary"] = "primary";
})(SLIDER_VARIANTS = exports.SLIDER_VARIANTS || (exports.SLIDER_VARIANTS = {}));
exports.ADDITIONAL_OFFSET = 4;
exports.DEFAULT_SIZE = SLIDER_SIZES.m;
exports.DEFAULT_VARIANT = SLIDER_VARIANTS.primary;