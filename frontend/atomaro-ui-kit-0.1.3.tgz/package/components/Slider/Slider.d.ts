import React from 'react';
import '../../styles/components/slider.scss';
import { ISliderProps } from './types';
declare const Slider: React.FC<ISliderProps>;
export default Slider;
