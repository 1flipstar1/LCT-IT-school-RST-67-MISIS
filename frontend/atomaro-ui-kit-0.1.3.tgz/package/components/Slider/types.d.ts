import { SLIDER_SIZES, SLIDER_VARIANTS } from './constants';
export type TrackType = 'inverted' | 'normal' | 'none';
export interface ISliderProps {
    /** Задаёт вид компонента
     *  @default primary */
    variant?: VariantsType;
    /** Задаёт размер элемента
     *  @default m */
    size?: SizeType;
    /** Задаёт лейбл компонента */
    label?: string;
    /** Задаёт цвет трека */
    colorTrack?: string;
    /** Задаёт текстовое значение позиций ручек справа от лейбла */
    subLabel?: (values: number[]) => string;
    /** Задаёт максимальное значение слайдера
     *  @default 100 */
    max?: number;
    /** Задаёт минимальное значение слайдера
     *  @default 0 */
    min?: number;
    /** Задаёт значение одного или нескольких ползунков, не должны превышать значения width
     *  @default 0 */
    values?: number[] | number;
    /** Устанавливает атрибут disabled */
    disabled?: boolean;
    /** Включает отображение точек внутри трека */
    dots?: boolean;
    /** Задаёт текстовые метки под шкалой, не должны выходить из диапазона min max */
    marks?: Array<{
        label?: string;
        value: number;
    }>;
    /** Задаёт отображение выделенного участка */
    track?: TrackType;
    /** Задаёт шаг, с которым можно перемещать метки */
    step?: number;
    /** Callback-функция, вызываемая при изменении значения */
    onChange?: (event: MouseEvent, value: number | number[]) => void;
    /** Запрещает пересекать ручки на треке */
    disableSwap?: boolean;
    /** Задаёт отображение тултипа */
    showTooltip?: 'hover' | 'always';
}
export type SizeType = keyof typeof SLIDER_SIZES;
export type VariantsType = keyof typeof SLIDER_VARIANTS;
