export declare enum BREADCRUMBS_VARIANTS {
    primary = "primary"
}
export declare enum BREADCRUMBS_SIZES {
    s = "s"
}
export type BreadcrumbsVariantType = keyof typeof BREADCRUMBS_VARIANTS;
export type BreadcrumbsSizeType = keyof typeof BREADCRUMBS_SIZES;
export declare const DEFAULT_VARIANT = BREADCRUMBS_VARIANTS.primary;
export declare const DEFAULT_SIZE = BREADCRUMBS_SIZES.s;
export declare const DEFAULT_CRUMBS_MAX_COUNT = 5;
export declare const DEFAULT_MAX_VISIBLE_CRUMBS = 3;
