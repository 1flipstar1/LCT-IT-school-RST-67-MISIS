import { FC } from 'react';
import '../../styles/components/breadcrumbs.scss';
import { IBreadcrumbsProps } from './types';
declare const Breadcrumbs: FC<IBreadcrumbsProps>;
export default Breadcrumbs;
