'use strict';
var PropTypes = require('prop-types');

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __createBinding =
  (this && this.__createBinding) ||
  (Object.create
    ? function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ('get' in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = {
            enumerable: true,
            get: function get() {
              return m[k];
            },
          };
        }
        Object.defineProperty(o, k2, desc);
      }
    : function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
      });
var __setModuleDefault =
  (this && this.__setModuleDefault) ||
  (Object.create
    ? function (o, v) {
        Object.defineProperty(o, 'default', {
          enumerable: true,
          value: v,
        });
      }
    : function (o, v) {
        o['default'] = v;
      });
var __importStar =
  (this && this.__importStar) ||
  function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null)
      for (var k in mod)
        if (k !== 'default' && Object.prototype.hasOwnProperty.call(mod, k))
          __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
  };
var __rest =
  (this && this.__rest) ||
  function (s, e) {
    var t = {};
    for (var p in s)
      if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === 'function')
      for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
          t[p[i]] = s[p[i]];
      }
    return t;
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importStar(require('react'));
var clsx_1 = __importDefault(require('clsx'));
require('../../styles/components/breadcrumbs.scss');
var navigation_1 = require('@atomaro/icons/24/navigation');
var constants_1 = require('./constants');
var DropdownMenu_1 = __importDefault(require('../DropdownMenu/DropdownMenu'));
var Breadcrumbs = function Breadcrumbs(props) {
  var _a = props.variant,
    variant = _a === void 0 ? constants_1.DEFAULT_VARIANT : _a,
    _b = props.children,
    children = _b === void 0 ? [] : _b,
    _c = props.size,
    size = _c === void 0 ? constants_1.DEFAULT_SIZE : _c,
    _d = props.maxCrumbs,
    maxCrumbsProp = _d === void 0 ? constants_1.DEFAULT_CRUMBS_MAX_COUNT : _d,
    _e = props.maxVisibleCrumbs,
    maxVisibleCrumbsProp = _e === void 0 ? constants_1.DEFAULT_MAX_VISIBLE_CRUMBS : _e,
    useInPortal = props.useInPortal,
    className = props.className,
    restProps = __rest(props, [
      'variant',
      'children',
      'size',
      'maxCrumbs',
      'maxVisibleCrumbs',
      'useInPortal',
      'className',
    ]);
  var ref = (0, react_1.useRef)(null);
  var _f = (0, react_1.useState)(false),
    isOpenDropdown = _f[0],
    setOpenedDropdown = _f[1];
  var maxVisibleCrumbs = maxVisibleCrumbsProp > 0 ? maxVisibleCrumbsProp - 1 : maxVisibleCrumbsProp;
  var maxCrumbs = maxVisibleCrumbsProp >= children.length ? maxVisibleCrumbsProp : maxCrumbsProp;
  var hiddenItems =
    maxVisibleCrumbs === 0 ? children.slice(1) : children.slice(1, -maxVisibleCrumbs);
  var renderMoreButton = react_1['default'].createElement(
    'button',
    {
      className: 'breadcrumbs__dividermenu',
      type: 'button',
      'aria-label': 'breadcrumbs__dividermenu',
      'data-active': isOpenDropdown,
      ref: ref,
      onClick: function onClick() {
        return setOpenedDropdown(!isOpenDropdown);
      },
    },
    react_1['default'].createElement(navigation_1.More, null)
  );
  var renderDropdown = react_1['default'].createElement(
    DropdownMenu_1['default'],
    {
      items: hiddenItems.map(function (item, key) {
        return {
          value: item,
          key: key.toString(),
        };
      }),
      checkIcon: null,
      variant: variant,
      size: size,
      onClose: function onClose() {
        return setOpenedDropdown(false);
      },
      isOpened: isOpenDropdown,
      useInPortal: useInPortal,
      placement: 'bottomLeft',
      offset: 4,
    },
    renderMoreButton
  );
  var renderItems = children.map(function (breadcrumb, index) {
    var _a;
    if (children.length > maxCrumbs && index > 0 && index < children.length - maxVisibleCrumbs) {
      return null;
    }
    var separator =
      children.length > maxCrumbs && children.length - 2 >= maxVisibleCrumbs && index === 0
        ? renderDropdown
        : react_1['default'].createElement('div', {
            className: 'breadcrumbs__divider',
          });
    return react_1['default'].createElement(
      react_1['default'].Fragment,
      null,
      react_1['default'].createElement(
        'span',
        {
          role: 'button',
          tabIndex: index === children.length - 1 ? undefined : 0,
          'aria-disabled': index === children.length - 1,
          className: 'breadcrumbs__item',
          key: (_a = breadcrumb.key) !== null && _a !== void 0 ? _a : index,
        },
        react_1['default'].createElement(
          'span',
          {
            className: 'breadcrumbs__text',
          },
          breadcrumb
        )
      ),
      index !== children.length - 1 && separator
    );
  });
  var rootClassName = (0, clsx_1['default'])(
    'breadcrumbs',
    'breadcrumbs--size-'.concat(constants_1.BREADCRUMBS_SIZES[size]),
    'breadcrumbs--'.concat(constants_1.BREADCRUMBS_VARIANTS[variant]),
    className
  );
  return react_1['default'].createElement(
    'div',
    __assign(
      {
        className: rootClassName,
      },
      restProps
    ),
    renderItems
  );
};

Breadcrumbs.propTypes = {
  /**
   * Массив ссылок
   */
  children: PropTypes.arrayOf(PropTypes.element).isRequired,
  className: PropTypes.string,
  /**
   * Задаёт максимальное количество ссылок. В случае, если ссылок больше, чем значение параметра, они скрываются в дропдаун (divider)
   * @default 5
   */
  maxCrumbs: PropTypes.number,
  /**
   * Задаёт количество ссылок, которые не скрываются
   * @default 3
   */
  maxVisibleCrumbs: PropTypes.number,
  /**
   * Задает  размер
   * @default s
   */
  size: PropTypes.string,
  /**
   * Задаёт вариант использования выпадающего списка ссылок с React Portal
   * @default false
   */
  useInPortal: PropTypes.bool,
  /**
   * Задает внешний вид
   *  @default primary
   */
  variant: PropTypes.string,
};

Breadcrumbs.displayName = 'Breadcrumbs';
exports['default'] = Breadcrumbs;
