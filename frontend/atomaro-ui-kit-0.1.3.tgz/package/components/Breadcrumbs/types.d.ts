import React from 'react';
import { BreadcrumbsSizeType, BreadcrumbsVariantType } from './constants';
export interface IBreadcrumbsProps extends React.HTMLAttributes<HTMLDivElement> {
    /** Задает  размер
     * @default s
     */
    size?: BreadcrumbsSizeType | string;
    /** Задает внешний вид
     *  @default primary */
    variant?: BreadcrumbsVariantType | string;
    /** Массив ссылок */
    children: React.ReactElement[];
    /** Задаёт максимальное количество ссылок. В случае, если ссылок больше, чем значение параметра, они скрываются в дропдаун (divider)
     * @default 5
     */
    maxCrumbs?: number;
    /** Задаёт количество ссылок, которые не скрываются
     * @default 3
     */
    maxVisibleCrumbs?: number;
    /** Задаёт вариант использования выпадающего списка ссылок с React Portal
     * @default false */
    useInPortal?: boolean;
}
