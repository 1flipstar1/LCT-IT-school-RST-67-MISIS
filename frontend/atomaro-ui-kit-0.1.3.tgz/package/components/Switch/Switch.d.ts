import React from 'react';
import '../../styles/components/switch.scss';
import { ISwitchProps } from './types';
declare const Switch: React.ForwardRefExoticComponent<ISwitchProps & React.RefAttributes<HTMLInputElement>>;
export default Switch;
