export declare enum SWITCH_SIZES {
    xs = "xs",
    s = "s"
}
export declare enum SWITCH_VARIANTS {
    primary = "primary"
}
export declare enum SWITCH_LABEL_POSITION {
    left = "left",
    right = "right"
}
export type SwitchSizesType = keyof typeof SWITCH_SIZES;
export type SwitchVariantsType = keyof typeof SWITCH_VARIANTS;
export type SwitchLabelPositionType = keyof typeof SWITCH_LABEL_POSITION;
export declare const DEFAULT_TOUCH_POSITION: {
    start: any;
    end: any;
};
