'use strict';
var PropTypes = require('prop-types');

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __createBinding =
  (this && this.__createBinding) ||
  (Object.create
    ? function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ('get' in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = {
            enumerable: true,
            get: function get() {
              return m[k];
            },
          };
        }
        Object.defineProperty(o, k2, desc);
      }
    : function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
      });
var __setModuleDefault =
  (this && this.__setModuleDefault) ||
  (Object.create
    ? function (o, v) {
        Object.defineProperty(o, 'default', {
          enumerable: true,
          value: v,
        });
      }
    : function (o, v) {
        o['default'] = v;
      });
var __importStar =
  (this && this.__importStar) ||
  function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null)
      for (var k in mod)
        if (k !== 'default' && Object.prototype.hasOwnProperty.call(mod, k))
          __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
  };
var __rest =
  (this && this.__rest) ||
  function (s, e) {
    var t = {};
    for (var p in s)
      if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === 'function')
      for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
          t[p[i]] = s[p[i]];
      }
    return t;
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importStar(require('react'));
var clsx_1 = __importDefault(require('clsx'));
require('../../styles/components/switch.scss');
var function_1 = require('../../utils/function');
var constants_1 = require('./constants');
var getValueFromCssVariable_1 = require('../../utils/getValueFromCssVariable');
var Switch = (0, react_1.forwardRef)(function Switch(props, ref) {
  var _a;
  var checked = props.checked,
    className = props.className,
    _b = props.defaultChecked,
    defaultChecked = _b === void 0 ? false : _b,
    _c = props.disabled,
    disabled = _c === void 0 ? false : _c,
    label = props.label,
    _d = props.labelPosition,
    labelPosition = _d === void 0 ? constants_1.SWITCH_LABEL_POSITION.right : _d,
    _e = props.size,
    size = _e === void 0 ? constants_1.SWITCH_SIZES.s : _e,
    _f = props.variant,
    variant = _f === void 0 ? constants_1.SWITCH_VARIANTS.primary : _f,
    _g = props.onChange,
    onChange = _g === void 0 ? function_1.noop : _g,
    _h = props.htmlFor,
    htmlFor = _h === void 0 ? 'switch' : _h,
    restProps = __rest(props, [
      'checked',
      'className',
      'defaultChecked',
      'disabled',
      'label',
      'labelPosition',
      'size',
      'variant',
      'onChange',
      'htmlFor',
    ]);
  var _j = (0, react_1.useState)(defaultChecked),
    isChecked = _j[0],
    setIsChecked = _j[1];
  var _k = (0, react_1.useState)(constants_1.DEFAULT_TOUCH_POSITION),
    touchPosition = _k[0],
    setTouchPosition = _k[1];
  var handleChange = (0, react_1.useCallback)(
    function (value) {
      onChange(value);
      if (checked === undefined) {
        setIsChecked(value);
      }
    },
    [checked, onChange]
  );
  var handleInputChange = (0, react_1.useCallback)(
    function (event) {
      handleChange(event.target.checked);
    },
    [handleChange]
  );
  var handleTouchStart = (0, react_1.useCallback)(
    function (event) {
      event.stopPropagation();
      if (!disabled) {
        setTouchPosition({
          start: event.touches[0].clientX,
          end: null,
        });
      }
    },
    [disabled]
  );
  var handleTouchMove = (0, react_1.useCallback)(
    function (event) {
      if (!disabled) {
        var currentTouchPosition_1 = event.touches[0].clientX;
        setTouchPosition(function (prevState) {
          return __assign(__assign({}, prevState), {
            end: currentTouchPosition_1,
          });
        });
      }
    },
    [disabled]
  );
  var handleTouchEnd = (0, react_1.useCallback)(
    function () {
      var start = touchPosition.start,
        end = touchPosition.end;
      var width = (0, getValueFromCssVariable_1.getValueFromCssVariable)(
        '--switch-'.concat(size, '-width')
      );
      var padding = (0, getValueFromCssVariable_1.getValueFromCssVariable)(
        '--switch-'.concat(size, '-track-padding-horizontal')
      );
      var SWITCH_DISPLACEMENT = parseFloat(width) / 2 - parseFloat(padding);
      if (disabled || end === null) {
        return;
      }
      if (start > end && start - end > SWITCH_DISPLACEMENT) {
        handleChange(false);
      }
      if (start < end && end - start > SWITCH_DISPLACEMENT) {
        handleChange(true);
      }
      setTouchPosition(constants_1.DEFAULT_TOUCH_POSITION);
    },
    [touchPosition, disabled, handleChange, size]
  );
  var handleCheckChecked = (0, react_1.useCallback)(
    function () {
      if (checked !== undefined && checked !== isChecked) {
        setIsChecked(checked);
      }
      // eslint-disable-next-line react-hooks/exhaustive-deps
    },
    [checked]
  );
  (0, react_1.useEffect)(handleCheckChecked, [handleCheckChecked]);
  var rootClassName = (0, clsx_1['default'])(
    'switch',
    'switch--'.concat(constants_1.SWITCH_VARIANTS[variant]),
    'switch--size-'.concat(constants_1.SWITCH_SIZES[size]),
    'switch--label-position-'.concat(constants_1.SWITCH_LABEL_POSITION[labelPosition]),
    ((_a = {}), (_a['switch--disabled'] = !!disabled), (_a['switch--checked'] = !!isChecked), _a),
    className
  );
  return react_1['default'].createElement(
    'label',
    {
      className: rootClassName,
      htmlFor: htmlFor,
    },
    react_1['default'].createElement(
      'span',
      {
        className: 'switch__container',
        onTouchStart: handleTouchStart,
        onTouchMove: handleTouchMove,
        onTouchEnd: handleTouchEnd,
      },
      react_1['default'].createElement(
        'input',
        __assign(
          {
            className: 'switch__input',
            ref: ref,
            type: 'checkbox',
            id: 'switch',
            checked: isChecked,
            disabled: disabled,
            onChange: handleInputChange,
          },
          restProps
        )
      ),
      react_1['default'].createElement(
        'span',
        {
          className: 'switch__track',
        },
        react_1['default'].createElement('span', {
          className: 'switch__knob',
        })
      )
    ),
    label &&
      react_1['default'].createElement(
        'span',
        {
          className: 'switch__labelcontainer',
        },
        react_1['default'].createElement(
          'p',
          {
            className: 'switch__label',
          },
          label
        )
      )
  );
});

Switch.propTypes = {
  /**
   * Задает значение для состояния компонента
   */
  checked: PropTypes.bool,
  className: PropTypes.string,
  /**
   * Задает значение по умолчанию
   */
  defaultChecked: PropTypes.bool,
  /**
   * Устанавливает атрибут disabled
   * @default false
   */
  disabled: PropTypes.bool,
  /**
   * Параметр для обертки компонента - label
   */
  htmlFor: PropTypes.string,
  /**
   * Устанавливает текст возле компонента
   */
  label: PropTypes.node,
  /**
   * Задает расположение текста относительно компонента
   * @default right
   */
  labelPosition: PropTypes.oneOf(['left', 'right']),
  /**
   * Callback функция, вызываемая при изменении состояния
   * @param {boolean} value состояние компонента
   */
  onChange: PropTypes.func,
  /**
   * Задает размер компонента
   */
  size: PropTypes.oneOf(['s', 'xs']),
  /**
   * Задает внешний вид компонента
   */
  variant: PropTypes.oneOf(['primary']),
};

Switch.displayName = 'Switch';
exports['default'] = Switch;
