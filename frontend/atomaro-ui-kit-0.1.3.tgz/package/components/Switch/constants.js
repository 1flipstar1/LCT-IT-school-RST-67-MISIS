'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.DEFAULT_TOUCH_POSITION =
  exports.SWITCH_LABEL_POSITION =
  exports.SWITCH_VARIANTS =
  exports.SWITCH_SIZES =
    void 0;
var SWITCH_SIZES;
(function (SWITCH_SIZES) {
  SWITCH_SIZES['xs'] = 'xs';
  SWITCH_SIZES['s'] = 's';
})((SWITCH_SIZES = exports.SWITCH_SIZES || (exports.SWITCH_SIZES = {})));
var SWITCH_VARIANTS;
(function (SWITCH_VARIANTS) {
  SWITCH_VARIANTS['primary'] = 'primary';
})((SWITCH_VARIANTS = exports.SWITCH_VARIANTS || (exports.SWITCH_VARIANTS = {})));
var SWITCH_LABEL_POSITION;
(function (SWITCH_LABEL_POSITION) {
  SWITCH_LABEL_POSITION['left'] = 'left';
  SWITCH_LABEL_POSITION['right'] = 'right';
})((SWITCH_LABEL_POSITION = exports.SWITCH_LABEL_POSITION || (exports.SWITCH_LABEL_POSITION = {})));
exports.DEFAULT_TOUCH_POSITION = {
  start: null,
  end: null,
};
