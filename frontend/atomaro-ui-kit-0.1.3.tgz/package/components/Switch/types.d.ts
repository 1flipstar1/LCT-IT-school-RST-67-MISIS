import React from 'react';
import { SwitchLabelPositionType, SwitchSizesType, SwitchVariantsType } from './constants';
export interface ISwitchProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'onChange' | 'type' | 'size' | 'htmlFor'> {
    /** Задает внешний вид компонента */
    variant?: SwitchVariantsType;
    /** Задает размер компонента */
    size?: SwitchSizesType;
    /** Задает значение для состояния компонента */
    checked?: boolean;
    /** Задает значение по умолчанию */
    defaultChecked?: boolean;
    /** Устанавливает текст возле компонента */
    label?: React.ReactNode;
    /** Задает расположение текста относительно компонента
     * @default right
     */
    labelPosition?: SwitchLabelPositionType;
    /** Устанавливает атрибут disabled
     * @default false
     */
    disabled?: boolean;
    /** Callback функция, вызываемая при изменении состояния
     * @param {boolean} value состояние компонента
     */
    onChange?: (value: boolean) => void;
    /** Параметр для обертки компонента - label */
    htmlFor?: string;
}
