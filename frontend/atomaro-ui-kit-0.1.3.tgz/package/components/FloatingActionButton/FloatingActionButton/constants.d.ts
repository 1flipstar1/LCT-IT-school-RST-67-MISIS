import { ICON_POSITIONS } from '../../../constants/components';
export declare enum FLOATING_ACTION_BUTTON_VARIANTS {
    primary = "primary",
    secondary = "secondary"
}
export declare enum FLOATING_ACTION_BUTTON_SIZES {
    l = "l"
}
export type FloatingActionButtonVariants = keyof typeof FLOATING_ACTION_BUTTON_VARIANTS;
export type FloatingActionButtonSizes = keyof typeof FLOATING_ACTION_BUTTON_SIZES;
export declare const DEFAULT_ICON_POSIION = ICON_POSITIONS.left;
export declare const DEFAULT_VARIANT = FLOATING_ACTION_BUTTON_VARIANTS.primary;
export declare const DEFAULT_SIZE = FLOATING_ACTION_BUTTON_SIZES.l;
