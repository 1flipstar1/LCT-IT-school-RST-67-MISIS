import { FC } from 'react';
import '../../../styles/components/floatingActionButton/floatingActionButton.scss';
import { IFloatingActionButton } from './types';
declare const FloatingActionButton: FC<IFloatingActionButton>;
export default FloatingActionButton;
