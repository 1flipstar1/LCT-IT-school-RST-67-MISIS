'use strict';
var PropTypes = require('prop-types');

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __createBinding =
  (this && this.__createBinding) ||
  (Object.create
    ? function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ('get' in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = {
            enumerable: true,
            get: function get() {
              return m[k];
            },
          };
        }
        Object.defineProperty(o, k2, desc);
      }
    : function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
      });
var __setModuleDefault =
  (this && this.__setModuleDefault) ||
  (Object.create
    ? function (o, v) {
        Object.defineProperty(o, 'default', {
          enumerable: true,
          value: v,
        });
      }
    : function (o, v) {
        o['default'] = v;
      });
var __importStar =
  (this && this.__importStar) ||
  function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null)
      for (var k in mod)
        if (k !== 'default' && Object.prototype.hasOwnProperty.call(mod, k))
          __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
  };
var __rest =
  (this && this.__rest) ||
  function (s, e) {
    var t = {};
    for (var p in s)
      if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === 'function')
      for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
          t[p[i]] = s[p[i]];
      }
    return t;
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
/* eslint-disable import/no-extraneous-dependencies */
var react_1 = __importStar(require('react'));
var react_dom_1 = require('react-dom');
var clsx_1 = __importDefault(require('clsx'));
require('../../../styles/components/floatingActionButton/floatingActionButton.scss');
var CloseSmall_1 = __importDefault(require('@atomaro/icons/24/navigation/CloseSmall'));
var function_1 = require('../../../utils/function');
var constants_1 = require('./constants');
var Overlay_1 = __importDefault(require('../../Overlay/Overlay'));
var FloatingActionMenuItem_1 = __importDefault(
  require('../FloatingActionMenuItem/FloatingActionMenuItem')
);
var Button_1 = __importDefault(require('../../Button/Button/Button'));
var FABRoot = typeof window !== 'undefined' ? document.createElement('div') : null;
var FloatingActionButton = function FloatingActionButton(props) {
  var iconPrefix = props.iconPrefix,
    iconSuffix = props.iconSuffix,
    _a = props.size,
    size = _a === void 0 ? constants_1.DEFAULT_SIZE : _a,
    _b = props.variant,
    variant = _b === void 0 ? constants_1.DEFAULT_VARIANT : _b,
    label = props.label,
    items = props.items,
    overlayVariant = props.overlayVariant,
    className = props.className,
    _c = props.useInPortal,
    useInPortal = _c === void 0 ? true : _c,
    _d = props.onClick,
    onClick = _d === void 0 ? function_1.noop : _d,
    _e = props.onClickOverlay,
    onClickOverlay = _e === void 0 ? function_1.noop : _e,
    otherProps = __rest(props, [
      'iconPrefix',
      'iconSuffix',
      'size',
      'variant',
      'label',
      'items',
      'overlayVariant',
      'className',
      'useInPortal',
      'onClick',
      'onClickOverlay',
    ]);
  var _f = (0, react_1.useState)(false),
    isOpen = _f[0],
    setIsOpen = _f[1];
  (0, react_1.useEffect)(
    function () {
      if (FABRoot && useInPortal) {
        document.body.appendChild(FABRoot);
      }
      return function () {
        if (FABRoot && document.body.contains(FABRoot)) {
          document.body.removeChild(FABRoot);
        }
      };
    },
    [useInPortal]
  );
  var onClose = function onClose() {
    return setIsOpen(false);
  };
  var overlay =
    overlayVariant &&
    react_1['default'].createElement(Overlay_1['default'], {
      variant: overlayVariant,
      onClick: function onClick() {
        return onClickOverlay(onClose);
      },
      isOpened: isOpen,
      useInPortal: false,
    });
  var buttonIconPrefix = isOpen
    ? react_1['default'].createElement(CloseSmall_1['default'], null)
    : iconPrefix;
  var buttonIconSuffix = isOpen ? null : iconSuffix;
  var menuContent =
    (items === null || items === void 0 ? void 0 : items.length) &&
    isOpen &&
    react_1['default'].createElement(
      'ul',
      {
        className: 'floating-action-button__menu',
      },
      items === null || items === void 0
        ? void 0
        : items.map(function (item) {
            return react_1['default'].createElement(
              FloatingActionMenuItem_1['default'],
              __assign({}, item, {
                key: item.key,
                variant: variant,
                size: size,
                label: item.label,
                icon: item.icon,
                tag: item.tag,
                onClick: function onClick(e) {
                  onClose();
                  if (item.onClick) {
                    item.onClick(e);
                  }
                },
              })
            );
          })
    );
  var clickHandler = function clickHandler(e) {
    if (
      (items === null || items === void 0 ? void 0 : items.length) &&
      (items === null || items === void 0 ? void 0 : items.length) > 0
    ) {
      setIsOpen(!isOpen);
    }
    onClick(e);
  };
  var rootClassName = (0, clsx_1['default'])(
    'floating-action-button',
    'floating-action-button--'.concat(constants_1.FLOATING_ACTION_BUTTON_VARIANTS[variant]),
    'floating-action-button--size-'.concat(constants_1.FLOATING_ACTION_BUTTON_SIZES[size]),
    isOpen && 'floating-action-button--open-menu',
    label && 'floating-action-button--with-label',
    className
  );
  var FABContent = react_1['default'].createElement(
    react_1['default'].Fragment,
    null,
    overlay,
    react_1['default'].createElement(
      'div',
      {
        className: rootClassName,
      },
      react_1['default'].createElement(
        Button_1['default'],
        __assign(
          {
            className: 'floating-action-button__button',
            label: !isOpen && label,
            variant: variant,
            size: size,
            iconPrefix: buttonIconPrefix,
            iconSuffix: buttonIconSuffix,
            onClick: clickHandler,
          },
          otherProps
        )
      ),
      menuContent
    )
  );
  return useInPortal && FABRoot ? (0, react_dom_1.createPortal)(FABContent, FABRoot) : FABContent;
};

FloatingActionButton.propTypes = {
  className: PropTypes.string,
  /**
   * Иконка для кнопки слева
   */
  iconPrefix: PropTypes.node,
  /**
   * Иконка для кнопки справа
   */
  iconSuffix: PropTypes.node,
  /**
   * Задает пункты меню в виде массива объектов
   * @param key - ключ пункта меню
   * @param label - текст пункта меню
   * @param icon - иконка пункта меню
   * @param tag - html-тег пункта меню. По умолчанию  - 'a'
   * @param onClick - callback-функция, вызываемая при клике на пункт меню
   */
  items: PropTypes.arrayOf(
    PropTypes.shape({
      /**
       * Задает дополнительные классы для компонента
       */
      className: PropTypes.string,
      /**
       * Задаёт иконку
       */
      icon: PropTypes.node,
      /**
       * Задает текст
       */
      label: PropTypes.string,
      /**
       * Callback функция, вызываемая при клике
       */
      onClick: PropTypes.func,
      /**
       * Задает размер
       */
      size: PropTypes.oneOf(['l']),
      /**
       * Задает дополнительные стили для компонента
       */
      style: PropTypes.object,
      /**
       * Задает тег для пункта (React.ElementType)
       *  @default "a"
       */
      tag: PropTypes.oneOfType([
        PropTypes.oneOf([
          'a',
          'abbr',
          'address',
          'animate',
          'animateMotion',
          'animateTransform',
          'area',
          'article',
          'aside',
          'audio',
          'b',
          'base',
          'bdi',
          'bdo',
          'big',
          'blockquote',
          'body',
          'br',
          'button',
          'canvas',
          'caption',
          'center',
          'circle',
          'cite',
          'clipPath',
          'code',
          'col',
          'colgroup',
          'data',
          'datalist',
          'dd',
          'defs',
          'del',
          'desc',
          'details',
          'dfn',
          'dialog',
          'div',
          'dl',
          'dt',
          'ellipse',
          'em',
          'embed',
          'feBlend',
          'feColorMatrix',
          'feComponentTransfer',
          'feComposite',
          'feConvolveMatrix',
          'feDiffuseLighting',
          'feDisplacementMap',
          'feDistantLight',
          'feDropShadow',
          'feFlood',
          'feFuncA',
          'feFuncB',
          'feFuncG',
          'feFuncR',
          'feGaussianBlur',
          'feImage',
          'feMerge',
          'feMergeNode',
          'feMorphology',
          'feOffset',
          'fePointLight',
          'feSpecularLighting',
          'feSpotLight',
          'feTile',
          'feTurbulence',
          'fieldset',
          'figcaption',
          'figure',
          'filter',
          'footer',
          'foreignObject',
          'form',
          'g',
          'h1',
          'h2',
          'h3',
          'h4',
          'h5',
          'h6',
          'head',
          'header',
          'hgroup',
          'hr',
          'html',
          'i',
          'iframe',
          'image',
          'img',
          'input',
          'ins',
          'kbd',
          'keygen',
          'label',
          'legend',
          'li',
          'line',
          'linearGradient',
          'link',
          'main',
          'map',
          'mark',
          'marker',
          'mask',
          'menu',
          'menuitem',
          'meta',
          'metadata',
          'meter',
          'mpath',
          'nav',
          'noindex',
          'noscript',
          'object',
          'ol',
          'optgroup',
          'option',
          'output',
          'p',
          'param',
          'path',
          'pattern',
          'picture',
          'polygon',
          'polyline',
          'pre',
          'progress',
          'q',
          'radialGradient',
          'rect',
          'rp',
          'rt',
          'ruby',
          's',
          'samp',
          'script',
          'search',
          'section',
          'select',
          'slot',
          'small',
          'source',
          'span',
          'stop',
          'strong',
          'style',
          'sub',
          'summary',
          'sup',
          'svg',
          'switch',
          'symbol',
          'table',
          'tbody',
          'td',
          'template',
          'text',
          'textarea',
          'textPath',
          'tfoot',
          'th',
          'thead',
          'time',
          'title',
          'tr',
          'track',
          'tspan',
          'u',
          'ul',
          'use',
          'var',
          'video',
          'view',
          'wbr',
          'webview',
        ]),
        PropTypes.func,
        PropTypes.shape({
          childContextTypes: PropTypes.object,
          contextType: PropTypes.shape({
            Consumer: PropTypes.func.isRequired,
            displayName: PropTypes.string,
            Provider: PropTypes.func.isRequired,
          }),
          contextTypes: PropTypes.object,
          defaultProps: PropTypes.object,
          displayName: PropTypes.string,
          getDerivedStateFromError: PropTypes.func,
          getDerivedStateFromProps: PropTypes.func,
          propTypes: PropTypes.object,
        }),
      ]),
      /**
       * Задает вариант
       *  @default "primary"
       */
      variant: PropTypes.oneOf(['primary', 'secondary']),
    })
  ),
  /**
   * Задает текст кнопки
   */
  label: PropTypes.string,
  onClick: PropTypes.func,
  /**
   * Callback функция, вызываемая при клике на Overlay
   * @param onClose - функция для закрытия меню
   */
  onClickOverlay: PropTypes.func,
  /**
   * Задает вариант overlay при открытом меню
   */
  overlayVariant: PropTypes.oneOf(['primary', 'secondary']),
  /**
   * Задает размер
   *  @default l
   */
  size: PropTypes.oneOf(['l']),
  /**
   * Задает использование в Portal
   *  @default true
   */
  useInPortal: PropTypes.bool,
  /**
   * Задает внешний вид
   *  @default primary
   */
  variant: PropTypes.oneOf(['primary', 'secondary']),
};

FloatingActionButton.displayName = 'FloatingActionButton';
exports['default'] = FloatingActionButton;
