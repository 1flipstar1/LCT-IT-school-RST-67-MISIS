import React from 'react';
import { OverlayVariantType } from '../../Overlay/constants';
import { FloatingActionButtonSizes, FloatingActionButtonVariants } from './constants';
import { IFloatingActionMenuItem } from '../FloatingActionMenuItem/types';
export interface IFloatingActionButton extends Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, 'children'> {
    /** Задает внешний вид
     *  @default primary */
    variant?: FloatingActionButtonVariants;
    /** Задает размер
     *  @default l */
    size?: FloatingActionButtonSizes;
    /** Задает текст кнопки */
    label?: string;
    /** Иконка для кнопки слева */
    iconPrefix?: React.ReactNode;
    /** Иконка для кнопки справа */
    iconSuffix?: React.ReactNode;
    /** Задает пункты меню в виде массива объектов
     * @param key - ключ пункта меню
     * @param label - текст пункта меню
     * @param icon - иконка пункта меню
     * @param tag - html-тег пункта меню. По умолчанию  - 'a'
     * @param onClick - callback-функция, вызываемая при клике на пункт меню
     */
    items?: IFloatingActionMenuItem[];
    /** Задает вариант overlay при открытом меню */
    overlayVariant?: OverlayVariantType;
    /** Задает использование в Portal
     *  @default true */
    useInPortal?: boolean;
    /** Callback функция, вызываемая при клике на Overlay
     * @param onClose - функция для закрытия меню
     */
    onClickOverlay?(onClose: () => void): void;
}
