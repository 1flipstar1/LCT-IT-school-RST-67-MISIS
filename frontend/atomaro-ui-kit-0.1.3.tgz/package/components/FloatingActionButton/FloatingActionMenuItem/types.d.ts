import { ReactNode, ElementType, CSSProperties } from 'react';
import { FloatingActionButtonSizes, FloatingActionButtonVariants } from '../FloatingActionButton/constants';
export type IFloatingActionMenuItem = {
    /** Задает вариант
     *  @default "primary" */
    variant?: FloatingActionButtonVariants;
    /** Задает размер */
    size?: FloatingActionButtonSizes;
    /** Задает текст */
    label?: string;
    /** Задаёт иконку */
    icon?: ReactNode;
    /** Задает дополнительные классы для компонента */
    className?: string;
    /** Задает дополнительные стили для компонента */
    style?: CSSProperties;
    /** Задает тег для пункта (React.ElementType)
     *  @default "a" */
    tag?: ElementType;
    /** Callback функция, вызываемая при клике */
    onClick?(event: MouseEvent): void;
    /** Позволяет задать дополнительные параметры для пункта меню */
    [x: string]: any;
};
