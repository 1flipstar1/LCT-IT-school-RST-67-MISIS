"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.DEFAULT_SIZE = exports.DEFAULT_VARIANT = void 0;
var constants_1 = require("../FloatingActionButton/constants");
exports.DEFAULT_VARIANT = constants_1.FLOATING_ACTION_BUTTON_VARIANTS.primary;
exports.DEFAULT_SIZE = constants_1.FLOATING_ACTION_BUTTON_SIZES.l;