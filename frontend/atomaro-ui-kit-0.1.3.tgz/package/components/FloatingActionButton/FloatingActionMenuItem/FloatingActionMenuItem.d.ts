import React from 'react';
import '../../../styles/components/floatingActionButton/floatingActionMenuItem.scss';
import { IFloatingActionMenuItem } from './types';
declare const FloatingActionMenuItem: React.FC<IFloatingActionMenuItem>;
export default FloatingActionMenuItem;
