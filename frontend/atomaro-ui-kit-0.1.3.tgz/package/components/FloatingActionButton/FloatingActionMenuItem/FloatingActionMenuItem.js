'use strict';
var PropTypes = require('prop-types');

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __rest =
  (this && this.__rest) ||
  function (s, e) {
    var t = {};
    for (var p in s)
      if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === 'function')
      for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
          t[p[i]] = s[p[i]];
      }
    return t;
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var clsx_1 = __importDefault(require('clsx'));
require('../../../styles/components/floatingActionButton/floatingActionMenuItem.scss');
var constants_1 = require('./constants');
var constants_2 = require('../FloatingActionButton/constants');
var noop_1 = require('../../../utils/noop');
var FloatingActionMenuItem = function FloatingActionMenuItem(props) {
  var _a = props.variant,
    variant = _a === void 0 ? constants_1.DEFAULT_VARIANT : _a,
    _b = props.size,
    size = _b === void 0 ? constants_1.DEFAULT_SIZE : _b,
    icon = props.icon,
    label = props.label,
    _c = props.tag,
    Tag = _c === void 0 ? 'a' : _c,
    _d = props.onClick,
    onClick = _d === void 0 ? noop_1.noop : _d,
    className = props.className,
    restProps = __rest(props, ['variant', 'size', 'icon', 'label', 'tag', 'onClick', 'className']);
  var rootClassName = (0, clsx_1['default'])(
    'floating-action-menu-item',
    'floating-action-menu-item--'.concat(constants_2.FLOATING_ACTION_BUTTON_VARIANTS[variant]),
    'floating-action-menu-item--size-'.concat(constants_2.FLOATING_ACTION_BUTTON_SIZES[size]),
    label && 'floating-action-menu-item--with-text',
    className
  );
  return react_1['default'].createElement(
    'li',
    {
      className: rootClassName,
    },
    react_1['default'].createElement(
      Tag,
      __assign(
        {
          className: 'floating-action-menu-item__link',
          label: label,
          onClick: onClick,
        },
        restProps
      ),
      react_1['default'].createElement('span', null, label),
      icon
    )
  );
};

FloatingActionMenuItem.propTypes = {
  /**
   * Задает дополнительные классы для компонента
   */
  className: PropTypes.string,
  /**
   * Задаёт иконку
   */
  icon: PropTypes.node,
  /**
   * Задает текст
   */
  label: PropTypes.string,
  /**
   * Callback функция, вызываемая при клике
   */
  onClick: PropTypes.func,
  /**
   * Задает размер
   */
  size: PropTypes.oneOf(['l']),
  /**
   * Задает тег для пункта (React.ElementType)
   *  @default "a"
   */
  tag: PropTypes.oneOfType([
    PropTypes.oneOf([
      'a',
      'abbr',
      'address',
      'animate',
      'animateMotion',
      'animateTransform',
      'area',
      'article',
      'aside',
      'audio',
      'b',
      'base',
      'bdi',
      'bdo',
      'big',
      'blockquote',
      'body',
      'br',
      'button',
      'canvas',
      'caption',
      'center',
      'circle',
      'cite',
      'clipPath',
      'code',
      'col',
      'colgroup',
      'data',
      'datalist',
      'dd',
      'defs',
      'del',
      'desc',
      'details',
      'dfn',
      'dialog',
      'div',
      'dl',
      'dt',
      'ellipse',
      'em',
      'embed',
      'feBlend',
      'feColorMatrix',
      'feComponentTransfer',
      'feComposite',
      'feConvolveMatrix',
      'feDiffuseLighting',
      'feDisplacementMap',
      'feDistantLight',
      'feDropShadow',
      'feFlood',
      'feFuncA',
      'feFuncB',
      'feFuncG',
      'feFuncR',
      'feGaussianBlur',
      'feImage',
      'feMerge',
      'feMergeNode',
      'feMorphology',
      'feOffset',
      'fePointLight',
      'feSpecularLighting',
      'feSpotLight',
      'feTile',
      'feTurbulence',
      'fieldset',
      'figcaption',
      'figure',
      'filter',
      'footer',
      'foreignObject',
      'form',
      'g',
      'h1',
      'h2',
      'h3',
      'h4',
      'h5',
      'h6',
      'head',
      'header',
      'hgroup',
      'hr',
      'html',
      'i',
      'iframe',
      'image',
      'img',
      'input',
      'ins',
      'kbd',
      'keygen',
      'label',
      'legend',
      'li',
      'line',
      'linearGradient',
      'link',
      'main',
      'map',
      'mark',
      'marker',
      'mask',
      'menu',
      'menuitem',
      'meta',
      'metadata',
      'meter',
      'mpath',
      'nav',
      'noindex',
      'noscript',
      'object',
      'ol',
      'optgroup',
      'option',
      'output',
      'p',
      'param',
      'path',
      'pattern',
      'picture',
      'polygon',
      'polyline',
      'pre',
      'progress',
      'q',
      'radialGradient',
      'rect',
      'rp',
      'rt',
      'ruby',
      's',
      'samp',
      'script',
      'search',
      'section',
      'select',
      'slot',
      'small',
      'source',
      'span',
      'stop',
      'strong',
      'style',
      'sub',
      'summary',
      'sup',
      'svg',
      'switch',
      'symbol',
      'table',
      'tbody',
      'td',
      'template',
      'text',
      'textarea',
      'textPath',
      'tfoot',
      'th',
      'thead',
      'time',
      'title',
      'tr',
      'track',
      'tspan',
      'u',
      'ul',
      'use',
      'var',
      'video',
      'view',
      'wbr',
      'webview',
    ]),
    PropTypes.func,
    PropTypes.shape({
      childContextTypes: PropTypes.object,
      contextType: PropTypes.shape({
        Consumer: PropTypes.func.isRequired,
        displayName: PropTypes.string,
        Provider: PropTypes.func.isRequired,
      }),
      contextTypes: PropTypes.object,
      defaultProps: PropTypes.object,
      displayName: PropTypes.string,
      getDerivedStateFromError: PropTypes.func,
      getDerivedStateFromProps: PropTypes.func,
      propTypes: PropTypes.object,
    }),
  ]),
  /**
   * Задает вариант
   *  @default "primary"
   */
  variant: PropTypes.oneOf(['primary', 'secondary']),
};

FloatingActionMenuItem.displayName = 'FloatingActionMenuItem';
exports['default'] = FloatingActionMenuItem;
