import { FLOATING_ACTION_BUTTON_SIZES, FLOATING_ACTION_BUTTON_VARIANTS } from '../FloatingActionButton/constants';
export type FloatingActionMenuItemVariants = keyof typeof FLOATING_ACTION_BUTTON_VARIANTS;
export type FloatingActionMenuItemSizes = keyof typeof FLOATING_ACTION_BUTTON_SIZES;
export declare const DEFAULT_VARIANT = FLOATING_ACTION_BUTTON_VARIANTS.primary;
export declare const DEFAULT_SIZE = FLOATING_ACTION_BUTTON_SIZES.l;
