'use strict';
var PropTypes = require('prop-types');

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __rest =
  (this && this.__rest) ||
  function (s, e) {
    var t = {};
    for (var p in s)
      if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === 'function')
      for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
          t[p[i]] = s[p[i]];
      }
    return t;
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importDefault(require('react'));
var clsx_1 = __importDefault(require('clsx'));
require('../../styles/components/loader.scss');
var constants_1 = require('./constants');
var Loader = function Loader(props) {
  var _a = props.size,
    size = _a === void 0 ? constants_1.LOADER_SIZES.s : _a,
    _b = props.variant,
    variant = _b === void 0 ? constants_1.LOADER_VIEW.secondary : _b,
    className = props.className,
    restProps = __rest(props, ['size', 'variant', 'className']);
  var rootClassName = (0, clsx_1['default'])(
    'loader',
    'loader--'.concat(constants_1.LOADER_VIEW[variant]),
    'loader--size-'.concat(size),
    className
  );
  return react_1['default'].createElement(
    'div',
    __assign(
      {
        className: rootClassName,
      },
      restProps
    ),
    react_1['default'].createElement('span', {
      className: 'loader__item',
    }),
    react_1['default'].createElement('span', {
      className: 'loader__item',
    }),
    react_1['default'].createElement('span', {
      className: 'loader__item',
    })
  );
};

Loader.propTypes = {
  className: PropTypes.string,
  /**
   * Задает  размер
   * @default s
   */
  size: PropTypes.oneOf(['2xs', 'm', 's']),
  /**
   * Задает внешний вид
   *  @default secondary
   */
  variant: PropTypes.oneOf(['primary', 'secondary']),
};

Loader.displayName = 'Loader';
exports['default'] = Loader;
