import { FC } from 'react';
import '../../styles/components/loader.scss';
import { ILoaderProps } from './types';
declare const Loader: FC<ILoaderProps>;
export default Loader;
