export declare enum LOADER_SIZES {
    '2xs' = "2xs",
    s = "s",
    m = "m"
}
export declare enum LOADER_VIEW {
    primary = "primary",
    secondary = "secondary"
}
