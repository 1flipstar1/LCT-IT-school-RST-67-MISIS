import React from 'react';
import { LOADER_SIZES, LOADER_VIEW } from './constants';
type LoaderSizesType = keyof typeof LOADER_SIZES;
type LoaderVariantType = keyof typeof LOADER_VIEW;
export interface ILoaderProps extends React.HTMLAttributes<HTMLDivElement> {
    /** Задает  размер
     * @default s
     */
    size?: LoaderSizesType;
    /** Задает внешний вид
     *  @default secondary */
    variant?: LoaderVariantType;
}
export {};
