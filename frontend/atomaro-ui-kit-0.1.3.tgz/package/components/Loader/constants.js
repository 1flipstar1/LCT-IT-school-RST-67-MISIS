"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.LOADER_VIEW = exports.LOADER_SIZES = void 0;
var LOADER_SIZES;
(function (LOADER_SIZES) {
  LOADER_SIZES["2xs"] = "2xs";
  LOADER_SIZES["s"] = "s";
  LOADER_SIZES["m"] = "m";
})(LOADER_SIZES = exports.LOADER_SIZES || (exports.LOADER_SIZES = {}));
var LOADER_VIEW;
(function (LOADER_VIEW) {
  LOADER_VIEW["primary"] = "primary";
  LOADER_VIEW["secondary"] = "secondary";
})(LOADER_VIEW = exports.LOADER_VIEW || (exports.LOADER_VIEW = {}));