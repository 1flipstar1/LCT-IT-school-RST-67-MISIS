export declare enum CHECKBOX_SIZES {
    xs = "xs",
    s = "s"
}
export declare enum CHECKBOX_VARIANTS {
    primary = "primary"
}
export type CheckboxVariantType = keyof typeof CHECKBOX_VARIANTS;
export type CheckboxSizeType = keyof typeof CHECKBOX_SIZES;
