'use strict';
var PropTypes = require('prop-types');

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __createBinding =
  (this && this.__createBinding) ||
  (Object.create
    ? function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ('get' in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = {
            enumerable: true,
            get: function get() {
              return m[k];
            },
          };
        }
        Object.defineProperty(o, k2, desc);
      }
    : function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
      });
var __setModuleDefault =
  (this && this.__setModuleDefault) ||
  (Object.create
    ? function (o, v) {
        Object.defineProperty(o, 'default', {
          enumerable: true,
          value: v,
        });
      }
    : function (o, v) {
        o['default'] = v;
      });
var __importStar =
  (this && this.__importStar) ||
  function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null)
      for (var k in mod)
        if (k !== 'default' && Object.prototype.hasOwnProperty.call(mod, k))
          __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
  };
var __rest =
  (this && this.__rest) ||
  function (s, e) {
    var t = {};
    for (var p in s)
      if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === 'function')
      for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
          t[p[i]] = s[p[i]];
      }
    return t;
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
/* eslint-disable import/no-extraneous-dependencies */
/* eslint-disable jsx-a11y/label-has-associated-control */
var react_1 = __importStar(require('react'));
var clsx_1 = __importDefault(require('clsx'));
require('../../../styles/components/checkbox/checkbox.scss');
var RemoveSmall_1 = __importDefault(require('@atomaro/icons/24/action/RemoveSmall'));
var CheckSmall_1 = __importDefault(require('@atomaro/icons/24/navigation/CheckSmall'));
var constants_1 = require('../constants');
var context_1 = require('../context');
var Checkbox = (0, react_1.forwardRef)(function Checkbox(props, ref) {
  var _a = props.variant,
    variant = _a === void 0 ? constants_1.CHECKBOX_VARIANTS.primary : _a,
    label = props.label,
    _b = props.disabled,
    disabled = _b === void 0 ? false : _b,
    _c = props.indeterminate,
    indeterminate = _c === void 0 ? false : _c,
    checked = props.checked,
    _d = props.defaultChecked,
    defaultChecked = _d === void 0 ? false : _d,
    _e = props.size,
    size = _e === void 0 ? constants_1.CHECKBOX_SIZES.s : _e,
    className = props.className,
    id = props.id,
    onChange = props.onChange,
    onClick = props.onClick,
    restProps = __rest(props, [
      'variant',
      'label',
      'disabled',
      'indeterminate',
      'checked',
      'defaultChecked',
      'size',
      'className',
      'id',
      'onChange',
      'onClick',
    ]);
  var _f = react_1['default'].useContext(context_1.CheckboxGroupContext),
    onGroupChange = _f.onGroupChange,
    groupValue = _f.groupValue,
    groupDisabled = _f.groupDisabled,
    disabledAll = _f.disabledAll;
  var _g = (0, react_1.useState)(defaultChecked),
    isChecked = _g[0],
    setIsChecked = _g[1];
  var _h = (0, react_1.useState)(indeterminate),
    isIndeterminate = _h[0],
    setIsIndeterminate = _h[1];
  var _j = (0, react_1.useState)(disabled),
    isDisabled = _j[0],
    setIsDisabled = _j[1];
  var handleInputChange = (0, react_1.useCallback)(
    function (event) {
      var checkboxChecked = event.target.checked;
      if (onChange) {
        onChange(checkboxChecked, isIndeterminate);
      }
      if (onGroupChange) {
        onGroupChange(event.target.id);
      }
      if (checked === undefined) {
        setIsChecked(checkboxChecked);
      }
    },
    [onChange, onGroupChange, checked, isIndeterminate]
  );
  (0, react_1.useEffect)(
    function () {
      if (indeterminate !== isIndeterminate) {
        setIsIndeterminate(indeterminate);
      }
      setIsChecked(!!checked);
      // eslint-disable-next-line react-hooks/exhaustive-deps
    },
    [indeterminate, checked]
  );
  var handleClick = (0, react_1.useCallback)(
    function (e) {
      e.stopPropagation();
      if (onClick) {
        onClick(e);
      }
    },
    [onClick]
  );
  var renderIcon = function renderIcon() {
    if (isIndeterminate) {
      return size === constants_1.CHECKBOX_SIZES.s
        ? react_1['default'].createElement(RemoveSmall_1['default'], {
            size: 24,
          })
        : react_1['default'].createElement(RemoveSmall_1['default'], {
            size: 20,
          });
    }
    if (isChecked) {
      return size === constants_1.CHECKBOX_SIZES.s
        ? react_1['default'].createElement(CheckSmall_1['default'], {
            size: 24,
          })
        : react_1['default'].createElement(CheckSmall_1['default'], {
            size: 20,
          });
    }
    return null;
  };
  (0, react_1.useEffect)(
    function () {
      if (indeterminate !== isIndeterminate) {
        setIsIndeterminate(indeterminate);
      }
      if (groupValue && id) {
        var newValue = groupValue.includes(id);
        setIsChecked(newValue);
      } else if (checked !== undefined && checked !== isChecked) {
        setIsChecked(checked);
      }
      // eslint-disable-next-line react-hooks/exhaustive-deps
    },
    [indeterminate, groupValue, groupDisabled, checked]
  );
  (0, react_1.useEffect)(
    function () {
      if (groupDisabled && id) {
        var newDisabled = disabledAll || groupDisabled.includes(id);
        setIsDisabled(newDisabled);
      } else if (disabled !== isDisabled) {
        setIsDisabled(disabled);
      }
    },
    [groupDisabled, disabled, id, isDisabled, disabledAll]
  );
  var checkboxIcon = renderIcon();
  var rootClassName = (0, clsx_1['default'])(
    'checkbox',
    'checkbox--'.concat(constants_1.CHECKBOX_VARIANTS[variant]),
    'checkbox--size-'.concat(constants_1.CHECKBOX_SIZES[size]),
    isDisabled && 'checkbox--disabled',
    className
  );
  return react_1['default'].createElement(
    'label',
    {
      className: rootClassName,
    },
    react_1['default'].createElement(
      'input',
      __assign(
        {
          id: id,
          type: 'checkbox',
          className: 'checkbox__input',
          ref: ref,
          onChange: handleInputChange,
          disabled: isDisabled,
          checked: isChecked || isIndeterminate,
        },
        restProps
      )
    ),
    react_1['default'].createElement(
      'div',
      {
        role: 'checkbox',
        'aria-checked': isChecked || isIndeterminate,
        'aria-disabled': isDisabled,
        tabIndex: isDisabled ? -1 : 0,
        className: 'checkbox__container',
        onClick: handleClick,
        onKeyDown: function onKeyDown() {},
      },
      checkboxIcon,
      react_1['default'].createElement('div', {
        className: 'checkbox__innerframe',
      })
    ),
    label &&
      react_1['default'].createElement(
        'span',
        {
          className: 'checkbox__label',
        },
        label
      )
  );
});

Checkbox.propTypes = {
  /**
   * Устанавливает атрибут checked
   */
  checked: PropTypes.bool,
  className: PropTypes.string,
  /**
   * Задает значение по умолчанию
   */
  defaultChecked: PropTypes.bool,
  /**
   * Устанавливает атрибут disabled
   */
  disabled: PropTypes.bool,
  id: PropTypes.string,
  /**
   * Задает неопределенное значение чекбокса
   *  @default false
   */
  indeterminate: PropTypes.bool,
  /**
   * Задает текст лейбла для чекбокса
   */
  label: PropTypes.node,
  /**
   * Callback функция, вызываемая при изменении значения
   */
  onChange: PropTypes.func,
  /**
   * Callback функция, вызываемая при клике на чекбокс
   */
  onClick: PropTypes.func,
  /**
   * Задает размер чекбокса
   * @default s
   */
  size: PropTypes.oneOf(['s', 'xs']),
  /**
   * Задает основной цвет для чекбокса
   *  @default primary
   */
  variant: PropTypes.oneOf(['primary']),
};

Checkbox.displayName = 'Checkbox';
exports['default'] = Checkbox;
