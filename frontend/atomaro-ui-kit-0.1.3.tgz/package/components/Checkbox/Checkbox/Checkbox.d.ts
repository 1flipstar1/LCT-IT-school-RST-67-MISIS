import React from 'react';
import '../../../styles/components/checkbox/checkbox.scss';
import { ICheckboxProps } from './types';
declare const Checkbox: React.ForwardRefExoticComponent<ICheckboxProps & React.RefAttributes<HTMLInputElement>>;
export default Checkbox;
