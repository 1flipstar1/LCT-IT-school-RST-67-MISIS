import React from 'react';
import { CheckboxSizeType, CheckboxVariantType } from '../constants';
export interface ICheckboxProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'onChange' | 'onClick' | 'type' | 'size' | 'childre'> {
    /** Задает основной цвет для чекбокса
     *  @default primary */
    variant?: CheckboxVariantType;
    /** Задает размер чекбокса
     * @default s
     */
    size?: CheckboxSizeType;
    /** Задает текст лейбла для чекбокса */
    label?: React.ReactNode;
    /** Задает неопределенное значение чекбокса
     *  @default false */
    indeterminate?: boolean;
    /** Устанавливает атрибут checked */
    checked?: boolean;
    /** Задает значение по умолчанию */
    defaultChecked?: boolean;
    /** Устанавливает атрибут disabled */
    disabled?: boolean;
    /** Callback функция, вызываемая при изменении значения */
    onChange?: (value: boolean, indeterminate: boolean) => void;
    /** Callback функция, вызываемая при клике на чекбокс */
    onClick?: (event: React.MouseEvent<HTMLDivElement>) => void;
}
