"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.CHECKBOX_VARIANTS = exports.CHECKBOX_SIZES = void 0;
var CHECKBOX_SIZES;
(function (CHECKBOX_SIZES) {
  CHECKBOX_SIZES["xs"] = "xs";
  CHECKBOX_SIZES["s"] = "s";
})(CHECKBOX_SIZES = exports.CHECKBOX_SIZES || (exports.CHECKBOX_SIZES = {}));
var CHECKBOX_VARIANTS;
(function (CHECKBOX_VARIANTS) {
  CHECKBOX_VARIANTS["primary"] = "primary";
})(CHECKBOX_VARIANTS = exports.CHECKBOX_VARIANTS || (exports.CHECKBOX_VARIANTS = {}));