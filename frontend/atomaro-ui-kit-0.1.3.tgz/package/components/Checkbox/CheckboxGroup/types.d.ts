import React from 'react';
import { CheckboxSizeType, CheckboxVariantType } from '../constants';
export type OptionType = {
    key: string;
    value: React.ReactNode;
};
export interface ICheckboxGroup extends Omit<React.HTMLAttributes<HTMLFieldSetElement>, 'defaultChecked' | 'title' | 'onChange'> {
    /** Задает основной цвет для чекбокса
     *  @default primary */
    variant?: CheckboxVariantType;
    /** Задает размер чекбокса
     * @default s
     */
    size?: CheckboxSizeType;
    /** Задает заголовок для группы
     * @default "Выбрать все"
     */
    title?: React.ReactNode;
    /** Включает родительский чекбокс для группы
     * @default true
     */
    parentBox?: boolean;
    /** Список чекбоксов. Массив объектов
     * @param key - ключ чекбокса
     * @param value - текст для чекбокса
     */
    options: OptionType[];
    /** Список выбранных чекбоксов. Массив с ключами
     * @param key - ключ checked чекбокса
     */
    defaultChecked?: string[];
    /** Список disabled чекбоксов
     * @param key - ключ disabled чекбокса
     */
    disabledItems?: string[];
    /** Disable для всей группы */
    disabledAll?: boolean;
    /** Callback функция, вызываемая при изменении значения */
    onChange?: (selected: string[]) => void;
}
