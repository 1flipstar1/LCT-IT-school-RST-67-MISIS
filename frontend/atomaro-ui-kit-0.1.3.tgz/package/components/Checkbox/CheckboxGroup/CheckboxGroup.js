'use strict';
var PropTypes = require('prop-types');

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __createBinding =
  (this && this.__createBinding) ||
  (Object.create
    ? function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ('get' in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = {
            enumerable: true,
            get: function get() {
              return m[k];
            },
          };
        }
        Object.defineProperty(o, k2, desc);
      }
    : function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
      });
var __setModuleDefault =
  (this && this.__setModuleDefault) ||
  (Object.create
    ? function (o, v) {
        Object.defineProperty(o, 'default', {
          enumerable: true,
          value: v,
        });
      }
    : function (o, v) {
        o['default'] = v;
      });
var __importStar =
  (this && this.__importStar) ||
  function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null)
      for (var k in mod)
        if (k !== 'default' && Object.prototype.hasOwnProperty.call(mod, k))
          __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
  };
var __rest =
  (this && this.__rest) ||
  function (s, e) {
    var t = {};
    for (var p in s)
      if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === 'function')
      for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
          t[p[i]] = s[p[i]];
      }
    return t;
  };
var __spreadArray =
  (this && this.__spreadArray) ||
  function (to, from, pack) {
    if (pack || arguments.length === 2)
      for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
          if (!ar) ar = Array.prototype.slice.call(from, 0, i);
          ar[i] = from[i];
        }
      }
    return to.concat(ar || Array.prototype.slice.call(from));
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importStar(require('react'));
var clsx_1 = __importDefault(require('clsx'));
require('../../../styles/components/checkbox/checkboxGroup.scss');
var context_1 = __importDefault(require('../context'));
var function_1 = require('../../../utils/function');
var Checkbox_1 = __importDefault(require('../Checkbox/Checkbox'));
var constants_1 = require('../constants');
var CheckboxGroup = function CheckboxGroup(props) {
  var _a;
  var _b = props.variant,
    variant = _b === void 0 ? constants_1.CHECKBOX_VARIANTS.primary : _b,
    _c = props.size,
    size = _c === void 0 ? constants_1.CHECKBOX_SIZES.s : _c,
    _d = props.title,
    title = _d === void 0 ? 'Выбрать все' : _d,
    _e = props.parentBox,
    parentBox = _e === void 0 ? true : _e,
    options = props.options,
    _f = props.defaultChecked,
    defaultChecked = _f === void 0 ? [] : _f,
    _g = props.disabledAll,
    disabledAll = _g === void 0 ? false : _g,
    _h = props.disabledItems,
    disabledItems = _h === void 0 ? [] : _h,
    className = props.className,
    style = props.style,
    _j = props.onChange,
    onChange = _j === void 0 ? function_1.noop : _j,
    restProps = __rest(props, [
      'variant',
      'size',
      'title',
      'parentBox',
      'options',
      'defaultChecked',
      'disabledAll',
      'disabledItems',
      'className',
      'style',
      'onChange',
    ]);
  var _k = (0, react_1.useState)(defaultChecked),
    groupValue = _k[0],
    setGroupValue = _k[1];
  var showLegend = (0, react_1.useMemo)(
    function () {
      return Boolean(!parentBox && title);
    },
    [parentBox, title]
  );
  var showLegendWithCheckbox = (0, react_1.useMemo)(
    function () {
      return Boolean(parentBox && title);
    },
    [parentBox, title]
  );
  var _l = (0, react_1.useMemo)(
      function () {
        return {
          checked: groupValue.length === options.length,
          indeterminate: groupValue.length > 0 && groupValue.length < options.length,
        };
      },
      [groupValue, options]
    ),
    checked = _l.checked,
    indeterminate = _l.indeterminate;
  var isEmptyEnabledBoxes = (0, react_1.useMemo)(
    function () {
      return options.some(function (opt) {
        return !disabledItems.includes(opt.key) && !groupValue.includes(opt.key);
      });
    },
    [options, groupValue, disabledItems]
  );
  var noChecked = groupValue.length === 0;
  var handleChange = (0, react_1.useCallback)(
    function (id) {
      if (!id) {
        return;
      }
      var newValue = __spreadArray([], groupValue, true);
      var indexValue = groupValue.findIndex(function (value) {
        return id === value;
      });
      if (indexValue === -1) {
        newValue.push(id);
      } else {
        newValue.splice(indexValue, 1);
      }
      setGroupValue(newValue);
      onChange(newValue);
    },
    [groupValue, onChange]
  );
  var setAllChecked = function setAllChecked() {
    var newValue = options.reduce(function (newArray, opt) {
      var isOptionDisabled = disabledItems.includes(opt.key);
      var isOptionChecked = groupValue.includes(opt.key);
      if (!(isOptionDisabled && !isOptionChecked)) {
        newArray.push(opt.key);
      }
      return newArray;
    }, []);
    setGroupValue(newValue);
    onChange(newValue);
  };
  var setAllUnchecked = function setAllUnchecked() {
    var newValue = options.reduce(function (newArray, opt) {
      if (disabledItems.includes(opt.key) && groupValue.includes(opt.key)) {
        newArray.push(opt.key);
      }
      return newArray;
    }, []);
    setGroupValue(newValue);
    onChange(newValue);
  };
  var parentBoxHandler = function parentBoxHandler() {
    // если нет выбранных или выбраны частично (есть пустые enabled)
    if (noChecked || (indeterminate && isEmptyEnabledBoxes)) {
      setAllChecked();
    } else {
      setAllUnchecked();
    }
  };
  var groupOptions = (0, react_1.useMemo)(
    function () {
      return options.map(function (option) {
        return react_1['default'].createElement(Checkbox_1['default'], {
          id: option.key,
          key: option.key,
          label: option.value,
          size: size,
          variant: variant,
        });
      });
      // eslint-disable-next-line react-hooks/exhaustive-deps
    },
    [options, variant, size]
  );
  var rootClassName = (0, clsx_1['default'])(
    'checkboxGroup',
    'checkboxGroup--'.concat(constants_1.CHECKBOX_VARIANTS[variant]),
    'checkboxGroup--size-'.concat(constants_1.CHECKBOX_SIZES[size]),
    ((_a = {}), (_a['checkboxGroup--with-legend'] = showLegendWithCheckbox), _a),
    className
  );
  return react_1['default'].createElement(
    context_1['default'],
    {
      value: {
        onGroupChange: handleChange,
        groupValue: groupValue,
        groupDisabled: disabledItems,
        disabledAll: disabledAll,
      },
    },
    react_1['default'].createElement(
      'fieldset',
      __assign(
        {
          className: rootClassName,
          style: style,
        },
        restProps
      ),
      showLegendWithCheckbox &&
        react_1['default'].createElement(
          'div',
          {
            className: 'checkboxGroup__title',
          },
          react_1['default'].createElement(Checkbox_1['default'], {
            name: 'parentBox',
            label: title,
            onChange: parentBoxHandler,
            checked: checked,
            indeterminate: indeterminate,
            disabled: disabledAll,
            size: size,
            variant: variant,
          })
        ),
      showLegend &&
        react_1['default'].createElement(
          'div',
          {
            className: 'checkboxGroup__title',
          },
          react_1['default'].createElement(
            'legend',
            {
              className: 'checkboxGroup__legend',
            },
            title
          )
        ),
      react_1['default'].createElement(
        'div',
        {
          className: 'checkboxGroup__container',
        },
        groupOptions
      )
    )
  );
};

CheckboxGroup.propTypes = {
  className: PropTypes.string,
  /**
   * Список выбранных чекбоксов. Массив с ключами
   * @param key - ключ checked чекбокса
   */
  defaultChecked: PropTypes.arrayOf(PropTypes.string),
  /**
   * Disable для всей группы
   */
  disabledAll: PropTypes.bool,
  /**
   * Список disabled чекбоксов
   * @param key - ключ disabled чекбокса
   */
  disabledItems: PropTypes.arrayOf(PropTypes.string),
  /**
   * Callback функция, вызываемая при изменении значения
   */
  onChange: PropTypes.func,
  /**
   * Список чекбоксов. Массив объектов
   * @param key - ключ чекбокса
   * @param value - текст для чекбокса
   */
  options: PropTypes.arrayOf(
    PropTypes.shape({
      key: PropTypes.string.isRequired,
      value: PropTypes.node,
    })
  ).isRequired,
  /**
   * Включает родительский чекбокс для группы
   * @default true
   */
  parentBox: PropTypes.bool,
  /**
   * Задает размер чекбокса
   * @default s
   */
  size: PropTypes.oneOf(['s', 'xs']),
  style: PropTypes.object,
  /**
   * Задает заголовок для группы
   * @default "Выбрать все"
   */
  title: PropTypes.node,
  /**
   * Задает основной цвет для чекбокса
   *  @default primary
   */
  variant: PropTypes.oneOf(['primary']),
};

CheckboxGroup.displayName = 'CheckboxGroup';
exports['default'] = CheckboxGroup;
