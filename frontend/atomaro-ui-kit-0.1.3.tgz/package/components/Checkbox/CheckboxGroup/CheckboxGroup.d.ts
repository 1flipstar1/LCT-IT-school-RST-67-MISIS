import { FC } from 'react';
import '../../../styles/components/checkbox/checkboxGroup.scss';
import { ICheckboxGroup } from './types';
declare const CheckboxGroup: FC<ICheckboxGroup>;
export default CheckboxGroup;
