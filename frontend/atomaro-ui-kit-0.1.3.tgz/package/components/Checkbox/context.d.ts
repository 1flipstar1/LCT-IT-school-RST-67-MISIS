import React from 'react';
export declare const CheckboxGroupContext: React.Context<ICheckboxGroupContext>;
declare const CheckboxGroupContextProvider: React.Provider<ICheckboxGroupContext>;
export default CheckboxGroupContextProvider;
export interface ICheckboxGroupContext {
    onGroupChange?: (id: string) => void;
    groupValue?: Array<string>;
    groupDisabled?: Array<string>;
    disabledAll?: boolean;
}
