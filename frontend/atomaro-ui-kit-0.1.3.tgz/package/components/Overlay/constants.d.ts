export declare enum OVERLAY_VARIANTS {
    primary = "primary",
    secondary = "secondary"
}
export type OverlayVariantType = keyof typeof OVERLAY_VARIANTS;
export declare const DEFAULT_VARIANT = OVERLAY_VARIANTS.primary;
