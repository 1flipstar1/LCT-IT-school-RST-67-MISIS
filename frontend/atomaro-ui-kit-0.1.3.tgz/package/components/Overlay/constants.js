"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.DEFAULT_VARIANT = exports.OVERLAY_VARIANTS = void 0;
var OVERLAY_VARIANTS;
(function (OVERLAY_VARIANTS) {
  OVERLAY_VARIANTS["primary"] = "primary";
  OVERLAY_VARIANTS["secondary"] = "secondary";
})(OVERLAY_VARIANTS = exports.OVERLAY_VARIANTS || (exports.OVERLAY_VARIANTS = {}));
exports.DEFAULT_VARIANT = OVERLAY_VARIANTS.primary;