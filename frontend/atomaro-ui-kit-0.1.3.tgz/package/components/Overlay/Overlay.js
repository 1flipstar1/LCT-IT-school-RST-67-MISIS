'use strict';
var PropTypes = require('prop-types');

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __createBinding =
  (this && this.__createBinding) ||
  (Object.create
    ? function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ('get' in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = {
            enumerable: true,
            get: function get() {
              return m[k];
            },
          };
        }
        Object.defineProperty(o, k2, desc);
      }
    : function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
      });
var __setModuleDefault =
  (this && this.__setModuleDefault) ||
  (Object.create
    ? function (o, v) {
        Object.defineProperty(o, 'default', {
          enumerable: true,
          value: v,
        });
      }
    : function (o, v) {
        o['default'] = v;
      });
var __importStar =
  (this && this.__importStar) ||
  function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null)
      for (var k in mod)
        if (k !== 'default' && Object.prototype.hasOwnProperty.call(mod, k))
          __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
  };
var __rest =
  (this && this.__rest) ||
  function (s, e) {
    var t = {};
    for (var p in s)
      if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === 'function')
      for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
          t[p[i]] = s[p[i]];
      }
    return t;
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = __importStar(require('react'));
var clsx_1 = __importDefault(require('clsx'));
var react_dom_1 = require('react-dom');
var function_1 = require('../../utils/function');
var constants_1 = require('./constants');
require('../../styles/components/overlay.scss');
var overlayRoot = typeof window !== 'undefined' ? document.createElement('div') : null;
var Overlay = (0, react_1.forwardRef)(function Overlay(props, ref) {
  var _a = props.isOpened,
    isOpened = _a === void 0 ? false : _a,
    _b = props.variant,
    variant = _b === void 0 ? constants_1.DEFAULT_VARIANT : _b,
    _c = props.useInPortal,
    useInPortal = _c === void 0 ? true : _c,
    _d = props.onClick,
    onClick = _d === void 0 ? function_1.noop : _d,
    className = props.className,
    restProps = __rest(props, ['isOpened', 'variant', 'useInPortal', 'onClick', 'className']);
  (0, react_1.useEffect)(
    function () {
      if (overlayRoot && isOpened && useInPortal) {
        document.body.appendChild(overlayRoot);
      }
      return function () {
        if (overlayRoot && document.body.contains(overlayRoot)) {
          document.body.removeChild(overlayRoot);
        }
      };
    },
    [isOpened, useInPortal]
  );
  var rootClassName = (0, clsx_1['default'])(
    'overlay',
    'overlay--'.concat(constants_1.OVERLAY_VARIANTS[variant]),
    className
  );
  var overlay = isOpened
    ? react_1['default'].createElement(
        'div',
        __assign(
          {
            className: rootClassName,
            ref: ref,
            onClick: onClick,
          },
          restProps
        )
      )
    : null;
  return useInPortal && overlayRoot ? (0, react_dom_1.createPortal)(overlay, overlayRoot) : overlay;
});

Overlay.propTypes = {
  className: PropTypes.string,
  /**
   * Ярлык видимости компонента
   *  @default false
   */
  isOpened: PropTypes.bool,
  onClick: PropTypes.func,
  /**
   * Задает использование в React.Portal
   *  @default true
   */
  useInPortal: PropTypes.bool,
  /**
   * Задает внешний вид
   *  @default primary
   */
  variant: PropTypes.oneOf(['primary', 'secondary']),
};

Overlay.displayName = 'Overlay';
exports['default'] = Overlay;
