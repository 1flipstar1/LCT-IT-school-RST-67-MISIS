import { FC } from 'react';
import '../../styles/components/overlay.scss';
import { IOverlay } from './types';
declare const Overlay: FC<IOverlay>;
export default Overlay;
