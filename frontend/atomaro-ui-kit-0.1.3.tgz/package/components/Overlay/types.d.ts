import React from 'react';
import { OverlayVariantType } from './constants';
export interface IOverlay extends React.HTMLAttributes<HTMLDivElement> {
    /** Ярлык видимости компонента
     *  @default false
     */
    isOpened?: boolean;
    /** Задает внешний вид
     *  @default primary
     */
    variant?: OverlayVariantType;
    /** Задает использование в React.Portal
     *  @default true */
    useInPortal?: boolean;
}
