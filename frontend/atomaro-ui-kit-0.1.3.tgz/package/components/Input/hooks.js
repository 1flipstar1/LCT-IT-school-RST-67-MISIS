'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.useTransformation = exports.useValidation = exports.useFocus = void 0;
var react_1 = require('react');
var noop_1 = require('../../utils/noop');
var input_1 = require('../../utils/input');
var useFocus = function useFocus(_a) {
  var _b = _a.onBlur,
    onBlur = _b === void 0 ? noop_1.noop : _b,
    _c = _a.onFocus,
    onFocus = _c === void 0 ? noop_1.noop : _c;
  var _d = (0, react_1.useState)(false),
    focused = _d[0],
    setFocused = _d[1];
  var handleFocus = (0, react_1.useCallback)(
    function (event) {
      setFocused(true);
      onFocus(event);
    },
    [onFocus]
  );
  var handleBlur = (0, react_1.useCallback)(
    function (event) {
      setFocused(false);
      onBlur(event);
    },
    [onBlur]
  );
  return {
    focused: focused,
    onFocus: handleFocus,
    onBlur: handleBlur,
  };
};
exports.useFocus = useFocus;
var useValidation = function useValidation(_a) {
  var _b = _a.validationRules,
    validationRules = _b === void 0 ? [] : _b,
    error = _a.error,
    forceError = _a.forceError,
    _c = _a.defaultValidatedStatus,
    defaultValidatedStatus = _c === void 0 ? false : _c;
  var _d = (0, react_1.useState)(undefined),
    validationRule = _d[0],
    setValidationRule = _d[1];
  var _e = (0, react_1.useState)(defaultValidatedStatus),
    validatedStatus = _e[0],
    setValidatedStatus = _e[1];
  var validate = function validate(value) {
    setValidationRule(
      validationRules.find(function (rule) {
        return !rule.validate(value);
      })
    );
  };
  var validateoOnChange = function validateoOnChange(value) {
    if (value === void 0) {
      value = '';
    }
    if (validatedStatus || forceError) {
      validate(value);
    }
  };
  var validateOnBlur = function validateOnBlur(value) {
    if (value === void 0) {
      value = '';
    }
    setValidatedStatus(true);
    validate(value);
  };
  return {
    error: error || (validationRule && validationRule.error),
    validateoOnChange: validateoOnChange,
    validateOnBlur: validateOnBlur,
  };
};
exports.useValidation = useValidation;
var useTransformation = function useTransformation(_a) {
  var _b = _a.transformationRule,
    transformationRule = _b === void 0 ? input_1.defaultTrasformationRule : _b,
    _c = _a.onChange,
    onChange = _c === void 0 ? noop_1.noop : _c,
    _d = _a.setValue,
    setValue = _d === void 0 ? noop_1.noop : _d;
  var transformOnChange = function transformOnChange(event) {
    var input = event.target;
    var selectionStart = input.selectionStart,
      prevValue = input.value;
    var transformedValue = transformationRule.transform(prevValue);
    var newEvent = Object.create(event);
    newEvent.target.value = transformedValue;
    var diff = prevValue.length - transformedValue.length;
    var newCaretPos = selectionStart ? Math.max(0, selectionStart - diff) : 0;
    if (input.setSelectionRange) {
      input.setSelectionRange(newCaretPos, newCaretPos);
    }
    onChange(newEvent);
    setValue(transformedValue);
  };
  var transformOnBlur = function transformOnBlur(value) {
    if (transformationRule.onBlurTransform && value) {
      setValue(transformationRule.onBlurTransform(value));
    }
  };
  return {
    transformOnChange: transformOnChange,
    transformOnBlur: transformOnBlur,
  };
};
exports.useTransformation = useTransformation;
