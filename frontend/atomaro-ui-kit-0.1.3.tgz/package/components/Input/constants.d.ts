export declare enum INPUT_SIZES {
    s = "s",
    m = "m",
    l = "l"
}
export declare enum INPUT_VARIANTS {
    primary = "primary"
}
export type InputSizesType = keyof typeof INPUT_SIZES;
export type InputVariantsType = keyof typeof INPUT_VARIANTS;
