"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.INPUT_VARIANTS = exports.INPUT_SIZES = void 0;
var INPUT_SIZES;
(function (INPUT_SIZES) {
  INPUT_SIZES["s"] = "s";
  INPUT_SIZES["m"] = "m";
  INPUT_SIZES["l"] = "l";
})(INPUT_SIZES = exports.INPUT_SIZES || (exports.INPUT_SIZES = {}));
var INPUT_VARIANTS;
(function (INPUT_VARIANTS) {
  INPUT_VARIANTS["primary"] = "primary";
})(INPUT_VARIANTS = exports.INPUT_VARIANTS || (exports.INPUT_VARIANTS = {}));