import React from 'react';
import { ValidationRule } from '../../types/validation';
import { TransformationRule } from '../../types/transformation';
export declare const useFocus: ({ onBlur, onFocus, }: {
    onBlur?: React.FocusEventHandler;
    onFocus?: React.FocusEventHandler;
}) => {
    focused: boolean;
    onFocus: (event: React.FocusEvent<HTMLInputElement>) => void;
    onBlur: (event: React.FocusEvent<HTMLInputElement>) => void;
};
export declare const useValidation: ({ validationRules, error, forceError, defaultValidatedStatus, }: {
    validationRules?: ValidationRule[];
    error?: string;
    forceError?: boolean;
    defaultValidatedStatus?: boolean;
}) => {
    error: string;
    validateoOnChange: (value?: string) => void;
    validateOnBlur: (value?: string) => void;
};
export declare const useTransformation: ({ transformationRule, onChange, setValue, }: {
    transformationRule?: TransformationRule;
    onChange?: React.FormEventHandler;
    setValue: (value: string) => void;
}) => {
    transformOnChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
    transformOnBlur: (value?: string) => void;
};
