import React, { InputHTMLAttributes, ReactNode } from 'react';
import { TransformationRule } from '../../types/transformation';
import { InputSizesType, InputVariantsType } from './constants';
import { ValidationRule } from '../../types/validation';
export interface IInputProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'onClick' | 'size'> {
    /** Задает основной цвет для компонента
     *  @default primary */
    variant?: InputVariantsType | string;
    /** Задает контент лейбла */
    label?: ReactNode;
    /** Задает контент плейсхолдера */
    placeholder?: string;
    /** Задает размер
     * @default m
     */
    size?: InputSizesType | string;
    /** Задает значение компонента, используется для управляемых компонентов.
     *  Не используется вместе с defaultValue */
    value?: string;
    /** Задает значение по умолчанию, для неуправляемых компонентов.
     *  Не используется вместе с value */
    defaultValue?: string;
    /** Задаёт правила валидации , а также содержит в себе текст ошибки
     * @param error - текстовое значение ошибки валидации
     * @param validate - метод, валидирующий значение value
     * */
    validationRules?: ValidationRule[];
    /** Задаёт правила трансформации
     *
     * @param transform - метод, изменяющий значение при вводе
     * @param onBlurTransform - метод, изменяющий значение при потере фокуса
     */
    transformationRule?: TransformationRule;
    /** Параметр принудительного отображения ошибки */
    forceError?: boolean;
    /** Устанавливает атрибут disabled */
    disabled?: boolean;
    /** Устанавливает атрибут error */
    error?: React.ReactNode;
    /** Устанавливает атрибут hint */
    hint?: React.ReactNode;
    /** Задаёт счетчик */
    counter?: React.ReactNode;
    /**
     * Прячет label, но оставляет поле доступным, добавляет аттрибут aria-label
     * @default false
     */
    hideLabel?: boolean;
    /** Отображает label всегда сверху
     * @default false
     */
    fixedLabel?: boolean;
    /** В значении true, при заполнении поля, появится иконка для удаления данных
     * @default false
     */
    clearable?: boolean;
    /** Добавляет иконку справа от поля ввода */
    iconSuffix?: ReactNode;
    /** Callback функция, вызываемая при клике на иконку */
    onClickIconSuffix?: (e: any) => void;
    /** Добавляет иконку слева от поля ввода */
    iconPrefix?: ReactNode;
    /** Callback функция, вызываемая при клике на иконку */
    onClickIconPrefix?: (e: any) => void;
    /** Callback функция, вызываемая при очищении поля */
    onClear?: React.FormEventHandler;
    /** Callback функция, вызываемая при клике */
    onClick?: (event: React.MouseEvent<HTMLInputElement>) => void;
}
