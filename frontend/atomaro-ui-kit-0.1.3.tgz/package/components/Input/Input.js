'use strict';
var PropTypes = require('prop-types');

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __createBinding =
  (this && this.__createBinding) ||
  (Object.create
    ? function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ('get' in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = {
            enumerable: true,
            get: function get() {
              return m[k];
            },
          };
        }
        Object.defineProperty(o, k2, desc);
      }
    : function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
      });
var __setModuleDefault =
  (this && this.__setModuleDefault) ||
  (Object.create
    ? function (o, v) {
        Object.defineProperty(o, 'default', {
          enumerable: true,
          value: v,
        });
      }
    : function (o, v) {
        o['default'] = v;
      });
var __importStar =
  (this && this.__importStar) ||
  function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null)
      for (var k in mod)
        if (k !== 'default' && Object.prototype.hasOwnProperty.call(mod, k))
          __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
  };
var __rest =
  (this && this.__rest) ||
  function (s, e) {
    var t = {};
    for (var p in s)
      if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === 'function')
      for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
          t[p[i]] = s[p[i]];
      }
    return t;
  };
var __importDefault =
  (this && this.__importDefault) ||
  function (mod) {
    return mod && mod.__esModule
      ? mod
      : {
          default: mod,
        };
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
/* eslint-disable import/no-extraneous-dependencies */
/* eslint-disable jsx-a11y/no-static-element-interactions */
/* eslint-disable jsx-a11y/no-noninteractive-element-interactions */
/* eslint-disable jsx-a11y/click-events-have-key-events */
var react_1 = __importStar(require('react'));
var clsx_1 = __importDefault(require('clsx'));
require('../../styles/components/input.scss');
var navigation_1 = require('@atomaro/icons/24/navigation');
var constants_1 = require('./constants');
var noop_1 = require('../../utils/noop');
var useCombinedRefs_1 = require('../../hooks/useCombinedRefs');
var hooks_1 = require('./hooks');
var input_1 = require('../../utils/input');
var function_1 = require('../../utils/function');
var Input = (0, react_1.forwardRef)(function Input(props, ref) {
  var _a;
  var _b = props.variant,
    variant = _b === void 0 ? constants_1.INPUT_VARIANTS.primary : _b,
    labelProp = props.label,
    _c = props.hideLabel,
    hideLabel = _c === void 0 ? false : _c,
    // fixedLabel = false,
    placeholder = props.placeholder,
    _d = props.disabled,
    disabled = _d === void 0 ? false : _d,
    _e = props.size,
    size = _e === void 0 ? constants_1.INPUT_SIZES.s : _e,
    className = props.className,
    _f = props.onClick,
    onClick = _f === void 0 ? noop_1.noop : _f,
    _g = props.hint,
    hint = _g === void 0 ? false : _g,
    errorProp = props.error,
    forceError = props.forceError,
    inputValue = props.value,
    defaultValue = props.defaultValue,
    _h = props.clearable,
    clearable = _h === void 0 ? false : _h,
    counter = props.counter,
    iconPrefix = props.iconPrefix,
    iconSuffixProp = props.iconSuffix,
    _j = props.onClickIconPrefix,
    onClickIconPrefix = _j === void 0 ? noop_1.noop : _j,
    _k = props.onClickIconSuffix,
    onClickIconSuffix = _k === void 0 ? noop_1.noop : _k,
    _l = props.validationRules,
    validationRules = _l === void 0 ? [] : _l,
    _m = props.transformationRule,
    transformationRule = _m === void 0 ? input_1.defaultTrasformationRule : _m,
    _o = props.onBlur,
    onPropsBlur = _o === void 0 ? noop_1.noop : _o,
    _p = props.onFocus,
    onPropFocus = _p === void 0 ? noop_1.noop : _p,
    _q = props.onChange,
    onChange = _q === void 0 ? noop_1.noop : _q,
    _r = props.onClear,
    onClear = _r === void 0 ? noop_1.noop : _r,
    restProps = __rest(props, [
      'variant',
      'label',
      'hideLabel',
      'placeholder',
      'disabled',
      'size',
      'className',
      'onClick',
      'hint',
      'error',
      'forceError',
      'value',
      'defaultValue',
      'clearable',
      'counter',
      'iconPrefix',
      'iconSuffix',
      'onClickIconPrefix',
      'onClickIconSuffix',
      'validationRules',
      'transformationRule',
      'onBlur',
      'onFocus',
      'onChange',
      'onClear',
    ]);
  var internalRef = (0, react_1.useRef)(null);
  var inputRef = (0, useCombinedRefs_1.useCombinedRefs)(ref, internalRef);
  var label = hideLabel ? null : labelProp;
  var _s = (0, react_1.useState)(transformationRule.transform(defaultValue)),
    value = _s[0],
    setValue = _s[1];
  var _t = (0, hooks_1.useFocus)({
      onBlur: onPropsBlur,
      onFocus: onPropFocus,
    }),
    focused = _t.focused,
    onBlur = _t.onBlur,
    onFocus = _t.onFocus;
  var _u = (0, hooks_1.useValidation)({
      validationRules: validationRules,
      error: errorProp === null || errorProp === void 0 ? void 0 : errorProp.toString(),
      forceError: forceError,
    }),
    error = _u.error,
    validateoOnChange = _u.validateoOnChange,
    validateOnBlur = _u.validateOnBlur;
  var _v = (0, hooks_1.useTransformation)({
      transformationRule: transformationRule,
      onChange: onChange,
      setValue: setValue,
    }),
    transformOnChange = _v.transformOnChange,
    transformOnBlur = _v.transformOnBlur;
  (0, react_1.useEffect)(
    function () {
      var formattedValue = transformationRule.transform(inputValue);
      if (inputValue !== undefined && formattedValue !== value) {
        setValue(formattedValue);
      }
    },
    [value, inputValue, transformationRule]
  );
  var handleChange = function handleChange(event) {
    validateoOnChange(event.target.value);
    transformOnChange(event);
  };
  var handleBlur = function handleBlur(event) {
    validateOnBlur(value);
    transformOnBlur(value);
    onBlur(event);
  };
  var handleClear = function handleClear(e) {
    setValue('');
    (0, input_1.resolveOnChange)(inputRef.current, e, onChange);
    onClear(e);
  };
  var handleClick = function handleClick(e) {
    var _a;
    (_a = inputRef.current) === null || _a === void 0 ? void 0 : _a.focus();
    onClick(e);
  };
  var renderFooter =
    (hint || counter || error) &&
    react_1['default'].createElement(
      'div',
      {
        className: 'input__hint',
      },
      react_1['default'].createElement(
        'div',
        {
          className: 'input__hint-label',
        },
        error || hint
      ),
      counter &&
        react_1['default'].createElement(
          'div',
          {
            className: 'input__hint-counter',
          },
          counter
        )
    );
  var renderIconSuffix = function renderIconSuffix() {
    var _a;
    if (clearable && value && focused && !disabled) {
      var ICON_CLOSE_SIZE_MAP = {
        l: 24,
        m: 24,
        s: 16,
      };
      return react_1['default'].createElement(
        'button',
        {
          type: 'button',
          className: 'input__suffix',
          onClick: handleClear,
          onMouseDown: function_1.preventDefaultFn,
          onTouchStart: function_1.preventDefaultFn,
          'aria-label': 'Clear',
        },
        react_1['default'].createElement(navigation_1.CloseSmall, {
          size: (_a = ICON_CLOSE_SIZE_MAP[size]) !== null && _a !== void 0 ? _a : undefined,
        })
      );
    }
    if (iconSuffixProp) {
      return react_1['default'].createElement(
        'button',
        {
          type: 'button',
          className: 'input__suffix',
          onClick: onClickIconSuffix,
          onMouseDown: function_1.preventDefaultFn,
          onTouchStart: function_1.preventDefaultFn,
          'aria-label': 'Input-right-icon',
        },
        iconSuffixProp
      );
    }
    return null;
  };
  var rootClassName = (0, clsx_1['default'])(
    'input',
    'input--'.concat(constants_1.INPUT_VARIANTS[variant]),
    'input--size-'.concat(constants_1.INPUT_SIZES[size]),
    ((_a = {}),
    (_a['input--has-placeholder'] = !!placeholder),
    (_a['input--has-value'] = !!value),
    (_a['input--has-label'] = !!label),
    (_a['input--hidelabel'] = !!hideLabel),
    (_a['input--with-hint'] = !!(hint || counter || error)),
    (_a['input--only-counter'] = !!counter && !hint && !error),
    (_a['input--error'] = !!error),
    (_a['input--disabled'] = !!disabled),
    (_a['input--icon-suffix'] = !!renderIconSuffix()),
    (_a['input--icon-prefix'] = !!iconPrefix),
    _a),
    className
  );
  return react_1['default'].createElement(
    react_1['default'].Fragment,
    null,
    react_1['default'].createElement(
      'div',
      {
        className: rootClassName,
        onClick: handleClick,
      },
      !!label &&
        react_1['default'].createElement(
          'div',
          {
            className: 'input__label',
          },
          label
        ),
      react_1['default'].createElement(
        'input',
        __assign(
          {
            type: 'text',
            value: value,
            ref: inputRef,
            className: 'input__field',
            placeholder: placeholder,
            disabled: disabled,
            onChange: handleChange,
            onBlur: handleBlur,
            onFocus: onFocus,
            onClick: handleClick,
          },
          restProps
        )
      ),
      iconPrefix &&
        react_1['default'].createElement(
          'div',
          {
            className: 'input__prefix',
            onClick: onClickIconPrefix,
          },
          iconPrefix
        ),
      renderIconSuffix()
    ),
    renderFooter
  );
});

Input.propTypes = {
  className: PropTypes.string,
  /**
   * В значении true, при заполнении поля, появится иконка для удаления данных
   * @default false
   */
  clearable: PropTypes.bool,
  /**
   * Задаёт счетчик
   */
  counter: PropTypes.node,
  /**
   * Задает значение по умолчанию, для неуправляемых компонентов.
   *  Не используется вместе с value
   */
  defaultValue: PropTypes.string,
  /**
   * Устанавливает атрибут disabled
   */
  disabled: PropTypes.bool,
  /**
   * Устанавливает атрибут error
   */
  error: PropTypes.node,
  /**
   * Параметр принудительного отображения ошибки
   */
  forceError: PropTypes.bool,
  /**
   * Прячет label, но оставляет поле доступным, добавляет аттрибут aria-label
   * @default false
   */
  hideLabel: PropTypes.bool,
  /**
   * Устанавливает атрибут hint
   */
  hint: PropTypes.node,
  /**
   * Добавляет иконку слева от поля ввода
   */
  iconPrefix: PropTypes.node,
  /**
   * Добавляет иконку справа от поля ввода
   */
  iconSuffix: PropTypes.node,
  /**
   * Задает контент лейбла
   */
  label: PropTypes.node,
  onBlur: PropTypes.func,
  onChange: PropTypes.func,
  /**
   * Callback функция, вызываемая при очищении поля
   */
  onClear: PropTypes.func,
  /**
   * Callback функция, вызываемая при клике
   */
  onClick: PropTypes.func,
  /**
   * Callback функция, вызываемая при клике на иконку
   */
  onClickIconPrefix: PropTypes.func,
  /**
   * Callback функция, вызываемая при клике на иконку
   */
  onClickIconSuffix: PropTypes.func,
  onFocus: PropTypes.func,
  /**
   * Задает контент плейсхолдера
   */
  placeholder: PropTypes.string,
  /**
   * Задает размер
   * @default m
   */
  size: PropTypes.string,
  /**
   * Задаёт правила трансформации
   *
   * @param transform - метод, изменяющий значение при вводе
   * @param onBlurTransform - метод, изменяющий значение при потере фокуса
   */
  transformationRule: PropTypes.shape({
    onBlurTransform: PropTypes.func,
    transform: PropTypes.func.isRequired,
  }),
  /**
   * Задаёт правила валидации , а также содержит в себе текст ошибки
   * @param error - текстовое значение ошибки валидации
   * @param validate - метод, валидирующий значение value
   */
  validationRules: PropTypes.arrayOf(
    PropTypes.shape({
      error: PropTypes.string,
      validate: PropTypes.func.isRequired,
    })
  ),
  /**
   * Задает значение компонента, используется для управляемых компонентов.
   *  Не используется вместе с defaultValue
   */
  value: PropTypes.string,
  /**
   * Задает основной цвет для компонента
   *  @default primary
   */
  variant: PropTypes.string,
};

Input.displayName = 'Input';
exports['default'] = Input;
