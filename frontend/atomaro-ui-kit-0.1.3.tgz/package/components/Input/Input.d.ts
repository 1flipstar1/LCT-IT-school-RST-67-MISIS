import React from 'react';
import '../../styles/components/input.scss';
import { IInputProps } from './types';
declare const Input: React.ForwardRefExoticComponent<IInputProps & React.RefAttributes<HTMLInputElement>>;
export default Input;
