export declare const useThemeContext: () => {
    themeName: "dark" | "light";
    themeConfig?: import("../types/theme").ITheme;
};
