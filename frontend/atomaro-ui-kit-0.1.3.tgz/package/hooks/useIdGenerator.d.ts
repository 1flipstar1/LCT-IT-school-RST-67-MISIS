export declare const useIdGenerator: (maxId?: number) => {
    generateNewId: () => number;
};
