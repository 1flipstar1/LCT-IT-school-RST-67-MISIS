'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.useFocus = void 0;
var react_1 = require('react');
var function_1 = require('../utils/function');
var useFocus = function useFocus(_a) {
  var _b = _a.onBlur,
    onBlur = _b === void 0 ? function_1.noop : _b,
    _c = _a.onFocus,
    onFocus = _c === void 0 ? function_1.noop : _c;
  var _d = (0, react_1.useState)(false),
    focused = _d[0],
    setFocused = _d[1];
  var handleFocus = (0, react_1.useCallback)(
    function (event) {
      setFocused(true);
      onFocus(event);
    },
    [onFocus]
  );
  var handleBlur = (0, react_1.useCallback)(
    function (event) {
      setFocused(false);
      onBlur(event);
    },
    [onBlur]
  );
  return {
    focused: focused,
    onFocus: handleFocus,
    onBlur: handleBlur,
  };
};
exports.useFocus = useFocus;
