'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.useIdGenerator = void 0;
var react_1 = require('react');
var useIdGenerator = function useIdGenerator(maxId) {
  var _a = (0, react_1.useState)(0),
    id = _a[0],
    setId = _a[1];
  (0, react_1.useEffect)(
    function () {
      if (maxId && id > maxId) {
        setId(0);
      }
    },
    [id, maxId]
  );
  var generateNewId = (0, react_1.useCallback)(
    function () {
      var newId = id + 1;
      setId(newId);
      return newId;
    },
    [id]
  );
  return {
    generateNewId: generateNewId,
  };
};
exports.useIdGenerator = useIdGenerator;
