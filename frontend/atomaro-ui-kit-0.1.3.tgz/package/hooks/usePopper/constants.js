"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.PLACEMENTS_MAP = exports.PLACEMENTS = void 0;
var PLACEMENTS;
(function (PLACEMENTS) {
  PLACEMENTS["auto"] = "auto";
  PLACEMENTS["top"] = "top";
  PLACEMENTS["bottom"] = "bottom";
  PLACEMENTS["right"] = "right";
  PLACEMENTS["left"] = "left";
  PLACEMENTS["topLeft"] = "topLeft";
  PLACEMENTS["topRight"] = "topRight";
  PLACEMENTS["bottomLeft"] = "bottomLeft";
  PLACEMENTS["bottomRight"] = "bottomRight";
  PLACEMENTS["leftTop"] = "leftTop";
  PLACEMENTS["leftBottom"] = "leftBottom";
  PLACEMENTS["rightTop"] = "rightTop";
  PLACEMENTS["rightBottom"] = "rightBottom";
})(PLACEMENTS = exports.PLACEMENTS || (exports.PLACEMENTS = {}));
var PLACEMENTS_MAP;
(function (PLACEMENTS_MAP) {
  PLACEMENTS_MAP["auto"] = "auto";
  PLACEMENTS_MAP["top"] = "top";
  PLACEMENTS_MAP["topRight"] = "top-end";
  PLACEMENTS_MAP["topLeft"] = "top-start";
  PLACEMENTS_MAP["bottom"] = "bottom";
  PLACEMENTS_MAP["bottomRight"] = "bottom-end";
  PLACEMENTS_MAP["bottomLeft"] = "bottom-start";
  PLACEMENTS_MAP["left"] = "left";
  PLACEMENTS_MAP["leftBottom"] = "left-end";
  PLACEMENTS_MAP["leftTop"] = "left-start";
  PLACEMENTS_MAP["right"] = "right";
  PLACEMENTS_MAP["rightBottom"] = "right-end";
  PLACEMENTS_MAP["rightTop"] = "right-start";
})(PLACEMENTS_MAP = exports.PLACEMENTS_MAP || (exports.PLACEMENTS_MAP = {}));