'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.matchWidth = void 0;
exports.matchWidth = {
  name: 'matchWidth',
  enabled: true,
  phase: 'beforeWrite',
  requires: ['computeStyles'],
  fn: function fn(_a) {
    var state = _a.state;
    state.styles.popper.width = ''.concat(state.rects.reference.width, 'px');
  },
  effect: function effect(_a) {
    var state = _a.state;
    return function () {
      var reference = state.elements.reference;
      state.elements.popper.style.width = ''.concat(reference.offsetWidth, 'px');
    };
  },
};
