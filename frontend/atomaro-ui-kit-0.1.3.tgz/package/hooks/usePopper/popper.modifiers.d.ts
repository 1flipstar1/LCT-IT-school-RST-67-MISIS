import { Modifier } from '@popperjs/core';
export declare const matchWidth: Modifier<'matchWidth', any>;
