'use strict';

var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };
var __createBinding =
  (this && this.__createBinding) ||
  (Object.create
    ? function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ('get' in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = {
            enumerable: true,
            get: function get() {
              return m[k];
            },
          };
        }
        Object.defineProperty(o, k2, desc);
      }
    : function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
      });
var __setModuleDefault =
  (this && this.__setModuleDefault) ||
  (Object.create
    ? function (o, v) {
        Object.defineProperty(o, 'default', {
          enumerable: true,
          value: v,
        });
      }
    : function (o, v) {
        o['default'] = v;
      });
var __importStar =
  (this && this.__importStar) ||
  function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null)
      for (var k in mod)
        if (k !== 'default' && Object.prototype.hasOwnProperty.call(mod, k))
          __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
  };
var __spreadArray =
  (this && this.__spreadArray) ||
  function (to, from, pack) {
    if (pack || arguments.length === 2)
      for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
          if (!ar) ar = Array.prototype.slice.call(from, 0, i);
          ar[i] = from[i];
        }
      }
    return to.concat(ar || Array.prototype.slice.call(from));
  };
Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.usePopper = void 0;
/* eslint-disable react-hooks/exhaustive-deps */
var react_1 = require('react');
var core_1 = require('@popperjs/core');
var customModifiers = __importStar(require('./popper.modifiers'));
var constants_1 = require('./constants');
var usePopper = function usePopper(props) {
  var _a = props.enabled,
    enabled = _a === void 0 ? false : _a,
    _b = props.offset,
    _offset = _b === void 0 ? 11 : _b,
    _c = props.offsetCounterAxis,
    offsetCounterAxis = _c === void 0 ? 0 : _c,
    _d = props.arrowPadding,
    arrowPadding = _d === void 0 ? 0 : _d,
    _e = props.flip,
    flip = _e === void 0 ? true : _e,
    _f = props.widthFitContent,
    widthFitContent = _f === void 0 ? false : _f,
    _g = props.preventOverflow,
    preventOverflow = _g === void 0 ? true : _g,
    _h = props.boundary,
    boundary = _h === void 0 ? 'clippingParents' : _h,
    _j = props.placement,
    placement = _j === void 0 ? 'auto' : _j,
    _k = props.eventListeners,
    eventListeners = _k === void 0 ? false : _k,
    _l = props.pointerIsCentered,
    pointerIsCentered = _l === void 0 ? false : _l,
    trigger = props.trigger,
    popper = props.popper,
    modifiers = props.modifiers;
  var instance = (0, react_1.useRef)(null);
  var cleanup = (0, react_1.useRef)(function () {});
  var setupPopper = (0, react_1.useCallback)(
    function () {
      var _a;
      if (!enabled || !trigger || !popper) {
        return;
      }
      (_a = cleanup.current) === null || _a === void 0 ? void 0 : _a.call(cleanup);
      instance.current = (0, core_1.createPopper)(trigger, popper, {
        placement: constants_1.PLACEMENTS_MAP[placement],
        modifiers: __spreadArray(
          [
            {
              name: 'offset',
              options: {
                offset: function offset(_a) {
                  var reference = _a.reference,
                    pos = _a.placement;
                  if (!pointerIsCentered) {
                    if (pos.includes('top') || pos.includes('bottom')) {
                      if (pos.includes('start')) {
                        return [-reference.width / 2 - offsetCounterAxis, _offset];
                      }
                      if (pos.includes('end')) {
                        return [reference.width / 2 + offsetCounterAxis, _offset];
                      }
                    }
                    if (pos.includes('left') || pos.includes('right')) {
                      if (pos.includes('start')) {
                        return [-reference.height / 2 - offsetCounterAxis, _offset];
                      }
                      if (pos.includes('end')) {
                        return [reference.height / 2 + offsetCounterAxis, _offset];
                      }
                    }
                  }
                  if (pos.includes('start')) {
                    return [offsetCounterAxis, _offset];
                  }
                  if (pos.includes('end')) {
                    return [-offsetCounterAxis, _offset];
                  }
                  return [0, _offset];
                },
              },
            },
            {
              name: 'arrow',
              options: {
                padding: function padding(_a) {
                  var pos = _a.placement;
                  if (pos.includes('start') || pos.includes('end')) {
                    return arrowPadding;
                  }
                  return 0;
                },
              },
            },
            {
              name: 'eventListeners',
              enabled: !!eventListeners,
              options: {
                scroll: true,
                resize: true,
              },
            },
            {
              name: 'flip',
              enabled: !!flip,
            },
            {
              name: 'preventOverflow',
              enabled: !!preventOverflow,
              options: {
                boundary: boundary,
              },
            },
            __assign(__assign({}, customModifiers.matchWidth), {
              enabled: !!widthFitContent,
            }),
          ],
          modifiers !== null && modifiers !== void 0 ? modifiers : [],
          true
        ),
      });
      instance.current.forceUpdate();
      cleanup.current = instance.current.destroy;
    },
    [
      enabled,
      trigger,
      popper,
      placement,
      eventListeners,
      flip,
      preventOverflow,
      boundary,
      widthFitContent,
      modifiers,
      _offset,
      offsetCounterAxis,
    ]
  );
  setupPopper();
  (0, react_1.useEffect)(function () {
    return function () {
      var _a;
      if (!trigger && !popper) {
        (_a = instance.current) === null || _a === void 0 ? void 0 : _a.destroy();
        instance.current = null;
      }
    };
  }, []);
  var getArrowProps = (0, react_1.useCallback)(function (ref) {
    if (ref === void 0) {
      ref = null;
    }
    return {
      ref: ref,
      'data-popper-arrow': '',
    };
  }, []);
  var getArrowInnerProps = (0, react_1.useCallback)(function (ref) {
    if (ref === void 0) {
      ref = null;
    }
    return {
      ref: ref,
      'data-popper-arrow-inner': '',
    };
  }, []);
  return {
    update: function update() {
      var _a;
      (_a = instance.current) === null || _a === void 0 ? void 0 : _a.update();
    },
    forceUpdate: function forceUpdate() {
      var _a;
      (_a = instance.current) === null || _a === void 0 ? void 0 : _a.forceUpdate();
    },
    getArrowProps: getArrowProps,
    getArrowInnerProps: getArrowInnerProps,
  };
};
exports.usePopper = usePopper;
