import { UsePopperProps } from './types';
export declare const usePopper: (props: UsePopperProps) => {
    update(): void;
    forceUpdate(): void;
    getArrowProps: (ref?: any) => {
        ref: any;
        'data-popper-arrow': string;
    };
    getArrowInnerProps: (ref?: any) => {
        ref: any;
        'data-popper-arrow-inner': string;
    };
};
