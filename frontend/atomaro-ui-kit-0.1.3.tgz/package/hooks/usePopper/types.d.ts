import { Modifier, VirtualElement } from '@popperjs/core';
import { PLACEMENTS } from './constants';
export type PlacementsType = keyof typeof PLACEMENTS;
export interface UsePopperProps {
    /** Включает popper.js для позиционирования
     *  @default "true" */
    enabled?: boolean;
    /** Задаёт смещение поппера относительно родительского компонента по основной оси
     *  @default 11 */
    offset?: number;
    /** Задаёт смещение поппера относительно родительского компонента по поперченой оси (не применяется при placement up, down, right, left)
     *  @default 0 */
    offsetCounterAxis?: number;
    /** Задаёт отступ для поинтера (стрелки) от края поппера (не применяется при placement up, down, right, left)
     *  @default 0 */
    arrowPadding?: number;
    /** Центририровать pointer на родительский компонент
     *  @default "false" */
    pointerIsCentered?: boolean;
    /** При включении, тултип будет менять своё положение на противоположное при нехватке места для отображения
     *  @default "true" */
    flip?: boolean;
    /** При включении, тултип будет соответствовать ширине родительского компонента
     *  @default "false" */
    widthFitContent?: boolean;
    /** При включении, тултип будет смещаться, чтобы оставаться в зоне видимости
     *  @default "true" */
    preventOverflow?: boolean;
    /** Задаёт область для preventOverflow
     *  @default 'clippingParents' */
    boundary?: 'clippingParents' | 'scrollParent' | HTMLElement;
    /** При включении, тултип будет обновлять позицию при scroll, resize
     *  @default "false" */
    eventListeners?: boolean;
    /** Задает расположение
     *  @default "auto" */
    placement?: PlacementsType;
    /** Задаёт модификаторы Popper.js */
    modifiers?: Array<Partial<Modifier<string, any>>>;
    trigger?: Element | VirtualElement | null;
    popper?: HTMLElement | null;
}
