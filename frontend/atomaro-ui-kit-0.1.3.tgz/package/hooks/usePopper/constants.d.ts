export declare enum PLACEMENTS {
    auto = "auto",
    top = "top",
    bottom = "bottom",
    right = "right",
    left = "left",
    topLeft = "topLeft",
    topRight = "topRight",
    bottomLeft = "bottomLeft",
    bottomRight = "bottomRight",
    leftTop = "leftTop",
    leftBottom = "leftBottom",
    rightTop = "rightTop",
    rightBottom = "rightBottom"
}
export declare enum PLACEMENTS_MAP {
    auto = "auto",
    top = "top",
    topRight = "top-end",
    topLeft = "top-start",
    bottom = "bottom",
    bottomRight = "bottom-end",
    bottomLeft = "bottom-start",
    left = "left",
    leftBottom = "left-end",
    leftTop = "left-start",
    right = "right",
    rightBottom = "right-end",
    rightTop = "right-start"
}
