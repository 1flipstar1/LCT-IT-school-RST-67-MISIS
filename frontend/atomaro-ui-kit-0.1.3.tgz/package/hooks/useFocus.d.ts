import { FocusEvent, FocusEventHandler } from 'react';
export declare const useFocus: ({ onBlur, onFocus, }: {
    onBlur?: FocusEventHandler;
    onFocus?: FocusEventHandler;
}) => {
    focused: boolean;
    onFocus: (event: FocusEvent<HTMLInputElement>) => void;
    onBlur: (event: FocusEvent<HTMLInputElement>) => void;
};
