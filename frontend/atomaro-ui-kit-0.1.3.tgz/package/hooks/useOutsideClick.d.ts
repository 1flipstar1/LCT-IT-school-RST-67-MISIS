declare const useOutsideClick: (ref: any, callback: any) => void;
export default useOutsideClick;
