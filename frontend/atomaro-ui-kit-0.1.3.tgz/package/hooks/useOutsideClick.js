'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true,
});
var react_1 = require('react');
var useOutsideClick = function useOutsideClick(ref, callback) {
  var handleClick = function handleClick(e) {
    if (ref.current && !ref.current.contains(e.target)) {
      callback(e.target);
    }
  };
  (0, react_1.useEffect)(function () {
    if (typeof window !== 'undefined') {
      document.addEventListener('click', handleClick);
    }
    return function () {
      if (typeof window !== 'undefined') {
        document.removeEventListener('click', handleClick);
      }
    };
  });
};
exports['default'] = useOutsideClick;
