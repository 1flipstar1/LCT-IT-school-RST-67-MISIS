'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true,
});
exports.useThemeContext = void 0;
var react_1 = require('react');
var ThemeContext_1 = require('../components/wrappers/ThemeProvider/ThemeContext');
var useThemeContext = function useThemeContext() {
  return (0, react_1.useContext)(ThemeContext_1.ThemeContext);
};
exports.useThemeContext = useThemeContext;
