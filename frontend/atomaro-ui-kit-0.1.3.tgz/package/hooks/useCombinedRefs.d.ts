import { MutableRefObject } from 'react';
type RefType<T> = ((instance: T | null) => void) | MutableRefObject<T | null> | null;
export declare const useCombinedRefs: <T>(...refs: RefType<T>[]) => MutableRefObject<T>;
export {};
